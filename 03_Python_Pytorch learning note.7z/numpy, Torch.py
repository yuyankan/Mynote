"""
torch将产生的tensor放入GPU中加速运算，numpy将array放入CPU中加速运算
"""
"""开局首先一句话
import numpy as np
import torch
"""
"""一、numpy在深度学习中的经典用法
1、生成numpy数组
直接转换np.array(list1）
random模块生成np.random.random([3,3])
创建特定形状np.zeros([3,3])
arange/linspace模块生成np.arange(1,4,0.5)，只有一个数字的话为1-数字
****************************************************************************************************************
2、获取元素
与python中类似，直接nd11[3:6]
random.choice函数可以从指定样本中随机抽取数据
**************************************************************************************************
3、Numpy的数学运算
对应相乘：A*B/np.numtiply(a,b)
点乘运算：np.dot()
"""
"""4、数组变形
4.1、更改数组形状
>>> reshape改变向量的维度（不改变向量本身）
   (1.)import numpy as np
   (2.) arr = np.arange(6).reshape(2,-1)

>>> resize改变向量的维度（修改向量本身）np.arange(6).resize(2,-1)
>>> T转置 np.arrange(12).reshape(3,4).T
>>> revel展平

  (1.)import numpy as np
  (2.) arr = np.arange(6).reshape(2,-1)
  (3.) print(arr)
  (4.) print(arr.ravel('F'))#按列优先展平
  (5.) print(arr.ravel())#按行优先展平
  
>>> flatten 将矩阵转成向量，卷积与全连接层之间进行
  (1.) a = np.floor(10*np.random.random((3,4)))
  (2.) print(a)
  (3.) print(a.flatten())
  
>>> squeeze压缩掉含1的维度arr.squeeze().shape
>>> transposearr2 = np.arange(24).reshape(2,3,4).transpose(1,2,0)

4.2、合并数组
>>> append在后面添加np.append(a,b,axis=0)0为行合并，1为列合并
>>> concatenate沿指定轴连接数组或者矩阵np.concatenate((a,b),axis=0)
>>> stack沿指定轴堆叠数组或矩阵np.stack((a,b),axis=0)
"""

"""5、批量处理
   (1.) import numpy as np

   (2.) data_train = np.random.randn(10000,2,3)
   (3.) print(data_train.shape)
   (4.) np.random.shuffle(data_train)
   (5.) batch_size = 100
   (6.) for i in range(0,len(data_train),batch_size):
   (7.)     x_batch_sum = np.sum(data_train[i:i+batch_size])
   (8.)     print("第{}批次，该批次数据的和：{}".format(i,x_batch_sum))

"""

"""6、通用函数
两种基本对象：ndarry和ufunc对象
>>> math与numpy：numpy.sin比math.sin快近10倍
>>>循环与向量：向量要比循环快的多
"""
"""7、广播机制
   (1.)import numpy as np
   (2.)A = np.arange(0,40,10).reshape(4,1)
   (3.)B = np.arange(0,3)
   (4.)C = A + B
   (5.)print(C)
"""
import numpy as np
print("\n----numpy broadcasting-------")
A = np.arange(0,40,10).reshape(4,1)
print("A:\n", A)
B = np.arange(0,3)
print("B:\n",B)
C = A + B
print("C:\n", C)

print("*"*50)
data_train = np.random.randn(10000,2,3)
print(data_train.shape)
print(data_train[0])
print(len(data_train))
