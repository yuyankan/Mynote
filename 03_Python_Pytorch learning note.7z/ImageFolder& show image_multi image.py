# ===image show example===============================

# =======step 1/2 : load data,using ImageFolder & dataset ======
from torchvision import transforms as T
import torchvision as tv
import torch.utils.data.dataloader as DataLoader
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
transforms = T.Compose(
    [
        T.ToTensor()
    ]
)

dataset = tv.datasets.ImageFolder('./01_Image', transform=transforms)  # image transfer to To tensor, then ImageFolder；
# transfer to tensor for image show: 使用ToPILImage函数时要注意，Pytorch显示一个Tensor类型的图片数据；
print(dataset.classes)
print(dataset.class_to_idx)
print(dataset.imgs)

# 返回的dataset都有以下三种属性：
# self.classes：用一个 list 保存类别名称
# self.class_to_idx：类别对应的索引，与不做任何转换返回的 target 对应
# self.imgs：保存(img-path, class) tuple的 list

# print(dataset.classes)  #根据分的文件夹的名字来确定的类别
# print(dataset.class_to_idx) #按顺序为这些类别定义索引为0,1...
# print(dataset.imgs) #返回从所有文件夹中得到的图片的路径以及其类别
# '''
# 输出：
# ['cat', 'dog']
# {'cat': 0, 'dog': 1}
# [('./data/train\\cat\\1.jpg', 0),
# ('./data/train\\cat\\2.jpg', 0),
#  ('./data/train\\dog\\1.jpg', 1),
# ('./data/train\\dog\\2.jpg', 1)]


# ===step 2/2:  show image==================================

batch_size = int(np.array(8))

data_loader = DataLoader.DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0)

for i, item in enumerate(data_loader):

    print('Batch: ', i) # i is the batch number index

    img_tensor, label = item # data: 4 dimensons: Batch size, CHW
    for i in range(1):
        # show image : method1: Image.show data need to transfer to image type by : transform.ToPILImage()(data):
        # note: data need to be 2/3 dimensional.could not take 4 dimesion data print(data[i].shape)  #  data[i] shape

        # CHW:  each example data in batch i.
        img_pil = T.ToPILImage()(img_tensor[i]) # transform.ToPILImage() only take 2/3 dimension tensor;
        print(img_pil.size)  # use 'image.size' to check dimension (HW), others numpy and tensor, use 'shape' for dimension.
        img_pil.show() # show all images automatically in sequence.

        # show image: method2: plit.imshow(ndarray)
        img_numpy = img_tensor[i].numpy()  # tensor to numpy: dimension: CHW--->still CHW
        img_numpy = np.transpose(img_numpy, (1, 2, 0))  # transpose dimension from CHW to HWC
        print(img_numpy.shape)
        plt.imshow(img_numpy)
        plt.show()  # different show method: next image only showed when manually close current image showed.

