"""
Empty class1: Defined by pass:
1. could define a name and other attributes for an object of this class:
2.  could not define a function for an instance of Empty class
"""
class A():
    pass

print(A.__dict__)
a1 = A()
a1.name = 'Hi'
print(a1.__dict__)
#a1.gree() = 'pass' # could not define a function for an instance of Empty class


"""2. 假如有一个这样的类，没有数据成员和操作（除了本身默认存在的构造函数、复制构造函数、析构函数、copy assignment函数），那么，它能做什么
它不希望通过构造函数生成，也不希望别的对象对它赋值。很不巧，如果我们没有在类中声明复制构造函数或者赋值操作符，那么编译器会为我们默认生成。
那么如何防止这样的事情发生呢？
将复制构造函数和赋值操作符声明为私有:
"""

class Someclass():
    private:
    Someclass(const Someclass&);
    someclass & operator = (const Someclass&)
