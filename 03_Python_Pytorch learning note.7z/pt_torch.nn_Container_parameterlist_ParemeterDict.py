
# summary:
"""

1. ParameterLlist:
    ->1.1: __setitem__: called when 给ParameterList 实例赋值时， e.g:a = nn.ParameterList, a[2] = xxx-->call ParameterList __setitem__
    ->1.2: __setattr__: 给类/类实例创建 非Parameter 的attr时， 'self.xx= value (not Parameter)' will call setattr.
2. ParameterLDict:
    ->1.1: __setitem__: called when 给ParameterDict 实例赋值时， e.g:a = nn.ParameterList, a[2] = value-->call ParameterList __setitem__
    ->1.2: __setattr__: 给类/类实例创建 非Parameter 的attr时， 'self.xx= value (not Parameter)' will call setattr.


Summary:
1. ParameterList: --> is container for parameters
   ->1.1 add modules in order to it's own Dict: self(nn.ParameterList)._parameters:
                                                    name is parameter idx in ''parameters: Optional[Iterable['Parameter']]''
           ->1.1.1: def __init__(self, parameters: Optional[Iterable['Parameter']] = None) -> None:
                    self += parameters
            ->1.1.2: def __iadd__() -->
            ->1.1.3: def extend() -->
            ->1.1.4: self(nn.ParameterList).register_parameter (str(idx), parameter)

   ->1.2: method: __getitem__, __setitem__, __delitem__, __len__, __dir__, __iter__: is dealing with nn.Sequntial, by
        directly deal with it's Dict: self._parameters.


2. ParameterDict:
    ->2.1 dd modules in order to it's own Dict: module name + value
            ->2.1.1: self.__init__ ->
            ->2.1.2: self.update (): self[key] = parameter-->
                ->2.1.3: self.__setitem__() -->
                >2.1.4: self(nn.ParameterList).register_parameter (str(idx), parameter)

    ->2.2: method: __getitem__, __setitem__, __delitem__, __len__, __dir__, __iter__: is dealing with nn.ModuleDict, by
            directly deal with it's Dict: self._parameters.
    ->2.3 have redefined more method: def keys(), items(), values(), update..

"""


import operator
import warnings

from torch.nn import Module
from typing import Any, overload, Union, TypeVar, Iterator,Optional, Iterable, Mapping,Tuple
from collections import OrderedDict
from itertools import islice
from torch._jit_internal import _copy_to_script_wrapper
from collections import abc as container_abcs
# summary:
""" torch.nn.parameter.Parameter
A kind of Tensor that is to be considered a module parameter.

Parameters are Tensor subclasses, that have a very special property when used with Module s - when they’re assigned as 
Module attributes they are automatically added to the list of its parameters, and will appear e.g. in parameters() iterator. 
Assigning a Tensor doesn’t have such effect. This is because one might want to cache some temporary state, like last 
hidden state of the RNN, in the model. If there was no such class as Parameter, these temporaries would get registered too.
"""


#1 Parameter 参数类源码
"""
此部分参考《pytorch源码阅读系列之Parameter类》，《通俗的讲解Python中的__new__()方法》

因为Parameter继承于torch.Tensor，没有新的变量和添加函数，只是对一些辅助函数进行了定义

Parameter作为Module类的参数，可以自动的添加到Module类的参数列表中，并且可以使用Module.parameters()提供的迭代器获取到，所以这个类是一切网络结构数据的核心。
"""
import torch
from collections import OrderedDict
from torch import utils
from torch.nn import Parameter

class Parameter_t(Parameter):
    r"""1. A kind of Tensor that is to be considered a module parameter.

    2. Parameters are: class: '~torch.Tensor' subclasses, that have a very special property when used with:class：
        ’Module's -when they are assigned as Module attributes they are automatically added to the list of its parameters,
        and will appear e.g: in :meth: '~Module.parameters' iterator.
            2.1 assigning a Tensor doesn't have such effect. This is because one might want to cache some temporary state,
                like last hidden state of the RNN, in the model. If there was no such class as: class:'Parameter',
                these temporaries would get registered too.

    3. Args:
        data(Tensor): parameter tensor
        requires_grad(bool, optional)L if the parameter requires gradient. See:ref: 'locally-disable-grad-doc' for
                more details. Default: 'True'
    """
    # 这个方法比__init__方法更先执行，这里就理解为一种初始化方法
    # 详细参考《通俗的讲解Python中的__new__()方法》
    def __new__(cls, data=None, requires_grad=True):
        print("\n1.__new__ is called")
        if data is None:
            data = torch.Tensor([])
        return torch.Tensor._make_subclass(cls, data, requires_grad)

    # attr of only Class 'Parameter' could add auto. to self._parameters dict.
    def __init__(self, data):
        print('\n2.__init is called')
        super(Parameter_t, self).__init__()
    #-->make subclass of 'Parameter'

    # 为了方便实用deepcopy方法，对当前数据进行深拷贝，正常的copy方法只拷贝一层，
    # 简单的来说list的list，最好用深拷贝。
    def __deepcopy__(self, memo): #: self: __new__返回的实例
        print("\n2.__deepcopy__ is called")
        if id(self) in memo:
            return memo[id(self)]
        else:
            result = type(self)(self.data.clone(memory_format=torch.preserve_format), self.requires_grad)
            memo[id(self)] = result
            return result

        # 一种可视化方法，给print使用
    def __repr__(self):
        print("\n3. __repr__ is called")
        return "Parameter containing:\n" + super(Parameter_t, self).__repr__()

    # 用于替代reduce方法
    def __reduce_ex__(self, proto):
        print("4. __reduce_ex__ is called")
        return(torch.utils._requires_grad, (self.data, self.requires_grad, OrderedDict()))

in_feature = 2
out_feature = 5

e1 = Parameter_t(torch.Tensor(out_feature, in_feature))
print(e1)

print("*"*50)
import torch.nn as nn
class E(Module):
    def __init__(self,fun):
        super(E, self).__init__()
        self.l = nn.Linear(1, 1)
        self.p = fun(torch.Tensor(5, 2)) # fun -Parameer function self defined, will not add self.p auto. to Module named_parameter list.
        self.p1 = nn.Parameter(torch.Tensor(5, 2)) # nn.Parameter could


e2 = E(Parameter_t)
for param in e2.named_parameters():
    print("\n")
    print(param)

print("\n")
print("*"*50)
print("\n")

print(type(e2.p))
print(isinstance(e2.p, Parameter))
print(type(e2.p1))




""" 
    __reduce__(self)
    当定义扩展类型时（也就是使用Python的C语言API实现的类型），如果你想pickle它们，你必须告诉Python如何pickle它们。 __reduce__
    被定义之后，
    当对象被Pickle时就会被调用。它要么返回一个代表全局名称的字符串，Pyhton会查找它并pickle，要么返回一个元组。这个元组包含2到5个元素，其中包括：
    一个可调用的对象，用于重建对象时调用；一个参数元素，供那个可调用对象使用；被传递给
    __setstate__
    的状态（可选）；一个产生被pickle的列表元素的迭代器
    （可选）；一个产生被pickle的字典元素的迭代器（可选）；

    __reduce_ex__(self)
    __reduce_ex__
    的存在是为了兼容性。如果它被定义，在pickle时
    __reduce_ex__
    会代替
    __reduce__
    被调用。 __reduce__
    也可以被定义，用于不支持
    __reduce_ex__
    的旧版pickle的API调用。

"""

"""**************************************************************************************************************"""


# deepcopy, while do not use memo in def clone()
"""
def clone(data):
    if isinstance(data,list):
        tmp_data = []
        for x in data:
            xt = clone(x)
            tmp_data.append(xt)
    elif isinstance(data,tuple):
        tmp_data = []
        for x in data:
            xt = clone(x)
            tmp_data.append(xt)
    elif isinstance(data,dict):
        tmp_data = {}
        for k,v in data.items():
            xt = clone(v)
            tmp_data[k] = xt
    elif isinstance(data,set):
        tmp_data = set()
        for x in data:
            xt = clone(x)
            tmp_data.add(xt)
    else:
        tmp_data = data
    return tmp_data
"""

T = TypeVar('T', bound=Module)

class ParameterList(Module):
    r"""Holds parameters in a list.

    :class: '~torch.nn.ParameterList' can be indexed like a regular python list,
    but paramters it contains are properly registered and will be visible by all:
    class: '~torch.nn.Module' methods.

    Args:
        parameters(iterable, optional): an iterable of : class: '~torch.nn.Parameter' to add

    Example::
            class MyModule(nn.Module):
            def __init__(self):
                super(MyModule, self).__init__()
                self.params = nn.ParameterList([nn.Parameter(torch.randn(10, 10)) for i in range(10)])

            def forward(self, x):
                # ParameterList can act as an iterable, or be indexed using ints
                for i, p in enumerate(self.params):
                    x = self.params[i // 2].mm(x) + p.mm(x)
                return x
    """

    def __init__(self, parameters: Optional[Iterable['Parameter']]=None) -> None:
        super(ParameterList, self).__init__()
        self._initialized = True
        if parameters is not None:
            self += parameters

    def __setstate__(self, state):
        state['_initialized'] = False
        super(ParameterList, self).__setstate__(state)#  self.__dict__.update(state)
        self._initialized = True

    def _get_abs_string_index(self, idx):
        """Get the absolute index for the list of modules"""
        idx = operator.index(idx)
        if not (-len(self) <= idx <= len(self)):
            raise IndexError("index {} is out of range".format(idx))
        if idx < 0:
            idx += len(self)
        return str(idx)

    @overload
    def __getitem__(self, index: int) -> 'Parameter':
        ...

    @overload # ?? Modlue?
    def __getitem__(self: T, index: slice) -> T:
        ...

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            return self.__class__(list(self._parameters.values())[idx])
        else:
            idx = self._get_abs_string_index(idx)
            return self._parameters[str(idx)]

    def __setitem__(self, idx:int, param: 'Parameter') -> None:
        idx = self._get_abs_string_index(idx)
        return self.register_parameters(str(idx), param)

    #??? when will call __setattr__
    def __setattr__(self, key:Any, value:Any) ->None:
        if getattr(self, '_initialized', False):
            if not hasattr(self, key) and not isinstance(value, torch.nn.Parameter):
                warnings.warn('Setting attributes on ParameterList is not supported')
        super(ParameterList, self).__setattr__(key, value)

    def __len__(self) -> int:
        return len(self._parameters)

    def __iter__(self) -> Iterator['Parameter']:
        return iter(self._parameters.values())

    def __dir__(self):
        keys = super(ParameterList, self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return keys

    def append(self, parameter: 'Pamaeter')-> 'ParameterList':
        """Appends a given parameter at the end of the list.

        Args:
            parameter(nn.Paramter): parameter to append
        """
        self.register_parameter(str(len(self)), parameter)
        return self

    def __iadd__(self, parameters:Iterable['Parameter']) -> 'ParameterList':
        return self.extend(parameters)

    def extend(self, parameters: Iterable['Paremter']) -> 'ParameterList':
        """Appends parameters from a Python iterable to the end of the list.
        Args:
            parameters(iterable): iterable of parameters to append
        """
        if not isinstance(parameters, container_abcs.Iterable):
            raise TypeError("ParameterList.extend should be called with an iterable, "
                            "but got" + type(parameters).__name__)

        offset = len(self)
        for i, param in enumerate(parameters):
            self.register_parameter(str(offset+i), param)
        return self

    def extra_repr(self) -> str:
        child_lines = []
        for k, p in self._parameters.items():
            size_str = 'x'.join(str(size) for size in p.size()) # 'parameter size: (3, 4)-->size_str = 3 x 4'
            device_str = '' if not p.is_cuda else '(GPU {})'.format(p.get_device())
            parastr = 'Parameter containing: [{} of size {} {} ]'.format(
                torch.typename(p), size_str, device_str )
            child_lines.append(' (' + str(k) +'): ' + parastr)
        tmpstr = '\n'.join(child_lines)
        return tmpstr

    def __call__(self, input):
        raise RuntimeError("ParameterList should not be called.")

    def _replicate_for_data_parallel(self):
        warnings.warn('nn.ParameterList is being used with DataParallel but this is not supported.'
                      'This list will appear empty for the models replicated on each GPU except the original one.')
        return super(ParameterList, self)._replicate_for_data_parallel

"""nn.Module: method
def _replicate_for_data_parallel(self):
        replica = self.__new__(type(self))
        replica.__dict__ = self.__dict__.copy()

        # replicas do not have parameters themselves, the replicas reference the original
        # module.
        replica._parameters = OrderedDict()
        replica._buffers = replica._buffers.copy()
        replica._modules = replica._modules.copy()
        replica._is_replica = True

        return replica
"""

class ParameterDict(Module):
    r"""1. Holds parameters in a dictionary.
    2.ParameterDict can be indexed like a regular Python dictionary,  but parameters it contains are properly registered,
        and will be visible by all Module methods.
    3.: class: '~torch.nn.ParameterDict' is an **ordered** dictionary, that respects :
        3.1: * the order of insertion , and
        3.2: * in: meth：’~torch.nn.ParameterDict.update', the order of the merged 'OrderedDict' or another: class:
            '~torch.nn.ParameterDict' (the argument to : meth: '~torch.nn.ParameterDict.update')
    4. Note that: meth: '~torch.nn.ParameterDict.update' with other unordered mapping types (e.g., Pythons's plain 'dict')
            does not preserve the order of the merged mapping.
    Args:
        parameters (iterable, optional): a mapping (dictionary) of (string:: class: '~torch.nn.Parameter') or,
                an iterable of key-value pairs of type (string, : class: '~torch.nn.Parameter')
    Example:
        class MyModule(nn.Module):
            def __init__(self):
                super(MyModule, self).__init__()
                self.params = nn.ParameterDict({
                        'left': nn.Parameter(torch.randn(5, 10)),
                        'right': nn.Parameter(torch.randn(5, 10))
                })

            def forward(self, x, choice):
                x = self.params[choice].mm(x)
                return x
    """
    def __init__(self, parameters: Optional[Mapping[str, 'Parameter']] = None) ->None:
        super(ParameterDict, self).__init__()
        self._initialized = True
        if parameters is not None:
            self.update(parameters)

    def __setstate__(self, state):
        state['_initialized'] = False
        super(ParameterDict, self).__setstate__(state)
        self._initialized = True

    def __getitem__(self, key: str) ->Parameter_t:
        return self._paramers[key]

    def __setitem__(self, key: str, value: 'Parameter') -> None:
        self.register_parameter(key, value)

    def __delitem__(self, key: str) ->None:
        del self._parameters[key]

    def __setattr__(self, key: Any, value: Any) ->None:
        if getattr(self, '_initialized', False):
            if not hasattr(self, key) and not isinstance(value, torch.nn.Parameter):
                warnings.warn("Setting attributes on ParameterDict is not supported")
            super(ParameterDict, self).__setattr__(key, value)

    def __len__(self) -> int:
        return len(self._parameters)

    def __iter__(self) ->Iterator:
        return iter(self._parameters.keys())

    def __contains__(self, key: str) -> bool:
        return key in self._parameters

    def clear(self) ->None:
        """Remove all items from the ParameterDict"""
        self._parameters.clear()

    def pop(self, key: str) -> 'Parameter': # ??not pop the last element in Dict???
        """Remove key from the ParameterDict and return its parameter
        Args:
            key(string): key to pop from the ParameterDict
        """
        v = self[key]
        del self[key]
        return v

    def keys(self) ->Iterable[str]:
        r"""Return an iterable of the parameterDict keys"""
        return self._parameters.keys()

    def items(self) ->Iterable[Tuple[str, 'Parameter']]:
        r"""Return an iterable of the parameterDict key/value pairs"""
        return self._parameters.items()

    def values(self) ->Iterable['Parameter']:
        r"""Return an iterable of the ParameterDict values"""
        return self._parameters.values()

    def update(self, parameters: Mapping[str, 'Parameter']) ->None:
        r""" Update the : class: '~torch.nn.ParameterDict' with the key-value pairs from a mapping or an iterable,
                overwriting existing keys.
        ..note::
            If: attr: 'parameters' is an ''OrderedDict'', a: class: '~torch.nn.ParameterDict', or an iterable
                of key-value pairs, the order of new elements in it is preserved.
        Args:
            parameters(iterable): a mapping (dictionary) from string to : class: '~torch.nn.Parameter',
                    or an iterable of key-value pairs of type (string, : class: '~torch.nn.Parameter')
        """
        if not isinstance(parameters, container_abcs.Iterable):
            raise TypeError ("ParameterDict.update should be called with an iterable of key/value paris,"
                             "bug got" + type(parameters).__name__)

        if isinstance(parameters, (OrderedDict, ParameterDict)):
            for key, parameter in parameters.items():
                self[key] = parameter
        else:
            for j, p in enumerate(parameters):
                if not isinstance(p, container_abcs.Iterable): # Iterable: list, tuple, dict are Iterable
                    raise TypeError("ParameterDict update sequence element"
                                    "#" + str(j) + "should be Iterable; is " + type(p).__name__)
                if not len(p) == 2:
                    raise ValueError("ParameterDict update sequence element # " + str(j) + 'has length'
                                     + str(len(p)) + '; 2 is required')
                # parameters as length-2 list too cumberson to type, see ModuleDict.update comment
                self[p[0]] = p[1]

    def extra_repr(self) ->str:
        child_lines = []
        for k, p in self._parameters.items():
            size_str = 'x'.join(str(size) for size in p.size())
            device_str = '' if not p.is_cuda else '(GPU {})'.format(p.get_device())
            parastr = 'Parameter containing: [{} of size {} {}]'.format(
                torch.dtypename(p), size_str, device_str)
            child_lines.append(' (' + k + '): ' + parastr)
            tmpstr = '\n'.join(child_lines)
            return tmpstr

    def __call__(self, input):
        raise RuntimeError('ParameterDict should not be called.')

    def _replicate_for_data_parallel(self):
        warnings.warn('nn.ParameterDict is being used with DataParallel but this is not supported.'
                      'This dict will appear empty for the modules replicated on each GPU except the original one.')
        return super(ParameterDict, self)._replicate_for_data_parallel()



