d = {'a':1, 'b':2, 'c':3}

print("\ndic d =: ",d)
"""1. 遍历字典 Key"""
print("1.遍历字典 Key: for key in d, print(key): ")
for key in d: # or: d.keys()
    print(key)

"""2. check if there is a key in dic"""
print("\n2. check if there is a ‘key’ in dic:")
print("2.1: a in d :", 'a' in d)
print("2.2: d in d:", 'd' in d)

print("\n3. Go through dic :")
print("3.1: go through key and value: for key,value in d.items(), print(key, value):")
for key, value in d.items():
    print(key, value)