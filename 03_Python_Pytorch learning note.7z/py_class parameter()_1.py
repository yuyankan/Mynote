"""************************************************************************************************************"""
# 1. 对于pytorch的各种操作类型来说，其weight和bias都是采用Parameter进行定义的，比如Linear的初始化函数【1】：
"""

def __init__(self, in_features, out_features, bias=True):
    super(Linear, self).__init__()
    self.in_features = in_features
    self.out_features = out_features
    self.weight = Parameter(torch.Tensor(out_features, in_features))
    if bias:
        self.bias = Parameter(torch.Tensor(out_features))
    else:
        self.register_parameter('bias', None)
    self.reset_parameters()
"""

# 选择Parameter类实例作为weight和bias的存储方式，涉及到Module类中的很多函数，
#
# 同时定义网络时可能还需要采用Parameter对象作为Module实例属性，此时就涉及到了参数的注册问题。
#
# 下文首先分析在Module类实例中使用Parameter产生的行为，然后从源码角度分析这一行为。
"""************************************************************************************************************"""
# 2、Parameter类作用
"""首先看一下Parameter类的注释【2】：
class Parameter(torch.Tensor):
 r""A kind of Tensor that is to be considered a module parameter.
 Parameters are : class: ~torch.Tensor、subclass, that have a very special prperty when used with with : class:/Modules-
 when they are assigned as Module attributes they are automatically added to the list of its parameters, and will appear
 e.g. in : meth:、~Module.parameters、iterator.
 Assigning a Tensor doesn't have such effect. this is because one might want to cache some temporary state, like last hidden statue 
 of the RNN, in the model. 
 
 If there was no such class as: class: 、Parameter, these temporaries would get registered too.
 
 arguments:
 data(Tensor): parameter tensor
 required_grad(bool, optional): if the parameter requires gradient. See:
 : ref:、excluding-subgraphs、for more details. Default:、True、
""
"""
"""--------------------------------------------------------------------------------------------------------------"""
#2.1 注释的核心含义为：Parameter作为Module类的参数，可以自动的添加到Module类的参数列表中，并且可以使用Module.parameters()提供的迭代器获取到。
# 在分析Parameter的实现代码之前，首先自定义一个Net，用于验证Net实例属性为Parameter对象时Net会自动将次Parameter对象注册到参数列表中：
import torch.nn as nn
import torch
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer = nn.Linear(1, 1) # nn.Linear: weights, bias = nn.Parameter(xxx)
        #print("self.__dict__['_parameters']:\n", self.__dict__["_parameters"])# self._parameters
        print("self._parameters:\n", self._parameters)  # self._parameters
        print("-" * 50)
        print("self.layers._parameters:\n", self.layer._parameters)
        #print("-" * 50)
        #print("\nself.layer.__dict__['_parameters']:\n", self.layer.__dict__["_parameters"])
        self.fun_param = nn.Parameter(torch.FloatTensor([1,]))# Parameter 实例化: self.fun_param(.parameters)
        print("-" * 50)
        print("\nself.__dict__['_parameters']:", self.__dict__["_parameters"])
print("\n")
print("1"*50)
net = Net()
print("\n")
print("2"*50)
for param in net.named_parameters(): #
    # note: self._parameters: Dict of 实例本身的参数， 不包括sub_model 的参数
    # method: named_parameter()/parameter(): yield name + parameter: of all module & submodule.
    print("\n")
    print(param)
    print("*"*50)
print("3"*50)
print("4"*50)
print("net.__dict__['_parameters']:\n", net.__dict__['_parameters']) # only have func_param, as weights and bias is in the __dict__ of object self.layer
print("5"*50)
print("net.layer.__dict__['_parameters']:\n", net.layer.__dict__['_parameters'])
print("\n")
print("6"*50)
#print(net.__dict__["named_parameters()"])

#下面得到的结果显示出，self.layer的Linear的weight和bias是Parameter对象，因为Linear是继承自Module类的。
# 同时，自己注册的fun_param也是Parameter对象，同样能够通过net的named_parameters()方法获取：
"""
('fun_param', Parameter containing:
tensor([1.], requires_grad=True))
**************************************************
('layer.weight', Parameter containing:
tensor([[-0.7233]], requires_grad=True))
**************************************************
('layer.bias', Parameter containing:
tensor([0.6442], requires_grad=True)
"""
# 上面已经验证了Module类实例的属性为Parameter对象时，可以“自动的”注册到Module实例的参数列表中
"""************************************************************************************************************"""
# 3. 下面来分析Parameter类的__new__()方法：
"""
def __new_(cls, data=None, requires_grad=True):
    if data is None:
        data = torch.Tensor()
    return torch.Tensor._make_subclass(cls, data, requires_grad) 
"""
#根据前面已知Parameter类是继承自torch.Tensor类的，但是阅读源码后发现Tensor.py中也没有__init__()函数，可能是定义在其它的文件中。
# __new__()采用“cls”作为参数表明这是一个类方法，返回的对象为Parameter实例，包含了Tensor类的全部方法，功能同样非常强大。
"""************************************************************************************************************"""

# 4.下面来分析Parameter是如何注册到Module类中的: 、Parameter在Module中的参数注册
#Parameter的注册在Module类中的__setattr__()函数【3】中，也就是说pytorch采用“类实例属性赋值时进行注册”的方式实现对Parameter的注册：
def __setattr__(self, name, value):
    # （1）从目标字典中删除重复名字为name的属性
    def remove_from(*dicts):
        for d in dicts:
            if name in d:
                del d[name]
    #  （2）获取属性管理字典中的所有Parameter
    params = self.__dict__.get("_parameters")
    #（3）通过value类型来确定name是否注册到_parameters中
    if isinstance(value, params):
        if params is None:
            raise AttributeError("can not assign parameters before Module.__init__() call")
        remove_from(self._dict__, self._buffers, self._modules)
        # （4）负责parameter注册的函数
        self.register_parameter(name, value)

#此函数涉及的内容较多，所以根据上述代码中的需要单独进行分析：
"""--------------------------------------------------------------------------------------------------------------"""
# 4.1:
# (1) 首先定义的内部函数remove_from()用于删除已经存在的“name”，应该是用于重复定义某个属性名的情况（比如已经定义了一次self.layer，
# 然后第二次出现“layer”这个name时就需要删除之前已经定义过的layer

"""--------------------------------------------------------------------------------------------------------------"""
# 4.2:
# (2) 实例采用self表示，所以__dict__维护着实例的全部属性（属性定义时通过__setattr__注册到__dict__中），
# get()方法中的_parameters参数就是实例的一个属性，这个属性在Module类的初始化函数中定义：
import torch
from collections import OrderedDict
def __init__(self):
    """
    Initializes internal Module state, shared by both nn.Module and ScripModule.
    """
    torch.C._log_api_usage_once("python.nn_module")
    self.training = True
    self._parameters = OrderedDict()
    # # 省略下面代码

"""--------------------------------------------------------------------------------------------------------------"""
# 4.3
# (3):通过isinstance()函数判断value是否为Parameter类型（因为name只是引用名字，没有任何含义，要通过值来确定类型），
# 如果为真还需要保证Module的__init__（）函数已经被调用（因为自己定义的类是继承自Module的，也就说Module作为父类，其__init__()函数必须首先被调用）。

"""--------------------------------------------------------------------------------------------------------------"""
#4.4 self的register_parameter()函数两个参数分别为name和value，其对应的源码如下：
def register_parameter(self, name, param):
    r"""
    Adds a parameter to the module.
    The parameter can be accessed as an attribute using given name.
    args:
    name(string): name of the parameter. The parameter can be accessed from this module using the given name
    param(Parameter): parameter to be added to the module.

    """
    if "_parameters" not in self._dict__:
        raise AttributeError("can not assign parameters before Module.__init__() call")
    # 省略其它类型检查
    else:
        self._parameter[name] = param
#这里负责完成Parameter对象在Module中的注册，注册到Module对象的_parameters属性中。

"""--------------------------------------------------------------------------------------------------------------"""
# 4.5 实际上，在__setattr__（）函数中省略了最后一行的代码：
""" 实际上，在__setattr__（）函数中省略了最后一行的代码：
else:
object._setattr__(self, name, value)
"""
#这个代码就是排除Parameter和Module以及buffer类型后，对用户定义的其它所有类型尤其是Module中_parameters、_buffer、_modules这些Order_dict
# 进行注册，注册使用的是父类object的__setattr__()方法，也就是将这些都加入到__dict__中。

