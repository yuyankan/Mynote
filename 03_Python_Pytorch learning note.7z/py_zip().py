
#python中zip()函数的用法

"""
zip函数的原型为：zip([iterable, …])

参数iterable为可迭代的对象，并且可以有多个参数。该函数返回一个以元组为元素的列表，其中第 i 个元组包含每个参数序列的第 i 个元素。
返回的列表长度被截断为最短的参数序列的长度。只有一个序列参数时，它返回一个1元组的列表。没有参数时，它返回一个空的列表。
"""

"""

import numpy as np
a=[1,2,3,4,5]
b=(1,2,3,4,5)
c=np.arange(5)
d="zhang"
zz=zip(a,b,c,d)
print(zz)

输出：
[(1, 1, 0, 'z'), (2, 2, 1, 'h'), (3, 3, 2, 'a'), (4, 4, 3, 'n'), (5, 5, 4, 'g')]
"""
# 当没有参数的时候
"""
import numpy as np
zz=zip()
print(zz)

输出：[]

当只有一个参数的时候

import numpy as np
a=[1,2,3]
zz=zip(a)
print(zz)

输出：[(1,), (2,), (3,)]
"""

#当多个参数长度不同的时候
"""
import numpy as np
a=[1,2,3]
b=[1,2,3,4]
c=[1,2,3,4,5]
zz=zip(a,b,c)
print(zz)

输出：[(1, 1, 1), (2, 2, 2), (3, 3, 3)]

"""

#zip() 和 * 操作符一起操作可以用来 unzip 一个列表，看下面的代码：

"""
import numpy as np
a=[1,2,3]
b=[4,5,6]
c=[7,8,9]
zz=zip(a,b,c)
print(zz)

x,y,z=zip(*zz)
print(x)
print(y)
print(z)

输出：
[(1, 4, 7), (2, 5, 8), (3, 6, 9)]
(1, 2, 3)
(4, 5, 6)
(7, 8, 9)
"""

# 注意这里输出的每个都是元组，而不一定是原来的类型，但是值不会发生变化（除非原来的参数列表长度不一样，看下面的代码）

"""
import numpy as np
a=[1,2,3]
b=[4,5,6,7]
c=[8,9,10,11,12]
zz=zip(a,b,c)
print(zz)

x,y,z=zip(*zz)
print(x)
print(y)
print(z)

输出：
[(1, 4, 8), (2, 5, 9), (3, 6, 10)]
(1, 2, 3)
(4, 5, 6)
(8, 9, 10)

unzip后的列表b和c的值都少了。

"""