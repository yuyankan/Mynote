"""
handle_torch_function(public_api: Callable, relevant_args: Iterable[Any], *args, **kwargs) -> Any
        Implement a function with checks for ``__torch_function__`` overrides.

        See torch::autograd::handle_torch_function for the equivalent of this
        function in the C++ implementation.

        Arguments
        ---------
        public_api : function
            Function exposed by the public torch API originally called like
            ``public_api(*args, **kwargs)`` on which arguments are now being
            checked.
        relevant_args : iterable
            Iterable of arguments to check for __torch_function__ methods.
        args : tuple
            Arbitrary positional arguments originally passed into ``public_api``.
        kwargs : tuple
            Arbitrary keyword arguments originally passed into ``public_api``.

        Returns
        -------
        object
            Result from calling ``implementation`` or an ``__torch_function__``
            method, as appropriate.

        Raises
        ------
        TypeError : if no implementation is found.

        Example
        -------
        #>>> def func(a):
        ...     if type(a) is not torch.Tensor:  # This will make func dispatchable by __torch_function__
        ...         return handle_torch_function(func, (a,), a)
        ...     return a + 0
"""
import torch
from torch.overrides import handle_torch_function
from torch.overrides import has_torch_function
def func(a):

    def __torch_function__():
        print('__torch__function is called')

    if any(type(x) is not torch.Tensor for x in a): #and has_torch_function(t):
        print("hi")
        return handle_torch_function(func, a, a)

    return a

b = torch.Tensor(2,3)
a = (1,2, 3) # list a do not implement _torch_function__
y = func(a)
print(y)

