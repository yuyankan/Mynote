
# 属性的优先访问级别总结:
# 1. 如果没有设置“描述符属性”：
"""
没有设置描述符属性，则属性的优先访问顺序和我们前面文章里面所讲的是一样的，即

（1） __getattribute__()， 无条件调用，任何时候都先调用!!!!
（2）实例属性
（3）类属性
（4）父类属性
（5） __getattr__() 方法  #如果所有的属性都没有搜索到，则才会调用该函数!!!!
"""
class E1:
    a = 3;
    print("test")
    print(a)
    print("\n")
    print("*"*50)
    def __init__(self, a):
        print("__init__ is called")
        self.a = 4
    a =8
print('1'*50)
p1 = E1(6)
print('2'*50)
print(p1.a)

# 2. 如果设置了“描述符属性”
#注意：因为描述符属性本身就是定义在类里面的，也可以当成是类属性，但是它并不是一般的类属性，请记住一句话：
#一旦一个属性被标记为“描述符属性”，那它的性质再也不会变，与它同名的变量不管是放在类还是类实例，都是描述符属性：不对啊 。。
 #-->如果是类属性， 会被同名人类属性覆盖， 不会被同名的类实例属性覆盖。。

#（1): 先比较实例属性和描述符属性


#人的性格描述，悲观的？开朗的？敏感的？多疑的？活泼的？等
class CharacterDescriptor():
    def __init__(self, value):
        print("1.CharacterDescriptor:  __init__ is called")
        self.value = value

    def __get__(self, instance, owner): # note: self in this class means: class 实例-defined actually by __new__
        print("2. CharacterDescriptor:get: visit CharacterDescriptor of owner's instance") # owner: class  that use this decriptor
        return self.value

    def __set__(self, instance, value):
        print('3. CharacterDescriptor: setting character value')
        self.value = value


# 人的体重描述，超重？过重？肥胖？微胖？合适？偏轻？太瘦？等等
class WeightDescriptor:
    def __init__(self, value):
        print("2.1.weightDescriptor: __init__ is called")
        self.value = value

    def __get__(self, instance, owner):
        print("2.2.weightDescriptor: Visit Weight")
        return self.value

    def __set__(self, instance, value):
        print("2.3.weightDescriptor: setting weight")
        self.value = value

"""*******************************************************************************************************"""
print("\n")
print("*"*50)
print("2"*50)
class Person:
    a2 = CharacterDescriptor("optimistic") # a2 is descriptor
    def __init__(self):
        print("1. Class Person , case __init__ is called")
        self.a2 = 'passive' # self.a2 = a2, also a descriptor

    def __getattribute__(self, key): # will only call when call class case parameter or method
        print("2. Class Person: getattribute is called")
        return super(Person, self).__getattribute__(key)

    def __getattr__(self, key):
        print("3.getattr__ is calaled, no this parameter")
print("3"*50)
p2 = Person()
print("4"*50)
print(p2.a2)  # RUN RESULT:
"""
P1 = Person():
1. Class Person , case __init__ is called
3. CharacterDescriptor: setting character value
# setting character value：这是由p1=Person()得到的，因为他会告诉你这是再给一个“描述符变量赋值，赋值为“悲观的”，所以调用了__set__”

p2.a2:
2. Class Person: getattribute is called
2. CharacterDescriptor:get: visit CharacterDescriptor of owner's instance
"""
# __getattribute__总是优先访问，而且访问的由于是“描述符变量”，故而访问的时候调用__get__

# （2）类属性与描述符属性

print("\n")
print("*"*50)
print("*"*50)
print("6"*50)
class Person2:
    #a2 = 'Passive'
    a2 = CharacterDescriptor("optimistic")  # a2 is descriptor
    print(a2)
    a2 = 'Passive'# 此处赋值， 覆盖描述符， a2 不再是描述符???
    #a2 = CharacterDescriptor("optimistic")
    print(a2)

    def __init__(self):
        print("1. Class Person , case __init__ is called")


    def __getattribute__(self, key):  # will only call when call class case parameter or method
        print("2. Class Person: getattribute is called")
        return super(Person2, self).__getattribute__(key)

    def __getattr__(self, key):
        print("3.getattr__ is calaled, no this parameter")

print("7"*50)
p3 = Person2()
print("8"*50)
print(p3.a2)# a2被覆盖： a2 ='passive', Not a descritptor any more.

"""
但是，这并不意味着类属性a2，就比描述符属性a2的优先级更高，仅仅是因为后面重新对a2进行复制，改变了a2的性质，不再是数据描述符，如果我交换两个a2的顺序，得到的结果为如下：

__getattribute__
访问性格属性
乐观的

因为此时，a2作为数据描述符存在。
"""
# 3、疑惑不解
"""
我搜集了很多博文，看到很多博主得到了如下结论，导致我自己也没有得出一个确切的定论，所以希望再次与广大网友讨论，下面的两个结论都是从博客上摘录下来的。

（1）类属性 > 数据描述符 > 实例属性 > 非数据描述符 > 找不到的属性触发__getattr__()

这样的说法显然不严谨，因为类属性不总是优先于实例属性的

（2） __getattribute__()> 数据描述符> 实例对象的字典（若与描述符对象同名，会被覆盖哦）>类的字典>非数据描述符

>父类的字典>__getattr__() 方法

这样的说法也不严谨，因为从我上面的调试来看，当数据描述符属性与实力属性同名的时候，最终显示的值是实例属性的值，但是并不是实例属性覆盖了描述符属性，恰好相反，此时，实例属性也是当做描述属性那样去用的，而且调用了__get__和__set__方法。

总结：个人认为“描述符”的作用有其特殊性，它的目的并不是改变属性访问的优先级，根本目的只是改变属性的控制方式，方便对属性进行更好的访问、修改和删除，所以没必要死记硬背一个固定的优先级，在具体的问题中根据代码的运行能够做出合理的判断即可。当然如果哪一位小伙伴有更加权威的排序，也可以私下里告诉我哦，解答我心中的疑惑，将万分感谢！
"""

"""************************************************************************************************************"""
# 四、描述符的应用场景
"""
描述符的本质在于“描述”二字，最大的用处是对属性的个性定制与控制，如前所说，
（1）可以在设置属性时，做些检测等方面的处理   
（2）设置属性不能被删除？那定义_delete_方法，并raise 异常。 
（3）还可以设置只读属性 
（4）把一个描述符作为某个对象的属性。这个属性要更改，比如增加判断，或变得更复杂的时候，所有的处理只要在描述符中操作就行了。 
 这一系列其实都是为了更好地去控制一个属性。

但是描述符因为它非常灵活的语法，可以实现一些非常高级的python特性，描述符是可以实现大部分python类特性中的底层魔法,包括@classmethod,
@staticmethd,@property甚至是__slots__属性，不仅如此，描述父是很多高级库和框架的重要工具之一,描述符通常是使用到装饰器或者元类的大型框架中的一个组件。
"""