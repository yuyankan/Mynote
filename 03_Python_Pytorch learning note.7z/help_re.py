
"""
Python中re模块主要包含以下几种方法：
**

re.compile:：编译一个正则表达式模式（pattern）
re.match:：从头开始匹配，使用group（）方法可以获取第一个匹配值
re.search ：用包含方式匹配，使用group（）方法可以获取第一个匹配值
re.findadll：用包含方式匹配，把所有匹配到的字符放到以列表中的元素返回多个返回值
re.sub：匹配字符并替换
re.split：以匹配到的字符当做列表分隔符，返回列表
"""

#Python正则表达式符号的意义
"""
模式	描述
^	匹配字符串的开头
$	匹配字符串的末尾。
.	匹配任意字符，除了换行符。
[…]	用来表示一组字符,单独列出：[amk] 匹配 ‘a’，‘m’或’k’
[^…]	不在[]中的字符：[^abc] 匹配除了a,b,c之外的字符。
*	匹配0个或多个的表达式。
+	匹配1个或多个的表达式。
?	匹配0个或1个由前面的正则表达式定义的片段，非贪婪方式
{ n}	精确匹配 n 个前面表达式。例如， o{2} 能匹配 “food” 中的两个 o。
{ n,}	匹配 n 个前面表达式。例如， o{2,} 能匹配 "foooood"中的所有 o。“o{1,}” 等价于 “o+”。“o{0,}” 则等价于 “o*”。
{ n, m}	匹配 n 到 m 次由前面的正则表达式定义的片段，贪婪方式
a	b
()	匹配括号内的表达式，也表示一个组
我们.号匹配所有字符。除此以外我们还可以使用以下字符匹配字母，空白符或数字。如\d代表一位整数，\d+代表一位或多位整数，\d{4}代表四位整数，如年份。

\w	匹配字母数字及下划线
\W	匹配非字母数字及下划线
\s	匹配任意空白字符，等价于 [\t\n\r\f].
\S	匹配任意非空字符
\d	匹配任意数字，等价于 [0-9].
\D	匹配任意非数字
\A	匹配字符串开始
\Z	匹配字符串结束，如果是存在换行，只匹配到换行前的结束字符串。
\z	匹配字符串结束
re.compile方法
compile函数用于编译正则表达式，生成一个正则表达式（Pattern）对象，供 **match（）**和 **search（）**这两个函数使用。
"""

def compile(pattern, flags=0):
    "Compile a regular expression pattern, returning a Pattern object."
    #return _compile(pattern, flags)
"""
参数：
pattern：一个字符串形式的正则表达式
flags：可选，表示匹配的模式，模式如下
re.I：忽略大小写
re.L：表特殊字符集 \w, \W, \b, \B, \s, \S 依赖于当前环境
re.M：多行模式

re.match和re.search方法
re.match和re.search方法类似，唯一不同就是re.match从头开始匹配，re.search可以从字符串的任意位置匹配。如果有匹配对象match返回，可以使用match.group()提取匹配字符。
"""
def match1(pattern, string, flags=0):
    """Try to apply the pattern at the start of the string, returning
    a Match object, or None if no match was found."""
    #return _compile(pattern, flags).match(string)

def search1(pattern, string, flags=0):
    """Scan through string looking for a match to the pattern, returning
    a Match object, or None if no match was found."""
    #return _compile(pattern, flags).search(string)

#简单示例：

import re

year_pattern = re.compile(r'\d{2}')
string1 = '我爱1998和1999年'
match1 = re.match(year_pattern, string1)        
print('match1:',match1)

match2 = re.search(year_pattern, string1)
print('match2',match2)
print('match2.group():',match2.group())              # group方法获取第一个值

#注意：group方法是从编号1开始的
"""
re.match 和 re.search 方每次最多返回一个匹配对象
re.match 方法是从头开始匹配的，如果从头开始就没有匹配的则返回None
re.search 方法是从字符串的任意位置开始搜索匹配的，一旦找到第一个匹配对象就停止工作，如果要所有匹配的字符串，则使用re.findall方法。

**

re.findall方法
从一个字符中提取所有符合正则表达式的字符串列表时需要使用re.findall方法，findall方法提供了两种方式

pattern.findall(string)
re.findall(pattern,string)
1
2
简单示例：pattern.findall(string)

import re
string = '我爱1998年和1999年'
string_pattern = re.compile(r'\d{4}')
res = string_pattern.findall(string)
print(res)  # 以列表的形式返回
1
2
3
4
5
简单示例：re.findall(pattern, string)

import requests
import re
response = requests.get('https://www.baidu.com')
urls = re.findall(r'<a.*>(.*)</a>', response.text)
for url in urls:
    print(url.encode('utf-8'))
1
2
3
4
5
6"""

#re.sub方法
"""字符串的替换，使用这个方法可以实现空格与无关字符的替换"""

def sub(pattern, repl, string, count=0, flags=0):
    return _compile(pattern, flags).sub(repl, string, count)

#简单示例：



string_pattern = re.compile(r'\d{4}')
string = '我爱1998和1999年'
replace_str = re.sub(string_pattern, '****', string)
print('replace_str:',replace_str)
"""
re.split方法
re.split方法是返回分割后的字符串

def split(pattern, string, maxsplit=0, flags=0):
	return _compile(pattern, flags).split(string, maxsplit)
1
2
简单示例

import re

string = '1cat2dog3pig4'
res = re.split(r'\d+', string)
print(res)

"""