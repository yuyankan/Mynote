
# Python2中的raw_input() 与 input
#不过python3里的input() 和python2里的raw_input()一致: 直接读取控制台的输入（任何类型的输入它都可以接收）， 将所有输入作为字符串看待，返回字符串类型。

"""
1. 这两个均是 python2 的内建函数，通过读取控制台的输入与用户实现交互。但他们的功能不尽相同。举两个小例子。
这两个函数均能接收 字符串 ，但 raw_input() 直接读取控制台的输入（任何类型的输入它都可以接收）。而对于 input() ，它希望能够读取一个合法的 python
 表达式，即你输入字符串的时候必须使用引号将它括起来，否则它会引发一个 SyntaxError 。

 raw_input() 将所有输入作为字符串看待，返回字符串类型。而 input() 在对待纯数字输入时具有自己的特性，它返回所输入的数字的类型（ int, float ）；
 input() 可接受合法的 python 表达式，举例：input( 1 + 3 ) 会返回 int 型的 4 。
"""

# input() 本质上还是使用 raw_input() 来实现的
"""
查看 Built-in Functions ，得知：

input([prompt])
    Equivalent to eval((raw_input(prompt)))
"""
#input() 本质上还是使用 raw_input() 来实现的，只是调用完 raw_input() 之后再调用 eval() 函数，所以，你甚至可以将表达式作为 input() 的参数，并且它会计算表达式的值并返回它。

#不过在 Built-in Functions 里有一句话是这样写的：Consider using the raw_input() function for general input from users.

#除非对 input() 有特别需要，否则一般情况下我们都是推荐使用 raw_input() 来与用户交互。

""" 不过python3里的input() 和python2里的raw_input()一致"""
a = input("input: ")
print(a)
print(type(a))
print(int(a))
print(type(int(a)))