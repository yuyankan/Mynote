from pt_nn_Module_init_1 import *
import torch.nn as nn
import torch
from typing import TypeVar, Tuple, Iterator, Set, Union, Optional, overload
import warnings
from torch import device, dtype

T = TypeVar('T', bound='Module')
class Module2(Module_s):
    def __init__(self):
        super(Module2, self).__init__()

    def _apply(self, fn):
        for module in self.children():
            module._apply(fn)

        def compute_should_use_set_data(tensor, tensor_applied):
            if torch._has_compatible_shallow_copy_type(tensor, tensor_applied):
                # 比较tensor, 及新的tensor_applied based on tesnor, 是否type 兼容， 是-->True: 改变现在tensor 内容为新tensor.
                # 但要有来自user 的确认，是否希望in-place change: torch.__future__.get_overwrite_module_params_on_conversion()
                """
                If the new tensor (tensor_applied) has compatible tensor type as the existing tensor,
                # the current behavior is to change the tensor in-place using `.data =`,
                # and the future behavior is to overwrite the existing tensor. However,
                # changing the current behavior is a BC-breaking change, and we want it
                # to happen in future releases. So for now we introduce the
                # `torch.__future__.get_overwrite_module_params_on_conversion()`
                # global flag to let the user control whether they want the future
                # behavior of overwriting the existing tensor or not.
                """
                return not torch.__future__.get_overwrite_module_params_on_conversion() # defaul is False
            else:
                return False

        for key, param in self._parameters.items():
            if param is not None:
                # Tensors stored in modules are graph leaves, and we don't want to
                # track autograd history of `param_applied`, so we have to use
                # `with torch.no_grad():`
                with torch.no_grad(): # 不记录grad, when call:backward(), grad won't be record.
                    param_applied = fn(param)
                should_use_set_data = compute_should_use_set_data(param, param_applied)
                if should_use_set_data: # in-place change, by using x.data = value
                    param.data = param_applied # update param in-place
                else:
                    assert isinstance(param, Parameter)
                    assert param.is_leaf # why only leaf could add to ._parameters??
                    self._parameters[key] = Parameter(param_applied, param.requires_grad) # new id()
                    # Parameter(tensor, requires_grad): creating a tensor with grad info.!!!

                if param.grad is not None: # why grad go through fn()???
                    with torch.no_grad():
                        grad_applied = fn(param.grad)
                    should_use_set_data = compute_should_use_set_data(param.grad, grad_applied)
                    if should_use_set_data:
                        param.grad.data = grad_applied # update param.grad-in place; ?? why not remvoe torch.no_grad in fn(param)

                    else:
                        assert param.grad.is_leaf # 1. requirs_grad = False or 2.: requires_grad = True, tensor_fn = False-no operation.
                        self._parameters[key].grad = grad_applied.requires_grad_(param.grad.requires_grad) # ???
                        # torch.requires_grad_()

            for key, buf in self._buffers.items():
                if buf is not None:
                    self._buffers[key] = fn(buf)
            return self


    def apply(self: T, fn: Callable[['Module'], None]) ->T: # T have to be Module
        r""" Applies 'fn' recursively to every submodule (as returned by '.children()')
        as well as self.

        Typical use includes initializing the parameter of a model
        (see also: ref: 'nn-init-doc').

        Args:
            fn(:class: 'Module' -> None): function to be applied to each submodule

        Returns:
            Module: self

        Example:

         Example::

            >> @torch.no_grad()
            >> def init_weights(m):
            >>     print(m)
            >>     if type(m) == nn.Linear:
            >>         m.weight.fill_(1.0)
            >>         print(m.weight)
            >> net = nn.Sequential(nn.Linear(2, 2), nn.Linear(2, 2))
            >> net.apply(init_weights)
            RUN: Result:
            Linear(in_features=2, out_features=2, bias=True)
            Parameter containing:
            tensor([[1., 1.],
                    [1., 1.]], requires_grad=True)

            Linear(in_features=2, out_features=3, bias=True)
            Parameter containing:
            tensor([[1., 1.],
                    [1., 1.],
                    [1., 1.]], requires_grad=True)

            Sequential(
                (0): Linear(in_features=2, out_features=2, bias=True)
                (1): Linear(in_features=2, out_features=3, bias=True)
                )
"""

        for module in self.children():
            module.apply(fn)
        fn(self)
        return self

    def cuda(self, T, device: Optional[Union[int, device]] = None) ->T:
        r""" Moves all model parameters and buffers to the GPU.
        This also makes associated parameters and buffers different object.So
        it should be called before constructing optimizer if the module will
        live on GPU while being optimized.

        ..note::
        This method modifies the module in-place.

        Args:
            device(int, optional): if specified, all parameters will be
            copied to that device

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.cuda(device))

    def xpu(self: T, device: Optional[Union[int, device]] = None) -> T:
        r"""Moves all model parameters and buffers to the XPU.

        This also makes associated parameters and buffers different objects. So
        it should be called before constructing optimizer if the module will
        live on XPU while being optimized.

        .. note::
            This method modifies the module in-place.

        Arguments:
            device (int, optional): if specified, all parameters will be
                copied to that device

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.xpu(device))

    def cpu(self: T) -> T:
        r"""Moves all model parameters and buffers to the CPU.

        .. note::
            This method modifies the module in-place.

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.cpu())

    def type(self:T, dst_type: Union[dtype, str]) -> T:
        r""" Casts all parameters and buffers to :attr:'dst_type'.

        ..note::
            This method modifies the module in-place.

        Args:
            dst_type(type or string): the desired type

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.type(dst_type))

    def float(self: T) -> T:
        r"""Casts all floating point parameters and buffers to ``float`` datatype.

        .. note::
            This method modifies the module in-place.

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.float() if t.is_floating_point() else t)

    def double(self: T) -> T:
        r"""Casts all floating point parameters and buffers to ``double`` datatype.

        .. note::
            This method modifies the module in-place.

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.double() if t.is_floating_point() else t)

    def half(self: T) -> T:
        r"""Casts all floating point parameters and buffers to ``half`` datatype.

        .. note::
            This method modifies the module in-place.

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.half() if t.is_floating_point() else t)

    def bfloat16(self: T) -> T:
        r"""Casts all floating point parameters and buffers to ``bfloat16`` datatype.

        .. note::
            This method modifies the module in-place.

        Returns:
            Module: self
        """
        return self._apply(lambda t: t.bfloat16() if t.is_floating_point() else t)

    def to_empty(self: T, *, device: Union[str, device]) ->T:
        r"""Moves the parameters and buffers to the specified device without copying storage.

        Args:
            device(:class:'torch.device'): The desired device of the parameters
                and buffers in this module.

        Returns:
            Module: self
        """
        return self._apply(lambda t: torch.empty_like(t, device=device))


    @overload
    def to(self: T, device: Optional[Union[int, device]] = ...,
           dtype: Optional[Union[dtype, str]] = ...,
           non_blcoking: bool = ...) ->T:
        ...

    @overload
    def to(self:T, dtype: Union[dtype, str], non_blocking: bool=...) ->T:
        ...

    @overload
    def to(self, tensor: Tensor, non_blocking: bool=...)->T:
        ...

    def to(self, *args, **kwargs):
        r""" Moves and/or casts the parameters and buffers.

        This can be called as
        ..function:: to(device=None, dtype=None, non_blocking = False) # only (non_blocking = False)
        ..function:: to(dtype, non_blocking=False) #(dtype, non_blocking)
        ..function:: to(tensor, non_blocking = False) # (tensor, non_blocking)
        ..function:: to(memory_format= torch.channels_last) #

        Its signature is similar to: meth:'torch.Tensor.to', but only accepts
        floating point or complex: attr: 'dtype's. In addition, this method will
        only cast the floating point or complex parameters an buffers to
        : attr:'dtype' (if given).
        The intergal parameters and buffers will be moved: attr:'device', if that is given, but with
        dtypes unchanged.
        When :attr:'non_blocking' is set, it tries to convert/move asynchronously with respect
        to the host if possible, e.g., moving CPU Tensors with pinnned memory to CUDA devices.

        See below for example.

        ..note::
            This method modifies the module in-place.

        Args:
            device(:class:'torch.device'): the desired device of the parameter
                and buffers in this module
            dtype(:class:'torch.dtype'): the desired floating point or complex
                dtype of the parameters and buffers in thi module
            tensor(torch.Tensor): Tensor whose dtype and device are the
                desired dtype and device for all parameters and buffers in this module
            memory_format(:class:'torch.memory_formate'): the desired memory
                formate for 4D parameters and buffers in this module(keywward only argument)

        Returns:
            Module: self

        Examples::
            >> linear = nn.Linear(2,2)
            >> linear.weight
            Parameter containing:
            tensor([[ 0.1913, -0.3420],
                    [-0.5113, -0.2325]])

            >> linear.to(torch.double)
            Linear(in_features=2, out_features=2, bias=True)
            >> linear.weight
            Parameter containing:
            tensor([[ 0.1913, -0.3420],
                    [-0.5113, -0.2325]], dtype=torch.float64)

            >>gpu1 = torch.device("cuda:1)
            >> linear.to(gpu1, dtype=torch.half, non_blocking=True)
            Linear(in_features=2, out_features=2, bias=True)
            >> linear.weight
            Parameter containing:
            tensor([[ 0.1914, -0.3420],
                    [-0.5112, -0.2324]], dtype=torch.float16, device='cuda:1')

            >> cpu = torch.device('cpu')
            >> linear.to(cpu)
            Linear(in_features=2, out_features=2, bias=True)
            >> linear.weight
            Parameter containing:
            tensor([[ 0.1914, -0.3420],
                    [-0.5112, -0.2324]], dtype=torch.float16)

            >> linear = nn.Linear(2,2, bias=None).to(torch.cdouble)
            >> linear.weight
            Parameter containing:
            tensor([[ 0.3741+0.j,  0.2382+0.j],
                    [ 0.5593+0.j, -0.4443+0.j]], dtype=torch.complex128)
            >> linear(torch.ones(3, 2, dtype=torch.cdouble))
            tensor([[0.6122+0.j, 0.1150+0.j],
                    [0.6122+0.j, 0.1150+0.j],
                    [0.6122+0.j, 0.1150+0.j]], dtype=torch.complex128)

        """
        device, dtype, non_blocking, convert_to_format = torch.C.nn.parse_to(*args, **kwargs)
        # note: **kwargs is for torch.memory_format memory_format
        """
        TypeError: to() received an invalid combination of arguments - got (tuple, dict), but expected one of:
            * (torch.device device, torch.dtype dtype, bool non_blocking, bool copy, *, torch.memory_format memory_format)
            * (torch.dtype dtype, bool non_blocking, bool copy, *, torch.memory_format memory_format)
            * (Tensor tensor, bool non_blocking, bool copy, *, torch.memory_format memory_format) """

        if dtype is not None:
            if not(dtype.is_floating_point or dtype.is_complex):
                raise TypeError('nn.Module.to only accepts floating point or complex'
                                'dtypes, but got desired dtype={}'.format(dtype))
            if dtype.is_complex:
                warnings.warn(""
                              "Complex Module are a new feature under active development "
                              "whose design may change, and some modules might not work as expected when"
                              "using complex tensor as parameters or buffers."
                              "Please file an issue at https://github.com/pytorch/pytorch/issues/new?template=bug-report.md"
                              "if a complex module does not work as expected.")
        def convert(t):
            if convert_to_format is not None and t.dim() in (4,5): # tensor dimension number between 4/5
                return t.to(device, dtype if t.is_floating_point() or t.is_complex() else None,
                            non_blocking, memory_format=convert_to_format)
            return t.to(device, dtype if t.is_floating_point() or t.is_complex() else None,
                        non_blocking)

        return self._apply(convert)



