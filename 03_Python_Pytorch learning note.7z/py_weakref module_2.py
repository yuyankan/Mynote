
"""
Python使用了垃圾回收器来自动销毁那些不再使用的对象。每个对象都有一个引用计数，当这个引用计数为0时Python能够安全地销毁这个对象。
使用weakref模块，你可以创建到对象的弱引用，Python在对象的引用计数为0或只存在对象的弱引用时将回收这个对象。
"""
# 一、 创建弱引用
"""
你可以通过调用weakref模块的ref(obj[,callback])来创建一个弱引用，obj是你想弱引用的对象，callback是一个可选的函数，当因没有引用导致Python要
销毁这个对象时调用。回调函数callback要求单个参数（弱引用的对象）。

一旦你有了一个对象的弱引用，你就能通过调用弱引用来获取被弱引用的对象。下面的例子创建了一个对socket对象的弱引用：
"""

# 1. 强相关：
a = [1, 2, 3]
b = a
del a
print(b) # b = [1,2,3]: 删掉 a 后， 不影响b; b = id(a)
print("*"*50)
# 2. 若相关： weakref.ref
from socket import *
import weakref
s=socket(AF_INET,SOCK_STREAM)
ref=weakref.ref(s)
print("s:",s)  #<socket._socketobject instance at 007B4A94>
print("\n")
print("ref: ", ref) # <weakref at 0x81195c; to 'instance' at 0x7b4a94>
print("\n")
print("ref():", ref())   #调用它来访问被引用的对象: <socket.socketobject instance at 007B4A94>
ref2 = weakref.ref(s) # ref2 is ref!!!
ref3 = weakref.ref(ref())
print("ref3", ref3)  # ref3 is ref2, is ref!!!
print("ref2():", ref2())
print("\n")
print("weakref.getweakrefcount(s):", weakref.getweakrefcount(s))
print("\n")
print("weakref.getweakrefs(s):", weakref.getweakrefs(s))


"""
一旦没有了对这个对象的其它的引用，调用弱引用将返回None，因为Python已经销毁了这个对象。 注意：大部分的对象不能通过弱引用来访问。
weakref模块中的getweakrefcount(obj)和getweakrefs(obj)分别返回弱引用数和关于所给对象的引用列表。

弱引用对于创建对象(这些对象很费资源)的缓存是有用的。
"""

# 2. 代理Proxy
#使用代理和使用普通weakref的区别就是不需要()，可以像原对象一样地使用proxy访问原对象的属性。
"""
import weakref
 
class TestObj:
 
    def __init__(self):
 
        self.test_attr = 100
 
def test_func(reference):
 
    print 'Hello from Callback function!'
 
   
 
a = TestObj()
 
#建立一个对a的代理(弱引用)
 
x = weakref.proxy(a, test_func)
 
print a.test_attr
 
print x.test_attr
 """
# callback参数的目的和ref函数相同。在Python删除了一个引用的对象之后，使用代理将会导致一个weakref.ReferenceError错误：
"""
>>> def s
>>> ref
Traceback (most recent call last):
  File "<stdin>", line 1, in ?
"""
import sys
import weakref
class Class1:
    def test(self):
        print("test...")
print("*"*50)
print("*"*50)
print('id(Class1):',id(Class1))
o = Class1()
print("sys.getrefcount(o):",sys.getrefcount(o)) # object o 引用次数为2
r = weakref.ref(o) #　创建一个弱引用
print("sys.getrefcount(o):",sys.getrefcount(o)) #　引用计数并没有改变, # object o 引用次数依然为2
print("r: ", r) # <weakref　at　00D3B3F0;　to　'instance'　at　00D37A30>　#　弱引用所指向的对象信息
o2 = r() #　获取弱引用所指向的对象 # 02 强引用o, 引用次数增加
print("o is o2:", o is o2) #True
print("sys.getrefcount(o):", sys.getrefcount(o))#3
print('id(o)_1: ',id(o))
print('id(o2)_1: ',id(o2))
o = None # id(o) changed, while id(o2) = class1() 's id; 无论实例o是可变对象还是不可变对象，次赋值行为改变id(o)
print('id(o)_2: ',id(o))
print('id(o2)_?: ',id(o2))
print('r',r)
o2 = None # note:!!! o2 is o--> if only set o = None, then r 若引用的对象id(o)没有改变， 弱引用还在。
print('id(o2)_2: ',id(o2))
print('r',r) #　当对象引用计数为零时，弱引用失效。<weakref　at　00D3B3F0;　dead>de>

"""
python的弱引用指引用一个对象但不增加它的引用计数器。这么做的好处是什么呢？什么时候需要考虑用若引用呢？

假设我们在设计一个游戏，有一个角色类Char，我们要给他添加一个效果（比如中毒），于是设计了一个效果类Effect。现在，给角色增加效果看上去就像这样：
 
"""


