# np.unique()数组的去重
"""

对于一维数组或者列表，unique函数去除其中重复的元素，并排序输出
"""
"""
temp = np.array([[1, 2, 3, 4], [3, 4, 5, 6]])
temp
array([[1, 2, 3, 4],
       [3, 4, 5, 6]])

np.unique(temp)
->
array([1, 2, 3, 4, 5, 6])

"""