"""
Dict: self._modules-->
1. Children:
    1.1: method_ def named_children (): yield name + model
         'for name, module in self._modules.items():
            if module is not None and module not in memo:
                memo.add(module)
                yield name, module'

    1.2: method_ def children(): yield model
        'for name, module in self.named_children():
            yield module'

       note: Dict: self._modules: <--- add by
                1. __setattr__,
                2. add_module () : will be called e.g. in: a =nn.Sequencial(Linear, ..)
2. module:
    2.1: method: named_modules(): yield name + modlue:
        --> Returns an iterator over all modules in the network; note:  name have prefix

            '        if memo is None:
                        memo = set()
                     if self not in memo:
                        if remove_duplicate:
                            memo.add(self)
                        yield prefix, self
                    for name, module in self._modules.items():
                        if module is None:
                            continue
                        submodule_prefix = prefix + ('.' if prefix else '') + name
                        for m in module.named_modules(memo, submodule_prefix, remove_duplicate):
                            yield m            '

    2.2: method: modules(): yield module
            'for _, module in self.named_modules():
                yield module
            '
"""


# named_children, children()
a = {'hi':1, 'world':2}
def y1():
    s1 = set()
    for key, values in a.items():
        s1.add(values)
        print(s1)
        yield key, values

def y2():
    for key, value in y1():
        yield value

for values in y2():
    print(values)

"""**************************************************************"""


def children(self) -> Iterator['Module']:
    r""" Returns an iterator over immediate children modules.

    Yields:
    Module: a child module
    """
    for name, module in self.named_children():
        yield module
"""*****************************************************************"""


def named_children(self) -> Iterator[Tuple[str, 'Module']]:
    r"""Return an iterator over immediate children modules, yielding both the name
    of the module as well as the module itself.

    Yields:
        (string, Module): Tuple containing a name and child module

    Example::

        >> for name, module in model.named_children():
        >>     if name in ['conv4', 'conv5']:
        >>         print(module)
    """
    memo = set()
    for name, module in self._modules.items():
        if module is not None and module not in memo:
            memo.add(module)  # note: set(), has no attr. append, use add()
            yield name, module
    """