import operator
a = 1

print(a)
print(operator.index(a))
"""
operator. index(a)
operator. __index__(a)
将a转换为整数数据并返回。等价于a. __index__() 确保a为整数， 否则报错。
"""