"""
1. 描述:
isinstance() 函数来判断一个对象是否是一个已知的类型，类似 type()。
isinstance() 与 type() 区别：
        type() 不会认为子类是一种父类类型，不考虑继承关系。
        isinstance() 会认为子类是一种父类类型，考虑继承关系。

如果要判断两个类型是否相同推荐使用 isinstance()。
********************************************************************************************************
2. 语法
以下是 isinstance() 方法的语法:
isinstance(object, classinfo)

3. 参数
    object -- 实例对象。
    classinfo -- 可以是直接或间接类名、基本类型或者有它们组成的元组。

4. 返回值
如果对象的类型与参数二的类型（classinfo）相同则返回 True，否则返回 False
"""

#  ====example 1: =====
a = 2;
print("\nisinstance check: a=2: \n"
      "                         isinstance(a, int)", isinstance(a, int))
print("                         isinstance(a, str)", isinstance(a, str))
print("        check in tuple:  isinstance(a, (str, int, list))", isinstance(a, (str, int, list)))

#  ====example 2: type() 与 isinstance()区别：=====
class A:
    pass
class B(A):
    pass

print("\nisinstance check: class A, B(A): \n"
      "                                  isinstance(A(), A): ", isinstance(A(), A))
print("                                  type(A())==A)", type(A())== A)
print("                                  isinstance(B(), A))", isinstance(B(), A))
print("                                  type(B())==A", type(B())== A)
print("                                  type(B())", type(B()))