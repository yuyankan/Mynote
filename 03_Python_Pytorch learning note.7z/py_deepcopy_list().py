#- deepcopy_list(): memo: record /copy x in this function, not modified in deepcopy(obj, memo), where used only
# for check if obj has been recorded or not

# - deepcopy(x, memo):return y= x/ y = memo[id(x)], memo_ modified here,
#
# copier = _deepcopy_dispatch.get(cls): for list, tuple/dict, copier will call deepcopy(x, obj)again：
# deepcopy(obj)内部循环调用deepcopy(): 传递参数：

#  1. deepcopy (obj)内部调用copier(x, memo)->2. _deepcopy_list(x, memo)-->:3.循环调用deepcopy(x, memo):
"""
1.自建 memo_d, 先传递给copier(x_2, memo_2)中memo_2-->传递给deepcopy(x_3, memo_3)中的memo_3:检查 x_3(列表元素)是否已经 memo_3/memo_d中,
返回 y_3= x_3 (memo_3[id(x)]=y_3, key id(x_3)的value 随y_3更新):返回列表元素； memo_3:字典中添加一对键值对：键=id(x_3)-列表元素地址, value = y_3 =x_3
2.2. _deepcopy_list(x_2, memo_2)：循环接收deepcopy(x_3, memo_3)：
   （1）：返回的y_3,至 y_2.append(): y_2 id 不变， 列表内存添加-y_2列表元素为要copy 对象后的对象;
          memo_2[id(x_2] = y_2: y_2 (chanegable object)update-->memo_2[id(x_2)] = y_2-obj列表copy,
          note: x_2 = obj-->memo[id(obj)] = obj:第一个键值对：被copy的list obj: 键：id(obj), value: obj所有的List元素
    (2): memo_3: 接受memo_2传递的参数，并在此基础上添加新的键值对：键=id(x_3)-列表元素地址, value = y_3 =x_3
         memo_2-->memo_3 字典为可变对象:memo_d, memo_2,memo_3 id 为同一个。 故memo_3update后， memo_2随之update-->memo_d 也一起update

         memo_2 first = memo_3-添加新的键值对, then in deepcopy_list: memo_2[id(x_2)] = y_2: 第一个键值对的value 更新。


"""

#  memo_d: memo_d(id(ob传递给copier(x, memo):
  # copier(x, memo)调用deepcopy(x, memo_d): 返回y,



from copy import deepcopy
from copy import _deepcopy_dispatch

def deepcopy(obj, memo_d=None, _nil=[]):
    print("\n0. deepcopy () is called")
    print("a in deepcopy:", obj)
    #print("memo_d in deepcopy():", memo_d)

    if memo_d is None:
        memo_d ={}
    d = id(obj)
    print("obj id in deepcopy:", d)
    y_d = memo_d.get(d, _nil)
    if y_d is not _nil:
        return y_d # then jump out def deepcopy method.
    cls = type(obj)
    if cls == list:

        copier = _deepcopy_list
    else:
        copier = _deepcopy_dispatch.get(cls)
    print("memo_d in deepcopy()1:", memo_d)
    y_d = copier(obj, memo_d) # memo_d no change here?

    memo_d[d] = y_d
    print("y in deepcopy(): id(y_d), y_d", id(y_d), y_d)
    print("memo_d in deepcopy()2:", memo_d)

    return y_d

def _deepcopy_list(x, memo, deepcopy=deepcopy):
    print("\n1. deepcopy_list is called")

    y = []
    memo[id(x)] = y
    print(memo[id(x)] is y)
    append = y.append
    print("memo in deepcopy_list():", memo)
    print("*"*50)
    for a in x:
        append(deepcopy(a, memo)) # memo is not modified here: -->yet memo[id(x)] = y: id(y): y changed-->memo value changed too.
        print("\na in deepcopy_list:", a)
        print('memo in deepcopy_list:', memo)
        print("y in deepcopy_list:", y)
        print("-" * 50)
    print(memo[id(x)] is y)
    print("*"*50)
    return y

obj = [1, 1, 2, 3]
y = deepcopy(obj)
print("*"*50)
print(y)





