import argparse
# argparse模块介绍
"""
在服务器上运行python程序时候，往往需要输入额外的参数，或者希望这些参数不用直接在代码里面改变，使用argparse内置模块不失为一种好办法。

使用步骤
使用仅仅需要3个步骤就可以完成：

# 1，创建对象
parser = argparse.ArgumentParser(description='example')
#2，增加参数
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='disables CUDA training')
#3 ，解析
args = parser.parse_args()
#print(args.cuda)

对应argarse,需要搞清楚第2步里面参数意义，带--开头，表示可选参数，不带则必须加入，否则会报错,

parser = argparse.ArgumentParser()
parser.add_argument("add", help="display a square of a given number", type=int)
args = parser.parse_args()
print(args.add+2)
 
 
#一些常用用法：

检测是否有GPU,如果有则打开：

parser = argparse.ArgumentParser(description='example')
 
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='disables CUDA training')
 
 
args = parser.parse_args()
 
args.cuda = not args.no_cuda and torch.cuda.is_available()
 
if args.cuda:
    print('\nGPU is ON!')
设置参数默认参数：

parser.add_argument('--var_bag_length', type=int, default=2, metavar='VL',
                    help='variance of bag length')

--var_bag_length ：表示变量名字为var_bag_length，是可选参数

type=int ：表示为int类型

default=2 ：表示 var_bag_length默认为2

metavar='VL' ：表示usage提升用户变量为VL

help='variance of bag length' :帮助信息

"""



# https://blog.csdn.net/u012005313/article/details/50111455?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522163901961516780366528494%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=163901961516780366528494&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-3-50111455.first_rank_v2_pc_rank_v29&utm_term=argparse%E6%A8%A1%E5%9D%97&spm=1018.2226.3001.4187

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("x", type=int, help="the base")
parser.add_argument("y", type=int, help="the exponent")
parser.add_argument("-v", "--verbosity", action="count", default=0)
args = parser.parse_args()
answer = args.x ** args.y
if args.verbosity >= 2:
    print("{} to the power {} equals {}".format(args.x, args.y, answer))
elif args.verbosity >= 1:
    print("{}^{} == {}".format(args.x, args.y, answer))
else:
    print(answer)