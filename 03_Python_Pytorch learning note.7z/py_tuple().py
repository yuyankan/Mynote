#  tuple()函数用于将列表、区间（range）等转换为元组。

# 注意：元组和列表非常类似，但列表与元组最大的区别在于：元组是不可改变的，列表是可改变的。元组支持的操作，列表基本上都支持；列表支持对元素的修改，
# 而元组则不支持。从这个角度来看，可以认为列表是增强版的元组。

"""

虽然大部分时候都可使用列表来代替元组，但如果程序不需要修改列表所包含的元素，那么使用元组代替列表会更安全。

语法:tuple(list/range...)
返回值: 返回元组

下面例子展示tuple()函数使用方法

a = [1,2] #list
b = {"1":2,"3":3} #dict
c = {1,2,3,3}  #set
d = range(2,10,2) #range
print(tuple(a))
print(tuple(b))
print(tuple(c))
print(tuple(d))
输出

(1, 2)
('1', '3')
(1, 2, 3)
(2, 4, 6, 8)

"""

a = (1,2, [3,4]) #list
b = {"1":2,"3":3} #dict
c = {1,2,3,3}  #set
d = range(2,10,2) #range

print(tuple(a))
print(tuple(b))
print(tuple(c))
print(tuple(d))
print(tuple(a[2]))
