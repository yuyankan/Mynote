"""
python中转换成字符有两种方法：str()和repr()，这两种又有什么区别？什么时候用str？什么时候用repr?
str()函数：将值转化为适于人阅读的字符串的形式
repr()函数：将值转化为供解释器读取的字符串形式

总结
1.除了字符串类型外，使用str还是repr转换没有什么区别，字符串类型的话，外层会多一对引号，这一特性有时候在eval操作时特别有用；
2.命令行下直接输出对象调用的是对象的repr方法，print输出调用的是str方法
"""

"""2. 命令行下print和直接输出的对比
每个类都有默认的__repr__, __str__方法，在命令行下用print 实例时调用的是类的str方法，直接调用的是类的repr方法；
在文件模式下没有print的话是不会有输出值的
"""

"""3. repr的使用场景
只有当repr再次作用在字符串上时会多一层引号，那么这一特性在拼接完字符串用eval执行时是特别有用的，如果不用repr而是采用str会报错，
"""

""" 代码示例
下面我们用例子来说明两个函数是差异点，还有就是print输出字符串时需要注意的点"""

# ====example1: 将整型转换为字符串 : str(), repr() same ======
a = 123  # int type
print('\nExample1:将整型转换为字符串: a = 123:  ')
print('type(a): ', type(a))
print('*' * 50)
print('\nuse str()')
print('type(str(a)): {}\nprint(str(a)): {}'.format(type(str(a)), str(a)))
print('*' * 50)
print('use repr()')
print('type(repr(a)): {}\nprint(repr(a)): {}'.format(type(repr(a)), repr(a)))

print('len(str(a)): {}\nlen(repr(a)): {}'.format(len(str(a)), len(repr(a))))

print("str(a) = '123'")
print("repr(a) = '123'")
"""note: 
str(a)  -->'123'
repr(a) -->'123' 
could not get '123' here without print command, only get in python .
"""

# ====example2: 将字符串转换为字符串 : str(), repr() different ======

a2 = 'abd'
print("\nExample12:将字符串转换为字符串 : a2='abd':  ")
print('type(a2): ', type(a2))
print('*' * 50)
print('\nuse str()')
print('type(str(a2)): {}\nprint(str(a2)): {}'.format(type(str(a2)), str(a2)))
print('*' * 50)
print('use repr()')
print('type(repr(a2)): {}\nprint(repr(a2)): {}'.format(type(repr(a2)), repr(a2)))

print('\nlen(str(a2)): {}\nlen(repr(a2)): {}'.format(len(str(a2)), len(repr(a2))))

print("str('abd') == 'abd'", str(a2) == 'abd')
print("repr('abd') == 'abd'", repr(a2) == 'abd')
print("\nstr(a2) = 'abd'")
print("repr(a2) = '' 'abd' ''")
"""note: 
str(a2)  -->'abd': str转换后还是原来的值 'abd'
repr(a2) -->" 'abd' ": repr转换后是在'abd'的外层又加了一层引号
repr转换后的字符串和str转换后的字符串个数都是不一样的: len(repr(a2)) =5

could not get str(a2), repr(a2) here without print command, only get in python .
"""

#  example3: 命令行下print和直接输出的对比====
"""命令行下print和直接输出的对比
每个类都有默认的__repr__, __str__方法，在命令行下用print 实例时调用的是类的str方法，直接调用的是类的repr方法；在文件模式下没有print的话是不会有输出值的，
"""


class eg3():
    def __repr__(self):
        return ('repr mehod is called')

    def __str__(self):
        return ('str method is called')


a3 = eg3()
a3  # 直接输出调用的是repr方法
print('\nexample3: 命令行下print: ', a3)  # print调用的是str方法


#  example4: repr的使用场景====
"""repr的使用场景
根据以上代码示例，可以得出只有当repr再次作用在字符串上时会多一层引号，那么这一特性在拼接完字符串用eval执行时是特别有用的，如果不用repr而是采用str会报错，，
"""

"""将字符串s = 'abdcf'转换成列表，如果用eval自己实现的话可以这样写："""
a4 = 'abdcf'
str4 = '['+','.join(str(i) for i in a4)+']'
repr4 = '['+','.join(repr(i) for i in a4)+']'
print("\nExample4: 将字符串s = 'abdcf'转换成列表，用eval实现:")
print("str4 = '['+','.join(str(i) for i in a4)+']'")
print("repr4 = '['+','.join(repr(i) for i in a4)+']'")
print('\nprint(eval(repr4)): ', eval(repr4))
print('print(repr4):', repr4)
print("repr4: directly ''['a','b','d','c','f']'' ")
print('\nprint(str4)', str4)
print("str4: directly: '[a,b,d,c,f]' ")
#eval('['+',' .join([str(i) for i in a4])+']'): will report error use str(i)
"""
当','.join([str(i) for i in s])拼接后的结果'a,b,d,c,f'只有一层引号，eval执行时会去掉这层引号，就成了a,b,d,c,f，解释器就会当做变量对待，但是并没有定义这样的变量，所以报NameError错误
"""

