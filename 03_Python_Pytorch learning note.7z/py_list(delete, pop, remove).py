
 # 从列表中删除元素
# 1. 使用 del 语句删除元素
"""
 - 如果知道要删除的元素在列表中的位置,可使用 del 语句。
 - 使用 del 可删除任何位置处的列表元素,条件是知道其索引。
 - 使用 del 语句将值从列表中删除后,你就无法再访问它了。
 """
motorcycles = ['honda', 'yamaha', 'suzuki']
print(motorcycles)

del motorcycles[0]
print(motorcycles)

# 2. 使用方法 pop() 删除元素
"""
 - 方法 pop() 可删除列表末尾的元素,并让你能够接着使用它。术语弹出 ( pop )源自这样的类比:列表就像一个栈,而删除列表末尾的元素相当于弹出栈顶元素。
下面从列表 motorcycles 中弹出一款摩托车:
 - 方法 pop() 是怎么起作用的呢?假设列表中的摩托车是按购买时间存储的,就可使用方法 pop() 打印一条消息,指出最后购买的是哪款摩托车:
"""

"""
如果你不确定该使用 del 语句还是 pop() 方法,下面是一个简单的判断标准:如果你要从列表中删除一个元素,且不再以任何方式使用它,就使用 del 语句;如果你要在删除元素后还能继续使用它,就使用方法 pop() 。
"""

# 3. 根据值删除元素
"""
有时候,你不知道要从列表中删除的值所处的位置。如果你只知道要删除的元素的值,可使用方法 remove() 。
例如,假设我们要从列表 motorcycles 中删除值 ‘ducati’ 。
"""
motorcycles = ['honda', 'yamaha', 'suzuki', 'ducati']
print(motorcycles)

motorcycles.remove('ducati')
print(motorcycles)
"""
代码让 Python 确定 ‘ducati’ 出现在列表的什么地方,并将该元素删除:
"""
"""
使用 remove() 从列表中删除元素时,也可接着使用它的值。下面删除值 ‘ducati’ ,并打印一条消息,指出要将其从列表中删除的原因:

motorcycles = ['honda', 'yamaha', 'suzuki', 'ducati']
print(motorcycles)

> too_expensive = 'ducati'
> motorcycles.remove(too_expensive)
> print(motorcycles)

定义列表后,我们将值 ‘ducati’ 存储在变量 too_expensive 中。接下来,我们使用这个变量来告诉 Python 将哪个值从列表中删除。最后,
值 ‘ducati’ 已经从列表中删除,但它还存储在变量 too_expensive 中,让我们能够打印一条消息,指出将 ‘ducati’ 从列表 motorcycles 中删除的原因:

['honda', 'yamaha', 'suzuki', 'ducati']
['honda', 'yamaha', 'suzuki']
A Ducati is too expensive for me.
"""

# 注意 ：方法 remove() 只删除第一个指定的值。如果要删除的值可能在列表中出现多次,就需要使用循环来判断是否删除了所有这样的值。