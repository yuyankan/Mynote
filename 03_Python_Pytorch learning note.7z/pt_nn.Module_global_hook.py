r"""This tracks hooks common to all modules that are executed before/after calling forward and backward. This is global
state used for debugging/profiling purposes"""
from typing import Dict, Callable, Optional
from collections import OrderedDict
from torch.utils.hooks import RemovableHandle
from torch.utils import hooks

_global_backward_hooks: Dict[int, Callable] = OrderedDict() #??
_global_is_full_backward_hook: Optional[bool] = None
_global_forward_pre_hooks: Dict[int, Callable] = OrderedDict()
_global_forward_hooks: Dict[int, callable] = OrderedDict()
#a: Dict[int, Callable] = OrderedDict()
#a = {1: '3',  2: '4' }

def register_module_forward_pre_hook(hook: Callable[...,None])->RemovableHandle:
    r"""Registers a forward pre-hook common to all modules.

    ..warning::

    This adds global state to the 'nn.module' module and it is only intended for debugging /profiling purposes.

    The hook will be called every time before: func: 'forward' is invoked.
    It should have the following signature::

        hook(module, input) -> None or modified input

    The input contains only the positional arguments given to the module.
    Keyword arguments won't be passed to hooks and only to the 'forward'.
    The hook can modify the input. User can either return a tuple or a single
    modified value in the hook. we will wrap the value into a tuple if a single
    value is returned(unless that value is already a tuple).

    This hook has precedence over the specific module hooks registered with
    'register_forward_pre_hook'.

    Returns:
        :class: 'torch.utils.hook.RemovableHandle':
            a handle that can be used to remove the added hook by calling
            'handle.remove()'
    """
    handle = hooks.RemovableHandle(_global_forward_pre_hooks)
    _global_forward_pre_hooks[handle.id] = hook
    return handle

def register_module_forward_hook(hook: Callable[..., None])->RemovableHandle:
    r"""Registers a global forward hook for all the modules

        .. warning ::

            This adds global state to the `nn.module` module
            and it is only intended for debugging/profiling purposes.

        The hook will be called every time after :func:`forward` has computed an output.
        It should have the following signature::

            hook(module, input, output) -> None or modified output

        The input contains only the positional arguments given to the module.
        Keyword arguments won't be passed to the hooks and only to the ``forward``.
        The hook can modify the output. 
       
    !!! It can modify the input inplace but
        it will not have effect on forward since this is called after
        :func:`forward` is called.!!!

        Returns:
            :class:`torch.utils.hooks.RemovableHandle`:
                a handle that can be used to remove the added hook by calling
                ``handle.remove()``

   !!! This hook will be executed before specific module hooks registered with
        ``register_forward_hook``.!!!
        """
    handle = hooks.RemovableHandle(_global_forward_hooks)# weakref. of _global_forward_hooks, not add+1 to 引用次数；
    _global_forward_hooks[handle.id] =  hook
    return handle # handle.remove(): could delete hooks forever;

from typing import Union, Tuple
from torch import Tensor
_grad_t = Union[Tuple[Tensor, ...], Tensor]

def register_module_backward_hook(hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]])->RemovableHandle:
    r"""Register a backward hook common to all the modules.

    This function is deprecated（废弃） in favor of : meth: 'nn.module.register_module_full_backward_hook'
    and behavious of this function will change in future versioins.

    Returns:
    :class:'torch.utils.hooks.RemovableHandle':
    a handle that can be used to remove the added hook by calling
            ``handle.remove()`

    """
    global _global_is_full_backward_hook
    if _global_is_full_backward_hook is True:
        raise RuntimeError("Cannot use  both regular backward hooks and full backward hooks"
                           "as a global Module hook, Please use only one of them ")
    _global_is_full_backward_hook = False

    handle = hooks.RemovableHandle(_global_backward_hooks)
    _global_backward_hooks[handle.id] = hook
    return handle

