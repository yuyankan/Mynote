""" Iterator
第一个用法：iter(iterable) -> iterator (把可迭代对象转换为迭代器)
第二个用法：iter(callable, sentinel) -> iterator (第一个参数：任何可调用对象，可以是函数，第二个是标记值，当可调用对象返回这个值时，迭代器抛出StopIteration异常，而不产出标记值)
"""

"""
iter(iterable) -> iterator
iter(callable, sentinel) -> iterator

Get an iterator from an object.  In the first form, the argument must
supply its own iterator, or be a sequence.
In the second form, the callable is called until it returns the sentinel.
"""
from random import choice
values = [1,2,3,4,5,6,7]
def test_iter():
    return choice(values) # 每次从列表或元组等选择一个值
it = iter(test_iter, 2)
print(it)

print("*"*50)
for i in it:
    print(i)

"""
test_iter函数从values列表中随机挑选一个值并返回，调用iter(callable, sentinel)函数，把sentinel标记值设置为2，
返回一个callable_iterator实例，遍历这个特殊的迭代器，如果函数返回标记值2，直接抛出异常退出程序。这就是iter函数的鲜为人知的另一个用法。
"""
