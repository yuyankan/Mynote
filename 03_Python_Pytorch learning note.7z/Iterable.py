from collections.abc import Iterable

"""
在Python中，有这两个概念容易让人混淆。第一个是可迭代对象（Iterable），第二个是迭代器（Iterator），第三个是生成器（Generator），这里暂且不谈生成器。
"""

""" 1. Iterable:
列表、元组、字符串、字典等都是可迭代对象，可以使用for循环遍历出所有元素的都可以称为可迭代对象（Iterable）。
在Python的内置数据结构中定义了Iterable这个类，在collections.abc模块中，我们可以用这个来检测是否为可迭代对象
"""
#  =====example1: Iterable: check ====

a = [1, 2, 3]
print('Example1： iterable check for: \n'
      '                               list a =[1, 2, 3]: ', isinstance(a, Iterable))
b = 'abcd'
print("                               str ='abcd': ", isinstance(b, Iterable))

""" note:
这些数据结构之所以能称之为Iterable，是因为其内部实现了__iter__()方法，从而可迭代。
当我们使用for循环时，解释器会调用内置的iter()函数，调用前首先会检查对象是否实现了__iter__()方法，如果有就调用它获取一个迭代器（接下来会讲）。
如果没有__iter__()方法，但是实现了__getitem__()方法，解释器会创建一个迭代器并且按顺序获取元素。如果这两个方法都没有找到，就会抛出TypeError异常。
"""

print('check if has __iter__: \n'
      '                        list a =[1, 2, 3]:', a.__iter__())
print('                        str b =abcd:', b.__iter__())


#  =====example2: Iterable: create ====
#  =====example2.1: Iterable: create with __getitem__ method ====
print("2"*50)
class myobj2:
    def __init__(self, iterable):
        self.iterable = list(iterable)

    def __getitem__(self, item):
        print("__getitem__ is called")
        return self.iterable[item]

obj2 = myobj2([1, 2, 3])
print('\nexample2: create iterable list with __getitem__:\n'
      '2.1: get list element with for loop: for i in obj2, print(i)')
for i in obj2:
      print(i)

print('2.2: get list element with for loop: for i in range(3), print(obj2.__getitem__(i))')
for i in range(3):
      print(obj2.__getitem__(i))
print("3"*50)
#  =====example3: Iterable: create with __iter__ method ====
class myobj3:
    def __init__(self, iterable):
        print('example 3: Iterable list: created by __iter__')
        self.iterable = list(iterable)

    def __iter__(self):
        index = 0
        while True:
            try:
                yield self.iterable[index]
            except IndexError:
                break
            index += 1
obj3 = myobj3([4, 5, 6])
print('3.1: get list element with for loop: for i in obj3, print(i)')
for i in obj3:
    print(i)

print('3.2: get list element with for loop: for i in range(3), print(next.(obj3.__iter__()))')
t = obj3.__iter__()
print('    obj3.__iter__ is: ', t)
print('    next(t): ', next(t))
print('             ', next(t))
print('             ', next(t))


"""
***********************************************************************************************************************

"""