"""
python中的内建函数callable( ), 可以检查一个对象是否是可调用的 。
对于函数, 方法, lambda 函数式, 类, 以及实现了 _ _call_ _ 方法的类实例, 它都返回 True.

# >>> help(callable)
Help on built-in function callable in module __builtin__:

callable(...)
    callable(object) -> bool
    Return whether the object is callable (i.e., some kind of function).
    Note that classes are callable, as are instances with a __call__() method.
"""


#  ==== example1: 函数是可调用的===========================

def add(x, y):
    return x + y


print('\nexample1: 函数是可调用的add(x, y): callable(add))', callable(add))


#  ==== example2: 类和类内的方法是可调用的===========================
class C:
    def print(self):
        print('This is class C')


print('\nexample2: 类是可调用的C: callable(C))', callable(C))
# 类是可调用的，调用它们, 就产生对应的类实例.

print('\nexample2: 类(C)的方法(print)是可调用的: callable( c.print): ', callable(C.print))

#  ==== example3: 实现了__call__()方法的类实例是可调用的===========================
objC = C()
print('\n example3: 没有__call__()方法的类实例是不可调用的: '
      'callable(objC = C()-note: not: objC = C, which is callable)', callable(objC))


class B:
    def __call__(self):
        print('This is class B')


objB = B()

print('\n example3: 有__call__()方法的类实例是可调用的: callable(objB = B()', callable(objB))

#  ==== example4: lambda表达式是可调用的===========================
f = lambda x, y: x+y
print('\nexample4: lambda表达式是可调用的: callable(f=lambda x, y: x+y)', callable(f))


#  ==== example5: 其它的，像整数，字符串，列表，元组，字典等等，都是不可调用的===========================
s = [1, 2, 3]
print('example5: 其它的，像整数，字符串，列表，元组，字典等等，都是不可调用的: eg.: s=[1, 2, 3], callable(s): ', callable(s))