import matplotlib.pyplot as plt

"""
Help on RcParams in module matplotlib object:

class RcParams(collections.abc.MutableMapping, builtins.dict)
 |  RcParams(*args, **kwargs)
 |
 |  A dictionary object including validation.
 |
 |  Validating functions are defined and associated with rc parameters in
 |  :mod:`matplotlib.rcsetup`.
 |
 |  The list of rcParams is:
 |
 |  - backend
 |  - backend_fallback
 |  - toolbar
 |  - interactive
 |  - timezone
 |  - webagg.port
 |  - webagg.address
 |  - webagg.open_in_browser
 |  - webagg.port_retries
 |  - lines.linewidth
 |  - lines.linestyle
 |  - lines.color
 |  - lines.marker
 |  - lines.markerfacecolor
 |  - lines.markeredgecolor
 |  - lines.markeredgewidth
 |  - lines.markersize
 |  - lines.antialiased
 |  - lines.dash_joinstyle
 |  - lines.solid_joinstyle
 |  - lines.dash_capstyle
 |  - lines.solid_capstyle
 |  - lines.dashed_pattern
 |  - lines.dashdot_pattern
 |  - lines.dotted_pattern
 |  - lines.scale_dashes
 |  - markers.fillstyle
 |  - pcolor.shading
 |  - pcolormesh.snap
 |  - patch.linewidth
 |  - patch.edgecolor
 |  - patch.force_edgecolor
 |  - patch.facecolor
 |  - patch.antialiased
 |  - hatch.color
 |  - hatch.linewidth
 |  - hist.bins
 |  - boxplot.notch
 |  - boxplot.vertical
 |  - boxplot.whiskers
 |  - boxplot.bootstrap
 |  - boxplot.patchartist
 |  - boxplot.showmeans
 |  - boxplot.showcaps
 |  - boxplot.showbox
 |  - boxplot.showfliers
 |  - boxplot.meanline
 |  - boxplot.flierprops.color
 |  - boxplot.flierprops.marker
 |  - boxplot.flierprops.markerfacecolor
 |  - boxplot.flierprops.markeredgecolor
 |  - boxplot.flierprops.markeredgewidth
 |  - boxplot.flierprops.markersize
 |  - boxplot.flierprops.linestyle
 |  - boxplot.flierprops.linewidth
 |  - boxplot.boxprops.color
 |  - boxplot.boxprops.linewidth
 |  - boxplot.boxprops.linestyle
 |  - boxplot.whiskerprops.color
 |  - boxplot.whiskerprops.linewidth
 |  - boxplot.whiskerprops.linestyle
 |  - boxplot.capprops.color
 |  - boxplot.capprops.linewidth
 |  - boxplot.capprops.linestyle
 |  - boxplot.medianprops.color
 |  - boxplot.medianprops.linewidth
 |  - boxplot.medianprops.linestyle
 |  - boxplot.meanprops.color
 |  - boxplot.meanprops.marker
 |  - boxplot.meanprops.markerfacecolor
 |  - boxplot.meanprops.markeredgecolor
 |  - boxplot.meanprops.markersize
 |  - boxplot.meanprops.linestyle
 |  - boxplot.meanprops.linewidth
 |  - font.family
 |  - font.style
 |  - font.variant
 |  - font.stretch
 |  - font.weight
 |  - font.size
 |  - font.serif
 |  - font.sans-serif
 |  - font.cursive
 |  - font.fantasy
 |  - font.monospace
 |  - text.color
 |  - text.usetex
 |  - text.latex.preamble
 |  - text.latex.preview
 |  - text.hinting
 |  - text.hinting_factor
 |  - text.kerning_factor
 |  - text.antialiased
 |  - mathtext.cal
 |  - mathtext.rm
 |  - mathtext.tt
 |  - mathtext.it
 |  - mathtext.bf
 |  - mathtext.sf
 |  - mathtext.fontset
 |  - mathtext.default
 |  - mathtext.fallback_to_cm
 |  - mathtext.fallback
 |  - image.aspect
 |  - image.interpolation
 |  - image.cmap
 |  - image.lut
 |  - image.origin
 |  - image.resample
 |  - image.composite_image
 |  - contour.negative_linestyle
 |  - contour.corner_mask
 |  - contour.linewidth
 |  - errorbar.capsize
 |  - xaxis.labellocation
 |  - yaxis.labellocation
 |  - axes.axisbelow
 |  - axes.facecolor
 |  - axes.edgecolor
 |  - axes.linewidth
 |  - axes.spines.left
 |  - axes.spines.right
 |  - axes.spines.bottom
 |  - axes.spines.top
 |  - axes.titlesize
 |  - axes.titlelocation
 |  - axes.titleweight
 |  - axes.titlecolor
 |  - axes.titley
 |  - axes.titlepad
 |  - axes.grid
 |  - axes.grid.which
 |  - axes.grid.axis
 |  - axes.labelsize
 |  - axes.labelpad
 |  - axes.labelweight
 |  - axes.labelcolor
 |  - axes.formatter.limits
 |  - axes.formatter.use_locale
 |  - axes.formatter.use_mathtext
 |  - axes.formatter.min_exponent
 |  - axes.formatter.useoffset
 |  - axes.formatter.offset_threshold
 |  - axes.unicode_minus
 |  - axes.prop_cycle
 |  - axes.autolimit_mode
 |  - axes.xmargin
 |  - axes.ymargin
 |  - axes.zmargin
 |  - polaraxes.grid
 |  - axes3d.grid
 |  - scatter.marker
 |  - scatter.edgecolors
 |  - date.epoch
 |  - date.autoformatter.year
 |  - date.autoformatter.month
 |  - date.autoformatter.day
 |  - date.autoformatter.hour
 |  - date.autoformatter.minute
 |  - date.autoformatter.second
 |  - date.autoformatter.microsecond
 |  - date.converter
 |  - date.interval_multiples
 |  - legend.fancybox
 |  - legend.loc
 |  - legend.numpoints
 |  - legend.scatterpoints
 |  - legend.fontsize
 |  - legend.title_fontsize
 |  - legend.markerscale
 |  - legend.shadow
 |  - legend.frameon
 |  - legend.framealpha
 |  - legend.borderpad
 |  - legend.labelspacing
 |  - legend.handlelength
 |  - legend.handleheight
 |  - legend.handletextpad
 |  - legend.borderaxespad
 |  - legend.columnspacing
 |  - legend.facecolor
 |  - legend.edgecolor
 |  - xtick.top
 |  - xtick.bottom
 |  - xtick.labeltop
 |  - xtick.labelbottom
 |  - xtick.major.size
 |  - xtick.minor.size
 |  - xtick.major.width
 |  - xtick.minor.width
 |  - xtick.major.pad
 |  - xtick.minor.pad
 |  - xtick.color
 |  - xtick.labelcolor
 |  - xtick.minor.visible
 |  - xtick.minor.top
 |  - xtick.minor.bottom
 |  - xtick.major.top
 |  - xtick.major.bottom
 |  - xtick.labelsize
 |  - xtick.direction
 |  - xtick.alignment
 |  - ytick.left
 |  - ytick.right
 |  - ytick.labelleft
 |  - ytick.labelright
 |  - ytick.major.size
 |  - ytick.minor.size
 |  - ytick.major.width
 |  - ytick.minor.width
 |  - ytick.major.pad
 |  - ytick.minor.pad
 |  - ytick.color
 |  - ytick.labelcolor
 |  - ytick.minor.visible
 |  - ytick.minor.left
 |  - ytick.minor.right
 |  - ytick.major.left
 |  - ytick.major.right
 |  - ytick.labelsize
 |  - ytick.direction
 |  - ytick.alignment
 |  - grid.color
 |  - grid.linestyle
 |  - grid.linewidth
 |  - grid.alpha
 |  - figure.titlesize
 |  - figure.titleweight
 |  - figure.figsize
 |  - figure.dpi
 |  - figure.facecolor
 |  - figure.edgecolor
 |  - figure.frameon
 |  - figure.autolayout
 |  - figure.max_open_warning
 |  - figure.raise_window
 |  - figure.subplot.left
 |  - figure.subplot.right
 |  - figure.subplot.bottom
 |  - figure.subplot.top
 |  - figure.subplot.wspace
 |  - figure.subplot.hspace
 |  - figure.constrained_layout.use
 |  - figure.constrained_layout.hspace
 |  - figure.constrained_layout.wspace
 |  - figure.constrained_layout.h_pad
 |  - figure.constrained_layout.w_pad
 |  - savefig.dpi
 |  - savefig.facecolor
 |  - savefig.edgecolor
 |  - savefig.orientation
 |  - savefig.jpeg_quality
 |  - savefig.format
 |  - savefig.bbox
 |  - savefig.pad_inches
 |  - savefig.directory
 |  - savefig.transparent
 |  - tk.window_focus
 |  - ps.papersize
 |  - ps.useafm
 |  - ps.usedistiller
 |  - ps.distiller.res
 |  - ps.fonttype
 |  - pdf.compression
 |  - pdf.inheritcolor
 |  - pdf.use14corefonts
 |  - pdf.fonttype
 |  - pgf.texsystem
 |  - pgf.rcfonts
 |  - pgf.preamble
 |  - svg.image_inline
 |  - svg.fonttype
 |  - svg.hashsalt
 |  - docstring.hardcopy
 |  - path.simplify
 |  - path.simplify_threshold
 |  - path.snap
 |  - path.sketch
 |  - path.effects
 |  - agg.path.chunksize
 |  - keymap.fullscreen
 |  - keymap.home
 |  - keymap.back
 |  - keymap.forward
 |  - keymap.pan
 |  - keymap.zoom
 |  - keymap.save
 |  - keymap.quit
 |  - keymap.quit_all
 |  - keymap.grid
 |  - keymap.grid_minor
 |  - keymap.yscale
 |  - keymap.xscale
 |  - keymap.all_axes
 |  - keymap.help
 |  - keymap.copy
 |  - animation.html
 |  - animation.embed_limit
 |  - animation.writer
 |  - animation.codec
 |  - animation.bitrate
 |  - animation.frame_format
 |  - animation.html_args
 |  - animation.ffmpeg_path
 |  - animation.ffmpeg_args
 |  - animation.avconv_path
 |  - animation.avconv_args
 |  - animation.convert_path
 |  - animation.convert_args
 |  - _internal.classic_mode
 |
 |  See Also
 |  --------
 |  :ref:`customizing-with-matplotlibrc-files`
 |
 |  Method resolution order:
 |      RcParams
 |      collections.abc.MutableMapping
 |      collections.abc.Mapping
 |      collections.abc.Collection
 |      collections.abc.Sized
 |      collections.abc.Iterable
 |      collections.abc.Container
 |      builtins.dict
 |      builtins.object
 |
 |  Methods defined here:
 |
 |  __getitem__(self, key)
 |      x.__getitem__(y) <==> x[y]
 |
 |  __init__(self, *args, **kwargs)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |
 |  __iter__(self)
 |      Yield sorted list of keys.
 |
 |  __len__(self)
 |      Return len(self).
 |
 |  __repr__(self)
 |      Return repr(self).
 |
 |  __setitem__(self, key, val)
 |      Set self[key] to value.
 |
 |  __str__(self)
 |      Return str(self).
 |
 |  copy(self)
 |      D.copy() -> a shallow copy of D
 |
 |  find_all(self, pattern)
 |      Return the subset of this RcParams dictionary whose keys match,
 |      using :func:`re.search`, the given ``pattern``.
 |
 |      .. note::
 |
 |          Changes to the returned dictionary are *not* propagated to
 |          the parent RcParams dictionary.
 |
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |
 |  __dict__
 |      dictionary for instance variables (if defined)
 |
 |  __weakref__
 |      list of weak references to the object (if defined)
 |
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |
 |  __abstractmethods__ = frozenset({'__delitem__'})
 |
 |  validate = {'_internal.classic_mode': <function validate_bool>, 'agg.p...
 |
 |  ----------------------------------------------------------------------
 |  Methods inherited from collections.abc.MutableMapping:
 |
 |  __delitem__(self, key)
 |
 |  clear(self)
 |      D.clear() -> None.  Remove all items from D.
 |
 |  pop(self, key, default=<object object at 0x00000222D79B8160>)
 |      D.pop(k[,d]) -> v, remove specified key and return the corresponding value.
 |      If key is not found, d is returned if given, otherwise KeyError is raised.
 |
 |  popitem(self)
 |      D.popitem() -> (k, v), remove and return some (key, value) pair
 |      as a 2-tuple; but raise KeyError if D is empty.
 |
 |  setdefault(self, key, default=None)
 |      D.setdefault(k[,d]) -> D.get(k,d), also set D[k]=d if k not in D
 |
 |  update(self, other=(), /, **kwds)
 |      D.update([E, ]**F) -> None.  Update D from mapping/iterable E and F.
 |      If E present and has a .keys() method, does:     for k in E: D[k] = E[k]
 |      If E present and lacks .keys() method, does:     for (k, v) in E: D[k] = v
 |      In either case, this is followed by: for k, v in F.items(): D[k] = v
 |
 |  ----------------------------------------------------------------------
 |  Methods inherited from collections.abc.Mapping:
 |
 |  __contains__(self, key)
 |
 |  __eq__(self, other)
 |      Return self==value.
 |
 |  get(self, key, default=None)
 |      D.get(k[,d]) -> D[k] if k in D, else d.  d defaults to None.
 |
 |  items(self)
 |      D.items() -> a set-like object providing a view on D's items
 |
 |  keys(self)
 |      D.keys() -> a set-like object providing a view on D's keys
 |
 |  values(self)
 |      D.values() -> an object providing a view on D's values
 |
 |  ----------------------------------------------------------------------
 |  Data and other attributes inherited from collections.abc.Mapping:
 |
 |  __hash__ = None
 |
 |  __reversed__ = None
 |
 |  ----------------------------------------------------------------------
 |  Class methods inherited from collections.abc.Collection:
 |
 |  __subclasshook__(C) from abc.ABCMeta
 |      Abstract classes can override this to customize issubclass().
 |
 |      This is invoked early on by abc.ABCMeta.__subclasscheck__().
 |      It should return True, False or NotImplemented.  If it returns
 |      NotImplemented, the normal algorithm is used.  Otherwise, it
 |      overrides the normal algorithm (and the outcome is cached).
 |
 |  ----------------------------------------------------------------------
 |  Class methods inherited from collections.abc.Iterable:
 |
 |  __class_getitem__ = GenericAlias(...) from abc.ABCMeta
 |      Represent a PEP 585 generic type
 |
 |      E.g. for t = list[int], t.__origin__ is list and t.__args__ is (int,).
 |
 |  ----------------------------------------------------------------------
 |  Methods inherited from builtins.dict:
 |
 |  __ge__(self, value, /)
 |      Return self>=value.
 |
 |  __getattribute__(self, name, /)
 |      Return getattr(self, name).
 |
 |  __gt__(self, value, /)
 |      Return self>value.
 |
 |  __ior__(self, value, /)
 |      Return self|=value.
 |
 |  __le__(self, value, /)
 |      Return self<=value.
 |
 |  __lt__(self, value, /)
 |      Return self<value.
 |
 |  __ne__(self, value, /)
 |      Return self!=value.
 |
 |  __or__(self, value, /)
 |      Return self|value.
 |
 |  __ror__(self, value, /)
 |      Return value|self.
 |
 |  __sizeof__(...)
 |      D.__sizeof__() -> size of D in memory, in bytes
 |
 |  ----------------------------------------------------------------------
 |  Class methods inherited from builtins.dict:
 |
 |  fromkeys(iterable, value=None, /) from abc.ABCMeta
 |      Create a new dictionary with keys from iterable and values set to value.
 |
 |  ----------------------------------------------------------------------
 |  Static methods inherited from builtins.dict:
 |
 |  __new__(*args, **kwargs) from builtins.type
 |      Create and return a new object.  See help(type) for accurate signature.


Process finished with exit code 0

"""
