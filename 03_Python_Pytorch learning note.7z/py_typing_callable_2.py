
# python Typing模块-类型注解
"""
typing 是python3.5中开始新增的专用于类型注解(type hints)的模块，为python程序提供静态类型检查，如下面的greeting函数规定了参数name的类型是str，返回值的类型也是str。


def greeting(name: str) -> str:
    return 'Hello ' + name

"""
# note: below case: help info. for input type, yet also ok to run if use other type parameter.

#在实践中，该模块常用的类型有 Any, Union, Tuple, Callable, TypeVar,Optional和Generic等

# 注意事项：typing模块虽然已经正式加入到了标准库中，但是如果核心开发者认为有必要的话，api也可能会发生改变，即不保证向后兼容性
def greeting(name: str) -> str:
    return name
a = greeting(1)
print(a)


"*****************************************************************************************************************"
# 3. Callable
"""
回调函数可以使用类似Callable[[Arg1Type, Arg2Type],ReturnType]的类型注释，这个比较简单，例子如下，如果只指定回调函数的返回值类型，
则可以使用Callable[..., ReturnType]的形式：
"""
from typing import Callable

def e(on_success: Callable[[int], None], on_error: Callable[[int, Exception], None]) ->None:
    pass

# 4. Generics
"""
由于无法以通用的方式静态推断有关保存在容器（list set tuple）中对象的类型信息，因此抽象类被用来拓展表示容器中的元素。如下面子里中，
使用基类Employee来扩展其可能得子类如 Sub1_Employee、Sub2_Employee等。但是其局限性明显，所以我们需要引入泛型(generics)。

"""
from typing import Mapping, Sequence

def notify_by_email(employees: Sequence[Employee],
                    overrides: Mapping[str, str]) -> None:
    pass

# 4.1 可以通过typing中的TypeVar将泛型参数化，如：
from typing import Sequence, TypeVar

T = TypeVar('T')      # Can be anything
A = TypeVar('A', str, bytes)  # Must be str or bytes

def first(l: Sequence[T]) -> T:   # Generic function
    return l[0]


# 5. User-defined generic types: 以将用户字定义的类定义为泛型类：
from typing import TypeVar, Generic
from logging import Logger

T = TypeVar('T')

class LoggedVar(Generic[T]):
    def __init__(self, value: T, name: str, logger: Logger) -> None:
        self.name = name
        self.logger = logger
        self.value = value

    def set(self, new: T) -> None:
        self.log('Set ' + repr(self.value))
        self.value = new

    def get(self) -> T:
        self.log('Get ' + repr(self.value))
        return self.value

    def log(self, message: str) -> None:
        self.logger.info('%s: %s', self.name, message)
"""
Generic[T] 作为基类定义了类 LoggedVar 采用单个类型参数 T。这也使得 T 作为类体内的一个类型有效。通过Generic基类使用元类(metaclass)定义
__getitem__()使得LoggedVar[t]是有效类型:
"""
from typing import Iterable

def zero_all_vars(vars: Iterable[LoggedVar[int]]) -> None:
    for var in vars:
        var.set(0)

"""泛型类型可以有任意数量的类型变量，并且类型变量可能会受到限制:"""
from typing import TypeVar, Generic

T = TypeVar('T')
S = TypeVar('S', int, str)

class StrangePair(Generic[T, S]):
    pass