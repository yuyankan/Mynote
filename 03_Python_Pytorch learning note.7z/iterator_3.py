"""__iter__():迭代器，生成迭代对象时调用，!!!!!返回值必须是对象自己,然后for可以循环调用next方法
next():每一次for循环都调用该方法（必须存在）!!!!
"""
class A(object):
    def __init__(self, num):
        self.num = num
        self.start_num = -1
        print("1. __init__")

    def __next__(self):
        """
         @summary: 每一次for循环都调用该方法（必须存在）
        """
        print("3. __next__")
        self.start_num += 1
        if self.start_num >self.num:
            raise StopIteration()
        return self.start_num

    def __iter__(self):
        """ @summary: 迭代器，生成迭代对象时调用，返回值必须是对象自己,然后for可以循环调用next方法 """
        print("2. __iter__")
        return(self)

if __name__ == "__main__":
    print("\nA.__dict__:\n", A.__dict__)
    print("*" * 50)
    t = A(3)
    print("*" * 50)
    t = iter(t)
    print("*"*50)
    for i in t:# will call __iter__ method once, __next__ every loop
        print("-"*50)
        print(i)
        print("-"*50)

    print('*'*50)


""" Run result: 
一、 class method sequence: for loop: 1rst __init__; 2nd: __str__, 3rd__next__, then only __next__
二.__str__could not remove for for-loop.
1. __init__
2. __iter__
3. __next__
0
3. __next__
1
3. __next__
2
3. __next__
3
3. __next__
"""

