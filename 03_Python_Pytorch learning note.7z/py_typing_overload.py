from typing import overload

# 1. Python3中增加了Function Annotation的功能，翻译过来就是函数（方法）注解，具体用法就是:
def foo(name: str) -> str:
    return 'hello' + name
""" 这么定义函数，可以达到静态类型的效果。如果你尝试使用foo(2) 传入一个int类型的话运行可能就会报错："""
#foo(2)

"""
Traceback (most recent call last):
File
    foo(2)
File
    return 'hello' + name
TypeError: can only concatenate str (not "int") to str
"""
"""
但这是运行时的错误，也就是代码在执行时才会发现问题。最好是我们能在写完代码时就发现是否存在问题。因此就有了类型检查工具，比如mypy这样的工具，还有很多IDE也集成了这样的检查工具。
如果用mypy检查上面的代码就会得到如下提示:
t_t.py:5:error:Argument 1 to 'foo' has incompatible type 'init'; expected 'str'

有了Annotation的Python3显然是对Python大工程开发能力的增强，动态语言最大的弊端就是太灵活，当然这也是优点。不过对于有经验的开发来说，
避免去修改函数的输入和输出是重要的设计思想。对于以往的参数，因为没有类型信息，所以我们需要在函数内部去做各种判断，来保证数据类型符合预期。
"""
"""****************************************************************************************"""

# 2. overload存在的必要
"""
overload翻译过来是“重载”的意思，Java中有这样的两个概念，重写(override)和重载(overload)。重写其实是在保证输入和输出不变的情况下重写实现逻辑。
而重载则是允许修改输入和输出，即同一个方法名可以支持多种类型的输入和输出。

上面介绍了annotation能够声明类型，这样在执行时能发现错误，也能够在静态检查阶段发现错误。但是如果函数的参数确实需要多种类型呢？
不能因为静态类型的声明而导致动态易用性的损失吧。

因此有两种方案：

一、使用typing.TypeVar
二、使用typing.overload
"""
# 2.1 typing.TypeVar
"""对于固定数量参数的方法而言，同一个参数如果打算接受多种类型，可以这么用，比方说参数可以是:int, float, str："""
from typing import TypeVar
T = TypeVar('T', int, float, str)

def foo2(name:T) -> str:
    return 'hello' + str(name)
print(foo2(2))

"""这种方案更类似于静态语言中的interface的概念，定义一个通用的父类，这样的话，你可以传递子类型过去。"""

# 2.2: typing.overload:
@overload
def foo3(name, str) -> str:  ...
@overload
def foo3(name, float) -> str: ...
@overload
def foo3(name: int, age: int) -> str: ...

def foo3(name, age=18):
    return 'hello'+ str(name)
print(foo3(2, 20))

#help(overload)
"""
overload(func)
    Decorator for overloaded functions/methods.
    
    In a stub file, place two or more stub definitions for the same
    function in a row, each decorated with @overload.  For example:
    
      @overload
      def utf8(value: None) -> None: ...
      @overload
      def utf8(value: bytes) -> bytes: ...
      @overload
      def utf8(value: str) -> bytes: ...
    
    In a non-stub file (i.e. a regular .py file), do the same but
    follow it with an implementation.  The implementation should *not*
    be decorated with @overload.  For example:
    
      @overload
      def utf8(value: None) -> None: ...
      @overload
      def utf8(value: bytes) -> bytes: ...
      @overload
      def utf8(value: str) -> bytes: ...
      def utf8(value):
          # implementation goes here


Process finished with exit code 0

"""