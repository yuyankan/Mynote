"""二、timeit 模块
特点：准确测量小段代码的执行时间

timeit 模块中的三个函数：

1 timeit.timeit(stmt='pass', setup='pass', timer=<default timer>, number=1000000)：
创建一个Timer实例，参数分别是stmt（需要测量的语句或函数），setup（初始化代码或构建环境的导入语句），timer（计时函数），number（每一次测量中语句被执行的次数）

2.timeit.repeat(stmt='pass', setup='pass', timer=<default timer>, repeat=3, number=1000000)：
创建一个Timer实例，指定整个试验的重复次数，返回一个包含了每次试验的执行时间的列表，利用这一函数可以很方便得实现多次试验取平均的方法。

3. timeit.default_timer()：默认的计时器，一般是time.perf_counter()，
time.perf_counter()方法能够在任一平台提供最高精度的计时器（它也只是记录了自然时间，记录自然时间会被很多其他因素影响，例如计算机的负载）

"""
# ====Example1:timeit.default_timer()====
import timeit
print("\nExample1: timeit.default_timer()")
start = timeit.default_timer()
print("hi")
end = timeit.default_timer()
print("程序历时:end=timer() - start=timer():", end-start)

"""
Python3中的timeit模块可以用来测试小段代码的运行时间
其中主要通过两个函数来实现：timeit和repeat，代码如下：
"""
# ====Example2:timeit.default_timer()====


def timeit(stmt="pass", setup="pass", timer=timeit.default_timer, number=timeit.default_number, globals=None):
    """Convenience function to create Timer object and call timeit method"""
    return timeit.Timer(stmt, setup, timer, globals).timeit(number)

import timeit
def repeat(stmt="pass", setup="pass", timer=timeit.default_timer, repeat=timeit.default_repeat,
           number = timeit.default_number, globals=None ):
    """Convinence fcunction to create Timer object and call repeate method"""
    return timeit.Timer(stmt, setup, timer, globals).repeat(repeat, number)

"""
在上面的代码中可见，无论是timeit还是repeat都是先生成Timer对象，然后调用了Timer对象的timeit或repeat函数。
在使用timeit模块时，可以直接使用timeit.timeit()、timeit.repeat()，还可以先用timeit.Timer()来生成一个Timer对象，
然后再用Timer对象用timeit()和repeat()函数，后者再灵活一些。
"""
"""
上述两个函数的入参：
stmt：用于传入要测试时间的代码，可以直接接受字符串的表达式，也可以接受单个变量，也可以接受函数。传入函数时要把函数申明在当前文件中，然后在 stmt = func() 执行函数，然后使用setup = from __main__ import func
setup：传入stmt的运行环境，比如stmt中使用到的参数、变量，要导入的模块等。可以写一行语句，也可以写多行语句，写多行语句时要用分号；隔开语句。
number：要测试的代码的运行次数，默认100000次，对于耗时的代码，运行太多次会比较慢，此时建议自己修改一下运行次数
repeat：指测试要重复几次，每次的结果构成列表返回，默认3次。
"""

# ====Example2: 直接使用timeit.timeit()、tiemit.repeat()：====
print("*"*50)
print("\nExample2: 直接使用timeit.timeit()、tiemit.repeat()：")

print("\n2.1: Setup is simple: setup='normal_list=range(10000)' ")
print("timeit.timeit(): ", timeit.timeit(stmt="list(i**2 for i in normal_list)", setup="normal_list=range(10000)", number=10))
print("timeit.repeat(): repeat=2(2 time timeit.timeit()):", timeit.repeat(stmt="list(i**2 for i in normal_list)",
                                                                          setup="normal_list=range(10000)", repeat=2, number=10))
print("\n2.2: Setup is complicated: 复合语句：setup='a=10000,normal_list=range(a)'")
print("timeit.timeit(): ", timeit.timeit(stmt="list(i**2 for i in normal_list)", setup='a=10000; normal_list=range(a)', number=10))
print("timeit.repeat(): repeat=2(2 time timeit.timeit()):", timeit.repeat(stmt="list(i**2 for i in normal_list)",
                                                                          setup='a=10000; normal_list=range(a)', repeat=2, number=10))

def func_stmt():
    normal_list = range(10000)
    L = [i**2 for i in normal_list]

#stmt为函数
print("\n2.3: stmt为函数 func_stmt(), setup='from__main__import func_stmt'")
print("timeit.timeit(): ", timeit.timeit("func_stmt()", setup='from __main__ import func_stmt', number=10))
print("timeit.repeat(): repeat=2(2 time timeit.timeit()):", timeit.repeat("func_stmt()",
                                                                          setup='from __main__ import func_stmt', repeat=2, number=10))

"""直接用函数的方式，速度更快。"""

# ===Example3: 先生成Timer，再调用timeit()、repeat()：====
import timeit
print("\nExample3: 先生成Timer，再调用timeit()、repeat()：")
timer1 = timeit.Timer(stmt="list(i**2 for i in normal_list)", setup="normal_list=range(10000)")
print("3.1 created timer1:\ntimer1 = timeit.Timer(stmt='list(i**2 for i in normal_list)', setup='normal_list=range(10000)'):\n", timer1 )
print("\ncall timer1.timeit(number=10):", timer1.timeit(number=10))
print("call timer1.repeat(repeat=2, number=10):", timer1.repeat(repeat=2, number=10))
print("*"*50)

print("\n3.2: Setup is complicated: 复合语句：setup='a=10000,normal_list=range(a)' ", )
print("timer1_2 = timeit.Timer(stmt='list(i**2 for i in normal_list)', setup='a=10000; normal_list=range(a)'):")
timer1_2 = timeit.Timer(stmt="list(i**2 for i in normal_list)", setup="a=10000; normal_list=range(a)")
print(timer1_2)
print("\ncall timer1_2.timeit(number=10):", timer1_2.timeit(number=10))
print("call timer1_2.repeat(repeat=2, number=10):", timer1_2.repeat(repeat=2, number=10))

print("\n3.3: stmt为函数 func_stmt(), setup='from__main__import func_stmt'")
print("timer1_3 = timeit.Timer('func_stmt()', setup='from __main__ import func_stmt'):")
timer1_3 = timeit.Timer("func_stmt()", setup='from __main__ import func_stmt')
print("\ncall timer1.timeit(number=10):", timer1_3.timeit(number=10))
print("call timer1.repeat(repeat=2, number=10):", timer1_3.repeat(repeat=2, number=10))