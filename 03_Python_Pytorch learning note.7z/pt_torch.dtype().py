import torch
# help(torch.dtype)

"""
D:\software\envs\pytorch\python.exe "D:/Exersize/02_DATA LOADER/01_Data loader and dataset/Classification-Model-of-RMB-master/02_test_try/try2.py"
Help on class dtype in module torch:

class dtype(builtins.object)
 |  Methods defined here:
 |  
 |  __reduce__(...)
 |      Helper for pickle.
 |  
 |  __repr__(self, /)
 |      Return repr(self).
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  is_complex
 |  
 |  is_floating_point
 |  
 |  is_signed

"""
# 1. torch.complex():
"""
torch.complex(real, imag, *, out=None) → Tensor
Constructs a complex tensor with its real part equal to real and its imaginary part equal to imag.

Parameters
real (Tensor) – The real part of the complex tensor. Must be float or double.

imag (Tensor) – The imaginary part of the complex tensor. Must be same dtype as real.

Keyword Arguments
out (Tensor) – If the inputs are torch.float32, must be torch.complex64. If the inputs are torch.float64, must be torch.complex128.

Example:

>>> real = torch.tensor([1, 2], dtype=torch.float32)
>>> imag = torch.tensor([3, 4], dtype=torch.float32)
>>> z = torch.complex(real, imag)
>>> z
tensor([(1.+3.j), (2.+4.j)])
>>> z.dtype
torch.complex64
"""
## 2. torch.is_floating_point(input) -> (bool)
"""
Returns True if the data type of input is a floating point data type i.e., one of torch.float64, torch.float32, torch.float16, and torch.bfloat16.

Parameters
input (Tensor) – the input tensor.
"""
# 2,2 Tensor.is_floating_point() → bool
# Returns True if the data type of self is a floating point data type.

# 3. Tensor.is_signed() → bool
"""
Returns True if the data type of self is a signed data type. """