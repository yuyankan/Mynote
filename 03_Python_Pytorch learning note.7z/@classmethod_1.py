"""python @classmethod
 被@classmethod装饰的方法
1. 强制带个参数，cls，cls代表这个类本身
2. 不用实例化，和静态方法一样，直接 类().方法() 即可调用
3. cls是个位置参数，可随意换成其他词，如this
"""

""" 3 see below example3:
ython做面向对象编程时候，经常需要使用classmethod的描述。类方法特别容易弄混淆，因为听起来就好像“类中的方法”一样。
类方法也算一种实用的技巧，简单描述之：“类方法让类模板具有记忆力”。

类模板就是我们所定义的类。在普通情况下，不使用类方法对类进行实例化，类本身是不具有记忆性的。只是当一个静态模板被套用多次而已。
如果我们想让类在每一次实例化之后，都能记载一些记忆，是否会对很多操作很有用？
—
"""
#  ===Example1: 直接cls.x 获取类属性x的值 =====
""" 如想获取类属性x的值，可直接cls.x，等价于A.x"""
print('\nExample1： class attributes called by method of classmethod: ')
print("class attributes: {'x': 1, 'y': 'hi'},  classmethod: b(cls)\n")
class eg1():
    x = 1
    y= 'hi'
    @classmethod
    def b(cls):
        print("in def b(cls): print(cls.x): {}\n"
              "               print(cls.y): {}".format(cls.x, cls.y))
eg1.b()

#  ===Example2: cls(obj) 实例化class =====
""" 
已知cls代表类本身，那么cls(123),就等价于A(123),调用init初始化，实例化为x
cls(123) 等价于 x = A(123)"""

print("\nExample2: cls(obj) 实例化class: cls(obj) = class(obj)")
class eg2():
    def __init__(self,q):
        self.q = q

    @classmethod
    def b(cls):
        return cls(10)  #  cls(10) = eg2(10),

x = eg2.b()
print("classmethod: def b(cls): return cls(10);  cls(10) = class(obj): x = class.b() , equal x = class()")
print("type(x = class.b())", type(x))

# =====Example3: 类在每一次实例化之后，都能记载一些记忆 ======
"""
类方法也算一种实用的技巧，简单描述之：“类方法让类模板具有记忆力”。
类模板就是我们所定义的类。在普通情况下，不使用类方法对类进行实例化，类本身是不具有记忆性的。只是当一个静态模板被套用多次而已。
如果我们想让类在每一次实例化之后，都能记载一些记忆，是否会对很多操作很有用？
"""
print("\nExample3: 让类在每一次实例化之后，都能记载一些记忆：\n"
      ">>>: classmethod: id_number(cls): cls.id +=1 , return cls.id;\n"
      ">>>: __init__(self): call classmethod: self.id = self.id_numbe\n"
      ">>>:  class case a3=eg3(): 实例化class eg3 1次\n"
      ">>>:  class case b3=eg3(): 实例化class eg3 1次： ")
class eg3():
    id = 0 # 类变量
    def __init__(self):

        self.id = self.id_number()

    @classmethod
    def id_number(cls):
        cls.id +=1
        return cls.id  # cls.id:类方法处理的变量一定要是类变量。因为在类方法里你用不了self来寻址实例变量,
        # 所以需要把类变量放到最前面描述，如上面的"id=0"所示。

a3 = eg3()
print("\nclass eg3: id = 0-->first case a3: a3.id=:  ", a3.id)
b3 = eg3()
print("class eg3: id changed to 1 in a3 and kept in class eg3-->second case a3: b3.id=:  ", b3.id)
eg3() # init mehtod call again-->id change from 2 to 3
print("class eg3, id after two times casesed: eg3.id=:", eg3.id)

"""
需要注意的是，类方法处理的变量一定要是类变量。因为在类方法里你用不了self来寻址实例变量，所以需要把类变量放到最前面描述，如上面的"id=0"所示。
类变量是可以被self访问的，所以，在类变量定义好了以后，不需要在_init_函数里对类变量再一次描述。所以，上面代码里self.id不一定需要。
对于研究深度学习的朋友，可以有效利用这个trick，来进行模型的加载。比如，把模型封装成一个类，把初始化网络和加载模型用类方法来描述，这样一次load之后，可以一直实用模型

"""