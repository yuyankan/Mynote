import torch.overrides
"""
has_torch_function = _has_torch_function(...)
        Check for __torch_function__ implementations in the elements of an iterable.
        Considers exact ``Tensor`` s and ``Parameter`` s non-dispatchable.
        Arguments
        ---------
        relevant_args : iterable
            Iterable or aguments to check for __torch_function__ methods.
        Returns
        -------
        bool
            True if any of the elements of relevant_args have __torch_function__
            implementations, False otherwise.
        See Also
        ________
        torch.is_tensor_like
            Checks if something is a Tensor-like, including an exact ``Tensor``.
"""
import torch
from torch.overrides import _has_torch_function
x = [1, 2, 3]
x1 = {"1":2, "3": 4}
x0 = torch.tensor((2,1))

print(_has_torch_function(x))
print(_has_torch_function(x1))
print(_has_torch_function(x0))  # even torch. tensor has no _torch_function_()
print("*"*50)
print(any(type(t) is not torch.Tensor for t in x0))
print(any(type(t) is not torch.Tensor for t in x))
print(any(type(t) is not torch.Tensor for t in x1))

print("*"*50)
print("*"*50)
from torch.overrides import is_tensor_like

class TensorLike:
    print("test")
    def __torch_function__(self, func, types, args, kwargs):
        print("__torch_function is called")

        return 'hi'
    print("test2")


print(is_tensor_like(TensorLike())) # just check if have def_torch_funtion, will not go into it.
