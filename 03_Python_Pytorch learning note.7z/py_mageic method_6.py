# 创建描述符对象
"""
描述符是一个类，当使用取值，赋值和删除 时它可以改变其他对象。描述符不是用来单独使用的，它们需要被一个拥有者类所包含。描述符可以用来创建面向对象数据库，
以及创建某些属性之间互相依赖的类。描述符在表现具有不同单位的属性，或者需要计算的属性时显得特别有用（例如表现一个坐标系中的点的类，其中的距离原点的距离这种属性）。

要想成为一个描述符，一个类必须具有实现 __get__ , __set__ 和 __delete__ 三个方法中至少一个。

让我们一起来看一看这些魔法方法：

__get__(self, instance, owner)
定义当试图取出描述符的值时的行为。 instance 是拥有者类的实例， owner 是拥有者类本身。

__set__(self, instance, owner)
定义当描述符的值改变时的行为。 instance 是拥有者类的实例， value 是要赋给描述符的值。

__delete__(self, instance, owner)
定义当描述符的值被删除时的行为。 instance 是拥有者类的实例

"""
class Meter():
    '''米的描述符。'''
    def __init__(self, value = 0.0):
        self.value = float(value)

    def __get__(self, instance, owner):
        print('1.1 Meter__get__ is called')
        return self.value

    def __set__(self, instance, value):
        print('1.2 Meter__set__ is called')
        self.value = float(value)

class Foot():
    '''英尺的描述符。'''
    def __get__(self, instance, owner):
        print('2.1 Foot__get__ is called')
        return instance.meter*3.2808

    def __set__(self, instance, value):
        print('2.2 Foot__get__ is called')
        instance.meter = float(value)/3.2808

class Distance():
    '''用于描述距离的类，包含英尺和米两个描述符。'''
    meter = Meter()  # ()代表函数， Meter代表名字/属性
    foot = Foot()

if __name__ == '__main__':
    d = Distance()
    d.meter = 100
    print(d.meter)
    print(d.foot)