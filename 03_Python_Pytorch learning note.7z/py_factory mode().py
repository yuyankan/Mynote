
# 简单工厂模式（python版）

#1.  什么是简单工厂模式
"""
工厂模式有一种非常形象的描述，建立对象的类就如一个工厂，而需要被建立的对象就是一个个产品；在工厂中加工产品，使用产品的人，不用在乎产品是如何生产出来的。
从软件开发的角度来说，这样就有效的降低了模块之间的耦合。

简单工厂的作用是实例化对象，而不需要客户了解这个对象属于哪个具体的子类。简单工厂实例化的类具有相同的接口或者基类，在子类比较固定并不需要扩展时，
可以使用简单工厂。如数据库生产工厂就是简单工厂的一个应用

采用简单工厂的优点是可以使用户根据参数获得对应的类实例，避免了直接实例化类，降低了耦合性；缺点是可实例化的类型在编译期间已经被确定，如果增加新类 型，
则需要修改工厂，不符合OCP（开闭原则）的原则。简单工厂需要知道所有要生成的类型，当子类过多或者子类层次过多时不适合使用。

"""

# 2. 简单工厂模式实现
"""
下面考虑《大话设计模式》中的一个例子：
题目：用任意一种面向对象语言实现一个计算器控制台程序。要求输入两个数和运算符号，得到结果。
"""
#2.1 题目分析：
"""
 程序应该做到：（1）可维护；（2）可复用；（3）可扩展；（4）灵活性好。
可维护：就是说代码一处更改，不能产生连锁反应，不能影响其他地方。
可复用：尽量减少重复性代码。
可扩展：如果要扩展新的功能、新的业务，则只需要增加新的类就好了，不对已有的类和逻辑产生影响。插拔式的应用。

面向对象要点：
面向对象三大特性：封装、继承、多态。
通过封装、继承、多态把程序耦合降低。
业务逻辑和界面逻辑分开。

"""
# 2.2 类的结构图：
"""
(1): 简单工厂类: +createOperate(): 运算类 --->
(2): 运算类:  + NumberA: double; + numberB: double;  + GetResult (): double <-------------
(3):   >>> 加法类： + GetResult (): double     >>> 减法类： + GetResult (): double
       >>> 乘法类： + GetResult (): double     >>> 除法类： + GetResult (): double
"""

# 2.3 代码实现：
"""
(1). 首先，搞清楚业务中容易发生变化的部分。在本应用中，要求计算两个数的运算结果，那么要进行什么样的运算，这就是一个容易发生变化的部分。
例如，我们现在只想实现加减乘除运算，后期又想增加开根或者求余运算。那么如何应对这种需求带来的变化。在程序设计的时候就应该考虑到程序的可维护性、可扩展性、代码的可复用性、灵活性等等。
 
(2). 例如现在这个运算器只有加减乘除四种运算。首先建一个Operation类，这个类是各种具体运算类（加减乘除）的父类，主要是接受用户输入的数值。该类如下：

class Operation():
	def __init__(self,NumberA=0,NumberB=0):
		self.NumberA = NumberA
		self.NumberB = NumberB
 
	def GetResult(self):
		pass

"""
"""
(3). 然后是具体的运算类：Add、Sub、Mul、Div。他们都继承了Operation类，并且重写了getResult()方法。这样就可以用多态性降低不同业务逻辑的耦合度，
修改任何一种运算类都不会影响其他的运算类。具体类的代码如下:

class AddOp(Operation):
	def GetResult(self):
		return self.NumberB + self.NumberA
 
class MinusOp(Operation):
	def GetResult(self):
		return self.NumberA - self.NumberB
 
class MultiOp(Operation):
	def GetResult(self):
		return self.NumberA * self.NumberB
 
class DivideOp(Operation):
	def GetResult(self):
		try:
			return 1.0*self.NumberA / self.NumberB
		except ZeroDivisionError:
"""

"""
(4).  那么如何让计算器知道我是要用哪一种运算呢？也就是说到底要实例化哪一个具体的运算类，Add？Sub？Mul？Div？这时就应该考虑用 一个单独的类来做这
个创造具体实例的过程，这个类就是工厂类。如下：

class OperationFatory():
	def ChooseOperation(self,op):
		if op == '+':
			return AddOp()
		if op == '-':
			return MinusOp()
		if op == '*':
			return MultiOp()
		if op == '/':
			return DivideOp()
"""

"""
(5) 这样，用户只要输入运算符，工厂类就可以创建合适的实例，通过多态性，即返回给父类的方式实现运算结果。客户端代码如下：

if __name__ == '__main__':
	ch = ''
	while not ch=='q': 
		NumberA = eval(raw_input('Please input number1:  '))
		op = str(raw_input('Please input the operation:  '))
		NumberB = eval(raw_input('Please input number2:  '))
		OPFactory = OperationFatory()
		OPType = OPFactory.ChooseOperation(op)
		OPType.NumberA = NumberA
		OPType.NumberB = NumberB
		print 'The result is:',OPType.GetResult()
		print '\n#--  input q to exit any key to continue'
		try:
			ch = str(raw_input())
		except:

"""

# 完整版代码如下：

class Operation():
    def __init__(self, NumberA=0, NumberB=0):
        self.NumberA = NumberA
        self.NumberB = NumberB

    def GetResult(self):
        pass

class AddOp(Operation):
    def __init__(self):
        super(AddOp, self).__init__()

    def GetResult(self):
        print(self.NumberA)
        print(self.NumberB)
        return self.NumberA + self.NumberB

class MinusOp(Operation):
    def __init__(self):
        super(MinusOp, self).__init__()
    def GetResult(self):
        return self.NumberA - self.NumberB

class MultiOp(Operation):
    def __init__(self):
        super(MultiOp, self).__init__()
    def GetResult(self):
        return self.NumberA * self.NumberB

class DividOp(Operation):
    def __init__(self):
        super(DividOp, self).__init__()
    def GetResult(self):
        try:
            return 1.0*self.NumberA / self.NumberB
        except ZeroDivisionError:
            raise

class OperationFatory():
    def ChooseOperation(self, op1):
        if op1 == "+":
            return AddOp
        if op1 =='-':
            return MinusOp
        if op1 == '*':
            return MultiOp
        if op1 == '/':
            return DividOp

if __name__ == '__main__':
    ch = ''
    while not ch == 'q':
        NumberA = eval(input("Please input number1: ")) # eval()-->去掉""

        op = str(input("Please input the operation: "))
        NumberB = eval(input("Please input number2: "))

        OPFactory = OperationFatory()
        OPType = OPFactory.ChooseOperation(op)() # '()' needed to be a 实例!!!!

        OPType.NumberA = NumberA
        OPType.NumberB = NumberB

        t = OPType.GetResult()
        print("The result is : ", t)
        print("\n--input q to exist, any key to continue: ")
        try:
            ch = str(input())
        except:
            ch =''