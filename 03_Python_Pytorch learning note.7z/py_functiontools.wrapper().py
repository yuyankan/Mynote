import functools
#help(functools)

# 1：装饰器是干什么用的？
""" 为了对一个函数在运行期的功能的拓展  """
#2：装饰器加上之后产生的问题：
""" 
解释器认为函数本身发生了改变，其函数本身的属性改变了，在某些情况下——比如测试时——会导致一些问题
Python 通过 functool.wraps 为我们解决了这个问题：在编写装饰器时，在实现前加入 @functools.wraps(func) 可以保证装饰器不会对被装饰函数造成影响。
"""
# 3：Flask 官方示例：
from functools import wraps
from flask import g, request, redirect, url_for

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if g.user is None:
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)

    return decorated_function

@login_required
def secret_page():
    pass

#： detail process:
"""
1. @login_required:  def secret_page -->deliver to def login_required as parameter f-->
2  @wraps(f): 
    2.1: wraps(f): returned a new function: wrapper:
        2.1.1: method wraps  'return functools.partial(update_wrapper, wrapped=wrapped, assigned=assigned, updated=updated)'
            ->get : def update_wrapper(wrapper)
    2.2:  def decorated_function: deliver to def update_wrapper(wrapper) as parameter wrapper: 
                -->1. Attr.: 复制引用: WRAPPER_ASSIGNMENTS : from wrapped: def secret_page
                -->2. Attr.: wrapper.__dict__: updated as new： different from wrapped: def secret _page
3.: def login_required: returned this wrapper to def secret_page
"""

# 4：详解
"""
当装饰器装饰一个函数时，实际上就是将被装饰的函数作为一个参数传入装饰器函数，返回一个闭包，而闭包内部调用这个函数，再另外多做一些事情。
然后再由我们的函数名字去接收那个返回值的闭包的引用，达到了我们装饰的目的，所以此时，我们的函数的__name__等属性其实已经改变，变成了我们闭包的私有属性。

functools.wraps()这个函数，作为一个装饰器去!!装饰闭包!!，并且给这个装饰器传入一个参数，这个参数是闭包外的装饰器装饰的那个外部的被装饰函数，
此时，外部我们的自定义的函数的私有属性如__name__、__doc__等还是为我们自定义的函数本身的私有属性，而不会变成闭包的私有属性。

"""
#5：反正记住写装饰器的时候，最好是加上@wraps(f)，这样可以在扩展函数功能的同时，保留原有函数的各种属性。


"""
update_wrapper(wrapper, wrapped, assigned=('__module__', '__name__', '__qualname__', '__doc__', '__annotations__'), updated=('__dict__',))
        Update a wrapper function to look like the wrapped function
        
        wrapper is the function to be updated
        wrapped is the original function
        assigned is a tuple naming the attributes assigned directly
        from the wrapped function to the wrapper function (defaults to
        functools.WRAPPER_ASSIGNMENTS)
        updated is a tuple naming the attributes of the wrapper that
        are updated with the corresponding attribute from the wrapped
        function (defaults to functools.WRAPPER_UPDATES)
    
    wraps(wrapped, assigned=('__module__', '__name__', '__qualname__', '__doc__', '__annotations__'), updated=('__dict__',))
        Decorator factory to apply update_wrapper() to a wrapper function
        
        Returns a decorator that invokes update_wrapper() with the decorated
        function as the wrapper argument and the arguments to wraps() as the
        remaining arguments. Default arguments are as for update_wrapper().
        This is a convenience function to simplify applying partial() to
        update_wrapper().
"""

################################################################################
### update_wrapper() and wraps() decorator
################################################################################

# update_wrapper() and wraps() are tools to help write
# wrapper functions that can handle naive introspection
import functools
WRAPPER_ASSIGNMENTS = ('__module__', '__name__', '__qualname__', '__doc__',
                       '__annotations__')
WRAPPER_UPDATES = ('__dict__',)
def update_wrapper(wrapper,
                   wrapped,
                   assigned = WRAPPER_ASSIGNMENTS,
                   updated = WRAPPER_UPDATES):
    """Update a wrapper function to look like the wrapped function

       wrapper is the function to be updated
       wrapped is the original function
       assigned is a tuple naming the attributes assigned directly
       from the wrapped function to the wrapper function (defaults to
       functools.WRAPPER_ASSIGNMENTS)
       updated is a tuple naming the attributes of the wrapper that
       are updated with the corresponding attribute from the wrapped
       function (defaults to functools.WRAPPER_UPDATES)
    """
    for attr in assigned: # warppered object/instance's attribute, deepcopy/shallow copy? to warpper attr.
        try:
            value = getattr(wrapped, attr)
        except AttributeError:
            pass
        else:
            setattr(wrapper, attr, value) # --> wrapper.__dict__['attr'] = value: 复制引用
    for attr in updated: # wrappered object, __dict__--->deepcopy to wrapper object
        getattr(wrapper, attr).update(getattr(wrapped, attr, {}))
    # Issue #17482: set __wrapped__ last so we don't inadvertently copy it
    # from the wrapped function when updating __dict__
    wrapper.__wrapped__ = wrapped # copy wrappered as __warapped__mehtod of wrapper function
    # Return the wrapper so this can be used as a decorator via partial()
    return wrapper

def wraps(wrapped,
          assigned = WRAPPER_ASSIGNMENTS,
          updated = WRAPPER_UPDATES):
    """Decorator factory to apply update_wrapper() to a wrapper function

       Returns a decorator that invokes update_wrapper() with the decorated
       function as the wrapper argument and the arguments to wraps() as the
       remaining arguments. Default arguments are as for update_wrapper().
       This is a convenience function to simplify applying partial() to
       update_wrapper().
    """
    return functools.partial(update_wrapper, wrapped=wrapped,
                   assigned=assigned, updated=updated)
    # return function: updated_wrapper, with updated defaul parameter:wrapped, assigned, updated;
"""
functools 中Partial可以用来改变一个方法默认参数
1 改变原有默认值参数的默认值
2 给原来没有默认值的参数增加默认值
"""

