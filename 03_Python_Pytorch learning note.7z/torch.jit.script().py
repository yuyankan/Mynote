"""script能够处理Module模型中的控制流。
3、trace、script混合方法转换模型
a)、trace和script针对的都是torch.nn.Module类对象及其子类对象
b)、在创建Module对象时就可以使用trace或者script，并根据具体的Module代码逻辑选择使用trace还是script
c)、trace里面可以包含script，script里面也可以包含trace
d)、如果Module中包含if分支或者loop循环处理，则使用script进行转换，否则使用trace进行转换
"""
import torch
print("Example1: script: for if , else:")
class eg2_d(torch.nn.Module):  # super class have to be torch.nn.Module
    def forward(self, x):
        print("forward test")
        if x.sum() > 0:
            return x
        else:
            return -x


class eg2(torch.nn.Module):
    def __init__(self, dg):
        super(eg2, self).__init__()
        print("1.__init__")
        self.dg = dg

        self.linear = torch.nn.Linear(4, 4)

    def forward(self, x, h):
        print("2.1 forward()")
        new_h = torch.tanh(self.linear(self.dg(x)) + h)
        print("2.2 forward()")
        return new_h


dg = eg2_d()
eg2_c = eg2(dg)  # 实例化without parameter(x,h)??
x2 = torch.ones(3, 4)  # x 是一个3 x 4的全1单位矩阵，所以 x .sum() > 0 必然成立
h2 = torch.ones(3, 4)
# 对模型进行trace转换，trace 方法把eg2_c模型在当前的x和h上执行一遍
# 因为 x .sum() > 0 成立，所以现在MyDecisionGate的forward执行if分支，返回x本身，else分支没有执行
script_eg2_c = torch.jit.script(eg2_c, (x2, h2))  # why print "forward test " 3 times???
print("1.1: code of judge conditions after script: traced_eg2_c.dg.code:\n", script_eg2_c.dg.code)
print("1.2: code of class case use judge conditions after script: traced_eg2_c.code:\n", script_eg2_c.code)

"""RUN Result:
def forward(self,
    x: Tensor) -> Tensor:
  print("forward test")  # "record print info. & else code"!!!
  if bool(torch.gt(torch.sum(x), 0)):
    _0 = x
  else:
    _0 = torch.neg(x)
  return _0
**************************************
traced_eg2_c.code:
 def forward(self,
    x: Tensor,
    h: Tensor) -> Tensor:
  print("2.1 forward()")
  _0 = (self.linear).forward((self.dg).forward(x, ), )
  new_h = torch.tanh(torch.add(_0, h))
  print("2.2 forward()")
  return new_h

"""
# 查看模型推理结果，traced_eg2_c与eg2_c的计算结果相同
print("\n1.3:查看模型推理结果，script_eg2_c与eg2_c的计算结果相同:\n")
print("script_eg2_c(x2, h2):\n")
print(script_eg2_c(x2, h2))
print("*"*50)
print("eg2_c(x2, h2):\n")
print(eg2_c(x2, h2))

# Example3： script for if-else, while trace for coding without if-else

"""
    1、MyDecisionGate是Module的子类，并且其中包含if分支语句，所以要使用script方法进行转换
    2、MyCell_v2是Module的子类，虽然其中包含的MyDecisionGate中包含if分支，但是已经经过script方法转换了，所以对MyCell_v2使用trace方法进行转换
    3、MyRNNLoop_TraceScript是Module的子类，并且其中包含for循环，所以要使用script方法进行转换
"""
"""
script_eg2_d = torch.jit.script(eg2_d())
eg3_c = eg2(script_eg2_d)
traced_eg3_c = torch.jit.trace(eg3_c, (x2, h2))
"""

# Example4: trace、script转换模型性能测试对比
"""
print("Example4: trace、script转换模型性能测试对比")
class eg4(torch.nn.Module):
    x2 = torch.ones(3, 4)
    h2 = torch.ones(3, 4)
    def __init__(self):
        super(eg4, self).__init__()
        self.cell = torch.jit.trace(eg2(torch.jit.script(eg2_d())),(x, h))


    def forward(self,xs):

        h = torch.ones(3, 4)
        y = torch.zeros(3, 4)
        for i in range(xs.size[0]):
            y, h = self.cell(xs[i], h)
        return y,h

rnn_loop = torch.jit.script(eg4())
print(rnn_loop.code)
"""
from timeit import default_timer as timer
trace_script_eg4_c = torch.jit.trace(eg2(torch.jit.script(eg2_d())),(x2, h2))
start2 = timer()
trace_script_eg4_c(x2, h2)
end2 = timer()
print("trace_script timine:\n", end2-start2)
start3 = timer()
eg2_c(x2, h2)
end3 = timer()
print("orgianl code timing:\n", end3-start3)
