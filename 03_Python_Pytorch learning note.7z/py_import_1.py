 # 1. python 模块相互import
"""
 模块A中import B，而在模块B中import A。这时会怎么样呢？这个在Python列表中由RobertChen给出了详细解释，抄录如下：
 """
# [py_import_1.py]: A
from py_import_2 import D
#import py_import_2
class C: pass

"""
ImportError: cannot import name 'D' from partially initialized module 'py_import_2' (most likely due to a circular import) 
"""

"""**************************************************************************************************************"""
#为什么执行A的时候不能加载D呢？如果将A.py改为：import B就可以了

""" # 1.normal: from B import D:
RobertChen：这跟Python内部import的机制是有关的，具体到from B import D，Python内部会分成几个步骤：

1.在sys.modules中查找符号”B”

2.如果符号B存在，则获得符号B对应的module对象< module B>。
    2.1 从 < module B> 的__ dict__中获得符号”D”对应的对象，如果”D”不存在，则抛出异常

3.  如果符号B不存在，则创建一个新的module对象< module B>，注意，这时，module对象的__ dict__为空。
    3.1 执行B.py中的表达式，填充的__dict__ 。
    3.2 从< module B>的__ dict__中获得”D”对应的对象，如果”D”不存在，则抛出异常。

"""
# 2.  [py_import_1.py]: from py_import_2 import D
# note: [py_import_1.py]->A, [py_import_2.py]-> as B.
"""
1、执行A.py中的from B import D

由于是执行的python A.py，所以在sys.modules中并没有< moduleB>存在，首先为B.py创建一个module对象(< moduleB>)，
注意，这时创建的这个module对象是空的，里边啥也没有，在Python内部创建了这个module对象之后，就会解析执行B.py，其目的是填充< module B>这个dict。

2、执行B.py中的from A import C
在执行B.py的过程中，会碰到这一句，首先检查sys.modules这个module缓存中是否已经存在< moduleA>了，
由于这时缓存还没有缓存，所以类似的，Python内部会为A.py创建一个module对象(< moduleA>)，然后，同样地，执行A.py中的语句。

3、再次执行A.py中的from B import D

这时，由于在第1步时，创建的< moduleB>对象已经缓存在了sys.modules中，所以直接就得到了< moduleB>，
但是，注意，从整个过程来看，我们知道，这时< moduleB>还是一个空的对象，里面啥也没有，所以从这个module中获得符号”D”的操作就会抛出异常。

如果这里只是importB，由于”B”这个符号在sys.modules中已经存在，所以是不会抛出异常的。
"""