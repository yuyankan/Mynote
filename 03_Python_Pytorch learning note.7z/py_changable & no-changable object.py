"""
pyhon中可变对象和不可变对象:

根据实际参数的类型不同，可以分为将实际参数的值传递给形式参数和将实际参数的引用传递给形式参数两种。其中:
1. 当实际参数为不可变对象时，进行的是值传递，也就是改变形式参数的值，实际参数的值不变； id(object-no changeble)-->实际参数 = value of id(object)
if 实际参数改变， id (实际参数）改变
2. 当实际参数为可变对象时，进行的是引用传递，也就是改变形式参数的值，实际参数的值也一同改变。id（object-changable) = 实际参数 = 形式参数

"""
# 一.函数值传递和引用传递
def test(obj): # obj为形参
    print('形式参数 obj及其id:', obj, id(obj))
    obj += obj # +=-->value of id(obj) change?
    print('改变形式参数后 obj及其id:', obj, id(obj))

#case1:


s = 'Hi'  # s 为实参； ’Hi' 为 object; string 是不可变对象
print("\n1. string id(s='Hi'):", id(s))
print("\n1.1: first call")
test(s) # RUN result: Hi;
# obj = ['Hi', 'Hi']-->id(obj = ['Hi', 'Hi']) ! = id(obj = ['Hi'])
print("\n1.2: second call:")
test(s) # RUN result: Hi; 再次调用，obj-->s value, still 'Hi'

#case2 :
list_2 = ['Hello', 'world']
print("\n2. List id(list_2 = ['Hello', 'world']: ", id(list_2))
print("\n2.1: first call:")
test(list_2) # RUN result: ['Hello', 'world']
print("\n2.2: second call:")
test(list_2) # RUN result: ['Hello', 'world', 'Hello', 'world']

# list object is changable: obj = list_2 = ['Hello', 'world']-->
# id(obj) = id(list-2) = id(['Hello', 'world']), change any value of them, id value changed-->all three object value change

"""由上面例子可以发现：
值传递没有改变实参，仅仅改变了形参；但是引用传递不仅改变了形参，也改变了实参。
所以我认为默认参数必须指向不可变对象也是这个原因，不然每次调用结果都不一样岂不是出大问题了，不会报错，但结果却是错的。
"""

#不可变对象：
"""
该对象所指向的内存中的值不能被改变。所以改变某个变量时，是把原来的值复制一份后再改变，也就是又用了一个新地址，变量指向这个新的地址。比如：
数值类型(int和float)、字符串str、元组tuple
"""
"""
举例：（以字符串为例，数值类型类似）"""
s = 'po'
print("\nid(s='po'): ", id(s))
s = s + 'you' # 修改值， 赋予新的内存id
print("id(s = s + 'you')", id(s))

s2 = 'po'
s3 = s + ''
print(id(s2), id(s3)) # s2,s3 id 不变
"""--> 改变字符串值时，内存地址发生了变化。"""

# 元组tuple需要单独说一下，稍微有些不一样：
print("\ntuple id: ")
t = (5, 2, 0)
t2 = (5, 2, 0)
t3 = t+()
print(id(t), id(t2), id((5, 2, 0)), id(t3))  # same id??
t4 = t + (4, 5, 6)
print(id(t4))


# 可变对象：
"""
该对象所指向的内存中的值可以被改变。所以改变某个变量时，是原来的值直接发生改变，并没有复制一份到新地址这样的操作。比如列表list、字典dict、集合set。
"""
print("\nstring id: ")
print(id([5, 2, 2]))
list1 = [5, 2, 0]
list2 = [5, 2, 0]
print(id([5, 2, 0]), id(list1), id(list2) )
print(list1)
print(id([5, 2, 2]))
"""相同内容， 不同变量名，内存地址不一样"""
list3 = [5, 2, 1]
list4 = list3
print("id list3 = list4:", id(list3),id(list4))
list4 = [5, 5, 5]
print("change list4 value: id(list4):",id(list4), id(list3))

# 可以发现在修改列表值时列表在原地址内容被直接修改。那我们有时候不想直接修改呢？毕竟这是直接被取代了，有点粗暴。没有关系，列表还有复制操作，
list5 = list4[:]
print("id: list5 = list4[:]:", id(list5), id(list4))
