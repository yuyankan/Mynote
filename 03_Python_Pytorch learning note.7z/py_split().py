
# python中split()函数讲解
"""
本文讲述的是string.split(s[, sep[, maxsplit]])，针对string类型的split()函数。它主要是切割字符串，结果返回由字符串元素组成的一个列表，具体怎么使用看下面的代码。
"""

# 1. 无参数的情况:
# 当没有参数的情况下，函数默认会以空格，回车符，空格符等作为分割条件。
"""
a="my name is zhangkang"
b="my\nname\nis\nzhangkang"
c="my\tname\tis\tzhangkang"

a=a.split()
b=b.split()
c=c.split()

print(a)
print(b)
print(c)

输出：
['my', 'name', 'is', 'zhangkang']
['my', 'name', 'is', 'zhangkang']
['my', 'name', 'is', 'zhangkang']
"""

# 2. 有参数的情况
#函数会以参数为分割条件，把字符串进行分割，得到的每个分割段作为列表的元素返回。
"""
d="my,name,is,zhangkang"
e="my;name;is;zhangkang"
f="my-name-is-zhangkang"

d=d.split(",")
e=e.split(";")
f=f.split("-")

print(d)
print(e)
print(f)

输出：
['my', 'name', 'is', 'zhangkang']
['my', 'name', 'is', 'zhangkang']
['my', 'name', 'is', 'zhangkang']

"""
# 3. 当具有两个参数的情况
# 第二个参数的意思是你想分多少次，，b1,b2,b8都好理解。有人可能会问b9那个是怎么回事，最大只能分成9段呀，分8次就行了。没错，但是当分第8次的时候，
# 最后一个分割段是”student”,再对“student”进行条件为“，”分割的时候是分不了的，也就是说还是原来的字符串不动。
# 意思就是第二个参数值超过最大分割次数其实是没有意思的，不过程序不会报错！

"""
a="My,name,is,zhangkang,and,I,am,a,student"
b1=a.split(",",1)
b2=a.split(",",2)
b8=a.split(",",8)
b9=a.split(",",9)

print(b1)
print(b2)
print(b8)
print(b9)

输出：
['My', 'name,is,zhangkang,and,I,am,a,student']
['My', 'name', 'is,zhangkang,and,I,am,a,student']
['My', 'name', 'is', 'zhangkang', 'and', 'I', 'am', 'a', 'student']
['My', 'name', 'is', 'zhangkang', 'and', 'I', 'am', 'a', 'student']
"""
