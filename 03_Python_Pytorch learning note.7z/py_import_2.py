 # 1. python 模块相互import

# [py_import_2.py]
from py_import_1 import C
class D: pass
