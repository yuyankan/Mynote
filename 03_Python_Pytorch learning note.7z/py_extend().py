
# python语法中，extend命令和append命令的区别。
#
# append命令是将整个对象加在列表末尾；
# 而extend命令是将新对象中的元素逐一加在列表的末尾。总的来说，append命令可以添加单个元素，也可以添加可迭代对象；而extend命令只能添加可迭代对象。
a = [1]
a1 = a.append
a2 = a.extend
t=[3, 4, 5]

print(a)
a1(t)
print(a)
a2(t)
print(a)



