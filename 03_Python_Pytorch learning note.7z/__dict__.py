"""
__dict__属性总结
1.类__dict__属性中包括类属性，类方法（非系统默认的，修改过的__init__()等，自己写的静态非静态方法），包括它实例化对象的方法
2.对象的属性就是__init__方法中带有的属性，子类默认继承父类__init__时候，子类创建对象的属性与父类一致，取决于你是否重写__init__属性，你可以尝试在子类重写__init__方法，并修改属性
3.可以通过操作对象__dict__属性来获取对象的属性。有时候会用到
由此可见， 类的静态函数、类函数、普通函数、全局变量以及一些内置的属性都是放在类__dict__里的,
对象的__dict__中存储了一些self.xxx的一些东西
4. 内置的数据类型没有__dict__属性
"""

"""__dict__属性:
1. 类__dict__属性：
>>>包括： 静态函数，类函数， 普通函数
>>>全局变量，一些内置属性

2.类对象__dic__属性：
>>>存储了一些self.xxx的东西{’a': 2, 'b':3, 'name':'lhh'}
>>> 父类子类对象共用__dict__  但是如果子类对象额外再添加属性(非init方法中添加)

3.是一个字典里面存放数据

4. 一些内置的数据类型没有__dict__属性：
    in, list, dict 等这些常用的数据类型是没有dict 属性
    
5. 继承的时候__dict__属性 
>>> 每个类的类变量，函数名都放在自己的__dict__中
>>> 实例变量的__dict__中 父类和子类对象的__dict__是公用的

"""

# ==example ==
class eg1():
    a1 = 0  # 全局变量eg1.__dict__: 中a1 = 0, not self.a1 =2: dict中是全局变量
    name = None
    b1 = 1
    def __init__(self,name): # self.xxx存储在类对象__dict__属性
        self.a1 = 2
        self.b1 = 3
        self.name = name
    def test (self):
        print('a normal func.')

class eg2(eg1):

    def test_2(self):
        print('func named test_2')

class eg3(eg1):
    a3 = 'Test: eg3'
    def __init__(self):
        self.a1 = 'new __init__in eg3: a1'
        self.b1 = 'new __init__in eg3: b1'

obj1 = eg1('Hi')
obj2 = eg2('World') #父类和子类对象的__dict__是公用的(子类不新建属性): obj1.__dict__ = obj2.__dict__
obj3 = eg3 ()  #父类和子类对象的__dict__不是公用的(子类新建属性: 全局属性a3,initi 属性： ): obj1.__dict__ != obj2.__dict__

print("\nExample1: base class and base class case:.__dict__:\n"
      "base class eg1, class cases obj1 = eg1('Hi'):")
print("1.1 base class eg1.__dict__: \n", eg1.__dict__)
print("\n1.2 base class case obj1=eg1().__dict__:\n", obj1.__dict__)

print("\nBase class case attributes' key : obj1.__dict__={}是个字典:")
for key, value in obj1.__dict__.items():
    print(key, value)

print("\nExample2: subclass without new attributes/__init__ and subclass case: __dict__:\n"
      "sub class eg2(eg1), sub class cases obj2 = eg2('world'):")
print("2.1 sub class eg2.__dict__: \n", eg2.__dict__)
print("\n2.2 sub class case obj2=eg2('world').__dict__:\n", obj2.__dict__)
print("父类和子类对象的__dict__是公用的: obj1.__dict__ == obj2.__dict__:", obj1.__dict__==obj2.__dict__)

print("\nExample3: subclass with new attributes : global attributes and__init__ and subclass case: __dict__:\n"
      "sub class eg3(eg1), sub class cases obj3 = eg3():")
print("3.1 sub class eg3(eg1).__dict__:\n", eg3.__dict__)
print("\b3.2 sub class case: obj3=eg3().__dict__: new self.xxx defined in eg3()\n", obj3.__dict__)




