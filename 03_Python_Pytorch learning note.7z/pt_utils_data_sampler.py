from torch.utils import data
# help(data)
help(data.sampler)
import torch
from torch import Tensor

from typing import Iterator, Optional, Sequence, List, TypeVar, Generic, Sized

T_co = TypeVar('T_co', covariant=True)

class Sampler(Generic[T_co]):
    r"""Base class for all Samplers.

    Every Sampler subclass has to provide an :meth:`__iter__` method, providing a
    way to iterate over indices of dataset elements, and a :meth:`__len__` method
    that returns the length of the returned iterators.

    .. note:: The :meth:`__len__` method isn't strictly required by
              :class:`~torch.utils.data.DataLoader`, but is expected in any
              calculation involving the length of a :class:`~torch.utils.data.DataLoader`.
    """

    def __init__(self, data_source: Optional[Sized]) -> None:
        pass

    def __iter__(self) -> Iterator[T_co]:
        raise NotImplementedError

    # NOTE [ Lack of Default `__len__` in Python Abstract Base Classes ]
    #
    # Many times we have an abstract class representing a collection/iterable of
    # data, e.g., `torch.utils.data.Sampler`, with its subclasses optionally
    # implementing a `__len__` method. In such cases, we must make sure to not
    # provide a default implementation, because both straightforward default
    # implementations have their issues:
    #
    #   + `return NotImplemented`:
    #     Calling `len(subclass_instance)` raises:
    #       TypeError: 'NotImplementedType' object cannot be interpreted as an integer
    #
    #   + `raise NotImplementedError()`:
    #     This prevents triggering some fallback behavior. E.g., the built-in
    #     `list(X)` tries to call `len(X)` first, and executes a different code
    #     path if the method is not found or `NotImplemented` is returned, while
    #     raising an `NotImplementedError` will propagate and and make the call
    #     fail where it could have use `__iter__` to complete the call.
    #
    # Thus, the only two sensible things to do are
    #
    #   + **not** provide a default `__len__`.
    #
    #   + raise a `TypeError` instead, which is what Python uses when users call
    #     a method that is not defined on an object.
    #     (@ssnl verifies that this works on at least Python 3.7.)


class SequentialSampler(Sampler[int]):
    r"""Samples elements sequentially, always in the same order.

    Args:
        data_source (Dataset): dataset to sample from
    """
    data_source: Sized

    def __init__(self, data_source: Sized) -> None:
        self.data_source = data_source

    def __iter__(self) -> Iterator[int]:
        return iter(range(len(self.data_source)))

    def __len__(self) -> int:
        return len(self.data_source)


class RandomSampler(Sampler[int]):
    r"""Samples elements randomly. If without replacement, then sample from a shuffled dataset.
    If with replacement, then user can specify :attr:`num_samples` to draw.

    Args:
        data_source (Dataset): dataset to sample from
        replacement (bool): samples are drawn on-demand with replacement if ``True``, default=``False``
        num_samples (int): number of samples to draw, default=`len(dataset)`. This argument
            is supposed to be specified only when `replacement` is ``True``.
        generator (Generator): Generator used in sampling.
    """
    data_source: Sized
    replacement: bool

    def __init__(self, data_source: Sized, replacement: bool = False,
                 num_samples: Optional[int] = None, generator=None) -> None:
        self.data_source = data_source
        self.replacement = replacement
        self._num_samples = num_samples
        self.generator = generator

        if not isinstance(self.replacement, bool):
            raise TypeError("replacement should be a boolean value, but got "
                            "replacement={}".format(self.replacement))

        if self._num_samples is not None and not replacement:
            raise ValueError("With replacement=False, num_samples should not be specified, "
                             "since a random permute will be performed.")

        if not isinstance(self.num_samples, int) or self.num_samples <= 0:
            raise ValueError("num_samples should be a positive integer "
                             "value, but got num_samples={}".format(self.num_samples))

    @property
    def num_samples(self) -> int:
        # dataset size might change at runtime
        if self._num_samples is None:
            return len(self.data_source)
        return self._num_samples

    def __iter__(self) -> Iterator[int]:
        n = len(self.data_source)
        if self.generator is None:
            generator = torch.Generator()
            generator.manual_seed(int(torch.empty((), dtype=torch.int64).random_().item()))
        else:
            generator = self.generator
        if self.replacement:
            for _ in range(self.num_samples // 32):
                yield from torch.randint(high=n, size=(32,), dtype=torch.int64, generator=generator).tolist()
            yield from torch.randint(high=n, size=(self.num_samples % 32,), dtype=torch.int64, generator=generator).tolist()
        else:
            yield from torch.randperm(n, generator=generator).tolist()

    def __len__(self) -> int:
        return self.num_samples


class SubsetRandomSampler(Sampler[int]):
    r"""Samples elements randomly from a given list of indices, without replacement.

    Args:
        indices (sequence): a sequence of indices
        generator (Generator): Generator used in sampling.
    """
    indices: Sequence[int]

    def __init__(self, indices: Sequence[int], generator=None) -> None:
        self.indices = indices
        self.generator = generator

    def __iter__(self) -> Iterator[int]:
        return (self.indices[i] for i in torch.randperm(len(self.indices), generator=self.generator))

    def __len__(self) -> int:
        return len(self.indices)


class WeightedRandomSampler(Sampler[int]):
    r"""Samples elements from ``[0,..,len(weights)-1]`` with given probabilities (weights).

    Args:
        weights (sequence)   : a sequence of weights, not necessary summing up to one
        num_samples (int): number of samples to draw
        replacement (bool): if ``True``, samples are drawn with replacement.
            If not, they are drawn without replacement, which means that when a
            sample index is drawn for a row, it cannot be drawn again for that row.
        generator (Generator): Generator used in sampling.

    Example:
        >>> list(WeightedRandomSampler([0.1, 0.9, 0.4, 0.7, 3.0, 0.6], 5, replacement=True))
        [4, 4, 1, 4, 5]
        >>> list(WeightedRandomSampler([0.9, 0.4, 0.05, 0.2, 0.3, 0.1], 5, replacement=False))
        [0, 1, 4, 3, 2]
    """
    weights: Tensor
    num_samples: int
    replacement: bool

    def __init__(self, weights: Sequence[float], num_samples: int,
                 replacement: bool = True, generator=None) -> None:
        if not isinstance(num_samples, int) or isinstance(num_samples, bool) or \
                num_samples <= 0:
            raise ValueError("num_samples should be a positive integer "
                             "value, but got num_samples={}".format(num_samples))
        if not isinstance(replacement, bool):
            raise ValueError("replacement should be a boolean value, but got "
                             "replacement={}".format(replacement))
        self.weights = torch.as_tensor(weights, dtype=torch.double)
        self.num_samples = num_samples
        self.replacement = replacement
        self.generator = generator

    def __iter__(self) -> Iterator[int]:
        rand_tensor = torch.multinomial(self.weights, self.num_samples, self.replacement, generator=self.generator)
        return iter(rand_tensor.tolist())

    def __len__(self) -> int:
        return self.num_samples


class BatchSampler(Sampler[List[int]]):
    r"""Wraps another sampler to yield a mini-batch of indices.

    Args:
        sampler (Sampler or Iterable): Base sampler. Can be any iterable object
        batch_size (int): Size of mini-batch.
        drop_last (bool): If ``True``, the sampler will drop the last batch if
            its size would be less than ``batch_size``

    Example:
        >>> list(BatchSampler(SequentialSampler(range(10)), batch_size=3, drop_last=False))
        [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
        >>> list(BatchSampler(SequentialSampler(range(10)), batch_size=3, drop_last=True))
        [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    """

    def __init__(self, sampler: Sampler[int], batch_size: int, drop_last: bool) -> None:
        # Since collections.abc.Iterable does not check for `__getitem__`, which
        # is one way for an object to be an iterable, we don't do an `isinstance`
        # check here.
        if not isinstance(batch_size, int) or isinstance(batch_size, bool) or \
                batch_size <= 0:
            raise ValueError("batch_size should be a positive integer value, "
                             "but got batch_size={}".format(batch_size))
        if not isinstance(drop_last, bool):
            raise ValueError("drop_last should be a boolean value, but got "
                             "drop_last={}".format(drop_last))
        self.sampler = sampler
        self.batch_size = batch_size
        self.drop_last = drop_last

    def __iter__(self) -> Iterator[List[int]]:
        batch = []
        for idx in self.sampler:
            batch.append(idx)
            if len(batch) == self.batch_size:
                yield batch
                batch = []
        if len(batch) > 0 and not self.drop_last:
            yield batch

    def __len__(self) -> int:
        # Can only be called if self.sampler has __len__ implemented
        # We cannot enforce this condition, so we turn off typechecking for the
        # implementation below.
        # Somewhat related: see NOTE [ Lack of Default `__len__` in Python Abstract Base Classes ]
        if self.drop_last:
            return len(self.sampler) // self.batch_size  # type: ignore[arg-type]
        else:
            return (len(self.sampler) + self.batch_size - 1) // self.batch_size  # type: ignore[arg-type]

"""

Help on module torch.utils.data.sampler in torch.utils.data:

NAME
    torch.utils.data.sampler

CLASSES
    typing.Generic(builtins.object)
        Sampler
            BatchSampler
            RandomSampler
            SequentialSampler
            SubsetRandomSampler
            WeightedRandomSampler
    
    class BatchSampler(Sampler)
     |  BatchSampler(sampler: torch.utils.data.sampler.Sampler[int], batch_size: int, drop_last: bool) -> None
     |  
     |  Wraps another sampler to yield a mini-batch of indices.
     |  
     |  Args:
     |      sampler (Sampler or Iterable): Base sampler. Can be any iterable object
     |      batch_size (int): Size of mini-batch.
     |      drop_last (bool): If ``True``, the sampler will drop the last batch if
     |          its size would be less than ``batch_size``
     |  
     |  Example:
     |      >>> list(BatchSampler(SequentialSampler(range(10)), batch_size=3, drop_last=False))
     |      [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
     |      >>> list(BatchSampler(SequentialSampler(range(10)), batch_size=3, drop_last=True))
     |      [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
     |  
     |  Method resolution order:
     |      BatchSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, sampler: torch.utils.data.sampler.Sampler[int], batch_size: int, drop_last: bool) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[List[int]]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[typing.List[int]],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.
    
    class RandomSampler(Sampler)
     |  RandomSampler(data_source: Sized, replacement: bool = False, num_samples: Optional[int] = None, generator=None) -> None
     |  
     |  Samples elements randomly. If without replacement, then sample from a shuffled dataset.
     |  If with replacement, then user can specify :attr:`num_samples` to draw.
     |  
     |  Args:
     |      data_source (Dataset): dataset to sample from
     |      replacement (bool): samples are drawn on-demand with replacement if ``True``, default=``False``
     |      num_samples (int): number of samples to draw, default=`len(dataset)`. This argument
     |          is supposed to be specified only when `replacement` is ``True``.
     |      generator (Generator): Generator used in sampling.
     |  
     |  Method resolution order:
     |      RandomSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, data_source: Sized, replacement: bool = False, num_samples: Optional[int] = None, generator=None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  num_samples
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'data_source': typing.Sized, 'replacement': <class ...
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.
    
    class Sampler(typing.Generic)
     |  Sampler(data_source: Optional[Sized]) -> None
     |  
     |  Base class for all Samplers.
     |  
     |  Every Sampler subclass has to provide an :meth:`__iter__` method, providing a
     |  way to iterate over indices of dataset elements, and a :meth:`__len__` method
     |  that returns the length of the returned iterators.
     |  
     |  .. note:: The :meth:`__len__` method isn't strictly required by
     |            :class:`~torch.utils.data.DataLoader`, but is expected in any
     |            calculation involving the length of a :class:`~torch.utils.data.DataLoader`.
     |  
     |  Method resolution order:
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, data_source: Optional[Sized]) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[+T_co]
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (typing.Generic[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.
    
    class SequentialSampler(Sampler)
     |  SequentialSampler(data_source: Sized) -> None
     |  
     |  Samples elements sequentially, always in the same order.
     |  
     |  Args:
     |      data_source (Dataset): dataset to sample from
     |  
     |  Method resolution order:
     |      SequentialSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, data_source: Sized) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'data_source': typing.Sized}
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.
    
    class SubsetRandomSampler(Sampler)
     |  SubsetRandomSampler(indices: Sequence[int], generator=None) -> None
     |  
     |  Samples elements randomly from a given list of indices, without replacement.
     |  
     |  Args:
     |      indices (sequence): a sequence of indices
     |      generator (Generator): Generator used in sampling.
     |  
     |  Method resolution order:
     |      SubsetRandomSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, indices: Sequence[int], generator=None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'indices': typing.Sequence[int]}
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.
    
    class WeightedRandomSampler(Sampler)
     |  WeightedRandomSampler(weights: Sequence[float], num_samples: int, replacement: bool = True, generator=None) -> None
     |  
     |  Samples elements from ``[0,..,len(weights)-1]`` with given probabilities (weights).
     |  
     |  Args:
     |      weights (sequence)   : a sequence of weights, not necessary summing up to one
     |      num_samples (int): number of samples to draw
     |      replacement (bool): if ``True``, samples are drawn with replacement.
     |          If not, they are drawn without replacement, which means that when a
     |          sample index is drawn for a row, it cannot be drawn again for that row.
     |      generator (Generator): Generator used in sampling.
     |  
     |  Example:
     |      >>> list(WeightedRandomSampler([0.1, 0.9, 0.4, 0.7, 3.0, 0.6], 5, replacement=True))
     |      [4, 4, 1, 4, 5]
     |      >>> list(WeightedRandomSampler([0.9, 0.4, 0.05, 0.2, 0.3, 0.1], 5, replacement=False))
     |      [0, 1, 4, 3, 2]
     |  
     |  Method resolution order:
     |      WeightedRandomSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, weights: Sequence[float], num_samples: int, replacement: bool = True, generator=None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'num_samples': <class 'int'>, 'replacement': <class...
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

DATA
    Iterator = typing.Iterator
        A generic version of collections.abc.Iterator.
    
    List = typing.List
        A generic version of list.
    
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Sequence = typing.Sequence
        A generic version of collections.abc.Sequence.
    
    Sized = typing.Sized
        A generic version of collections.abc.Sized.
    
    T_co = +T_co

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\utils\data\sampler.py



Process finished with exit code 0

"""

# """D:\software\envs\pytorch\Lib\site-packages/torch\utils\data"""

"""
Help on package torch.utils.data in torch.utils:

NAME
    torch.utils.data

PACKAGE CONTENTS
    _decorator
    _typing
    _utils (package)
    dataloader
    datapipes (package)
    dataset
    distributed
    sampler

CLASSES
    builtins.object
        torch.utils.data._decorator.functional_datapipe
        torch.utils.data._decorator.guaranteed_datapipes_determinism
        torch.utils.data._decorator.non_deterministic
        torch.utils.data._decorator.runtime_validation_disabled
        torch.utils.data.dataloader._DatasetKind
    typing.Generic(builtins.object)
        torch.utils.data.dataloader.DataLoader
        torch.utils.data.dataset.Dataset
            torch.utils.data.dataset.ConcatDataset
            torch.utils.data.dataset.IterableDataset
                torch.utils.data.dataset.ChainDataset
            torch.utils.data.dataset.Subset
            torch.utils.data.dataset.TensorDataset
        torch.utils.data.sampler.Sampler
            torch.utils.data.distributed.DistributedSampler
            torch.utils.data.sampler.BatchSampler
            torch.utils.data.sampler.RandomSampler
            torch.utils.data.sampler.SequentialSampler
            torch.utils.data.sampler.SubsetRandomSampler
            torch.utils.data.sampler.WeightedRandomSampler

    class BatchSampler(Sampler)
     |  BatchSampler(sampler: torch.utils.data.sampler.Sampler[int], batch_size: int, drop_last: bool) -> None
     |  
     |  Wraps another sampler to yield a mini-batch of indices.
     |  
     |  Args:
     |      sampler (Sampler or Iterable): Base sampler. Can be any iterable object
     |      batch_size (int): Size of mini-batch.
     |      drop_last (bool): If ``True``, the sampler will drop the last batch if
     |          its size would be less than ``batch_size``
     |  
     |  Example:
     |      >>> list(BatchSampler(SequentialSampler(range(10)), batch_size=3, drop_last=False))
     |      [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
     |      >>> list(BatchSampler(SequentialSampler(range(10)), batch_size=3, drop_last=True))
     |      [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
     |  
     |  Method resolution order:
     |      BatchSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, sampler: torch.utils.data.sampler.Sampler[int], batch_size: int, drop_last: bool) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[List[int]]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[typing.List[int]],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class ChainDataset(IterableDataset)
     |  ChainDataset(datasets: Iterable[torch.utils.data.dataset.Dataset]) -> None
     |  
     |  Dataset for chainning multiple :class:`IterableDataset` s.
     |  
     |  This class is useful to assemble different existing dataset streams. The
     |  chainning operation is done on-the-fly, so concatenating large-scale
     |  datasets with this class will be efficient.
     |  
     |  Args:
     |      datasets (iterable of IterableDataset): datasets to be chained together
     |  
     |  Method resolution order:
     |      ChainDataset
     |      IterableDataset
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, datasets: Iterable[torch.utils.data.dataset.Dataset]) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self)
     |  
     |  __len__(self)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __abstractmethods__ = frozenset()
     |  
     |  __type_class__ = False
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from IterableDataset:
     |  
     |  __add__(self, other: torch.utils.data.dataset.Dataset[+T_co])
     |  
     |  __getattr__(self, attribute_name)
     |  
     |  __reduce_ex__(self, *args, **kwargs)
     |      Helper for pickle.
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from IterableDataset:
     |  
     |  __init_subclass__ = _dp_init_subclass(*args, **kwargs) from torch.utils.data._typing._DataPipeMeta
     |  
     |  register_datapipe_as_function(function_name, cls_to_register) from torch.utils.data._typing._DataPipeMeta
     |  
     |  register_function(function_name, function) from torch.utils.data._typing._DataPipeMeta
     |  
     |  set_reduce_ex_hook(hook_fn) from torch.utils.data._typing._DataPipeMeta
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from IterableDataset:
     |  
     |  __annotations__ = {'functions': typing.Dict[str, typing.Callable], 're...
     |  
     |  __orig_bases__ = (torch.utils.data.dataset.Dataset[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  functions = {'batch': functools.partial(<function IterableDataset.regi...
     |  
     |  reduce_ex_hook = None
     |  
     |  type = typing.Generic[+T_co]
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from Dataset:
     |  
     |  __getitem__(self, index) -> +T_co
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Dataset:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from torch.utils.data._typing._DataPipeMeta

    class ConcatDataset(Dataset)
     |  ConcatDataset(datasets: Iterable[torch.utils.data.dataset.Dataset]) -> None
     |  
     |  Dataset as a concatenation of multiple datasets.
     |  
     |  This class is useful to assemble different existing datasets.
     |  
     |  Args:
     |      datasets (sequence): List of datasets to be concatenated
     |  
     |  Method resolution order:
     |      ConcatDataset
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __getitem__(self, idx)
     |  
     |  __init__(self, datasets: Iterable[torch.utils.data.dataset.Dataset]) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __len__(self)
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  cumsum(sequence)
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  cummulative_sizes
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'cumulative_sizes': typing.List[int], 'datasets': t...
     |  
     |  __orig_bases__ = (torch.utils.data.dataset.Dataset[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from Dataset:
     |  
     |  __add__(self, other: 'Dataset[T_co]') -> 'ConcatDataset[T_co]'
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Dataset:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class DataLoader(typing.Generic)
     |  DataLoader(dataset: torch.utils.data.dataset.Dataset[+T_co], batch_size: Optional[int] = 1, shuffle: bool = False, sampler: Optional[torch.utils.data.sampler.Sampler[int]] = None, batch_sampler: Optional[torch.utils.data.sampler.Sampler[Sequence[int]]] = None, num_workers: int = 0, collate_fn: Optional[Callable[[List[~T]], Any]] = None, pin_memory: bool = False, drop_last: bool = False, timeout: float = 0, worker_init_fn: Optional[Callable[[int], NoneType]] = None, multiprocessing_context=None, generator=None, *, prefetch_factor: int = 2, persistent_workers: bool = False)
     |  
     |  Data loader. Combines a dataset and a sampler, and provides an iterable over
     |  the given dataset.
     |  
     |  The :class:`~torch.utils.data.DataLoader` supports both map-style and
     |  iterable-style datasets with single- or multi-process loading, customizing
     |  loading order and optional automatic batching (collation) and memory pinning.
     |  
     |  See :py:mod:`torch.utils.data` documentation page for more details.
     |  
     |  Args:
     |      dataset (Dataset): dataset from which to load the data.
     |      batch_size (int, optional): how many samples per batch to load
     |          (default: ``1``).
     |      shuffle (bool, optional): set to ``True`` to have the data reshuffled
     |          at every epoch (default: ``False``).
     |      sampler (Sampler or Iterable, optional): defines the strategy to draw
     |          samples from the dataset. Can be any ``Iterable`` with ``__len__``
     |          implemented. If specified, :attr:`shuffle` must not be specified.
     |      batch_sampler (Sampler or Iterable, optional): like :attr:`sampler`, but
     |          returns a batch of indices at a time. Mutually exclusive with
     |          :attr:`batch_size`, :attr:`shuffle`, :attr:`sampler`,
     |          and :attr:`drop_last`.
     |      num_workers (int, optional): how many subprocesses to use for data
     |          loading. ``0`` means that the data will be loaded in the main process.
     |          (default: ``0``)
     |      collate_fn (callable, optional): merges a list of samples to form a
     |          mini-batch of Tensor(s).  Used when using batched loading from a
     |          map-style dataset.
     |      pin_memory (bool, optional): If ``True``, the data loader will copy Tensors
     |          into CUDA pinned memory before returning them.  If your data elements
     |          are a custom type, or your :attr:`collate_fn` returns a batch that is a custom type,
     |          see the example below.
     |      drop_last (bool, optional): set to ``True`` to drop the last incomplete batch,
     |          if the dataset size is not divisible by the batch size. If ``False`` and
     |          the size of dataset is not divisible by the batch size, then the last batch
     |          will be smaller. (default: ``False``)
     |      timeout (numeric, optional): if positive, the timeout value for collecting a batch
     |          from workers. Should always be non-negative. (default: ``0``)
     |      worker_init_fn (callable, optional): If not ``None``, this will be called on each
     |          worker subprocess with the worker id (an int in ``[0, num_workers - 1]``) as
     |          input, after seeding and before data loading. (default: ``None``)
     |      generator (torch.Generator, optional): If not ``None``, this RNG will be used
     |          by RandomSampler to generate random indexes and multiprocessing to generate
     |          `base_seed` for workers. (default: ``None``)
     |      prefetch_factor (int, optional, keyword-only arg): Number of samples loaded
     |          in advance by each worker. ``2`` means there will be a total of
     |          2 * num_workers samples prefetched across all workers. (default: ``2``)
     |      persistent_workers (bool, optional): If ``True``, the data loader will not shutdown
     |          the worker processes after a dataset has been consumed once. This allows to
     |          maintain the workers `Dataset` instances alive. (default: ``False``)
     |  
     |  
     |  .. warning:: If the ``spawn`` start method is used, :attr:`worker_init_fn`
     |               cannot be an unpicklable object, e.g., a lambda function. See
     |               :ref:`multiprocessing-best-practices` on more details related
     |               to multiprocessing in PyTorch.
     |  
     |  .. warning:: ``len(dataloader)`` heuristic is based on the length of the sampler used.
     |               When :attr:`dataset` is an :class:`~torch.utils.data.IterableDataset`,
     |               it instead returns an estimate based on ``len(dataset) / batch_size``, with proper
     |               rounding depending on :attr:`drop_last`, regardless of multi-process loading
     |               configurations. This represents the best guess PyTorch can make because PyTorch
     |               trusts user :attr:`dataset` code in correctly handling multi-process
     |               loading to avoid duplicate data.
     |  
     |               However, if sharding results in multiple workers having incomplete last batches,
     |               this estimate can still be inaccurate, because (1) an otherwise complete batch can
     |               be broken into multiple ones and (2) more than one batch worth of samples can be
     |               dropped when :attr:`drop_last` is set. Unfortunately, PyTorch can not detect such
     |               cases in general.
     |  
     |               See `Dataset Types`_ for more details on these two types of datasets and how
     |               :class:`~torch.utils.data.IterableDataset` interacts with
     |               `Multi-process data loading`_.
     |  
     |  .. warning:: See :ref:`reproducibility`, and :ref:`dataloader-workers-random-seed`, and
     |               :ref:`data-loading-randomness` notes for random seed related questions.
     |  
     |  Method resolution order:
     |      DataLoader
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, dataset: torch.utils.data.dataset.Dataset[+T_co], batch_size: Optional[int] = 1, shuffle: bool = False, sampler: Optional[torch.utils.data.sampler.Sampler[int]] = None, batch_sampler: Optional[torch.utils.data.sampler.Sampler[Sequence[int]]] = None, num_workers: int = 0, collate_fn: Optional[Callable[[List[~T]], Any]] = None, pin_memory: bool = False, drop_last: bool = False, timeout: float = 0, worker_init_fn: Optional[Callable[[int], NoneType]] = None, multiprocessing_context=None, generator=None, *, prefetch_factor: int = 2, persistent_workers: bool = False)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> '_BaseDataLoaderIter'
     |      # We quote '_BaseDataLoaderIter' since it isn't defined yet and the definition can't be moved up
     |      # since '_BaseDataLoaderIter' references 'DataLoader'.
     |  
     |  __len__(self) -> int
     |  
     |  __setattr__(self, attr, val)
     |      Implement setattr(self, name, value).
     |  
     |  check_worker_number_rationality(self)
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  multiprocessing_context
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'_iterator': typing.Optional[ForwardRef('_BaseDataL...
     |  
     |  __orig_bases__ = (typing.Generic[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class Dataset(typing.Generic)
     |  An abstract class representing a :class:`Dataset`.
     |  
     |  All datasets that represent a map from keys to data samples should subclass
     |  it. All subclasses should overwrite :meth:`__getitem__`, supporting fetching a
     |  data sample for a given key. Subclasses could also optionally overwrite
     |  :meth:`__len__`, which is expected to return the size of the dataset by many
     |  :class:`~torch.utils.data.Sampler` implementations and the default options
     |  of :class:`~torch.utils.data.DataLoader`.
     |  
     |  .. note::
     |    :class:`~torch.utils.data.DataLoader` by default constructs a index
     |    sampler that yields integral indices.  To make it work with a map-style
     |    dataset with non-integral indices/keys, a custom sampler must be provided.
     |  
     |  Method resolution order:
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __add__(self, other: 'Dataset[T_co]') -> 'ConcatDataset[T_co]'
     |  
     |  __getitem__(self, index) -> +T_co
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (typing.Generic[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class DistributedSampler(torch.utils.data.sampler.Sampler)
     |  DistributedSampler(dataset: torch.utils.data.dataset.Dataset, num_replicas: Optional[int] = None, rank: Optional[int] = None, shuffle: bool = True, seed: int = 0, drop_last: bool = False) -> None
     |  
     |  Sampler that restricts data loading to a subset of the dataset.
     |  
     |  It is especially useful in conjunction with
     |  :class:`torch.nn.parallel.DistributedDataParallel`. In such a case, each
     |  process can pass a :class:`~torch.utils.data.DistributedSampler` instance as a
     |  :class:`~torch.utils.data.DataLoader` sampler, and load a subset of the
     |  original dataset that is exclusive to it.
     |  
     |  .. note::
     |      Dataset is assumed to be of constant size.
     |  
     |  Args:
     |      dataset: Dataset used for sampling.
     |      num_replicas (int, optional): Number of processes participating in
     |          distributed training. By default, :attr:`world_size` is retrieved from the
     |          current distributed group.
     |      rank (int, optional): Rank of the current process within :attr:`num_replicas`.
     |          By default, :attr:`rank` is retrieved from the current distributed
     |          group.
     |      shuffle (bool, optional): If ``True`` (default), sampler will shuffle the
     |          indices.
     |      seed (int, optional): random seed used to shuffle the sampler if
     |          :attr:`shuffle=True`. This number should be identical across all
     |          processes in the distributed group. Default: ``0``.
     |      drop_last (bool, optional): if ``True``, then the sampler will drop the
     |          tail of the data to make it evenly divisible across the number of
     |          replicas. If ``False``, the sampler will add extra indices to make
     |          the data evenly divisible across the replicas. Default: ``False``.
     |  
     |  .. warning::
     |      In distributed mode, calling the :meth:`set_epoch` method at
     |      the beginning of each epoch **before** creating the :class:`DataLoader` iterator
     |      is necessary to make shuffling work properly across multiple epochs. Otherwise,
     |      the same ordering will be always used.
     |  
     |  Example::
     |  
     |      >>> sampler = DistributedSampler(dataset) if is_distributed else None
     |      >>> loader = DataLoader(dataset, shuffle=(sampler is None),
     |      ...                     sampler=sampler)
     |      >>> for epoch in range(start_epoch, n_epochs):
     |      ...     if is_distributed:
     |      ...         sampler.set_epoch(epoch)
     |      ...     train(loader)
     |  
     |  Method resolution order:
     |      DistributedSampler
     |      torch.utils.data.sampler.Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, dataset: torch.utils.data.dataset.Dataset, num_replicas: Optional[int] = None, rank: Optional[int] = None, shuffle: bool = True, seed: int = 0, drop_last: bool = False) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[+T_co]
     |  
     |  __len__(self) -> int
     |  
     |  set_epoch(self, epoch: int) -> None
     |      Sets the epoch for this sampler. When :attr:`shuffle=True`, this ensures all replicas
     |      use a different random ordering for each epoch. Otherwise, the next iteration of this
     |      sampler will yield the same ordering.
     |      
     |      Args:
     |          epoch (int): Epoch number.
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch.utils.data.sampler.Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    IterDataPipe = class IterableDataset(Dataset)
     |  An iterable Dataset.
     |  
     |  All datasets that represent an iterable of data samples should subclass it.
     |  Such form of datasets is particularly useful when data come from a stream.
     |  
     |  All subclasses should overwrite :meth:`__iter__`, which would return an
     |  iterator of samples in this dataset.
     |  
     |  When a subclass is used with :class:`~torch.utils.data.DataLoader`, each
     |  item in the dataset will be yielded from the :class:`~torch.utils.data.DataLoader`
     |  iterator. When :attr:`num_workers > 0`, each worker process will have a
     |  different copy of the dataset object, so it is often desired to configure
     |  each copy independently to avoid having duplicate data returned from the
     |  workers. :func:`~torch.utils.data.get_worker_info`, when called in a worker
     |  process, returns information about the worker. It can be used in either the
     |  dataset's :meth:`__iter__` method or the :class:`~torch.utils.data.DataLoader` 's
     |  :attr:`worker_init_fn` option to modify each copy's behavior.
     |  
     |  Example 1: splitting workload across all workers in :meth:`__iter__`::
     |  
     |      >>> class MyIterableDataset(torch.utils.data.IterableDataset):
     |      ...     def __init__(self, start, end):
     |      ...         super(MyIterableDataset).__init__()
     |      ...         assert end > start, "this example code only works with end >= start"
     |      ...         self.start = start
     |      ...         self.end = end
     |      ...
     |      ...     def __iter__(self):
     |      ...         worker_info = torch.utils.data.get_worker_info()
     |      ...         if worker_info is None:  # single-process data loading, return the full iterator
     |      ...             iter_start = self.start
     |      ...             iter_end = self.end
     |      ...         else:  # in a worker process
     |      ...             # split workload
     |      ...             per_worker = int(math.ceil((self.end - self.start) / float(worker_info.num_workers)))
     |      ...             worker_id = worker_info.id
     |      ...             iter_start = self.start + worker_id * per_worker
     |      ...             iter_end = min(iter_start + per_worker, self.end)
     |      ...         return iter(range(iter_start, iter_end))
     |      ...
     |      >>> # should give same set of data as range(3, 7), i.e., [3, 4, 5, 6].
     |      >>> ds = MyIterableDataset(start=3, end=7)
     |  
     |      >>> # Single-process loading
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=0)))
     |      [3, 4, 5, 6]
     |  
     |      >>> # Mult-process loading with two worker processes
     |      >>> # Worker 0 fetched [3, 4].  Worker 1 fetched [5, 6].
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=2)))
     |      [3, 5, 4, 6]
     |  
     |      >>> # With even more workers
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=20)))
     |      [3, 4, 5, 6]
     |  
     |  Example 2: splitting workload across all workers using :attr:`worker_init_fn`::
     |  
     |      >>> class MyIterableDataset(torch.utils.data.IterableDataset):
     |      ...     def __init__(self, start, end):
     |      ...         super(MyIterableDataset).__init__()
     |      ...         assert end > start, "this example code only works with end >= start"
     |      ...         self.start = start
     |      ...         self.end = end
     |      ...
     |      ...     def __iter__(self):
     |      ...         return iter(range(self.start, self.end))
     |      ...
     |      >>> # should give same set of data as range(3, 7), i.e., [3, 4, 5, 6].
     |      >>> ds = MyIterableDataset(start=3, end=7)
     |  
     |      >>> # Single-process loading
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=0)))
     |      [3, 4, 5, 6]
     |      >>>
     |      >>> # Directly doing multi-process loading yields duplicate data
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=2)))
     |      [3, 3, 4, 4, 5, 5, 6, 6]
     |  
     |      >>> # Define a `worker_init_fn` that configures each dataset copy differently
     |      >>> def worker_init_fn(worker_id):
     |      ...     worker_info = torch.utils.data.get_worker_info()
     |      ...     dataset = worker_info.dataset  # the dataset copy in this worker process
     |      ...     overall_start = dataset.start
     |      ...     overall_end = dataset.end
     |      ...     # configure the dataset to only process the split workload
     |      ...     per_worker = int(math.ceil((overall_end - overall_start) / float(worker_info.num_workers)))
     |      ...     worker_id = worker_info.id
     |      ...     dataset.start = overall_start + worker_id * per_worker
     |      ...     dataset.end = min(dataset.start + per_worker, overall_end)
     |      ...
     |  
     |      >>> # Mult-process loading with the custom `worker_init_fn`
     |      >>> # Worker 0 fetched [3, 4].  Worker 1 fetched [5, 6].
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=2, worker_init_fn=worker_init_fn)))
     |      [3, 5, 4, 6]
     |  
     |      >>> # With even more workers
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=20, worker_init_fn=worker_init_fn)))
     |      [3, 4, 5, 6]
     |  
     |  Method resolution order:
     |      IterableDataset
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __add__(self, other: torch.utils.data.dataset.Dataset[+T_co])
     |  
     |  __getattr__(self, attribute_name)
     |  
     |  __iter__(self) -> Iterator[+T_co]
     |  
     |  __reduce_ex__(self, *args, **kwargs)
     |      Helper for pickle.
     |  
     |  ----------------------------------------------------------------------
     |  Class methods defined here:
     |  
     |  __init_subclass__ = _dp_init_subclass(*args, **kwargs) from torch.utils.data._typing._DataPipeMeta
     |  
     |  register_datapipe_as_function(function_name, cls_to_register) from torch.utils.data._typing._DataPipeMeta
     |  
     |  register_function(function_name, function) from torch.utils.data._typing._DataPipeMeta
     |  
     |  set_reduce_ex_hook(hook_fn) from torch.utils.data._typing._DataPipeMeta
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __abstractmethods__ = frozenset()
     |  
     |  __annotations__ = {'functions': typing.Dict[str, typing.Callable], 're...
     |  
     |  __orig_bases__ = (torch.utils.data.dataset.Dataset[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  __type_class__ = False
     |  
     |  functions = {'batch': functools.partial(<function IterableDataset.regi...
     |  
     |  reduce_ex_hook = None
     |  
     |  type = typing.Generic[+T_co]
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from Dataset:
     |  
     |  __getitem__(self, index) -> +T_co
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Dataset:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from torch.utils.data._typing._DataPipeMeta

    class IterableDataset(Dataset)
     |  An iterable Dataset.
     |  
     |  All datasets that represent an iterable of data samples should subclass it.
     |  Such form of datasets is particularly useful when data come from a stream.
     |  
     |  All subclasses should overwrite :meth:`__iter__`, which would return an
     |  iterator of samples in this dataset.
     |  
     |  When a subclass is used with :class:`~torch.utils.data.DataLoader`, each
     |  item in the dataset will be yielded from the :class:`~torch.utils.data.DataLoader`
     |  iterator. When :attr:`num_workers > 0`, each worker process will have a
     |  different copy of the dataset object, so it is often desired to configure
     |  each copy independently to avoid having duplicate data returned from the
     |  workers. :func:`~torch.utils.data.get_worker_info`, when called in a worker
     |  process, returns information about the worker. It can be used in either the
     |  dataset's :meth:`__iter__` method or the :class:`~torch.utils.data.DataLoader` 's
     |  :attr:`worker_init_fn` option to modify each copy's behavior.
     |  
     |  Example 1: splitting workload across all workers in :meth:`__iter__`::
     |  
     |      >>> class MyIterableDataset(torch.utils.data.IterableDataset):
     |      ...     def __init__(self, start, end):
     |      ...         super(MyIterableDataset).__init__()
     |      ...         assert end > start, "this example code only works with end >= start"
     |      ...         self.start = start
     |      ...         self.end = end
     |      ...
     |      ...     def __iter__(self):
     |      ...         worker_info = torch.utils.data.get_worker_info()
     |      ...         if worker_info is None:  # single-process data loading, return the full iterator
     |      ...             iter_start = self.start
     |      ...             iter_end = self.end
     |      ...         else:  # in a worker process
     |      ...             # split workload
     |      ...             per_worker = int(math.ceil((self.end - self.start) / float(worker_info.num_workers)))
     |      ...             worker_id = worker_info.id
     |      ...             iter_start = self.start + worker_id * per_worker
     |      ...             iter_end = min(iter_start + per_worker, self.end)
     |      ...         return iter(range(iter_start, iter_end))
     |      ...
     |      >>> # should give same set of data as range(3, 7), i.e., [3, 4, 5, 6].
     |      >>> ds = MyIterableDataset(start=3, end=7)
     |  
     |      >>> # Single-process loading
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=0)))
     |      [3, 4, 5, 6]
     |  
     |      >>> # Mult-process loading with two worker processes
     |      >>> # Worker 0 fetched [3, 4].  Worker 1 fetched [5, 6].
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=2)))
     |      [3, 5, 4, 6]
     |  
     |      >>> # With even more workers
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=20)))
     |      [3, 4, 5, 6]
     |  
     |  Example 2: splitting workload across all workers using :attr:`worker_init_fn`::
     |  
     |      >>> class MyIterableDataset(torch.utils.data.IterableDataset):
     |      ...     def __init__(self, start, end):
     |      ...         super(MyIterableDataset).__init__()
     |      ...         assert end > start, "this example code only works with end >= start"
     |      ...         self.start = start
     |      ...         self.end = end
     |      ...
     |      ...     def __iter__(self):
     |      ...         return iter(range(self.start, self.end))
     |      ...
     |      >>> # should give same set of data as range(3, 7), i.e., [3, 4, 5, 6].
     |      >>> ds = MyIterableDataset(start=3, end=7)
     |  
     |      >>> # Single-process loading
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=0)))
     |      [3, 4, 5, 6]
     |      >>>
     |      >>> # Directly doing multi-process loading yields duplicate data
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=2)))
     |      [3, 3, 4, 4, 5, 5, 6, 6]
     |  
     |      >>> # Define a `worker_init_fn` that configures each dataset copy differently
     |      >>> def worker_init_fn(worker_id):
     |      ...     worker_info = torch.utils.data.get_worker_info()
     |      ...     dataset = worker_info.dataset  # the dataset copy in this worker process
     |      ...     overall_start = dataset.start
     |      ...     overall_end = dataset.end
     |      ...     # configure the dataset to only process the split workload
     |      ...     per_worker = int(math.ceil((overall_end - overall_start) / float(worker_info.num_workers)))
     |      ...     worker_id = worker_info.id
     |      ...     dataset.start = overall_start + worker_id * per_worker
     |      ...     dataset.end = min(dataset.start + per_worker, overall_end)
     |      ...
     |  
     |      >>> # Mult-process loading with the custom `worker_init_fn`
     |      >>> # Worker 0 fetched [3, 4].  Worker 1 fetched [5, 6].
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=2, worker_init_fn=worker_init_fn)))
     |      [3, 5, 4, 6]
     |  
     |      >>> # With even more workers
     |      >>> print(list(torch.utils.data.DataLoader(ds, num_workers=20, worker_init_fn=worker_init_fn)))
     |      [3, 4, 5, 6]
     |  
     |  Method resolution order:
     |      IterableDataset
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __add__(self, other: torch.utils.data.dataset.Dataset[+T_co])
     |  
     |  __getattr__(self, attribute_name)
     |  
     |  __iter__(self) -> Iterator[+T_co]
     |  
     |  __reduce_ex__(self, *args, **kwargs)
     |      Helper for pickle.
     |  
     |  ----------------------------------------------------------------------
     |  Class methods defined here:
     |  
     |  __init_subclass__ = _dp_init_subclass(*args, **kwargs) from torch.utils.data._typing._DataPipeMeta
     |  
     |  register_datapipe_as_function(function_name, cls_to_register) from torch.utils.data._typing._DataPipeMeta
     |  
     |  register_function(function_name, function) from torch.utils.data._typing._DataPipeMeta
     |  
     |  set_reduce_ex_hook(hook_fn) from torch.utils.data._typing._DataPipeMeta
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __abstractmethods__ = frozenset()
     |  
     |  __annotations__ = {'functions': typing.Dict[str, typing.Callable], 're...
     |  
     |  __orig_bases__ = (torch.utils.data.dataset.Dataset[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  __type_class__ = False
     |  
     |  functions = {'batch': functools.partial(<function IterableDataset.regi...
     |  
     |  reduce_ex_hook = None
     |  
     |  type = typing.Generic[+T_co]
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from Dataset:
     |  
     |  __getitem__(self, index) -> +T_co
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Dataset:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from torch.utils.data._typing._DataPipeMeta

    class RandomSampler(Sampler)
     |  RandomSampler(data_source: Sized, replacement: bool = False, num_samples: Optional[int] = None, generator=None) -> None
     |  
     |  Samples elements randomly. If without replacement, then sample from a shuffled dataset.
     |  If with replacement, then user can specify :attr:`num_samples` to draw.
     |  
     |  Args:
     |      data_source (Dataset): dataset to sample from
     |      replacement (bool): samples are drawn on-demand with replacement if ``True``, default=``False``
     |      num_samples (int): number of samples to draw, default=`len(dataset)`. This argument
     |          is supposed to be specified only when `replacement` is ``True``.
     |      generator (Generator): Generator used in sampling.
     |  
     |  Method resolution order:
     |      RandomSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, data_source: Sized, replacement: bool = False, num_samples: Optional[int] = None, generator=None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  num_samples
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'data_source': typing.Sized, 'replacement': <class ...
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class Sampler(typing.Generic)
     |  Sampler(data_source: Optional[Sized]) -> None
     |  
     |  Base class for all Samplers.
     |  
     |  Every Sampler subclass has to provide an :meth:`__iter__` method, providing a
     |  way to iterate over indices of dataset elements, and a :meth:`__len__` method
     |  that returns the length of the returned iterators.
     |  
     |  .. note:: The :meth:`__len__` method isn't strictly required by
     |            :class:`~torch.utils.data.DataLoader`, but is expected in any
     |            calculation involving the length of a :class:`~torch.utils.data.DataLoader`.
     |  
     |  Method resolution order:
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, data_source: Optional[Sized]) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[+T_co]
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (typing.Generic[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class SequentialSampler(Sampler)
     |  SequentialSampler(data_source: Sized) -> None
     |  
     |  Samples elements sequentially, always in the same order.
     |  
     |  Args:
     |      data_source (Dataset): dataset to sample from
     |  
     |  Method resolution order:
     |      SequentialSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, data_source: Sized) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'data_source': typing.Sized}
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class Subset(Dataset)
     |  Subset(dataset: torch.utils.data.dataset.Dataset[+T_co], indices: Sequence[int]) -> None
     |  
     |  Subset of a dataset at specified indices.
     |  
     |  Args:
     |      dataset (Dataset): The whole Dataset
     |      indices (sequence): Indices in the whole set selected for subset
     |  
     |  Method resolution order:
     |      Subset
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __getitem__(self, idx)
     |  
     |  __init__(self, dataset: torch.utils.data.dataset.Dataset[+T_co], indices: Sequence[int]) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __len__(self)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'dataset': torch.utils.data.dataset.Dataset[+T_co],...
     |  
     |  __orig_bases__ = (torch.utils.data.dataset.Dataset[+T_co],)
     |  
     |  __parameters__ = (+T_co,)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from Dataset:
     |  
     |  __add__(self, other: 'Dataset[T_co]') -> 'ConcatDataset[T_co]'
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Dataset:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class SubsetRandomSampler(Sampler)
     |  SubsetRandomSampler(indices: Sequence[int], generator=None) -> None
     |  
     |  Samples elements randomly from a given list of indices, without replacement.
     |  
     |  Args:
     |      indices (sequence): a sequence of indices
     |      generator (Generator): Generator used in sampling.
     |  
     |  Method resolution order:
     |      SubsetRandomSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, indices: Sequence[int], generator=None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'indices': typing.Sequence[int]}
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class TensorDataset(Dataset)
     |  TensorDataset(*tensors: torch.Tensor) -> None
     |  
     |  Dataset wrapping tensors.
     |  
     |  Each sample will be retrieved by indexing tensors along the first dimension.
     |  
     |  Args:
     |      *tensors (Tensor): tensors that have the same size of the first dimension.
     |  
     |  Method resolution order:
     |      TensorDataset
     |      Dataset
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __getitem__(self, index)
     |  
     |  __init__(self, *tensors: torch.Tensor) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __len__(self)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'tensors': typing.Tuple[torch.Tensor, ...]}
     |  
     |  __orig_bases__ = (torch.utils.data.dataset.Dataset[typing.Tuple[torch....
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from Dataset:
     |  
     |  __add__(self, other: 'Dataset[T_co]') -> 'ConcatDataset[T_co]'
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Dataset:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class WeightedRandomSampler(Sampler)
     |  WeightedRandomSampler(weights: Sequence[float], num_samples: int, replacement: bool = True, generator=None) -> None
     |  
     |  Samples elements from ``[0,..,len(weights)-1]`` with given probabilities (weights).
     |  
     |  Args:
     |      weights (sequence)   : a sequence of weights, not necessary summing up to one
     |      num_samples (int): number of samples to draw
     |      replacement (bool): if ``True``, samples are drawn with replacement.
     |          If not, they are drawn without replacement, which means that when a
     |          sample index is drawn for a row, it cannot be drawn again for that row.
     |      generator (Generator): Generator used in sampling.
     |  
     |  Example:
     |      >>> list(WeightedRandomSampler([0.1, 0.9, 0.4, 0.7, 3.0, 0.6], 5, replacement=True))
     |      [4, 4, 1, 4, 5]
     |      >>> list(WeightedRandomSampler([0.9, 0.4, 0.05, 0.2, 0.3, 0.1], 5, replacement=False))
     |      [0, 1, 4, 3, 2]
     |  
     |  Method resolution order:
     |      WeightedRandomSampler
     |      Sampler
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, weights: Sequence[float], num_samples: int, replacement: bool = True, generator=None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __iter__(self) -> Iterator[int]
     |  
     |  __len__(self) -> int
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'num_samples': <class 'int'>, 'replacement': <class...
     |  
     |  __orig_bases__ = (torch.utils.data.sampler.Sampler[int],)
     |  
     |  __parameters__ = ()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from Sampler:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from builtins.type
     |  
     |  __init_subclass__(*args, **kwargs) from builtins.type
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.

    class _DatasetKind(builtins.object)
     |  Static methods defined here:
     |  
     |  create_fetcher(kind, dataset, auto_collation, collate_fn, drop_last)
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  Iterable = 1
     |  
     |  Map = 0

    class functional_datapipe(builtins.object)
     |  functional_datapipe(name: str) -> None
     |  
     |  ######################################################
     |  # Functional API
     |  ######################################################
     |  
     |  Methods defined here:
     |  
     |  __call__(self, cls)
     |      Call self as a function.
     |  
     |  __init__(self, name: str) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'name': <class 'str'>}

    class guaranteed_datapipes_determinism(builtins.object)
     |  guaranteed_datapipes_determinism() -> None
     |  
     |  Methods defined here:
     |  
     |  __enter__(self) -> None
     |  
     |  __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None
     |  
     |  __init__(self) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'prev': <class 'bool'>}

    class non_deterministic(builtins.object)
     |  non_deterministic(arg: Union[Type[torch.utils.data.dataset.IterableDataset], Callable[[], bool]]) -> None
     |  
     |  Methods defined here:
     |  
     |  __call__(self, *args, **kwargs)
     |      Call self as a function.
     |  
     |  __init__(self, arg: Union[Type[torch.utils.data.dataset.IterableDataset], Callable[[], bool]]) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  deterministic_wrapper_fn(self, *args, **kwargs) -> torch.utils.data.dataset.IterableDataset
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'cls': typing.Optional[typing.Type[torch.utils.data...
     |  
     |  cls = None

    class runtime_validation_disabled(builtins.object)
     |  runtime_validation_disabled() -> None
     |  
     |  Methods defined here:
     |  
     |  __enter__(self) -> None
     |  
     |  __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None
     |  
     |  __init__(self) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __annotations__ = {'prev': <class 'bool'>}

FUNCTIONS
    argument_validation(f)
        ######################################################
        # typing
        ######################################################
        # Validate each argument of DataPipe with hint as a subtype of the hint.

    get_worker_info()
        Returns the information about the current
        :class:`~torch.utils.data.DataLoader` iterator worker process.

        When called in a worker, this returns an object guaranteed to have the
        following attributes:

        * :attr:`id`: the current worker id.
        * :attr:`num_workers`: the total number of workers.
        * :attr:`seed`: the random seed set for the current worker. This value is
          determined by main process RNG and the worker id. See
          :class:`~torch.utils.data.DataLoader`'s documentation for more details.
        * :attr:`dataset`: the copy of the dataset object in **this** process. Note
          that this will be a different object in a different process than the one
          in the main process.

        When called in the main process, this returns ``None``.

        .. note::
           When used in a :attr:`worker_init_fn` passed over to
           :class:`~torch.utils.data.DataLoader`, this method can be useful to
           set up each worker process differently, for instance, using ``worker_id``
           to configure the ``dataset`` object to only read a specific fraction of a
           sharded dataset, or use ``seed`` to seed other libraries used in dataset
           code.

    random_split(dataset: torch.utils.data.dataset.Dataset[~T], lengths: Sequence[int], generator: Optional[torch._C.Generator] = <torch._C.Generator object at 0x000001EC3B635310>) -> List[torch.utils.data.dataset.Subset[~T]]
        Randomly split a dataset into non-overlapping new datasets of given lengths.
        Optionally fix the generator for reproducible results, e.g.:

        >>> random_split(range(10), [3, 7], generator=torch.Generator().manual_seed(42))

        Args:
            dataset (Dataset): Dataset to be split
            lengths (sequence): lengths of splits to be produced
            generator (Generator): Generator used for the random permutation.

    runtime_validation(f)
        # Runtime checking
        # Validate output data is subtype of return hint

DATA
    __all__ = ['Sampler', 'SequentialSampler', 'RandomSampler', 'SubsetRan...

FILE
d:\software\envs\pytorch\lib\site-packages/torch\utils\data\__init__.py
"""