import torch.nn as nn
#help(nn.Module.children)
"""
Help on function children in module torch.nn.modules.module:

children(self) -> Iterator[ForwardRef('Module')]
    Returns an iterator over immediate children modules.
    
    Yields:
        Module: a child module

"""