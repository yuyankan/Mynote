
# summary:
"""

1. ParameterLlist:
    ->1.1: __setitem__: called when 给ParameterList 实例赋值时， e.g:a = nn.ParameterList, a[2] = xxx-->call ParameterList __setitem__
    ->1.2: __setattr__: 给类参数赋值时， '=' will call setattr.
"""

import torch.nn as nn
import torch
from typing import Optional, Iterable, overload, TypeVar, Any, Iterator, Union
from torch import Tensor
import warnings
import operator
from collections import abc as container_abcs

T = TypeVar('T', bound=nn.Module)

class ParameterList1(nn.Module):

    def __init__(self, parameters: Optional[Iterable['Parameter']]=None) -> None:
        print("1.1. ParameterList1: __init__ is called:")
        super(ParameterList1, self).__init__()

        self._initialized = True
        if parameters is not None:
            self += parameters

    def __setstate__(self, state):
        state['_initialized'] = False
        super(ParameterList1, self).__setstate__(state)#  self.__dict__.update(state)
        self._initialized = True

    def _get_abs_string_index(self, idx):
        """Get the absolute index for the list of modules"""
        idx = operator.index(idx)
        if not (-len(self) <= idx <= len(self)):
            raise IndexError("index {} is out of range".format(idx))
        if idx < 0:
            idx += len(self)
        return str(idx)

    @overload
    def __getitem__(self, index: int) -> 'Parameter':
        ...

    @overload # ?? Modlue?
    def __getitem__(self: T, index: slice) -> T:
        ...

    def __getitem__(self, idx):
        print("\n1.5. ParameterList1:. __getitem__ is called:")
        if isinstance(idx, slice):
            return self.__class__(list(self._parameters.values())[idx])
        else:
            idx = self._get_abs_string_index(idx)
            return self._parameters[str(idx)]

    def __setitem__(self, idx:int, param: 'Parameter') -> None:
        print("\n1.3. ParameterList1:. __setitem__ is called:")

        idx = self._get_abs_string_index(idx)
        return self.register_parameter(str(idx), param)

    #??? when will call __setattr__  for self.__init__ 赋值
    def __setattr__(self, key:Any, value:Any) ->None:

        print("\n1.2. ParameterList1:. __setattr__ is called:")
        print('      key -> value:  ', key, '->', value)
        if getattr(self, '_initialized', False):
            if not hasattr(self, key) and not isinstance(value, torch.nn.Parameter):
                warnings.warn('Setting attributes on ParameterList is not supported')
        super(ParameterList1, self).__setattr__(key, value)


    def __len__(self) -> int:
        return len(self._parameters)

    def __iter__(self) -> Iterator['Parameter']:
        return iter(self._parameters.values())

    def __dir__(self):
        keys = super(ParameterList1, self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return keys

    def append(self, parameter: 'Parameter')-> 'ParameterList':
        print("\n1.7. ParameterList1:. append() is called:")
        """Appends a given parameter at the end of the list.

        Args:
            parameter(nn.Paramter): parameter to append
        """
        self.register_parameter(str(len(self)), parameter)
        return self

    def __iadd__(self, parameters:Iterable['Parameter']) -> 'ParameterList':
        print("\n1.3. ParameterList1: __iadd__ is called:")
        return self.extend(parameters)

    def extend(self, parameters: Iterable['Paremter']) -> 'ParameterList':
        print("\n1.4. ParameterList1:.extend () is called:")
        """Appends parameters from a Python iterable to the end of the list.
        Args:
            parameters(iterable): iterable of parameters to append
        """
        if not isinstance(parameters, container_abcs.Iterable):
            raise TypeError("ParameterList.extend should be called with an iterable, "
                            "but got" + type(parameters).__name__)

        offset = len(self)
        for i, param in enumerate(parameters):
            self.register_parameter(str(offset+i), param)
        return self

    def extra_repr(self) -> str: # called by __repr__() actually.!!!
        print("\n1.6. ParameterList1:.extra_repr () is called:")
        child_lines = []
        for k, p in self._parameters.items():
            size_str = 'x'.join(str(size) for size in p.size()) # 'parameter size: (3, 4)-->size_str = 3 x 4'
            device_str = '' if not p.is_cuda else '(GPU {})'.format(p.get_device())
            parastr = 'Parameter containing: [{} of size {} {} ]'.format(
                torch.typename(p), size_str, device_str )
            child_lines.append(' (' + str(k) +'): ' + parastr)
        tmpstr = '\n'.join(child_lines)
        return tmpstr

    def __call__(self, input):
        raise RuntimeError("ParameterList should not be called.")

    def _replicate_for_data_parallel(self):
        warnings.warn('nn.ParameterList is being used with DataParallel but this is not supported.'
                      'This list will appear empty for the models replicated on each GPU except the original one.')
        return super(ParameterList1, self)._replicate_for_data_parallel

class MyModule(nn.Module):
    def __init__(self):
        super(MyModule, self).__init__()
        self.params = nn.ParameterDict({
        'left': nn.Parameter(torch.randn(5, 10)),'right': nn.Parameter(torch.randn(5, 10))})


class MyModule1(nn.Module):
    def __init__(self):
        print("0.1 Mymodule1: --init__ is called:")
        super(MyModule1, self).__init__()
        print("1*"*50)
        self.params = ParameterList1([nn.Parameter(torch.randn(3, 2)) for i in range(2)])
        # 1rst: 实例化ParameterList:
        #   1.1 ParameterList:__init__,
        #   1.2: ParameterList: super().__init__: set OrderedDict(nn.Module.__init__)--->
        #           1.3 ParameterList:__setattr__ is called !!!!!!
        #   1.4. ParameterList1: __iadd__ is called:
        #   1.5. ParameterList1:.extend () is called:-->ParameterList created and returned.
        #2nd:
        # 0.2: Mymodule1: __setattr__ is called: 赋值ParameterList 给 self.params.



        print('test'*15)

        self.params[2] = nn.Parameter(torch.randn(2, 2), requires_grad=True) #  -->ParameterList, self.__setitem__ is called
        print("test2"*15)
        self.a = 1 # --> class: self.__setattr__ is called.!!!
        self.b = [1, 2, 3]
        print("hi"*15)
        self.b[2] ='test'  #-->self.__setattr__ will not be called.!!!

    def __setattr__(self, name: str, value: Union[Tensor, 'nn.Module']) -> None:
        print("\n0.2: Mymodule1: __setattr__ is called: for nn.Module.__init__ & 后续赋值")
        print("     name -> value:  ", name, '->', value)
        def remove_from(*dicts_or_sets):
            for d in dicts_or_sets:
                if name in d:
                    if isinstance(d, dict):
                        del d[name]
                    else:
                        d.discard(name)

        params = self.__dict__.get('_parameters')
        if isinstance(value, nn.Parameter):
            if params is None:
                raise AttributeError(
                    "cannot assign parameters before Module.__init__() call")
            remove_from(self.__dict__, self._buffers, self._modules, self._non_persistent_buffers_set)
            self.register_parameter(name, value)
        elif params is not None and name in params:
            if value is not None:
                raise TypeError("cannot assign '{}' as parameter '{}' "
                                "(torch.nn.Parameter or None expected)"
                                .format(torch.typename(value), name))
            self.register_parameter(name, value)
        else:
            modules = self.__dict__.get('_modules')
            if isinstance(value, nn.Module):
                if modules is None:
                    raise AttributeError(
                        "cannot assign module before Module.__init__() call")
                remove_from(self.__dict__, self._parameters, self._buffers, self._non_persistent_buffers_set)
                modules[name] = value
            elif modules is not None and name in modules:
                if value is not None:
                    raise TypeError("cannot assign '{}' as child module '{}' "
                                    "(torch.nn.Module or None expected)"
                                    .format(torch.typename(value), name))
                modules[name] = value
            else:
                buffers = self.__dict__.get('_buffers')
                if buffers is not None and name in buffers:
                    if value is not None and not isinstance(value, torch.Tensor):
                        raise TypeError("cannot assign '{}' as buffer '{}' "
                                        "(torch.Tensor or None expected)"
                                        .format(torch.typename(value), name))
                    buffers[name] = value
                else:
                    object.__setattr__(self, name, value)

a1 = MyModule1()
print("2"*50)
print(a1.params)
print("3"*50)
a1.params.append(nn.Parameter(torch.Tensor(2,1), requires_grad=True))
print("4"*50)
print(a1.params)
print("5"*50)
a1.params[3] = nn.Parameter(torch.Tensor(3,1), requires_grad=True)
print("6"*50)
a1.b[1]= 'test'
print(a1.b)

