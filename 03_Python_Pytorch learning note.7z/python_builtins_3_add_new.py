"""python3 中的 builtins 和 __builtins_:
添加内建函数:
当使用内建模块中函数或其它功能时，可以直接使用，不用添加内建模块的名字；但是，如果想要向内建模块中添加一些功能，以便在任何函数中都能直接使用而不用再进行
import，这时，就要导入内建模块 builtins（ python2 导入 __builtin__），在内建模块的命名空间(即 __dict__ 字典属性)中添加该功能。就要导入 模块。

"""
import builtins


def print_hello():
    print('hello world')


builtins.__dict__['hello'] = print_hello
print('hello' in builtins.__dict__.keys())

hello()
""" 
此时，print_hello 和 hello 两个函数名几乎是一样，但是有一点区别，print_hello 只能在该模块中使用，
而 hello 可以在本程序中的其它任何一个模块中使用，因为 hello 已经放到内建模块中了。

"""

""" dict: search key , value:
a ={'hi': 'ok', 'test': 'result'}
print('test' in a.keys())
print('ok' in a.values())
print(a['hi'])"""

"""
print('int' in builtins.__dict__.keys())
builtins.__dict__['hello']()
print(builtins.__dict__['int'](3.5))
print(int(3.5))
"""
