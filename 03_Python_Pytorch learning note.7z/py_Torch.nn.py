"""
nn软件包包含以下模块和类：

S.No	                                    类和模块	                                 Description
1.	                                   torch.nn.Parameter	                  它是一种张量, 将被视为模块参数。

2.	                                   Containers
1)torch.nn.Module	                   它是所有神经网络模块的基类。
2)torch.nn.Sequential	              它是一个顺序容器, 其中模块的添加顺序与在构造函数中传递模块时的顺序相同。
3)torch.nn.ModuleList	               这会将子模块保存在列表中。
4)torch.nn.ModuleDict	这会将子模块保存在目录中。
5)torch.nn.ParameterList	这会将参数保存在列表中。
6)torch.nn.parameterDict	这会将参数保存在目录中。

3.	Convolution layers
1)torch.nn.Conv1d	该软件包将用于对由多个输入平面组成的输入信号进行一维卷积。
2)torch.nn.Conv2d	该软件包将用于在由多个输入平面组成的输入信号上应用2D卷积。
3)torch.nn.Conv3d	该软件包将用于在由多个输入平面组成的输入信号上应用3D卷积。
4)torch.nn.ConvTranspose1d	该软件包将用于在由多个输入平面组成的输入图像上应用一维转置卷积算符。
5)torch.nn.ConvTranspose2d	该软件包将用于在由多个输入平面组成的输入图像上应用2D转置卷积运算符。
6)torch.nn.ConvTranspose3d	该软件包将用于在由多个输入平面组成的输入图像上应用3D转置卷积运算符。
7)torch.nn。展开	它用于从成批的输入张量中提取滑动局部块。
8)PyTorch折叠	它用于将一系列滑动局部块组合成一个大的包含张量。

4.	Pooling layers
1)torch.nn.MaxPool1d	它用于在由多个输入平面组成的输入信号上应用一维最大池。
2)torch.nn.MaxPool2d	它用于在由多个输入平面组成的输入信号上应用2D max池。
3)torch.nn.MaxPool3d	它用于在由多个输入平面组成的输入信号上应用3D max池。
4)torch.nn.MaxUnpool1d	它用于计算MaxPool1d的局部逆。
5)torch.nn.MaxUnpool2d	它用于计算MaxPool2d的局部逆。
6)torch.nn.MaxUnpool3d	它用于计算MaxPool3d的局部逆。
7)torch.nn.AvgPool1d	它用于在由多个输入平面组成的输入信号上应用一维平均池。
8)torch.nn.AvgPool2d	它用于在由多个输入平面组成的输入信号上应用2D平均池。
9)torch.nn.AvgPool3d	它用于在由多个输入平面组成的输入信号上应用3D平均池。
10)torch.nn.FractionalMaxPool2d	它用于在由多个输入平面组成的输入信号上应用2D分数最大池化。
11)torch.nn.LPPool1d	它用于在由多个输入平面组成的输入信号上应用一维功率平均池。
12)torch.nn.LPPool2d	它用于在由多个输入平面组成的输入信号上应用2D功率平均池。
13)torch.nn.AdavtiveMaxPool1d	它用于在由多个输入平面组成的输入信号上应用一维自适应最大池化。
14)torch.nn.AdavtiveMaxPool2d	它用于在由多个输入平面组成的输入信号上应用2D自适应最大池化。
15)torch.nn.AdavtiveMaxPool3d	它用于在由多个输入平面组成的输入信号上应用3D自适应最大池化。
16)torch.nn.AdavtiveAvgPool1d	它用于在由多个输入平面组成的输入信号上应用一维自适应平均池。
17)torch.nn.AdavtiveAvgPool2d	它用于在由多个输入平面组成的输入信号上应用2D自适应平均池。
18)torch.nn.AdavtiveAvgPool3d	它用于在由多个输入平面组成的输入信号上应用3D自适应平均池。

5.	填充层
1)torch.nn.ReflectionPad1d	它将使用输入边界的反射填充输入张量。
2)torch.nn.ReflactionPad2d	它将使用输入边界的反射来填充输入张量。
3)torch.nn.ReplicationPad1	它将使用输入边界的复制来填充输入张量。
4)torch.nn.ReplicationPad2d	它将使用输入边界的复制来填充输入张量。
5)torch.nn.ReplicationPad3d	它将使用输入边界的复制来填充输入张量。
6)torch.nn.ZeroPad2d	它将用零填充输入张量边界。
7)torch.nn.ConstantPad1d	它将用恒定值填充输入张量边界。
8)torch.nn.ConstantPad2d	它将用恒定值填充输入张量边界。
9)torch.nn.ConstantPad3d	它将用恒定值填充输入张量边界。

6.	非线性激活(加权和, 非线性)
1)torch.nn.ELU	它将用于应用按元素的函数：ELU(x)= max(0, x)+ min(0, α*(exp(x)-1))
2)torch.nn.Hardshrink	它将用于应用硬收缩函数逐元素函数：
3)torch.nn.LeakyReLU	它将用于应用按元素的函数：LeakyReLu(x)= max(0, x)+ negative_slope * min(0, x)
4)torch.nn.LogSigmoid	它将用于应用逐元素函数：
5)torch.nn.MultiheadAttention	它用于允许模型关注来自不同表示子空间的信息
6)torch.nn.PReLU	它将用于应用按元素的函数：PReLU(x)= max(0, x)+ a * min(0, x)
7)torch.nn.ReLU	它将按元素应用于整流线性单位函数：ReLU(x)= max(0, x)
8)torch.nn.ReLU6	它将用于应用按元素的函数：ReLU6(x)= min(max(0, x), 6)
9)torch.nn.RReLU	如本文所述, 它将用于逐元素地应用随机泄漏整流线性单位函数：
10)torch.nn.SELU	它将按以下方式应用按元素的函数：SELU(x)= scale *(max(0, x)+ min(0, a *(exp(x)-1)))这里α= 1.6732632423543772772848170429916717和scale = 1.0507009873554804934193193349852946。
11)PyTorch日期	它将按以下方式应用按元素的功能：
12)PyTorch乙状结肠	它将按以下方式应用按元素的功能：
13)torch.nn.Softplus	它将按以下方式应用按元素的功能：
14)torch.nn.Softshrink	它将按元素应用软收缩功能, 如下所示：
15)torch.nn.Softsign	它将按以下方式应用按元素的功能：
16)torch.nn.Tanh	它将按以下方式应用按元素的功能：
17)torch.nn.Tanhshrink	它将按以下方式应用按元素的函数：Tanhshrink(x)= x-Tanh(x)
18)torch.nn.Threshold	它将用于阈值输入张量的每个元素。阈值定义为：

7.	非线性激活(其他)
1)torch.nn.Softmin	它用于将softmin函数应用于n维输入张量以重新缩放它们。之后, n维输出Tensor的元素位于0、1的范围内, 且总和为1。Softmin定义为：
2)torch.nn.Softmax	它用于将softmax函数应用于n维输入张量以重新缩放它们。之后, n维输出Tensor的元素位于0、1的范围内, 且总和为1。Softmax定义为：
3)torch.nn.Softmax2d	它用于将SoftMax应用于要素上的每个空间位置。
4)torch.nn.LogSoftmax	它用于将LogSoftmax函数应用于n维输入张量。 LofSoftmax函数可以定义为：
5)torch.nn.AdaptiveLogSoftmaxWithLoss	这是训练具有较大输出空间的模型的策略。标签分布高度不平衡时非常有效

8.	归一化层
1)torch.nn.BatchNorm1d	它用于对2D或3D输入应用批量归一化。
2)torch.nn.BatchNorm2d	它用于在4D上应用批量归一化。
3)torch.nn.BatchNorm3d	它用于对5D输入应用批量归一化。
4)torch.nn.GroupNorm	它用于在最小输入批次上应用组归一化。
5)torch.nn.SyncBatchNorm	它用于对n维输入应用批量归一化。
6)torch.nn.InstanceNorm1d	它用于在3D输入上应用实例规范化。
7)torch.nn.InstanceNorm2d	它用于在4D输入上应用实例规范化。
8)torch.nn.InstanceNorm3d	它用于在5D输入上应用实例规范化。
9)torch.nn.LayerNorm	它用于在最小输入批次上应用层归一化。
10)torch.nn.LocalResponseNorm	它用于对由多个输入平面组成的输入信号进行局部响应归一化, 其中通道占据第二维。

9.	Recurrent layers
1)torch.nn.RNN	它用于将具有tanh或ReLU非线性的多层Elman RNN应用于输入序列。每一层为输入序列中的每个元素计算以下函数：ht = tanh(Wih xt + bih + Whh tt-1 + bhh)
2)Torch.nn.LSTM	它用于将多层长期短期记忆(LSTM)RNN应用于输入序列。每一层为输入序列中的每个元素计算以下功能：
3)GNUPyTorch	它用于将多层门控循环单元(GRU)RNN应用于输入序列。每一层为输入序列中的每个元素计算以下功能：
4)torch.nn.RNNCell	它用于将具有tanh或ReLU非线性的Elman RNN单元应用于输入序列。每一层为输入序列中的每个元素计算以下函数：h’= tanh(Wih x + bih + Whh h + bhh)使用ReLU代替tanh
5)torch.nn.LSTMCell	它用于将长短期记忆(LSTM)单元应用于输入序列。每一层为输入序列中的每个元素计算以下函数：其中σ是S型函数, 而*是Hadamard乘积。
6)torch.nn.GRUCell	它用于将门控循环单元(GRU)单元应用于输入序列。每一层为输入序列中的每个元素计算以下功能：

10.	线性层
1)PyTorch身份	它是一个占位符身份运算符, 对参数不敏感。
2)torch.nn.Linear	它用于对输入数据进行线性变换：y = xAT + b
3)torch.nn.Bilinear	它用于对输入数据进行双线性变换：y = x1 Ax2 + b

11.	Dropout layers
1)torch.nn.Dropout	它用于调节和预防神经元的共适应。培训过程中的一个因素会缩放输出。这意味着模块将在评估期间计算身份函数。
2)torch.nn.Dropout2d	如果要素图中的相邻像素相关, 则torch.nn.Dropout不会使激活规则化, 并且会降低有效学习率。在这种情况下, torch.nn.Dropout2d()用于促进要素图之间的独立性。
3)torch.nn.Dropout3d	如果要素图中的相邻像素相关, 则torch.nn.Dropout不会使激活规则化, 并且会降低有效学习率。在这种情况下, torch.nn.Dropout2d()用于促进要素图之间的独立性。
4)torch.nn.AlphaDropout	它用于在输入上应用Alpha Dropout。 Alpha Dropout是一种Dropout, 可以保持自规范化属性。

12.	Sparse layers
1)torch.nn。嵌入	它用于存储单词嵌入, 并使用索引检索它们。模块的输入是索引列表, 输出是相应的词嵌入。
2)torch.nn.EmbeddingBag	它用于计算嵌入的”袋子”的总和或平均值, 而无需实例化中间嵌入。

13.	距离功能
1)torch.nn.Cosine相似度	它将返回x1和x2之间的余弦相似度(沿dim计算)。
2)torch.nn.PairwiseDistance	它使用p范数计算向量v1, v2之间的成批成对距离：

14.	Loss function
1)torch.nn.L1Loss	它用于衡量输入x和目标y中每个元素之间的平均绝对误差的标准。未减少的损失可描述为：l(x, y)= L = {l1, …, ln}, ln = | xn-yn |, 其中N是批次大小。
2)torch.nn.MSELoss	它用于衡量输入x和目标y中每个元素之间的均方误差的标准。未减少的损失可描述为：l(x, y)= L = {l1, …, ln}, ln =(xn-yn)2, 其中N是批次大小。
3)torch.nn.CrossEntropyLoss	此条件将nn.LogSoftmax()和nn.NLLLoss()组合在一个类中。当我们训练C类的分类问题时, 这将很有帮助。
4)torch.nn.CTCLoss	连接主义者的时间分类损失计算连续时间序列和目标序列之间的损失。
5)torch.nn.NLLLoss	负对数似然损失用于训练C类的分类问题。
6)torch.nn.PoissonNLLLoss	目标的Poisson分布为负的对数似然损失-目标(Posson(input)loss(input, target)= input-target * log(target！))
7)torch.nn.KLDivLoss	这对于连续分布是有用的距离度量, 并且在我们对连续输出分布的空间进行直接回归时也很有用。
8)torch.nn.BCELoss	它用于创建衡量目标和输出之间的二进制交叉熵的标准。未减少的损失可描述为：l(x, y)= L = {l1, …, ln}, ln = -wn [yn * logxn +(1-yn)* log(1-xn)], 其中N是批次大小。
9)torch.nn.BCEWithLogitsLoss	它在一个类别中将Sigmoid层和BCELoss结合在一起。通过将操作合并到一层, 我们可以利用log-sum-exp技巧来实现数值稳定性。
10)torch.nn.MarginRankingLoss	它创建一个标准来测量给定输入x1, x2, 两个1D迷你批量张量和包含1或-1的标签1D迷你批量张量y的损耗。迷你批次中每个样本的损失函数如下：loss(x, y)= max(0, -y *(x1-x2)+ margin
11)torch.nn.HingeEmbeddingLoss	HingeEmbeddingLoss度量给定输入张量x和包含1或-1的标签张量y的损失。它用于测量两个输入是否相似或不相似。损失函数定义为：
12)torch.nn.MultiLabelMarginLoss	它用于创建优化输入x和输出y之间的多类多分类铰链损耗的标准。
13)torch.nn.SmoothL1Loss	它用于创建一个标准, 如果绝对逐项误差低于1, 则使用平方项, 否则使用L1项。也称为胡贝尔损耗：
14)torch.nn.SoftMarginLoss	它用于创建优化输入张量x和目标张量y之间(包含1或-1)的两类分类逻辑损失的标准。
15)torch.nn.MultiLabelSoftMarginLoss	它用于创建一个标准, 该标准基于输入x与大小(N, C)的目标y之间的最大熵来优化多标签对所有损失。
16)torch.nn.CosineEmbeddingLoss	它用于创建一个标准, 该标准测量给定输入张量x1, x2和张量标签y的值为1或-1的损失。它用于使用余弦距离来测量两个输入是相似还是相异。
17)torch.nn.MultiMarginLoss	它用于创建优化输入x和输出y之间的多类分类铰链损耗的标准。
18)torch.nn.TripletMarginLoss	它用于创建衡量给定输入张量x1, x2, x3和值大于0的余量的三重态损失的标准。它用于衡量样本之间的相对相似性。三元组由锚点, 正例和负例组成。 L(a, p, n)= max {d(ai, pi)-d(a​​i, ni)+ margin, 0}

15.	Vision layers
1)torch.nn.PixelShuffle	用于将形状为(*, C×r2, H, W)的张量的元素重新排列为形状为(*, C, H×r, W, r)的张量的元素
2)torch.nn.Upsample	它用于对给定的多通道1D, 2D或3D数据进行升采样。
3)torch.nn.upsamplingNearest2d	它用于对由多个输入通道组成的输入信号进行2D最近邻居上采样。
4)torch.nn.UpsamplingBilinear2d	用于将二维双线性上采样应用于由多个输入通道组成的输入信号。

16.	DataParallel层(多GPU, 分布式)
1)torch.nn.DataParallel	它用于在模块级别实现数据并行性。
2)torch.nn.DistributedDataParallel	它用于实现分布式数据并行性, 它基于模块级别的torch.distributed包。
3)torch.nn.DistributedDataParallelCPU	它用于在模块级别为CPU实现分布式数据并行性。

17.	Utilities
1)torch.nn.clip_grad_norm_	它用于裁剪可迭代参数的梯度范数。
2)torch.nn.clip_grad_value_	用于将可迭代参数的梯度范数裁剪为指定值。
3)torch.nn.parameters_to_vector	用于将参数转换为一个向量。
4)torch.nn.vector_to_parameters	它用于将一个向量转换为参数。
5)torch.nn.weight_norm	它用于对给定模块中的参数应用权重归一化。
6)torch.nn.remove_weight_norm	它用于删除模块的权重归一化和重新参数化。
7)torch.nn.spectral_norm	它用于将频谱归一化应用于给定模块中的参数。
8)torch.nn.PackedSequence	它将用于保存打包序列的数据和batch_size的列表。
9)torch.nn.pack_padded_sequence	它用于打包包含可变长度填充序列的Tensor。
10)torch.nn.pad_packed_sequence	它用于填充打包的可变长度序列批次。
11)torch.nn.pad_sequence	它用于填充具有填充值的可变长度张量列表。
12)torch.nn.pack_sequence	它用于打包可变长度张量的列表
13)torch.nn.remove_spectral_norm	它用于删除模块的频谱归一化和重新参数化

"""