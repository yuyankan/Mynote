""" map(function, iterable,...)
1.描述：
map() 会根据提供的函数对指定序列做映射。
第一个参数 function 以参数序列中的每一个元素调用 function 函数，返回包含每次 function 函数返回值的新列表。
2. 语法：
map() 函数语法：map(function, iterable, …)
3.参数：
function – 函数
iterable – 一个或多个序列
4.返回值：
Python 2.x 返回列表。
Python 3.x 返回迭代器。
"""


# ===example1: create new function , work on list===
def square(x):
    return x ** 2


a = [1, 2, 3, 4]

b =map(square, a)
print("map(square,a):", b)
""" python3可将map转换为list："""
print("list(map(square,a)):", list(b))

