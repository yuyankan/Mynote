import copy

def clone(data):
    if isinstance(data,list):
        tmp_data = []
        for x in data:
            xt = clone(x)
            tmp_data.append(xt)
    elif isinstance(data,tuple):
        tmp_data = []
        for x in data:
            xt = clone(x)
            tmp_data.append(xt)
    elif isinstance(data,dict):
        tmp_data = {}
        for k,v in data.items():
            xt = clone(v)
            tmp_data[k] = xt
    elif isinstance(data,set):
        tmp_data = set()
        for x in data:
            xt = clone(x)
            tmp_data.add(xt)
    else:
        tmp_data = data # -->复制引用
    return tmp_data

x = [1, 2, 3, [4, 5]]
y = copy.copy(x) # -->shallow copy: new id(y), yet y (object): id(object) : same：子对象仍是复制引用'=': 地址引用-指向同一地址
y2 = copy.deepcopy(x) # --> new id for object and all sub_object that are changable,
y3 = clone(x) # -->for object and all sub_ojbect: 复制引用： no new  id of (y3)
print('1. shallow copy_object: ',y is x) # False: new id (y) for list, same id for non-changable object
print('1.1 shallow copy_sub_object: ',y[3] is x[3]) # True: sub_object id same
print('-'*50)
print('2. deep copy_object: ',y2 is x) # False: new id (y2)
print('2.1 deep copy_sub_object: ',y2[3] is x[3]) # False: new id (y2[3])
print('-'*50)
print('3. clone_object: ',y3 is x) # False: new id (y3)
print('3.1 clone_sub_object: ',y3[3] is x[3]) # False: new id (y2[3]);

# clone: seems similar with deepcopy, yet no memo dict.
