from typing import Tuple, TypeVar, Mapping, Union, Dict, Optional,Callable
from torch import Tensor
x = [1,2, 3,4]
y = [5, 6, 7, 8]
z = Union[Tuple['hi', str], int]
print(z)
_grad_t = Union[Tuple[Tensor, ...], Tensor]
print(_grad_t)
#help(Callable)

# 7. typing.Callable
"""
    Callable type; Callable[[int], str] is a function of (int) -> str.
    
    The subscription syntax must always be used with exactly two
    values: the argument list and the return type.  The argument list
    must be a list of types or ellipsis; the return type must be a single type.
    
    There is no syntax to indicate optional or keyword arguments,
    such function types are rarely used as callback types.
"""
#6. typing.optional
""" Optional[X] is equivalent to Union[X, None]."""

#5. typing.Dict
""" A generic version of dict."""

#4. typing.Mapping
"""
A generic version of collections.abc.Mapping.
"""
#3. typing.Tuple
"""
    Tuple type; Tuple[X, Y] is the cross-product type of X and Y.
    
    Example: Tuple[T1, T2] is a tuple of two elements corresponding
    to type variables T1 and T2.  Tuple[int, float, str] is a tuple
    of an int, a float and a string.
    
    To specify a variable-length tuple of homogeneous type, use Tuple[T, ...].

"""

# 2. typing.Union
"""
typing.Union
    Union type; Union[X, Y] means either X or Y.
"""

# 1. TypeVar
""" Help on class TypeVar in module typing:

class TypeVar(_Final, _Immutable)
 |  TypeVar(name, *constraints, bound=None, covariant=False, contravariant=False)
 |  
 |  Type variable.
 |  
 |  Usage::
 |  
 |    T = TypeVar('T')  # Can be anything
 |    A = TypeVar('A', str, bytes)  # Must be str or bytes
 |  
 |  Type variables exist primarily for the benefit of static type
 |  checkers.  They serve as the parameters for generic types as well
 |  as for generic function definitions.  See class Generic for more
 |  information on generic types.  Generic functions work as follows:
 |  
 |    def repeat(x: T, n: int) -> List[T]:
 |        '''Return a list containing n references to x.'''
 |        return [x]*n
 |  
 |    def longest(x: A, y: A) -> A:
 |        '''Return the longest of two strings.'''
 |        return x if len(x) >= len(y) else y
 |  
 |  The latter example's signature is essentially the overloading
 |  of (str, str) -> str and (bytes, bytes) -> bytes.  Also note
 |  that if the arguments are instances of some subclass of str,
 |  the return type is still plain str.
 |  
 |  At runtime, isinstance(x, T) and issubclass(C, T) will raise TypeError.
 |  
 |  Type variables defined with covariant=True or contravariant=True
 |  can be used to declare covariant or contravariant generic types.
 |  See PEP 484 for more details. By default generic types are invariant
 |  in all type variables.
 |  
 |  Type variables can be introspected. e.g.:
 |  
 |    T.__name__ == 'T'
 |    T.__constraints__ == ()
 |    T.__covariant__ == False
 |    T.__contravariant__ = False
 |    A.__constraints__ == (str, bytes)
 |  
 |  Note that only type variables defined in global scope can be pickled.
 |  
 |  Method resolution order:
 |      TypeVar
 |      _Final
 |      _Immutable
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, name, *constraints, bound=None, covariant=False, contravariant=False)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  __reduce__(self)
 |      Helper for pickle.
 |  
 |  __repr__(self)
 |      Return repr(self).
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __bound__
 |  
 |  __constraints__
 |  
 |  __contravariant__
 |  
 |  __covariant__
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Class methods inherited from _Final:
 |  
 |  __init_subclass__(*args, **kwds) from builtins.type
 |      This method is called when a class is subclassed.
 |      
 |      The default implementation does nothing. It may be
 |      overridden to extend subclasses.
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from _Final:
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from _Immutable:
 |  
 |  __copy__(self)
 |  
 |  __deepcopy__(self, memo)


Process finished with exit code 0

"""
# 2. typing.Union
"""
typing.Union
    Union type; Union[X, Y] means either X or Y.
    
    To define a union, use e.g. Union[int, str].  Details:
    - The arguments must be types and there must be at least one.
    - None as an argument is a special case and is replaced by
      type(None).
    - Unions of unions are flattened, e.g.::
    
        Union[Union[int, str], float] == Union[int, str, float]
    
    - Unions of a single argument vanish, e.g.::
    
        Union[int] == int  # The constructor actually returns int
    
    - Redundant arguments are skipped, e.g.::
    
        Union[int, str, int] == Union[int, str]
    
    - When comparing unions, the argument order is ignored, e.g.::
    
        Union[int, str] == Union[str, int]
    
    - You cannot subclass or instantiate a union.
    - You can use Optional[X] as a shorthand for Union[X, None].

"""