"""
其中 memo 保存着所有拷贝过的对象。为什么要设置 memo 呢？在某些特殊情况下，一个对象的相关对象可以指向它自己，比如双向链表。
    如果不将拷贝过的对象存着，那程序将陷入死循环。

    另外一个值得注意的点是 copier = _deepcopy_dispatch.get(cls)，这行代码根据待拷贝对象的类型，选择相应的拷贝函数。可选的拷贝函数有：
    用于拷贝基本数据类型的 _deepcopy_atomic, 用于拷贝列表的 _deepcopy_list，用于拷贝元组 _deepcopy_tuple，
    用于拷贝字典 的 _deepcopy_dict，用于拷贝自定义对象的 _deepcopy_inst 等等。

    其中比较重要的拷贝函数 __deepcopy_inst 代码如下所示：如果对象有 _ _ deepcopy _ _ 函数，则使用该函数进行拷贝；如果没有，
    那么先拷贝初始构造参数，然后构造一个对象，再拷贝对象状态。

"""
import copy
def deepcopy(x, memo=None, _nil=[]):
    """Deep copy operation on arbitrary Python objects.
    See the module's __doc__ string for more info.
    """
    if memo is None:
        memo = {}
        # memo 用于记录对象是否被复制过了, 可以防止对象出现循环引用导致无限复制的情景.

    d = id(x)
    y = memo.get(d, _nil)
    """
    Python：字典的get()方法使用: 字典-d.get(argument a, argument2 b):
    表示：若是字典d中包含键"a"，则返回键"a"的键值，若不包含键"a"，则返回b。
    即get()函数的第二个参数设置的就是字典中不包含该键时，get()函数的返回值。
    若是不设置第二个参数，则默认返回None
    """
    if y is not _nil:
        return y  # 对象已经被复制过， 跳出def 方法: y = id(x): 已经复制过的x 的id

    cls = type(x)

    copier = __deepcopy__dispatch.get(cls) # 一些内置的数据类型有特定的复制函数, 比如list等, 在copy.py中可以找到其定义.
    """
    copier = _deepcopy_dispatch.get(cls)，这行代码根据待拷贝对象的类型，选择相应的拷贝函数。可选的拷贝函数有：
    用于拷贝基本数据类型的 _deepcopy_atomic, 用于拷贝列表的 _deepcopy_list，用于拷贝元组 _deepcopy_tuple，
    用于拷贝字典 的 _deepcopy_dict，用于拷贝自定义对象的 _deepcopy_inst 等等。
    """
    if copier:
        y = copier(x, memo) # ？？
    else:
        ....#### 其他特殊的拷贝方式
    memo[d] = y # 添加新的赋值到memo, memo[id(x)] = _nil
    return y # id(x)??


"""deepcopy_inst:
 拷贝自定义对象。其中比较重要的拷贝函数 __deepcopy_inst 代码如下所示：
 如果对象有 _ _ deepcopy _ _ 函数，则使用该函数进行拷贝；如果没有，那么先拷贝初始构造参数(__init__)，然后构造一个对象，再拷贝对象状态。
 """

def __deepcopy__inst(x, memo):
    if hasattr(x, '__deepcopy__'): # 自定义对象x 是否有__deepcopy__函数
        return x.__deepcopy__(memo) # 返回的是？？memo 什么意思： memo 保存着所有拷贝过的对象。

    if hasattr(x, '__getinitargs__'): # 拷贝初始构造参数(__init__)
        args = x.__getinitargs__()
        args = deepcopy(args, memo) #
        y = x.__class__(*args)

    else:
        y = _EmptyClass()
        y.__class__ = x.__class__

    memo[id(x)] = y
    if hasattr(x, 'getstate__'):
        state = x._getstate__()
    else:
        state = x.__dict__()

    state = deepcopy(state, memo)
    if hasattr(y, '__setstate__'):
        y.__setstate__(state)
    else:
        y.__dict__.update(state)
    return y


"""
深拷贝需要维护一个 memo 用于记录已经拷贝的对象，这是它比较慢的原因。在绝大多数情况下，程序里都不存在相互引用。但作为通用模块，Python 深拷贝必须为了
这 1% 情形，牺牲 99% 情形下的性能。
"""
#一个场景
#上面给出了深拷贝效率对比的结果，已经可以看出深拷贝很慢了，但没有办法直观感受深拷贝拖累整个程序的运行速度。下面给一个实际项目的例子，最近在写的一些游戏环境。
# 玩家程序获得游戏环境给出的信息，当前玩家程序选择合适的动作，游戏环境根据该动作推进游戏逻辑；重复上述过程，直到分出胜负；整个过程如下所示。给玩家程序的
# 信息必须从游戏环境深拷贝出来。如果给玩家的信息是从游戏环境浅拷贝出来的，那么玩家程序有可能通过信息获取游戏秘密或者操纵游戏。
#我们已经知道默认的深拷贝很慢。为了改进深拷贝的效率，我们在信息类以及相关类都添加了 _ _ deepcopy _ _ 函数，下面是信息类示例。
"""
class FiveCardStudInfo(roomai.abstract.AbstractInfo):
    public_state  = None
    person_state  = None

    def __deepcopy__(self, memodict={}):
        info = FiveCardStudInfo()
        info.public_state = self.public_state.__deepcopy__()
        info.public_state = self.person_state.__deepcopy__()
        return info

"""
# 使用原始深拷贝，程序运行时间为 143 秒，其中深拷贝时间 134 秒，深拷贝时间占整个程序时间的 94%。使用了改进深拷贝，程序运行时间是 23 秒，
# 其中深拷贝时间 16 秒，占比为 69 %。虽然深拷贝依然占到了 69%，相比之间 94 % 已经下降很多。整个程序运行时间也从 134 秒减少到 23 秒了。

"""总结
Python 的深拷贝很慢，原因在于深拷贝需要维护一个 memo 用于记录已经拷贝的对象。而维护这个 memo 的原因是为了避免相互引用造成的死循环。绝大多数情况下，
程序中不存在相互引用。但作为通用模块，Python 深拷贝必须为了这 1% 情形，牺牲 99% 情形下的性能。真是无奈呀。我们可以通过自己实现 _ _ deepcopy _ _ 函数来改进其效率。
"""
