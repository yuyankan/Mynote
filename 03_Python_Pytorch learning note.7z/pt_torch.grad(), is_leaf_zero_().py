import torch
#help(torch.Tensor)
# torch.grad:
""" 1. 
This attribute is ``None`` by default and becomes a Tensor the first time a call to
    :func:`backward` computes gradients for ``self``.
    The attribute will then contain the gradients computed and future calls to
    :func:`backward` will accumulate (add) gradients into it.
"""

# is_leaf:!!!
"""
is_cuda
 |      Is ``True`` if the Tensor is stored on the GPU, ``False`` otherwise.
 |  
 |  is_leaf
 |      All Tensors that have :attr:`requires_grad` which is ``False`` will be leaf Tensors by convention.
 |      
 |      For Tensors that have :attr:`requires_grad` which is ``True``, they will be leaf Tensors if they were
 |      created by the user. This means that they are not the result of an operation and so
 |      :attr:`grad_fn` is None.
 |      
 |      Only leaf Tensors will have their :attr:`grad` populated during a call to :func:`backward`.
 |      To get :attr:`grad` populated for non-leaf Tensors, you can use :func:`retain_grad`.
 |      
 |      Example::
 |      
 |          >>> a = torch.rand(10, requires_grad=True)
 |          >>> a.is_leaf
 |          True
 |          >>> b = torch.rand(10, requires_grad=True).cuda()
 |          >>> b.is_leaf
 |          False
 |          # b was created by the operation that cast a cpu Tensor into a cuda Tensor
 |          >>> c = torch.rand(10, requires_grad=True) + 2
 |          >>> c.is_leaf
 |          False
 |          # c was created by the addition operation
 |          >>> d = torch.rand(10).cuda()
 |          >>> d.is_leaf
 |          True
 |          # d does not require gradients and so has no operation creating it (that is tracked by the autograd engine)
 |          >>> e = torch.rand(10).cuda().requires_grad_()
 |          >>> e.is_leaf
 |          True
 |          # e requires gradients and has no operations creating it
 |          >>> f = torch.rand(10, requires_grad=True, device="cuda")
 |          >>> f.is_leaf
 |          True
 |          # f requires grad, has no operation creating it
"""
import torch
a = torch.rand(10, requires_grad=True)
print(a.is_leaf) # True
#b = torch.rand(10, requires_grad=True).cuda()
#print(b.is_leaf) # False
# b was created by the operation that cast a cpu Tensor into a cuda Tensor
c = torch.rand(10, requires_grad=True) + 2
print(c.is_leaf) #False
# c was created by the addition operation
#d = torch.rand(10).cuda()
#print(d.is_leaf) # True
# d does not require gradients and so has no operation creating it (that is tracked by the autograd engine)
e = torch.rand(10).requires_grad_()
print(e.is_leaf) # True
# e requires gradients and has no operations creating it
f = torch.rand(10, requires_grad=True)
print(f.is_leaf) # True
# f requires grad, has no operation creating it

"""***************************************************************************************************"""
# 3. requires_grad
"""
requires_grad
 |      Is ``True`` if gradients need to be computed for this Tensor, ``False`` otherwise.
 |      
 |      .. note::
 |      
 |          The fact that gradients need to be computed for a Tensor do not mean that the :attr:`grad`
 |          attribute will be populated, see :attr:`is_leaf` for more details.
"""

"""
  zero_(...)
 |      zero_() -> Tensor
 |      
 |      Fills :attr:`self` tensor with zeros.
 
 Tensor.zero_() → Tensor
Fills self tensor with zeros.
"""