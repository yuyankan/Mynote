
# import package:
"""
Example:
在test_1.py文件中import我在lstm_1.py中定义的LstmParam和 LstmNetwork。
直接采用的是最简单的引用方法：from lstm_1 import LstmParam, LstmNetwork，但是很明显报错了，不能直接这样引用。因为，编译环境无法直接找到。
"""

# import process:
"""
当import的时候，python解释器只会在sys.path这个变量（一个list，你可以print出来看）里面的路径中找可能匹配的package或module。

而一个package跟一个普通文件夹的区别在于，package的文件夹中多了一个__init__.py文件。
换句话说，如果你在某个文件夹中添加了一个__init__.py文件，则python就认为这个文件夹是一个python中的package。

__init__.py文件的内容可以是空的（package里面必备这个模块，.py的文件就是模块，这个知识点要知道），它只是告诉python当前文件夹是一个python中的package。当然，你可以在这个__init__.py的module里面添加一些代码，这些代码会在import这个package的时候运行，也就是package下__init__.py模块，会在import package后，立刻会从无缩进的地方开始执行代码。

所以，请确保你要import的py文件所在的目录有__init__.py文件。

那出现以上问题时我们怎样才能成功引用呢？解决方法就是讲我们需要引用的目标文件放到我们编译环境的site-pakage 包文件里边，然后就可以import了。
"""