""" 1.实现generator的两种方式

python中的generator保存的是算法，真正需要计算出值的时候才会去往下计算出值。它是一种惰性计算（lazy evaluation）。
要创建一个generator有两种方式:
第一种方法：把一个列表生成式的[]改成()，就创建了一个generator：

第二种方式：在函数中使用yield关键字，函数就变成了一个generator。
函数里有了yield后，执行到yield就会停住，当需要再往下算时才会再往下算。所以生成器函数即使是有无限循环也没关系，它需要算到多少就会算多少，不需要就不往下算。

如上例，第一次输出f，它就是一个generator，之后每次next，它就执行到yield a。
当然其实平常很少用到next()，我们直接用for循环就可以遍历一个generator，其实for循环的内部实现就是不停调用next()。

生成器可以避免不必要的计算，带来性能上的提升；而且会节约空间，可以实现无限循环（无穷大的）的数据结构。

"""

""" 2.可迭代对象(Iterable)和迭代器(Iterator)的概念
可以直接作用于for循环的对象统称为可迭代对象：Iterable。
包括集合数据类型（list、tuple、dict、set、str等）和生成器（generator）。
可以使用isinstance()判断一个对象是否是Iterable对象。

 迭代器：Iterator：
它表示的是一个数据流，Iterator对象可以被next()函数调用并不断返回下一个数据，直到没有数据时抛出StopIteration错误。
可以把这个数据流看做是一个有序序列，但我们却不能提前知道序列的长度，只能不断通过next()函数实现按需计算下一个数据，所以Iterator的计算是惰性的，
只有在需要返回下一个数据时它才会计算。
Iterator甚至可以表示一个无限大的数据流，例如全体自然数。而使用list是永远不可能存储全体自然数的。

"""

"""3. 
生成器（generator）都是Iterator对象，但list、dict、str虽然是Iterable，却不是Iterator。

把list、dict、str等Iterable变成Iterator可以使用iter()函数；
Python的for循环本质上就是通过不断调用next()函数实现的

"""

""" 3.itertools模块
python的内置模块itertools提供了用于操作迭代对象的函数，非常方便实用。举一个例子：
islice(iterable, [start, ] stop [, step]):
创建一个迭代器，生成项的方式类似于切片返回值： iterable[start : stop : step]，将跳过前start个项，迭代在stop所指定的位置停止，
step指定用于跳过项的步幅。与切片不同，负值不会用于任何start，stop和step，如果省略了start，迭代将从0开始，如果省略了step，步幅将采用1.

"""

# =======example1 generator: =================
"""
通过列表生成式，我们可以直接创建一个列表。但是，受到内存限制，列表容量肯定是有限的。而且，创建一个包含100万个元素的列表，不仅占用很大的存储空间，
如果我们仅仅需要访问前面几个元素，那后面绝大多数元素占用的空间都白白浪费了。
所以，如果列表元素可以按照某种算法推算出来，那我们是否可以在循环的过程中不断推算出后续的元素呢？这样就不必创建完整的list，从而节省大量的空间。
在Python中，这种!!!一边循环一边计算的机制，称为生成器：generator!!!
"""

# = 1.1 generator creating: 第一种方法很简单，只要把一个列表生成式的[]改成()，就创建了一个generator =======
eg1 = [x * x for x in range(10)]
print(eg1)  # run: [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
eg1_g = (x * x for x in range(10))
print('1.1 list generator\n', eg1_g)  # run: <generator object <genexpr> at 0x000001E2EB495510>

# ====1.2: print generator every element using next()======
print('1.2: print list element in generator by next()\n', next(eg1_g))
print('1.2: print list element in generator by next()\n', next(eg1_g))
# ====1.3: print generator every element using for loop- as generator is iterable ======

for i in eg1_g:
    print('1.2: print generator list element by for loop: ', i)

""" note: 创建了一个generator后，基本上永远不会调用next()，而是通过for循环来迭代它，并且不需要关心StopIteration的错误。 """

# = 1.3 generator creating: 第二种方法: 函数 =======
"""
generator非常强大。如果推算的算法比较复杂，用类似列表生成式的for循环无法实现的时候，还可以用函数来实现。
比如，著名的斐波拉契数列（Fibonacci），除第一个和第二个数外，任意一个数都可由前两个数相加得到：
1, 1, 2, 3, 5, 8, 13, 21, 34, ...
斐波拉契数列用列表生成式写不出来，但是，用函数把它打印出来却很容易：
"""


# ====1.3.1 function without yield: for complex computation===
def fib(max):
    n, a, b = 0, 0, 1
    while n < max:
        print(b)
        a, b = b, a + b
        n = n + 1
    return 'done'


"""" note: a, b = b, a + b, is equal to:
t = (b, a + b) # t is tuple
a = t[0]
b = t[1]
"""
print('\n1.3.1 function without yield: ', fib(6))


# fib函数实际上是定义了斐波拉契数列的推算规则，可以从第一个元素开始，推算出后续任意的元素，这种逻辑其实非常类似generator。generator仅一步之遥。
# 要把fib函数变成generator，只需要把print(b)改为yield b就可以了：

# ====1.3.2 function with yield: for complex computation-->generator===
# 这就是定义generator的另一种方法。如果一个函数定义中包含yield关键字，那么这个函数就不再是一个普通函数，而是一个generator

def fib2(max):
    n, a, b = 0, 0, 1
    while n < max:
        yield (b)  # use yield-->generator
        t = (b, a + b)
        a = t[0]
        b = t[1]
        n = n + 1
    return 'done'


print('\n1.3.2 creating generator with yield', fib2(6))  # <generator object fib2 at 0x0000024761E00EB0>
f = fib2(6)

for i in f:
    print('1.3.2 print generator created with yield:, for loop', i)

""" note 1: 用for循环调用generator时，发现拿不到generator的return语句的返回值。如果想要拿到返回值，必须捕获StopIteration错误，
返回值包含在StopIteration的value中：
take element in generator: 
use next(): will report error when reach the end of generator element
use for loop: not report error when reach last element in generator.
"""
#while True:

#    try:
#        x = next(f)
#        print('1.3.2 print generator created with yield:, not for loop-getting generator -return value', x)
#    except StopIteration as e:
 #       print('Generator return value', e.value)
 #       break



"""generator和函数的执行流程不一样。函数是顺序执行，遇到return语句或者最后一行函数语句就返回。而变成generator的函数，
在每次调用next()的时候执行，遇到yield语句返回，再次执行时从上次返回的yield语句处继续执行。
"""

"""

"""