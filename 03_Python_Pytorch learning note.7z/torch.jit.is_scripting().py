""" torch.jit.is_scripting()
Help on function: is_scripting in module
torch._jit_internal:
is_scripting() -> bool
Function that returns True when in compilation and False otherwise.This is useful especially with the @unused decorator
 to leave code in your model that is not yet TorchScript compatible.
"""

"""test code::"""

import torch

@torch.jit.unused  # 该程序/方法不可被script 编译
def eg1_1(x):
    #if torch.jit.is_scripting(): # 判断该程序是否是编译过的scripting,因方法前有@torch.jit.unused, -->不可script 编译， -->一直为false
        x = x+1
        return x



def eg1_2(x):
    if torch.jit.is_scripting(): # 判断该程序是否是编译过的scripting,
        return x
    else:
        return (eg1_1(x))

x = torch.ones(3, 4)
b1_c = eg1_2(x)
script_b1 = torch.jit.script(eg1_2) # torch.jit.trace(fun, input)， trace have to create class case first with input: 运行一遍以记住程序。
# while script not need to run one case first.
print("\n1.script method:--return x:\n", script_b1(x))
print("\n2.original python codes-->return x+1:\n", b1_c)


