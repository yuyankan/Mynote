from collections import OrderedDict, namedtuple
from typing import Union, Tuple
import torch
from torch import Tensor

_grad_t = Union[Tuple[Tensor, ...], Tensor]
# See https://mypy.readthedocs.io/en/latest/generics.html#generic-methods-and-generic-self for the use
# of `T` to annotate `self`. Many methods of `Module` return `self` and we want those return values to be
# the type of the subclass, not the looser type of `Module`.
from typing import TypeVar
T = TypeVar('T', bound='Module')

class _IncompatibleKeys(namedtuple('IncompatibleKeys', ['missing_keys', 'unexpected_keys'])):
    # namedtuple(name, tuple[])-->is a function with input tuple , return name: tuple
    def __repr__(self):
        if not self.missing_keys and not self.unexpected_keys:
            return '<All keys matched sucessfully>'
        return super(_IncompatibleKeys, self).__repr__()
    __str__ = __repr__

def _addindent(s_, numSpaces):
    s = s_.split('\n')
    # do not do anything for single-line stuff
    if len(s)==1:
        return s_
    first = s.pop(0)
    s = [(numSpaces * '') + line for line in s]
    s = '\n'.join(s)
    s = first + '\n' + s
    return s

# Example for _addindent
s_1 = 'hi\nworld\nhaha'

s1 = s_1.split('\n')
print(s_1)
# hi
# world
# haha
print(s1) #['hi', 'world', 'haha']
s2 = [(10 * ' ') + line for line in s1]
print(s2) # ['          hi', '          world', '          haha']
s3 = '\n'.join(s2)
print(s3)
#          hi
#          world
#          haha


