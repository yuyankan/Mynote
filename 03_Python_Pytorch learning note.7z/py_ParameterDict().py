
# ParameterDict 参数字典类源码
"""
ParameterDict 是一个字典类源码，与python的字典非常相似，下面就是字典的一个例子，输入参数是个普通字典，然后转换为ParameterDict类型。
"""

"""
params = nn.ParameterDict({ 'left': nn.Parameter(torch.randn(5, 10)), 'right': nn.Parameter(torch.randn(5, 10))})
"""
import torch.nn as nn
import collections.abc as abc
from collections import OrderedDict

class ParameterDict(nn.Module):
    def __init__(self, parameters=None):
        super(ParameterDict, self).__init__()
        if parameters is not None:
            self.update(parameters) # 更新字典

    def update(self, parameters):# 输入新的字典，更新当前的参数字典
        if not isinstance(parameters, abc.Iterable): # 保证输入一定是个字典
            raise TypeError("ParametersDict.update should be called with an "
                            "iterable of key/value pairs, but got " +
                            type(parameters).__name__)
        if isinstance(parameters, abc.Mapping):# 判断是不是一个Mapping类型
            if isinstance(parameters, (OrderedDict, ParameterDict)):
                for key, parameter in parameters.items():
                    self[key] = parameter
            else:
                for key, parameter in sorted(parameters.items()):
                    self[key] = parameter
        else:
     # 感觉这里是为了适应其他的字典类，毕竟有可能用户自己也写个字典类
            for j, p in enumerate(parameters):
                if not isinstance(p, abc.Iterable):
                    raise TypeError("ParametersDict.update should be called with an "
                            "iterable of key/value pairs, but got " +
                            type(parameters).__name__)
                if not len(p) ==2:
                    raise ValueError("ParameterDict update sequence element "
                                     "# "+str(j) + "has length" + str(len(p))+"; 2 is required")
                self[p[0]] = self[p[1]]

    def __getitem__(self, key):# 同上一节，可以使用键访问值
        return self._parameters[key]

    def __setitem__(self, key, parameter):# 同上一节，可以使用键设置值
        print("__setitem__ is called: register_parameter")
        self.register_parameter(key, parameter)

    def __delitem__(self, key): # 删除某个键，可使用del删除
        del self._paramters[key]

    def __len__(self): # 返回字典个数
        return len(self._parameters)

    def __iter__(self):# 同上一节，可以得到迭代器，迭代器用键表示
        return iter(self._parameters.key())

    def __contains__(self, key): # 判断当前key是否在字典中，重载关键字in， key in dict
        return key in self._parameters

    def clear(self):# 清空字典
        self._parameter.clear()

    def pop(self, key): # 删除某个键，并返回其值。
        v = self[key]
        del self[key]
        return v

    def keys(self):# 返回所有的键的名称
        return self._parameters.keys()

    def items(self):# 同字典的item用法
        return self._parameters.items()

    def values(self):# 返回所有的值
        r"""Return an iterable of the ParameterDict values.
                """
        return self._parameters.values()

    # 字典可视化
    # (left): Parameter containing: [torch.FloatTensor of size 5x10]
    # (right): Parameter containing: [torch.FloatTensor of size 5x10]
    def extra_repr(self):
        import torch
        child_lines = []
        for k, p in self._parameters.items():
            size_str = 'x'.join(str(size for size in p.size()))
            device_str = '' if not p.is_cuda else '(GPU {})'.format(p.get_device())
            parastr = 'Parameter containing: [{} of size {}{}]'.format(torch.typename(p.data), size_str, device_str)
            child_lines.append('(' + k + '):' + parastr)
        tmpstr = '\n'.join(child_lines)
        return tmpstr

    """
    
    总结
关于参数的三个类的分析就到这里了，其实感觉跟正常的python用法也没啥区别，为了方便用户使用pytorch，官方重载了大量的函数，方便用户使用，
很大程度上降低了使用难度。后续，我再对模型的几个类比如Sequential，ModuleList，ModuleDict进行分析，Module这个类我估计不会进行分析了，
将近1000行，实现了太多太多功能，我觉得太底层了，就不分析了，如果有人感兴趣的话，欢迎一起讨论研究。
——
    """