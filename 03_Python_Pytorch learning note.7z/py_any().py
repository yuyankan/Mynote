"""python的any函数
Python any() function is one of the built-in functions. It takes iterable as an argument and returns True if any of the
element in the iterable is True. If iterable is empty, then it returns False.

Python any（）函数是内置函数之一。 它以iterable作为参数，如果iterable中的任何元素为True，则返回True。 如果iterable为空，则返回False。

"""
"""
1. Python any() function is a utility method and shortcut to below function.
Python any（）函数是一种实用程序方法，是以下函数的快捷方式。"""

def any(iterable):
    for element in iterable:
        if element:
            return True
    return False


""" iterable cases/object:
1. When we want an object boolean value, python looks for __bool__ function in the object.
当我们想要一个对象布尔值时，python在对象中寻找__bool__函数。

2. If __bool__ function is not defined, then len() function is called if it’s defined. 
The object boolean value is considered as True if len() output is non-zero.
如果__bool__函数没有定义，则如果已定义len()函数，则将调用它。 如果len()输出为非零，则对象布尔值被视为True。

3. If a class defines neither __len__() nor __bool__() functions, all its instances are considered True.
如果一个类没有__len__()或__bool__()函数，则其所有实例均被视为True。

4. __bool__ function to check object boolean value, if you are using python 2.x then you have to implement __bool__函数
检查对象的布尔值，如果使用的是python 2.x，则必须实现 __nonzero__ function. __nonzero__函数。
"""

# Example1: 带有布尔值的Python any（）示例 (Python any() example with boolean)===
list1_bools = [True, True, False]
print("\nExample1: 带有布尔值的Python any（）示例 (Python any() example with boolean):")
print("any(list1_bools):", any(list1_bools))

# Example2: 带有空可迭代的Python any（） (Python any() with empty iterable)===
print("\nExample2: 带有空可迭代的Python any（） (Python any() with empty iterable):")
list2_empty = []
print("any(list2_empty=[]): ", any(list2_empty))

# Example3: Python any（）与字符串列表 (Python any() with list of strings)==
print("\nExample3: Python any（）与字符串列表 (Python any() with list of strings):\n")
print("3.1: iterable elements are True string (at least one)")
list3_1string = ['True', 'False']
print("any(list3_string= ['True', 'False']):", any(list3_1string))

print("\n3.2: iterable any elements is true string with different case")
list3_2string = ['fff', 'true']
print("any(list3_2string= ['fff', 'true']): ", any(list3_2string))

print("\n3.3: iterable any elements are not true string")
list3_3string = ['abc', 'def']
print("any(list3_3string= ['abc', 'def']):", any(list3_3string))

print("\n3.4: iterable all elements are empty strin")
list3_4string = []
print("any(list3_4string= []):", any(list3_4string))

# Example 4: 有自定义对象的Python any（） (Python any() with custom objects)===

"""
Let’s test above explanation with a custom class. We will create a custom Employee class and use its objects in the 
list and call any() function on it.
让我们用自定义类测试以上解释。 我们将创建一个自定义的Employee类，并在列表中使用其对象，然后在其上调用any()函数
"""
print("\nExample 4: 有自定义对象的Python any（） (Python any() with custom objects):")
"""Since eg4 class doesn’t have __len__() and __bool__() function defined, it’s boolean value is True."""

print("\n4.1: class eg4 doesn’t have __len__() and __bool__() function defined:")
class eg4():
    name = ''
    def __init__(self, n):
        self.name = n

list4 = [eg4('Hi'), eg4('World')]
print("any(list4= [eg4('Hi'), eg4('World')]:)", any(list4))

"""
define __len__() function for class
"""
print("\n4.2: define __len__() function for class")
class eg4_2():
    name = ''
    def __init__(self, n):
        self.name = n

    def __len__(self):
        print("len function called")
        return len(self.name)

list4_2 = [eg4_2('Hi'), eg4_2('World')]
# print(len(list5[0])): len funciton will not auto.call, need to use len(list5)
print("any(list4= [eg4('Hi'), eg4('World')]:)", any(list4_2)) # any(): will call len() funciton if there is no __bool__method.

"""
Notice that len() function is getting called when any() is used with the list of Employee objects. Since the first 
object in the iterable returned True, other elements are not required to be evaluated for the boolean value.
注意，将any（）与Employee对象的列表一起使用时，会调用len()函数。 由于iterable中的第一个对象返回True，因此不需要评估其他元素的布尔值。
"""

"""4.3:  define __bool__ function for class """

print("\n4.3: define __bool__() function for class")
class eg4_3():
    name = ''
    def __init__(self, n):
        self.name = n

    def __bool__(self):
        print("boll function called")
        if len(self.name) > 3:
            return True
        else:
            return False

list4_3 = [eg4_3('Hi'), eg4_3('World')] # or [eg4_3('Hi'), eg4_3('World')]-->__bool__ will call twice as first item len('Hi')-->False
print("any(list4_3= [eg4_3('Hi'), eg4_3('World')]:) ", any(list4_3))

"""
It’s clear from the output that if __bool__ function is defined, then it’s used for getting the python object boolean value.
从输出中很明显，如果定义了__bool__函数，那么它将用于获取python对象的布尔值。

Notice that second list any() function output is False and boolean value is retrieved for all the objects in the list.
请注意，第二个列表的any（）函数输出为False，并且为列表中的所有对象检索了布尔值。
"""

