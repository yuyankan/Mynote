import os
# help(os.walk)

# os.walk:
"""
alk(top, topdown=True, onerror=None, followlinks=False)
    Directory tree generator.
    
    For each directory in the directory tree rooted at top (including top
    itself, but excluding '.' and '..'), yields a 3-tuple
    
        dirpath, dirnames, filenames
"""


"""
下面列出了一些在os模块中比较有用的部分。它们中的大多数都简单明了。

os.sep可以取代操作系统特定的路径分隔符。windows下为 “\\”

os.name字符串指示你正在使用的平台。比如对于Windows，它是'nt'，而对于Linux/Unix用户，它是'posix'。

os.getcwd()函数得到当前工作目录，即当前Python脚本工作的目录路径。

os.getenv()获取一个环境变量，如果没有返回none

os.putenv(key, value)设置一个环境变量值

os.listdir(path)返回指定目录下的所有文件和目录名。

os.remove(path)函数用来删除一个文件。

os.system(command)函数用来运行shell命令。

os.linesep字符串给出当前平台使用的行终止符。例如，Windows使用'\r\n'，Linux使用'\n'而Mac使用'\r'。

os.curdir:返回当前目录（'.')

os.chdir(dirname):改变工作目录到dirname

========================================================================================

os.path常用方法：

os.path.isfile()和os.path.isdir()函数分别检验给出的路径是一个文件还是目录。

os.path.exists()函数用来检验给出的路径是否真地存在

os.path.getsize(name):获得文件大小，如果name是目录返回0L

os.path.abspath(name):获得绝对路径

os.path.normpath(path):规范path字符串形式

os.path.split(path) ：将path分割成目录和文件名二元组返回。

os.path.splitext():分离文件名与扩展名

os.path.join(path,name):连接目录与文件名或目录;使用“\”连接

os.path.basename(path):返回文件名

os.path.dirname(path):返回文件路径

#部分示例：

import os

path = os.path.abspath(__file__)

path2 = os.path.dirname(__file__)

path3 = os.path.dirname(os.path.abspath(__file__))

path4 = os.path.split(path3)[0]

path5 = os.path.join(path4, "test\\ogf", "inog")

print(path)

print(path2)

print(path3)

print(path4)

print(path5)
"""

# os.walk:
"""
alk(top, topdown=True, onerror=None, followlinks=False)
    Directory tree generator.

    For each directory in the directory tree rooted at top (including top
    itself, but excluding '.' and '..'), yields a 3-tuple

        dirpath, dirnames, filenames
"""


import os
path = 'D:/Exersize/02_DATA LOADER/01_Data loader and dataset/Classification-Model-of-RMB-master'
for a, b, c in os.walk(path):
    print('a:',a)
    print('b:',b)
    print('c:',c)
    break
print("-"*50)
import os
data_dir = '02_test_tryLib'
for root, dirs, s in os.walk(data_dir):
    print(root)
    print(dirs)
    print(s)
    print("-"*50)
    img_names = os.listdir(root)
    print(img_names)
    print("*"*50)