"""@Property
Python中有一个被称为属性函数(property)的小概念，它可以做一些有用的事情。在这篇文章中，我们将看到如何能做以下几点：

将类方法转换为只读属性
重新实现一个属性的setter和getter方法
"""
"""1. 使用属性函数的最简单的方法之一是将它作为一个方法的装饰器来使用
这可以让你将一个类方法转变成一个类属性。当我需要做某些值的合并时，我发现这很有用。其他想要获取它作为方法使用的人，发现在写转换函数时它很有用。
"""
class Person():
    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name

    @property
    def full_name(self):
        return "%s %s "%(self.first_name, self.last_name)

"""
在上面的代码中，我们创建了两个类属性： self.first_name和 self.last_name。接下来，我们创建了一个 full_name方法，
它有一个 @property装饰器。这使我们能够在Python解释器会话中有如下的交互："""

person = Person('Hi', 'World')
print(person.full_name) # Hi World
print(person.first_name) # Hi
#person.full_name = 'hi' #-->     person.full_name = 'hi', AttributeError: can't set attribute
"""
正如你所看到的，因为我们将方法变成了属性，我们可以使用正常的点符号访问它。但是，如果我们试图将该属性设为其他值，我们会引发一个 AttributeError错误。
改变 full_name属性的唯一方法是间接这样做：
>>> person.first_name = "Dan"
>>> person.full_name
'Dan World'
"""

"""这是一种限制，因此让我们来看看另一个例子，其中我们可以创建一个允许设置的属性。"""

#  使用Python property取代setter和getter方法
"""orginal code"""
class E2():
    def __init__(self):
        self.fee = None

    def get_fee(self):
        return self.fee

    def set_fee(self, value):
        self.fee = value

""" 要使用这个类，我们必须要使用定义的getter和setter方法：
>>> f = E2()
>>> f.set_fee("1")
>>> f.get_fee()
"""

"""如果你想添加可以使用正常点符号访问的属性，而不破坏所有依赖于这段代码的应用程序，你可以通过添加一个属性函数非常简单地改变它："""
class E3():
    def __init__(self):
        self._fee = None

    @property
    def fee(self):
        return self._fee

    @fee.setter
    def fee(self, value):
        print("@fee.setter is called")
        self._fee = value

"""上面的代码演示了如何为 fee属性创建一个setter方法,得到一个''允许设置的属性值''。你可以用一个名为 @fee.setter的装饰器装饰第二个方法名也为fee的方法来实现这个。
当你如下所做时，setter被调用：
>>> f = E3()
>>> f.fee = "1"  # not: only could use f.fee, not f.fee()：带（）表示函数， 而此时没有函数，设置为属性。
"""
f = E3()
f.fee = 2
print(f.fee)
