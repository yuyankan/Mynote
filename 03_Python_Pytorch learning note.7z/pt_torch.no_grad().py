
# In this mode, the result of every computation will have `requires_grad=False`, even when the inputs have `requires_grad=True`.


"""
Help on class no_grad in module torch.autograd.grad_mode:

class no_grad(_DecoratorContextManager)
 |  Context-manager that disabled gradient calculation.
 |
 |  Disabling gradient calculation is useful for inference, when you are sure
 |  that you will not call :meth:`Tensor.backward()`. It will reduce memory
 |  consumption for computations that would otherwise have `requires_grad=True`.
 |
 |  In this mode, the result of every computation will have
 |  `requires_grad=False`, even when the inputs have `requires_grad=True`.
 |
 |  This context manager is thread local; it will not affect computation
 |  in other threads.
 |
 |  Also functions as a decorator. (Make sure to instantiate with parenthesis.)
 |
 |  .. note::
 |      No-grad is one of several mechanisms that can enable or
 |      disable gradients locally see :ref:`locally-disable-grad-doc` for
 |      more information on how they compare.
 |
 |  Example::
 |
 |      >>> x = torch.tensor([1], requires_grad=True)
 |      >>> with torch.no_grad():
 |      ...   y = x * 2
 |      >>> y.requires_grad
 |      False
 |      >>> @torch.no_grad()
 |      ... def doubler(x):
 |      ...     return x * 2
 |      >>> z = doubler(x)
 |      >>> z.requires_grad
 |      False
 |
 |  Method resolution order:
 |      no_grad
 |      _DecoratorContextManager
 |      builtins.object
 |
 |  Methods defined here:
 |
 |  __enter__(self)
 |
 |  __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None
 |
 |  __init__(self)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |
 |  ----------------------------------------------------------------------
 |  Methods inherited from _DecoratorContextManager:
 |
 |  __call__(self, func: ~F) -> ~F
 |      Call self as a function.
 |
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from _DecoratorContextManager:
 |
 |  __dict__
 |      dictionary for instance variables (if defined)
 |
 |  __weakref__
 |      list of weak references to the object (if defined)


Process finished with exit code 0

"""
import torch
x = torch.tensor([1], dtype=torch.float32, requires_grad=True)
with torch.no_grad():
    y = x * 2
print(y.requires_grad) # False

print("*"*50)

@torch.no_grad()
def doubler(x):
    return x * 2
z = doubler(x)
print(z.requires_grad) # False