"""1.  torch.mul(input, other, out=None)
功能：
对位相乘，可以广播
该函数能处理两种情况：
input是矩阵/向量，other是标量, 这个时候是就是input的所有元素乘上other
input是矩阵/向量，other是矩阵/向量, 这时out_i = input_i x other_i , 对位相乘，如果两个都是向量，则可以广播的
"""

"""2. torch.mm(input, mat2, out=None)
解决的问题：
处理二维矩阵的乘法，而且也只能处理二维矩阵，其他维度要用torch.matmul
"""

"""3. torch.bmm (input, mat2, out=None)
看函数名就知道，在torch.mm的基础上加了个batch计算，不能广播
"""

"""4. torch.matmul(input, other, out=None)
功能：
适用性最多的，能处理batch、广播的矩阵：
如果第一个参数是一维，第二个是二维，那么给第一个提供一个维度
如果第一个是二维，第二个是一维，就是矩阵乘向量
带有batch的情况，可保留batch计算
维度不同时，可先广播，再batch计算
"""
"""总结
对位相乘用torch.mul，二维矩阵乘法用torch.mm, batch二维矩阵用torch.bmm，    batch、广播用torch.matmul
"""
import torch
t1 = torch.randn(3)*10
t2 = torch.rand(3)
print("t1:{}\nt2: {}\n".format(t1, t2))
print("torch.mul(t1, t2)", torch.mul(t1, t2))

print("\ntorch.matmul(t1, t2)", torch.matmul(t1, t2))
#print("\ntorch.mm(t1, t2)", torch.mm(t1, t2))

import torch
a = torch.ones(2, 2, 5)
b = torch.ones(5, 3)
print("*"*50)
print("a:", a)
print("*"*50)
print("b:", b)
print("*"*50)
print("a.matmul(b): ", a.matmul(b))
