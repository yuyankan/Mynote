
# summary:
"""
0. self.param_groups:
        list[dict]: [{'params': [{p1}, {p2}..], 'name1': default1 },{'params': [{p3}, {p4}..], 'name2': default2 },]

        1.-->add contents by:
            (1.1) def add_param_group()
                        self.param_groups.append(param_group)

        2.-->used by:
            (2.1) def state _dict(self):
                        return: {'state': packed_state, 'param_groups': param_groups}
                        -->used by :
                        (2.1.1): def load_state_dict (self, state_dict):
                                    use method:
                                    --> 1): def cast(param, value):
                                                        'make a deep copy of value, casting all tensors to device of param'
                                    --> 2): def update_group(group, new_group)

                        (2.1.2): def __setstate__(self, state)
                                    self.__dict__.update(state)
                                    self._hook_for_profile()

            (2.2): def __getstate__(self):
                    return {
                         'defaults': self.defaults,
                         'state': self.state,
                         'param_groups': self.param_groups,
                            }

            (2.4): def zero_grad ():
                            (self, set_to_none: bool = False)
                            'for group in self.param_groups:
                                for p in group['params']:
                                    if p.grad is not None:
                                        if set_to_none:
                                            p.grad = None
                                        else:
                                            if p.grad.grad_fn is not None:
                                                p.grad.detach_()
                                            else:
                                                p.grad.requires_grad_(False)
                                            p.grad.zero_()'
                            use method:
                            2.4.1): def _hook_for_profile(self):
                                    -->use:
                                       2.4.1.1)) def profile_hook_step(func):



1. def step(self, closure):
        'Performs a single optimization step (parameter update)'
        'note::
            Unless otherwise specified, this function should not modify the
            ``.grad`` field of the parameters.'

        raise NotImplementedError

2. self.defaults：# {}: 包含超参数的字典

                for name, default in self.defaults.items():
                    if default is required and name not in param_group:
                        raise ValueError("parameter group didn't specify a value of required optimization parameter" + name)
                    else:
                        param_group.setdefault(name, default) # ??



"""



import warnings
from itertools import chain
import torch
import functools
from collections import defaultdict, abc as container_abcs
from copy import deepcopy

class _RequiredParameter(object):
    """Singleton class representing a required parameter for an Optimizer"""
    def __repr__(self):
        return "<required parameter>"

required =_RequiredParameter()

class Optimizer(object):
    r""" Base class for all optimizers.

    ..warning::
        Parameters need to be specified as collections that have a deterministic
        ordering that is consistent between runs.
            Examples of object that don't satisfy those properties are sets and iterators over values of dictionaries.
    Args:
        params(iterable): an iterable of : class:'torch.Tensor'' or: class:'dict's.
            Specify what Tensors should be optimized.

        defaults: (dict): a dict containing default values of optimization options
            (used when a parameter group doest not specify them)
    """
    def __init__(self, params, defaults):
        torch._C._log_api_usage_once("python.optimizer")
        self.defaults = defaults # {}: 包含超参数的字典

        self._hook_for_profile()# ->给self.__class__属性step赋值.hooked =True.

        if isinstance(params, torch.Tensor):
            raise TypeError("params argument given to the optimizer should be an iterable of Tensors or dicts,"
                            "but got" + torch.typename(params))
        self.state = defaultdict(dict) # the value of dict, when key not specified
        self.param_groups = []

        param_groups = list(params)
        if len(param_groups) == 0:
            raise ValueError("optimizer got an empty parameter list")
        if not isinstance(param_groups[0], dict): # -->make param_groups type as: [ {}, {}, ...{}]
            param_groups = [{"params": param_groups}] # ->[{'params': param_groups}, ]=[{'params': [{p1}, {p2}..] } , ]

        for param_group in param_groups:
            self.add_param_group(param_group)# param_group: {'params': [{p1}, {p2}..] }

    def __getstate__(self):
        return {
            'defaults': self.defaults,
            'state': self.state,
            'param_groups':self.param_groups }

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._hook_for_profile() # To support multiprocessing pickle/unpickle# ??

    def __repr__(self):
        format_string = self.__class__.__name__ + '('
        for i, group in enumerate(self.param_groups):
            format_string +='\n'
            format_string += 'Parameter Group {0}\n'.format((i))
            for key in sorted (group.keys()):
                if key!= 'params':
                    format_string += '      {0}: {1}\n'.format(key, group[key])
        format_string += ')'
        return format_string


    def _hook_for_profile(self):
        self._zero_grad_profile_name = "Optimizer.zero_grad {}.zero_grad".format(self.__class__.__name__)
        def profile_hook_step(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                obj, *_ = args
                profile_name = "Optimizer.step#{}.step".format(obj.__class__.__name__)
                with torch.autograd.profiler.record_function(profile_name): # 记录一下code as 'profile_name'
                    return func(*args, **kwargs)
            return wrapper

        hooked = getattr(self.__class__.step, 'hooked', None)
        if not hooked:
            self.__class__.step = profile_hook_step(self.__class__.step)
            self.__class__.step.hooked = True

    def state_dict(self):
        r"""Returns the state of the optimizer as a : class: 'dict'.

        It contains two entries:

        *state- a dict holding current optimization state.
            Its contents differes between optimizer classes.
        * param_groups- a l ist containing all paraemer groups where each parameter group is a dict.
        """
        # save order indices insdtead of Tensors
        param_mappings = {}
        start_index = 0

        def pack_group(group): #group: dict: {'params': [{p1}, {p2}..], 'name1': default1 },
            nonlocal start_index
            packed = {k: v for k, v in group.items() if k!= 'params'}# packed ={'name1': default1}
            param_mappings.update({id(p): i for i, p in enumerate(group['params'], start_index)
                                  if id(p) not in param_mappings})# param_mappings ={id(p1): 0, id(p2):1, ..}
            # i start from start_index: enumerate(iterable, start_index)
            """ a={'h':1, 'h2':2}
                b = 0
                for i, j in enumerate(a, 3):
                >>: 3, 'h'; 4'h2'
            """
            packed['params'] =[param_mappings[id(p)] for p in group['params']] #packed = {'name1': default1, 'params': [0, 1, 2,..}
            start_index +=len(packed['params'])
            return packed

        param_groups = [pack_group(g) for g in self.param_groups]# [{'params': [{p1}, {p2}..], 'name1': default1 },{'params': [{p3}, {p4}..], 'name2': default2 },]
        # param_groups = [{'name1': default1, 'params': [0, 1, 2,..}, {'name2': default2, 'params': [0, 1, 2,..}, ]
        #remap state to use order indices as keys
        packed_state = {(param_mappings[id(k)] if isinstance(k, torch.Tensor) else k):
                v for k, v in self.state.items() # {0:v}..
                        }
        return {
            'state': packed_state,
            'param_groups': param_groups # {'state': packed_state,'param_groups': [{'name1': default1, 'params': [0, 1, 2,..}, {'name2': default2, 'params': [0, 1, 2,..}, ], }
        }

    def load_state_dict(self, state_dict):
        r"""Loads the optimizer state.
        Args:
            state_dict(dict): optimizer state. Should be an object returned
                from a call to: meth:'state_dict'.
        """
        # deepcopy, to be consistent with module API
        state_dict = deepcopy(state_dict)
        # validate the state dict
        groups = self.param_groups
        saved_groups = state_dict['param_groups']# [{'name1': default1, 'params': [0, 1, 2,..}, {'name2': default2, 'params': [0, 1, 2,..}, ]

        if len(groups) != len(saved_groups):
            raise ValueError("loaded state dict has a different number of parameter groups")
        param_lens = (len(g['grams'] for g in groups))
        saved_len = (len(g['grams'] for g in saved_groups))
        if any(p_len != s_len for p_len, s_len in zip(param_lens, saved_groups)):
            raise ValueError("loaded state dict contains a parameter group that does not match the size of optimizer's group ")

        #update the state
        id_map = {old_id: p for old_id, p in zip(
            chain.from_iterable(g['params'] for g in saved_groups),
            chain.from_iterable(g['params'] for g in groups))} # {0:p1, 1: p2, ..k: pk}

        def cast(param, value):
            r"""make a deep copy of value, casting all tensors to device of param."""
            if isinstance(value, torch.Tensor):
                # Floating-point types are a bit special here. They are the only ones
                # that are assumed to always match the type of params.
                if param.is_floating_point():
                    value = value.to(param.dtype)
                value = value.to(param.device)
                return value

            elif isinstance(value, dict):
                return{k: cast(param, v) for k, v in value.items()}

            elif isinstance(value, container_abcs.Iterable):
                return type(value)(cast(param, v) for v in value)
            else:
                return value

            #copy state assigned to params (and cast tensors to appropriate types).
            # state that is not assigned to params is copied as is( needed for
            # backward compatibility)
            state = defaultdict(dict)
            for k, v in state_dict['state'].items():# {0:v1, 1: v2}..
                if k in id_map:
                    param = id_map[k]
                    state[param] = cast(param, v)# state={'p1': v1, 'p2':v2}
                else:
                    state[k] = v

            # Update parameter groups, setting their 'params' value
            def update_group(group, new_group):
                new_group['params'] = group['params']
                return new_group
            param_groups = [update_group(g, ng) for g, ng in zip(groups, saved_groups)]
            self.__setstate__({'sate':state, 'param_groups':param_groups})# update dict.

    def zero_grad(self, set_to_none: bool = False):
        r"""Set the gradients of all optimized: class: 'torch.Tensor's to zero

        Args:
            set_to_none(bool): instead of setting to zero, set the grads to None.
                This will in general have lower memory footprint, and can modestly improve performance.

                However, it changes certain behaviors. For example:
                1. when the uer tries to access a gradient and perform manual ops on it,
                    a Noe attribute or a Tensor fuel of 0s will behave differently.
                2. If the user requests 'zero_grad'(set_to_none=True) followed by a backward pass,
                    'grad;s are guranteed to be None for params that did not receive a gradient.
                3. 'torch.optim' optimizers have a different behavior if the the gradient is 0 or None

                    (in one case it does the step with a gradient of 0 and in the other it skips the step altogether)
                  """
        if not hasattr(self, '_zero_grad_profile_name'):
            self._hook_for_profile()
        with torch.autograd.profiler.record_function(self._zero_grad_profile_name):
            for group in self.param_groups:
                for p in group['params']:
                    if p.grad is not None:
                        if set_to_none:
                            p.grad = None
                        else:
                            if p.grad.grad_fn is not None:
                                p.grad.detach_() # p.grad 无法参与backward
                            else:
                                p.grad.requires_grad(False)
                            p.grad.zero_() # grad 设置为0， 同时不参与backward grad 计算。



    def step(self, closure):
        r"""Performs a single optimization step(parameter update)

        Args:
        closure(callable): A closure that reevaluates the model and return the loss.
            Optional for most optimizers.

        ..note::
            Unless otherwise specified, this function should not modify the 'grad' filed of the parameters.
             """
        raise NotImplementedError

    def add_param_group(self, param_group):## param_group: {'params': [{p1}, {p2}..] }
        r""" Add a param group to the : class: 'Optimizer's 'param_groups'.

        This can be useful when fine tuning a pre-trained network as frozen layers can be made trainable
        and added to the : class: 'Optimizer' as training progresses.

        Args:
            param_group: specifies what Tensor should be optimized along with group specific optimization options.
        """
        assert isinstance(param_group, dict), "param group must be a dict"

        params = param_group['params'] # [{p1}, {p2}..]
        if isinstance(params, torch.Tensor):
            param_group['params'] = [params] # -->value: = param_group['params'] , becomes a list of torch.Tensor
        elif isinstance(params, set):
            raise TypeError("optimizer parameters need to be organized in ordered collections."
                            "but the ordering of tensor in sets will change between runs."
                            "please use a list instead")
        # note: ordering of tensor in sets will change between runs."use a list instead
        else:
            param_group['params'] = list(params) # -->make value is a list

        for param in param_group['params']: # 同一名字对应的所有参数[{p1}, {p2}..]
            if not isinstance(param, torch.Tensor):
                raise TypeError("Optimizer can only optimze Tensors, but one of the param is " + torch.typename(param))

            if not param.is_leaf:
                raise ValueError("can't optimize a non-leaf Tensor")

        for name, default in self.defaults.items():
            if default is required and name not in param_group:
                raise ValueError("parameter group didn't specify a value of required optimization parameter" + name)
            else:
                param_group.setdefault(name, default) # ??{'params': [{p1}, {p2}..], 'name': default }
                "setdefault(self, key, default=None, /)"
                'Insert key with a value of default if key is not in the dictionary.'

                'Return the value for key if key is in the dictionary, else default.'

        # check if one parameter group has duplicate parameter
        params = param_group['params']
        if len(params) != len(set(params)): # len(list) ! = len(set(list)): note set(dict) = (dict.keys.()): 不重复的Key {key1, key2,..}
            #???
            warnings.warn("optimizer contains a parameter group with duplicate parameters;"
                          "in future , this will cause an error;"
                          "see github.com/pytorch/pytorch/issues/40967 for more information", stacklevel=3)

            # check is parameter appear in more than one parameter group
        param_set = set()
        for group in self.param_groups:# [{'params': [{p1}, {p2}..], 'name1': default1 },]
            param_set.update(set(group['params'])) # set.update(): update a set with the union of itself and others. # (p1, p2, ..)

        if not param_set.isdisjoint(set(param_group['params'])):
            raise ValueError("some parameters appear in more than one parameter group")

        self.param_groups.append(param_group)# param_groups now is a list[{}, {}..]
        # ->[{'params': [{p1}, {p2}..], 'name1': default1 },{'params': [{p3}, {p4}..], 'name2': default2 },]





