#- deepcopy_list(): memo: record /copy x in this function, not modified in deepcopy(obj, memo), where used only
# for check if obj has been recorded or not

# - deepcopy(x, memo):return y= x/ y = memo[id(x)], memo_ modified here,
#
# copier = _deepcopy_dispatch.get(cls): for list, tuple/dict, copier will call deepcopy(x, obj)again：
# deepcopy(obj)内部循环调用deepcopy(): 传递参数：


#  memo_d: memo_d(id(ob传递给copier(x, memo):
  # copier(x, memo)调用deepcopy(x, memo_d): 返回y,


from copy import _deepcopy_dispatch


def deepcopy(obj, memo_d=None, _nil=[]):
    print("\n0. deepcopy () is called")
    print("a in deepcopy:", obj)
    #print("memo_d in deepcopy():", memo_d)

    if memo_d is None:
        memo_d ={}
    d = id(obj)
    print("obj id in deepcopy:", d)
    y_d = memo_d.get(d, _nil)
    if y_d is not _nil:
        return y_d # then jump out def deepcopy method.
    cls = type(obj)
    if cls == dict:

        copier = _deecopy_dict
    else:
        copier = _deepcopy_dispatch.get(cls)
    print("memo_d in deepcopy()1:", memo_d)
    y_d = copier(obj, memo_d) # memo_d no change here?

    memo_d[d] = y_d
    print("y in deepcopy(): id(y_d), y_d", id(y_d), y_d)
    print("memo_d in deepcopy()2:", memo_d)

    return y_d

def _deecopy_dict(x, memo, deepcopy=deepcopy):
    print("\n1. deepcopy_dict is called")
    y = {}
    memo[id(x)] = y
    print("memo in deepcopy_dict():", memo)
    print("*"*50)
    for key, value in x.items():
        y[deepcopy(key, memo)] = deepcopy(value, memo) # deepcopy (x,memo) = y= _deepcopy_atomic(x, memo) =x
        # y[key] = value,while for memo[id(x)] = {y[key], y[key] value}
        print("\n key: value in deepcopy_copy:", key, value)
        print('memo in deepcopy_copy:', memo) # memo[id(x)] = y, y updates, memo also updated here.
        print("y in deepcopy_copy:", y)
        print("-" * 50)
    print(memo[id(x)] is y) # memo[id(x)] = y, y is list, contents changed, yet id no change.
    print("*" * 50)
    return y


"""**********************************************************************************"""
def _deepcopy_list(x, memo, deepcopy=deepcopy):
    print("\n1. deepcopy_list is called")

    y = []
    memo[id(x)] = y
    print(memo[id(x)] is y)
    append = y.append
    print("memo in deepcopy_list():", memo)
    print("*"*50)
    for a in x:
        append(deepcopy(a, memo)) # memo is not modified here: -->yet memo[id(x)] = y: id(y): y changed-->memo value changed too.
        print("\na in deepcopy_list:", a)
        print('memo in deepcopy_list:', memo)
        print("y in deepcopy_list:", y)
        print("-" * 50)
    print(memo[id(x)] is y)
    print("*"*50)
    return y

obj = {'Hi': 1, "world": 2}
y = deepcopy(obj)
print("f*"*50)
print(y)





