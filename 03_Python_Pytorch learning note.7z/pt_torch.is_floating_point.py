from torch import cuda
from torch import device
import torch
#help(torch.is_floating_point)
help(torch.empty_like)
#1. torch.is_floating_point
"""
is_floating_point(...)
    is_floating_point(input) -> (bool)
    
    Returns True if the data type of :attr:`input` is a floating point data type i.e.,
    one of ``torch.float64``, ``torch.float32``, ``torch.float16``, and ``torch.bfloat16``.
    
    Args:
        input (Tensor): the input tensor.
"""
# 2.torch.empty_like()
"""
empty_like(...)
    empty_like(input, *, dtype=None, layout=None, device=None, requires_grad=False, memory_format=torch.preserve_format) -> Tensor
    
    Returns an uninitialized tensor with the same size as :attr:`input`.
    ``torch.empty_like(input)`` is equivalent to
    ``torch.empty(input.size(), dtype=input.dtype, layout=input.layout, device=input.device)``.
    
    Args:
        input (Tensor): the size of :attr:`input` will determine size of the output tensor.
    
    Keyword args:
        dtype (:class:`torch.dtype`, optional): the desired data type of returned Tensor.
            Default: if ``None``, defaults to the dtype of :attr:`input`.
        layout (:class:`torch.layout`, optional): the desired layout of returned tensor.
            Default: if ``None``, defaults to the layout of :attr:`input`.
        device (:class:`torch.device`, optional): the desired device of returned tensor.
            Default: if ``None``, defaults to the device of :attr:`input`.
        requires_grad (bool, optional): If autograd should record operations on the
            returned tensor. Default: ``False``.
        memory_format (:class:`torch.memory_format`, optional): the desired memory format of
            returned Tensor. Default: ``torch.preserve_format``.
    
    Example::
    
        >>> torch.empty((2,3), dtype=torch.int64)
        tensor([[ 9.4064e+13,  2.8000e+01,  9.3493e+13],
                [ 7.5751e+18,  7.1428e+18,  7.5955e+18]])

"""