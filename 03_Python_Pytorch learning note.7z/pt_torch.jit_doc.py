import torch
#help(torch.jit)
"""
Help on package torch.jit in torch:

NAME
    torch.jit

PACKAGE CONTENTS
    _async
    _builtins
    _check
    _freeze
    _fuser
    _logging
    _monkeytype_config
    _pickle
    _recursive
    _script
    _serialization
    _state
    _trace
    annotations
    frontend
    mobile (package)
    quantized
    supported_ops
    unsupported_tensor_ops

CLASSES
    builtins.Exception(builtins.BaseException)
        Error
    pybind11_builtins.pybind11_object(builtins.object)
        CompilationUnit
        ScriptFunction
    torch._C.Future(pybind11_builtins.pybind11_object)
        Future(torch._C.Future, typing.Generic)
    typing.Generic(builtins.object)
        Future(torch._C.Future, typing.Generic)
    
    class CompilationUnit(pybind11_builtins.pybind11_object)
     |  Method resolution order:
     |      CompilationUnit
     |      pybind11_builtins.pybind11_object
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __getattr__(...)
     |      __getattr__(self: torch._C.CompilationUnit, arg0: str) -> torch::jit::StrongFunctionPtr
     |  
     |  __init__(...)
     |      __init__(self: torch._C.CompilationUnit, lang: str = '', _frames_up: int = 0) -> None
     |  
     |  create_function(...)
     |      create_function(self: torch._C.CompilationUnit, qualified_name: str, graph: torch._C.Graph, should_mangle: bool = False) -> torch::jit::StrongFunctionPtr
     |  
     |  define(...)
     |      define(self: torch._C.CompilationUnit, src: str, rcb: Callable[[str], object] = None, _frames_up: int = 0) -> None
     |  
     |  find_function(...)
     |      find_function(self: torch._C.CompilationUnit, arg0: str) -> Optional[torch::jit::StrongFunctionPtr]
     |  
     |  get_functions(...)
     |      get_functions(self: torch._C.CompilationUnit) -> List[torch::jit::StrongFunctionPtr]
     |  
     |  get_interface(...)
     |      get_interface(self: torch._C.CompilationUnit, arg0: str) -> torch._C.InterfaceType
     |  
     |  set_optimized(...)
     |      set_optimized(self: torch._C.CompilationUnit, arg0: bool) -> None
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from pybind11_builtins.pybind11_object:
     |  
     |  __new__(*args, **kwargs) from pybind11_builtins.pybind11_type
     |      Create and return a new object.  See help(type) for accurate signature.
    
    class Error(builtins.Exception)
     |  Method resolution order:
     |      Error
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.Exception:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.Exception:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
    
    class Future(torch._C.Future, typing.Generic)
     |  Future(*, devices: Optional[List[Union[int, str, torch.device]]] = None)
     |  
     |  Wrapper around a ``torch._C.Future`` which encapsulates an asynchronous
     |  execution of a callable, e.g. :meth:`~torch.distributed.rpc.rpc_async`. It
     |  also exposes a set of APIs to add callback functions and set results.
     |  
     |  .. warning:: GPU support is a beta feature, subject to changes.
     |  
     |  Method resolution order:
     |      Future
     |      torch._C.Future
     |      pybind11_builtins.pybind11_object
     |      typing.Generic
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, *, devices: Optional[List[Union[int, str, torch.device]]] = None)
     |      Create an empty unset ``Future``. If the future is intended to hold
     |      values containing CUDA tensors, (a superset of) their CUDA devices must
     |      be specified at construction. (This is only supported if
     |      ``torch.cuda.is_available()`` returns ``True``). This is needed to
     |      ensure proper CUDA stream synchronization. The child futures, returned
     |      by the ``then`` method, will inherit these devices.
     |      
     |      Args:
     |          devices(``List[Union[int, str, torch.device]]``, optional): the set
     |              of devices on which tensors contained in this future's value are
     |              allowed to reside and on which callbacks are allowed to operate.
     |  
     |  add_done_callback(self, callback)
     |      Append the given callback function to this ``Future``, which will be run
     |      when the ``Future`` is completed.  Multiple callbacks can be added to
     |      the same ``Future``, but the order in which they will be executed cannot
     |      be guaranteed. The callback must take one argument, which is the
     |      reference to this ``Future``. The callback function can use the
     |      :meth:`value` method to get the value. Note that if this ``Future`` is
     |      already completed, the given callback will be run inline.
     |      
     |      We recommend that you use the :meth:`then` method as it provides a way
     |      to synchronize after your callback has completed. ``add_done_callback``
     |      can be cheaper if your callback does not return anything. But both
     |      :meth:`then` and ``add_done_callback`` use the same callback
     |      registration API under the hood.
     |      
     |      With respect to GPU tensors, this method behaves in the same way as
     |      :meth:`then`.
     |      
     |      Args:
     |          callback(``Future``): a ``Callable`` that takes in one argument,
     |          which is the reference to this ``Future``.
     |      
     |      .. note:: Note that if the callback function throws, either
     |          through the original future being completed with an exception and
     |          calling ``fut.wait()``, or through other code in the callback,
     |          error handling must be carefully taken care of. For example, if
     |          this callback later completes additional futures, those futures are
     |          not marked as completed with an error and the user is responsible
     |          for handling completion/waiting on those futures independently.
     |      
     |      Example::
     |          >>> import torch
     |          >>>
     |          >>> def callback(fut):
     |          >>>     print(f"This will run after the future has finished.")
     |          >>>     print(fut.wait())
     |          >>>
     |          >>> fut = torch.futures.Future()
     |          >>> fut.add_done_callback(callback)
     |          >>> fut.set_result(5)
     |          >>>
     |          >>> # Outputs are:
     |          >>> This will run after the future has finished.
     |          >>> 5
     |  
     |  done(self) -> bool
     |      Return ``True`` if this ``Future`` is done. A ``Future`` is done if it
     |      has a result or an exception.
     |      
     |      If the value contains tensors that reside on GPUs, ``Future.done()``
     |      will return ``True`` even if the asynchronous kernels that are
     |      populating those tensors haven't yet completed running on the device,
     |      because at such stage the result is already usable, provided one
     |      performs the appropriate synchronizations (see :meth:`wait`).
     |  
     |  set_exception(self, result: ~T) -> None
     |      Set an exception for this ``Future``, which will mark this ``Future`` as
     |      completed with an error and trigger all attached callbacks. Note that
     |      when calling wait()/value() on this ``Future``, the exception set here
     |      will be raised inline.
     |      
     |      Args:
     |          result (BaseException): the exception for this ``Future``.
     |      
     |      Example::
     |          >>> import torch
     |          >>>
     |          >>> fut = torch.futures.Future()
     |          >>> fut.set_exception(ValueError("foo"))
     |          >>> fut.wait()
     |          >>>
     |          >>> # Output:
     |          >>> # This will run after the future has finished.
     |          >>> ValueError: foo
     |  
     |  set_result(self, result: ~T) -> None
     |      Set the result for this ``Future``, which will mark this ``Future`` as
     |      completed and trigger all attached callbacks. Note that a ``Future``
     |      cannot be marked completed twice.
     |      
     |      If the result contains tensors that reside on GPUs, this method can be
     |      called even if the asynchronous kernels that are populating those
     |      tensors haven't yet completed running on the device, provided that the
     |      streams on which those kernels were enqueued are set as the current ones
     |      when this method is called. Put simply, it's safe to call this method
     |      immediately after launching those kernels, without any additional
     |      synchronization, as long as one doesn't change streams in between. This
     |      method will record events on all the relevant current streams and will
     |      use them to ensure proper scheduling for all the consumers of this
     |      ``Future``.
     |      
     |      Args:
     |          result (object): the result object of this ``Future``.
     |      
     |      Example::
     |          >>> import threading
     |          >>> import time
     |          >>> import torch
     |          >>>
     |          >>> def slow_set_future(fut, value):
     |          >>>     time.sleep(0.5)
     |          >>>     fut.set_result(value)
     |          >>>
     |          >>> fut = torch.futures.Future()
     |          >>> t = threading.Thread(
     |          >>>     target=slow_set_future,
     |          >>>     args=(fut, torch.ones(2) * 3)
     |          >>> )
     |          >>> t.start()
     |          >>>
     |          >>> print(fut.wait())  # tensor([3., 3.])
     |          >>> t.join()
     |  
     |  then(self, callback)
     |      Append the given callback function to this ``Future``, which will be run
     |      when the ``Future`` is completed.  Multiple callbacks can be added to
     |      the same ``Future``, but the order in which they will be executed cannot
     |      be guaranteed (to enforce a certain order consider chaining:
     |      ``fut.then(cb1).then(cb2)``). The callback must take one argument, which
     |      is the reference to this ``Future``. The callback function can use the
     |      :meth:`value` method to get the value. Note that if this ``Future`` is
     |      already completed, the given callback will be run immediately inline.
     |      
     |      If the ``Future``'s value contains tensors that reside on GPUs, the
     |      callback might be invoked while the async kernels that are populating
     |      those tensors haven't yet finished executing on the device. However, the
     |      callback will be invoked with some dedicated streams set as current
     |      (fetched from a global pool) which will be synchronized with those
     |      kernels. Hence any operation performed by the callback on these tensors
     |      will be scheduled on the device after the kernels complete. In other
     |      words, as long as the callback doesn't switch streams, it can safely
     |      manipulate the result without any additional synchronization. This is
     |      similar to the non-blocking behavior of :meth:`wait`.
     |      
     |      Similarly, if the callback returns a value that contains tensors that
     |      reside on a GPU, it can do so even if the kernels that are producing
     |      these tensors are still running on the device, as long as the callback
     |      didn't change streams during its execution. If one wants to change
     |      streams, one must be careful to re-synchronize them with the original
     |      streams, that is, those that were current when the callback was invoked.
     |      
     |      Args:
     |          callback(``Callable``): a ``Callable`` that takes this ``Future`` as
     |                                  the only argument.
     |      
     |      Returns:
     |          A new ``Future`` object that holds the return value of the
     |          ``callback`` and will be marked as completed when the given
     |          ``callback`` finishes.
     |      
     |      .. note:: Note that if the callback function throws, either
     |          through the original future being completed with an exception and
     |          calling ``fut.wait()``, or through other code in the callback, the
     |          future returned by ``then`` will be marked appropriately with the
     |          encountered error. However, if this callback later completes
     |          additional futures, those futures are not marked as completed with
     |          an error and the user is responsible for handling completion/waiting
     |          on those futures independently.
     |      
     |      Example::
     |          >>> import torch
     |          >>>
     |          >>> def callback(fut):
     |          >>>     print(f"RPC return value is {fut.wait()}.")
     |          >>>
     |          >>> fut = torch.futures.Future()
     |          >>> # The inserted callback will print the return value when
     |          >>> # receiving the response from "worker1"
     |          >>> cb_fut = fut.then(callback)
     |          >>> chain_cb_fut = cb_fut.then(
     |          >>>     lambda x : print(f"Chained cb done. {x.wait()}")
     |          >>> )
     |          >>> fut.set_result(5)
     |          >>>
     |          >>> # Outputs are:
     |          >>> # RPC return value is 5.
     |          >>> # Chained cb done. None
     |  
     |  value(self) -> ~T
     |      Obtain the value of an already-completed future.
     |      
     |      This method should only be called after a call to :meth:`wait` has
     |      completed, or inside a callback function passed to :meth:`then`. In
     |      other cases this ``Future`` may not yet hold a value and calling
     |      ``value()`` could fail.
     |      
     |      If the value contains tensors that reside on GPUs, then this method will
     |      *not* perform any additional synchronization. This should be done
     |      beforehand, separately, through a call to :meth:`wait` (except within
     |      callbacks, for which it's already being taken care of by :meth:`then`).
     |      
     |      Returns:
     |          The value held by this ``Future``. If the function (callback or RPC)
     |          creating the value has thrown an error, this ``value()`` method will
     |          also throw an error.
     |  
     |  wait(self) -> ~T
     |      Block until the value of this ``Future`` is ready.
     |      
     |      If the value contains tensors that reside on GPUs, then an additional
     |      synchronization is performed with the kernels (executing on the device)
     |      which may be asynchronously populating those tensors. Such sync is
     |      non-blocking, which means that ``wait()`` will insert the necessary
     |      instructions in the current streams to ensure that further operations
     |      enqueued on those streams will be properly scheduled after the async
     |      kernels but, once that is done, ``wait()`` will return, even if those
     |      kernels are still running. No further synchronization is required when
     |      accessing and using the values, as long as one doesn't change streams.
     |      
     |      Returns:
     |          The value held by this ``Future``. If the function (callback or RPC)
     |          creating the value has thrown an error, this ``wait`` method will
     |          also throw an error.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  __orig_bases__ = (<class 'torch._C.Future'>, typing.Generic[~T])
     |  
     |  __parameters__ = (~T,)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch._C.Future:
     |  
     |  __getstate__(...)
     |      __getstate__(self: torch._C.Future) -> tuple
     |  
     |  __setstate__(...)
     |      __setstate__(self: torch._C.Future, arg0: tuple) -> None
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from pybind11_builtins.pybind11_object:
     |  
     |  __new__(*args, **kwargs) from pybind11_builtins.pybind11_type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from typing.Generic:
     |  
     |  __class_getitem__(params) from torch.futures._PyFutureMeta
     |  
     |  __init_subclass__(*args, **kwargs) from torch.futures._PyFutureMeta
     |      This method is called when a class is subclassed.
     |      
     |      The default implementation does nothing. It may be
     |      overridden to extend subclasses.
    
    class ScriptFunction(pybind11_builtins.pybind11_object)
     |  Functionally equivalent to a :class:`ScriptModule`, but represents a single
     |  function and does not have any attributes or Parameters.
     |  
     |  Method resolution order:
     |      ScriptFunction
     |      pybind11_builtins.pybind11_object
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __call__(...)
     |      __call__(*args, **kwargs) -> object
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get_debug_state(...)
     |      get_debug_state(self: torch._C.ScriptFunction) -> torch._C.GraphExecutorState
     |  
     |  graph_for = _graph_for(self, *args, **kwargs)
     |  
     |  save(...)
     |      save(self: torch._C.ScriptFunction, filename: str, _extra_files: Dict[str, str] = {}) -> None
     |  
     |  save_to_buffer(...)
     |      save_to_buffer(self: torch._C.ScriptFunction, _extra_files: Dict[str, str] = {}) -> bytes
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  code
     |  
     |  graph
     |  
     |  inlined_graph
     |  
     |  name
     |  
     |  qualified_name
     |  
     |  schema
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from pybind11_builtins.pybind11_object:
     |  
     |  __new__(*args, **kwargs) from pybind11_builtins.pybind11_type
     |      Create and return a new object.  See help(type) for accurate signature.

FUNCTIONS
    annotate(the_type, the_value)
        This method is a pass-through function that returns `the_value`, used to hint TorchScript
        compiler the type of `the_value`. It is a no-op when running outside of TorchScript.
        
        Though TorchScript can infer correct type for most Python expressions, there are some cases where
        type infernece can be wrong, including:
        - Empty containers like `[]` and `{}`, which TorchScript assumes to be container of `Tensor`s
        - Optional types like `Optional[T]` but assigned a valid value of type `T`, TorchScript would assume
        it is type `T` rather than `Optional[T]`
        
        Note that `annotate()` does not help in `__init__` method of `torch.nn.Module` subclasses because it
        is executed in eager mode. To annotate types of `torch.nn.Module` attributes,
        use :meth:`~torch.jit.Annotate` instead.
        
        Example:
        
        .. testcode::
        
            import torch
            from typing import Dict
        
            @torch.jit.script
            def fn():
                # Telling TorchScript that this empty dictionary is a (str -> int) dictionary
                # instead of default dictionary type of (str -> Tensor).
                d = torch.jit.annotate(Dict[str, int], {})
        
                # Without `torch.jit.annotate` above, following statement would fail because of
                # type mismatch.
                d["name"] = 20
        
        .. testcleanup::
        
            del fn
        
        Args:
            the_type: Python type that should be passed to TorchScript compiler as type hint for `the_value`
            the_value: Value or expression to hint type for.
        
        Returns:
            `the_value` is passed back as return value.
    
    export_opnames(m)
        Generates new bytecode for a Script module and returns what the op list
        would be for a Script Module based off the current code base. If you
        have a LiteScriptModule and want to get the currently present
        list of ops call _export_operator_list instead.
    
    isinstance(obj, target_type)
        This function provides for conatiner type refinement in TorchScript. It can refine
        parameterized containers of the List, Dict, Tuple, and Optional types. E.g. ``List[str]``,
        ``Dict[str, List[torch.Tensor]]``, ``Optional[Tuple[int,str,int]]``. It can also
        refine basic types such as bools and ints that are available in TorchScript.
        
        Args:
            obj: object to refine the type of
            target_type: type to try to refine obj to
        Returns:
            ``bool``: True if obj was successfully refined to the type of target_type,
                False otherwise with no new type refinement
        
        
        Example (using ``torch.jit.isinstance`` for type refinement):
        .. testcode::
        
            import torch
            from typing import Any, Dict, List
        
            class MyModule(torch.nn.Module):
                def __init__(self):
                    super(MyModule, self).__init__()
        
                def forward(self, input: Any): # note the Any type
                    if torch.jit.isinstance(input, List[torch.Tensor]):
                        for t in input:
                            y = t.clamp(0, 0.5)
                    elif torch.jit.isinstance(input, Dict[str, str]):
                        for val in input.values():
                            print(val)
        
            m = torch.jit.script(MyModule())
            x = [torch.rand(3,3), torch.rand(4,3)]
            m(x)
            y = {"key1":"val1","key2":"val2"}
            m(y)
    
    last_executed_optimized_graph = _last_executed_optimized_graph(...) method of builtins.PyCapsule instance
        _last_executed_optimized_graph() -> torch._C.Graph
        
        Retrieve the optimized graph that was run the last time the graph executor ran on this thread
    
    script_if_tracing(fn)
        Compiles ``fn`` when it is first called during tracing. ``torch.jit.script``
        has a non-negligible start up time when it is first called due to
        lazy-initializations of many compiler builtins. Therefore you should not use
        it in library code. However, you may want to have parts of your library work
        in tracing even if they use control flow. In these cases, you should use
        ``@torch.jit.script_if_tracing`` to substitute for
        ``torch.jit.script``.
        
        Args:
            fn: A function to compile.
        
        Returns:
            If called during tracing, a :class:`ScriptFunction` created by `torch.jit.script` is returned.
            Otherwise, the original function `fn` is returned.

DATA
    Final = typing.Final
        Special typing construct to indicate final names to type checkers.
        
        A final name cannot be re-assigned or overridden in a subclass.
        For example:
        
          MAX_SIZE: Final = 9000
          MAX_SIZE += 1  # Error reported by type checker
        
          class Connection:
              TIMEOUT: Final[int] = 10
        
          class FastConnector(Connection):
              TIMEOUT = 1  # Error reported by type checker
        
        There is no runtime checking of these properties.
    
    Iterator = typing.Iterator
        A generic version of collections.abc.Iterator.

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\jit\__init__.py



Process finished with exit code 0

"""



