"""二、torch基础概述
1、tensor概述
 >> torch.add(x,y)和x.add(y)等价
 >> x.add(y)不会修改自身数据，x.add_(y)修改自身数据

"""

"""2、创建tensor"""
print("--------------Torch--------------")
import torch
e2_11 = torch.Tensor([1, 2, 3, 4])
e2_12 = torch.tensor([1, 2, 3, 4])
e2_21 = torch.Tensor(2, 3)
#e2_22 = torch.tensor(2, 3) # wrong :
e2_23 = torch.tensor(1)
e2_24 = torch.Tensor(1)
e2_31 = torch.Tensor([[1, 2], [3, 4]])
e2_32 = torch.tensor([[1, 2], [3, 4]])
print("torch.Tensor([1, 2, 3, 4]): ", e2_11)
print("torch.tensor([1, 2, 3, 4]):", e2_12)
print("\ntorch.Tensor(2, 3)", e2_21)
print("torch.tensor(1): ", e2_23)
print("torch.Tensor(1): ", e2_24)

print("\ntorch.Tensor([[1, 2], [3, 4]]): ", e2_31)
print("torch.tensor([[1, 2], [3, 4]]): ", e2_32)
"""
torch.Tensor默认浮点型数据，torch.tensor从数据中推断数据类型。
torch.tensor(1)返回固定值1，torch.Tensor(1)返回大小为0的1个张量，！！！随机初始值。
"""
"""3、修改tensor维度
大部分与numpy类似
添加维度torch.unsqueeze(y,0)
view(-1)展平数组，只能由torch.Tensor.view()来调用
"""
"""4、索引操作"""
print("\nTorch: 索引操作\n")
torch.manual_seed(100)
x = torch.randn(2, 3)
print("x:", x)
print("x[1:]", x[1:, ])
print("x[:, -1]", x[:, -1])
mask = x > 0
print("\ntorch.masked_select(x, mask): \n", torch.masked_select(x, mask))
print("torch.nonzero(mask):", torch.nonzero(mask))

"""5、广播机制
"""
print("\n------------------------torch: broadcasting----------------")
import numpy as np
A = np.arange(0, 40, 10).reshape(4, 1)
B = np.arange(0, 3)
A1 = torch.from_numpy(A)
B1 = torch.from_numpy(B)
C = A1 + B1
print("\nnumpy A: \n", A)
print("numpy B: \n", B)
print("torch A1 = torch.from_numpy(A): \n", A1)
print("torch B1 = torch.from_numpy(B): \n", B1)
print("torch A1 + B1: \n", C)