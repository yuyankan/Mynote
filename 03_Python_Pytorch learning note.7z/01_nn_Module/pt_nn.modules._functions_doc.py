import torch
#help(torch.nn.modules._functions)
"""
Help on module torch.nn.modules._functions in torch.nn.modules:

NAME
    torch.nn.modules._functions

CLASSES
    torch.autograd.function.Function(torch._C._FunctionBase, torch.autograd.function._ContextMethodMixin, torch.autograd.function._HookMixin)
        BackwardHookFunction
        CrossMapLRN2d
        SyncBatchNorm
    
    class BackwardHookFunction(torch.autograd.function.Function)
     |  BackwardHookFunction(*args, **kwargs)
     |  
     |  Method resolution order:
     |      BackwardHookFunction
     |      torch.autograd.function.Function
     |      torch._C._FunctionBase
     |      torch.autograd.function._ContextMethodMixin
     |      torch.autograd.function._HookMixin
     |      builtins.object
     |  
     |  Static methods defined here:
     |  
     |  backward(ctx, *args)
     |      Defines a formula for differentiating the operation.
     |      
     |      This function is to be overridden by all subclasses.
     |      
     |      It must accept a context :attr:`ctx` as the first argument, followed by
     |      as many outputs as the :func:`forward` returned (None will be passed in
     |      for non tensor outputs of the forward function),
     |      and it should return as many tensors, as there were inputs to
     |      :func:`forward`. Each argument is the gradient w.r.t the given output,
     |      and each returned value should be the gradient w.r.t. the
     |      corresponding input. If an input is not a Tensor or is a Tensor not
     |      requiring grads, you can just pass None as a gradient for that input.
     |      
     |      The context can be used to retrieve tensors saved during the forward
     |      pass. It also has an attribute :attr:`ctx.needs_input_grad` as a tuple
     |      of booleans representing whether each input needs gradient. E.g.,
     |      :func:`backward` will have ``ctx.needs_input_grad[0] = True`` if the
     |      first input to :func:`forward` needs gradient computated w.r.t. the
     |      output.
     |  
     |  forward(ctx, *args)
     |      Performs the operation.
     |      
     |      This function is to be overridden by all subclasses.
     |      
     |      It must accept a context ctx as the first argument, followed by any
     |      number of arguments (tensors or other types).
     |      
     |      The context can be used to store arbitrary data that can be then
     |      retrieved during the backward pass.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch.autograd.function.Function:
     |  
     |  __call__(self, *args, **kwargs)
     |      Call self as a function.
     |  
     |  __init__(self, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch.autograd.function.Function:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from torch.autograd.function.Function:
     |  
     |  is_traceable = False
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch._C._FunctionBase:
     |  
     |  name(...)
     |  
     |  register_hook(...)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from torch._C._FunctionBase:
     |  
     |  apply(...) from torch.autograd.function.FunctionMeta
     |  # apply(...) method of torch.autograd.function.FunctionMeta instance
     |  ----------------------------------------------------------------------
     |  Static methods inherited from torch._C._FunctionBase:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch._C._FunctionBase:
     |  
     |  dirty_tensors
     |  
     |  materialize_grads
     |  
     |  metadata
     |  
     |  needs_input_grad
     |  
     |  next_functions
     |  
     |  non_differentiable
     |  
     |  requires_grad
     |  
     |  saved_tensors
     |  
     |  saved_variables
     |  
     |  to_save
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch.autograd.function._ContextMethodMixin:
     |  
     |  mark_dirty(self, *args)
     |      Marks given tensors as modified in an in-place operation.
     |      
     |      **This should be called at most once, only from inside the**
     |      :func:`forward` **method, and all arguments should be inputs.**
     |      
     |      Every tensor that's been modified in-place in a call to :func:`forward`
     |      should be given to this function, to ensure correctness of our checks.
     |      It doesn't matter whether the function is called before or after
     |      modification.
     |  
     |  mark_non_differentiable(self, *args)
     |      Marks outputs as non-differentiable.
     |      
     |      **This should be called at most once, only from inside the**
     |      :func:`forward` **method, and all arguments should be outputs.**
     |      
     |      This will mark outputs as not requiring gradients, increasing the
     |      efficiency of backward computation. You still need to accept a gradient
     |      for each output in :meth:`~Function.backward`, but it's always going to
     |      be a zero tensor with the same shape as the shape of a corresponding
     |      output.
     |      
     |      This is used e.g. for indices returned from a max :class:`Function`.
     |  
     |  mark_shared_storage(self, *pairs)
     |  
     |  save_for_backward(self, *tensors)
     |      Saves given tensors for a future call to :func:`~Function.backward`.
     |      
     |      **This should be called at most once, and only from inside the**
     |      :func:`forward` **method.**
     |      
     |      Later, saved tensors can be accessed through the :attr:`saved_tensors`
     |      attribute. Before returning them to the user, a check is made to ensure
     |      they weren't used in any in-place operation that modified their content.
     |      
     |      Arguments can also be ``None``.
     |  
     |  set_materialize_grads(self, value)
     |      Sets whether to materialize output grad tensors. Default is true.
     |      
     |      **This should be called only from inside the** :func:`forward` **method**
     |      
     |      If true, undefined output grad tensors will be expanded to tensors full
     |      of zeros prior to calling the :func:`backward` method.
    
    class CrossMapLRN2d(torch.autograd.function.Function)
     |  CrossMapLRN2d(*args, **kwargs)
     |  
     |  Method resolution order:
     |      CrossMapLRN2d
     |      torch.autograd.function.Function
     |      torch._C._FunctionBase
     |      torch.autograd.function._ContextMethodMixin
     |      torch.autograd.function._HookMixin
     |      builtins.object
     |  
     |  Static methods defined here:
     |  
     |  backward(ctx, grad_output)
     |      Defines a formula for differentiating the operation.
     |      
     |      This function is to be overridden by all subclasses.
     |      
     |      It must accept a context :attr:`ctx` as the first argument, followed by
     |      as many outputs as the :func:`forward` returned (None will be passed in
     |      for non tensor outputs of the forward function),
     |      and it should return as many tensors, as there were inputs to
     |      :func:`forward`. Each argument is the gradient w.r.t the given output,
     |      and each returned value should be the gradient w.r.t. the
     |      corresponding input. If an input is not a Tensor or is a Tensor not
     |      requiring grads, you can just pass None as a gradient for that input.
     |      
     |      The context can be used to retrieve tensors saved during the forward
     |      pass. It also has an attribute :attr:`ctx.needs_input_grad` as a tuple
     |      of booleans representing whether each input needs gradient. E.g.,
     |      :func:`backward` will have ``ctx.needs_input_grad[0] = True`` if the
     |      first input to :func:`forward` needs gradient computated w.r.t. the
     |      output.
     |  
     |  forward(ctx, input, size, alpha=0.0001, beta=0.75, k=1)
     |      Performs the operation.
     |      
     |      This function is to be overridden by all subclasses.
     |      
     |      It must accept a context ctx as the first argument, followed by any
     |      number of arguments (tensors or other types).
     |      
     |      The context can be used to store arbitrary data that can be then
     |      retrieved during the backward pass.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch.autograd.function.Function:
     |  
     |  __call__(self, *args, **kwargs)
     |      Call self as a function.
     |  
     |  __init__(self, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch.autograd.function.Function:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from torch.autograd.function.Function:
     |  
     |  is_traceable = False
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch._C._FunctionBase:
     |  
     |  name(...)
     |  
     |  register_hook(...)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from torch._C._FunctionBase:
     |  
     |  apply(...) from torch.autograd.function.FunctionMeta
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from torch._C._FunctionBase:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch._C._FunctionBase:
     |  
     |  dirty_tensors
     |  
     |  materialize_grads
     |  
     |  metadata
     |  
     |  needs_input_grad
     |  
     |  next_functions
     |  
     |  non_differentiable
     |  
     |  requires_grad
     |  
     |  saved_tensors
     |  
     |  saved_variables
     |  
     |  to_save
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch.autograd.function._ContextMethodMixin:
     |  
     |  mark_dirty(self, *args)
     |      Marks given tensors as modified in an in-place operation.
     |      
     |      **This should be called at most once, only from inside the**
     |      :func:`forward` **method, and all arguments should be inputs.**
     |      
     |      Every tensor that's been modified in-place in a call to :func:`forward`
     |      should be given to this function, to ensure correctness of our checks.
     |      It doesn't matter whether the function is called before or after
     |      modification.
     |  
     |  mark_non_differentiable(self, *args)
     |      Marks outputs as non-differentiable.
     |      
     |      **This should be called at most once, only from inside the**
     |      :func:`forward` **method, and all arguments should be outputs.**
     |      
     |      This will mark outputs as not requiring gradients, increasing the
     |      efficiency of backward computation. You still need to accept a gradient
     |      for each output in :meth:`~Function.backward`, but it's always going to
     |      be a zero tensor with the same shape as the shape of a corresponding
     |      output.
     |      
     |      This is used e.g. for indices returned from a max :class:`Function`.
     |  
     |  mark_shared_storage(self, *pairs)
     |  
     |  save_for_backward(self, *tensors)
     |      Saves given tensors for a future call to :func:`~Function.backward`.
     |      
     |      **This should be called at most once, and only from inside the**
     |      :func:`forward` **method.**
     |      
     |      Later, saved tensors can be accessed through the :attr:`saved_tensors`
     |      attribute. Before returning them to the user, a check is made to ensure
     |      they weren't used in any in-place operation that modified their content.
     |      
     |      Arguments can also be ``None``.
     |  
     |  set_materialize_grads(self, value)
     |      Sets whether to materialize output grad tensors. Default is true.
     |      
     |      **This should be called only from inside the** :func:`forward` **method**
     |      
     |      If true, undefined output grad tensors will be expanded to tensors full
     |      of zeros prior to calling the :func:`backward` method.
    
    class SyncBatchNorm(torch.autograd.function.Function)
     |  SyncBatchNorm(*args, **kwargs)
     |  
     |  Method resolution order:
     |      SyncBatchNorm
     |      torch.autograd.function.Function
     |      torch._C._FunctionBase
     |      torch.autograd.function._ContextMethodMixin
     |      torch.autograd.function._HookMixin
     |      builtins.object
     |  
     |  Static methods defined here:
     |  
     |  backward(self, grad_output)
     |      Defines a formula for differentiating the operation.
     |      
     |      This function is to be overridden by all subclasses.
     |      
     |      It must accept a context :attr:`ctx` as the first argument, followed by
     |      as many outputs as the :func:`forward` returned (None will be passed in
     |      for non tensor outputs of the forward function),
     |      and it should return as many tensors, as there were inputs to
     |      :func:`forward`. Each argument is the gradient w.r.t the given output,
     |      and each returned value should be the gradient w.r.t. the
     |      corresponding input. If an input is not a Tensor or is a Tensor not
     |      requiring grads, you can just pass None as a gradient for that input.
     |      
     |      The context can be used to retrieve tensors saved during the forward
     |      pass. It also has an attribute :attr:`ctx.needs_input_grad` as a tuple
     |      of booleans representing whether each input needs gradient. E.g.,
     |      :func:`backward` will have ``ctx.needs_input_grad[0] = True`` if the
     |      first input to :func:`forward` needs gradient computated w.r.t. the
     |      output.
     |  
     |  forward(self, input, weight, bias, running_mean, running_var, eps, momentum, process_group, world_size)
     |      Performs the operation.
     |      
     |      This function is to be overridden by all subclasses.
     |      
     |      It must accept a context ctx as the first argument, followed by any
     |      number of arguments (tensors or other types).
     |      
     |      The context can be used to store arbitrary data that can be then
     |      retrieved during the backward pass.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch.autograd.function.Function:
     |  
     |  __call__(self, *args, **kwargs)
     |      Call self as a function.
     |  
     |  __init__(self, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch.autograd.function.Function:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from torch.autograd.function.Function:
     |  
     |  is_traceable = False
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch._C._FunctionBase:
     |  
     |  name(...)
     |  
     |  register_hook(...)
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from torch._C._FunctionBase:
     |  
     |  apply(...) from torch.autograd.function.FunctionMeta
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from torch._C._FunctionBase:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from torch._C._FunctionBase:
     |  
     |  dirty_tensors
     |  
     |  materialize_grads
     |  
     |  metadata
     |  
     |  needs_input_grad
     |  
     |  next_functions
     |  
     |  non_differentiable
     |  
     |  requires_grad
     |  
     |  saved_tensors
     |  
     |  saved_variables
     |  
     |  to_save
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch.autograd.function._ContextMethodMixin:
     |  
     |  mark_dirty(self, *args)
     |      Marks given tensors as modified in an in-place operation.
     |      
     |      **This should be called at most once, only from inside the**
     |      :func:`forward` **method, and all arguments should be inputs.**
     |      
     |      Every tensor that's been modified in-place in a call to :func:`forward`
     |      should be given to this function, to ensure correctness of our checks.
     |      It doesn't matter whether the function is called before or after
     |      modification.
     |  
     |  mark_non_differentiable(self, *args)
     |      Marks outputs as non-differentiable.
     |      
     |      **This should be called at most once, only from inside the**
     |      :func:`forward` **method, and all arguments should be outputs.**
     |      
     |      This will mark outputs as not requiring gradients, increasing the
     |      efficiency of backward computation. You still need to accept a gradient
     |      for each output in :meth:`~Function.backward`, but it's always going to
     |      be a zero tensor with the same shape as the shape of a corresponding
     |      output.
     |      
     |      This is used e.g. for indices returned from a max :class:`Function`.
     |  
     |  mark_shared_storage(self, *pairs)
     |  
     |  save_for_backward(self, *tensors)
     |      Saves given tensors for a future call to :func:`~Function.backward`.
     |      
     |      **This should be called at most once, and only from inside the**
     |      :func:`forward` **method.**
     |      
     |      Later, saved tensors can be accessed through the :attr:`saved_tensors`
     |      attribute. Before returning them to the user, a check is made to ensure
     |      they weren't used in any in-place operation that modified their content.
     |      
     |      Arguments can also be ``None``.
     |  
     |  set_materialize_grads(self, value)
     |      Sets whether to materialize output grad tensors. Default is true.
     |      
     |      **This should be called only from inside the** :func:`forward` **method**
     |      
     |      If true, undefined output grad tensors will be expanded to tensors full
     |      of zeros prior to calling the :func:`backward` method.

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\nn\modules\_functions.py



Process finished with exit code 0

"""