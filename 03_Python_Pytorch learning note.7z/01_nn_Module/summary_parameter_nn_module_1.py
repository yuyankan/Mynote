# 1. nn.Module: add parameter auto. to Module
"""
1.1  defined: 1)Dict: self._parameter --->only for model per se: not included submodel's parameters.
#             2)def method:
                    (1)named_parameters (yield :dict: with parameter name, module); -->use for loop: for all submoules
#                   (2) parameters(no name info.): yield parameter-->use for loop
1.2: Used class: torch.nn.Parameter;
1.3 Process:
            nn.Module : def method:
            1)__init__ : self.xx = torch.nn.Parameter(torch.Tensor(xx), required_grad=True)
                        (self.xx1 = nn.Sequential(submodel1, submodel2, ..) --> nn.Sequential is subclass of nn.Module
                                    -->self.xx1 is instance of nn.Sequential:
                                            self.xx1.__parameters dict is parameter of nn.Sequential(submode1, submodel2)'s parameters.)
                        --> will call:
            2) __setattr__:
                    (1): check:
                        ->1: isinstance(self.xx, Parameter): if params is None
                                check : cannot assign parameters before Module.__init__() call
                        ->2: def register_parameter(name, value): 注册parameter
            3)register_parameter(name, param):
                        ->1: isinstance(self.xx, Parameter):
                                是否是Parameter object (通过Paramer class 产生的tensor)
                        ->2. param.grad.fn;
                                if self.xx is leaf tensor # only leaf tensor could be register as parameter.
                        ->3. set: self._parameters[name]=param
"""

# 2. torch.nn.Parameter():
""" ->Return a Tensor, with requires_grad = True/False
"""

# 3. Note: grad:
"""
1. only leaf tensor could be register as parameter.
2. is_leaf：
 |     (1): All Tensors that have :attr:`requires_grad` which is ``False`` will be leaf Tensors by convention.
 |
 |      (2): For Tensors that have :attr:`requires_grad` which is ``True``, they will be leaf Tensors if they were
 |          created by the user.
            This means that they are not the result of an operation and so:
 |          :attr:`grad_fn` is None.
 |
 |      (3): Only leaf Tensors will have their :attr:`grad` populated during a call to :func:`backward`.
 |          To get :attr:`grad` populated for non-leaf Tensors, you can use :func:`retain_grad`.!!!buffers
 
3. :This attribute is ``None`` by default and becomes a Tensor the first time a call to
    :func:`backward` computes gradients for ``self``.
    The attribute will then contain the gradients computed and future calls to
    :func:`backward` will accumulate (add) gradients into it.

4.  for parameters: created with nn.DataParallel() (check: self._is_replica (attr. defined in nn.Module)
        The parameters are copied (in a differentiable manner) from the original module:
        This means they are not leaf nodes in autograd and so don't accumulate gradients


4.class Parameter: nn.module.Parameter()-->created tensor, when this tensor is the attr of Module, it will
# be add automatically to module.parameters: module._parameter dict.-->then could be find in module.named parameters, moduel._parameters:
"""