from typing import Optional, Set
import torch.nn as nn

class A0(nn.Module):
    def __init__(self):
        super(A0, self).__init__()
        self.l0_1 =nn.Linear(3,2)

class A1(A0):
    def __init__(self):
        super(A1, self).__init__()
        self.l1_1 =nn.Linear(3,2)


class A2(A1):
    def __init__(self):
        super(A2, self).__init__()
        self.l2_1 =nn.Linear(3,2)
        self.l2_2 = nn.Linear(2, 1)
        self.s_2 = nn.Sequential(self.l2_1 , self.l2_2)
        self.test= 'test'

    def named_modules1(self, memo: Optional[Set['Module']] = None, prefix: str = '', remove_duplicate: bool = True):
        print("1. named_modules is called")

        if memo is None:
            memo = set()
        if self not in memo:
            if remove_duplicate:
                memo.add(self)
            yield prefix, self
            for name, module in self._modules.items():
                if module is None:
                    continue
                submodule_prefix = prefix + ('.' if prefix else '') + name
                for m in module.named_modules(memo, submodule_prefix, remove_duplicate):
                    yield m

e1 = A2()
print('='*50)
print("e1.__dict__['_modules']: \n",e1.__dict__['_modules'])
print('='*50)
for name, module in e1.named_modules1():
    print(name, '->', module)