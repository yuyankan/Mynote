# help __getattr__ for nn.Module: understanding __getattr__,
# called when class instance attr. is called.
import torch
import torch.nn as nn
from torch.nn import Parameter
from typing import Union
from torch import Tensor

class A(nn.Module):
    def __init__(self):
        super(A, self).__init__()
        self.p = nn.Linear(2,1)
        self.a = Parameter(torch.ones(3,2))

    def __getattr__(self, name: str) -> Union[Tensor, 'Module']:
        print("*"*50)
        print("__getattr__ is called")
        if "_parameters" in self.__dict__:
            _parameters = self.__dict__['_parameters']
            if name in _parameters:
                return _parameters[name]
        if '_buffers' in self.__dict__:
            _buffers = self.__dict__['_buffers']
            if name in _buffers:
                return _buffers[name]
        if '_modules' in self.__dict__:
            modules = self.__dict__['_modules']
            if name in modules:
                return modules[name]
        raise AttributeError("'{}' object has no attribute '{}'"
                             .format(type(self).__name__, name))

a1 = A()
print(a1.__dict__)
print("-"*50)
print(a1.__dict__.get('_parameters'))
print("-"*50)
print(a1.__dict__['_parameters'])
print(a1.a) # -->class A() __getattr__ is called.


""" python字典get()方法和[key]区别
dic.get(key[,fault]) ，当key不存在不会抛出异常，会显示fault信息
dic[key]，当key不存在会抛出 KeyError 错误
"""

print("*"*50)
print("*"*50)
d = {"hi":1, 'world':2}
print(d.get('hii'))
print(d['hii'])
