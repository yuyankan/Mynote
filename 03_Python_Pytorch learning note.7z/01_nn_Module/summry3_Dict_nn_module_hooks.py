
# Dict in nn.Module __init__

"""
_global_backward_hooks: Dict[int, Callable] = OrderedDict()
_global_is_full_backward_hook: Optional[bool] = None
_global_forward_pre_hooks: Dict[int, Callable] = OrderedDict()
_global_forward_hooks: Dict[int, Callable] = OrderedDict()

"""


"""nn.Module.Dict

        self._parameters = OrderedDict()
        self._buffers = OrderedDict()
        self._non_persistent_buffers_set = set()

        self._backward_hooks = OrderedDict()
        self._is_full_backward_hook = None
        self._forward_hooks = OrderedDict()
        self._forward_pre_hooks = OrderedDict()

        self._state_dict_hooks = OrderedDict()
        self._load_state_dict_pre_hooks = OrderedDict()

        self._modules = OrderedDict()
"""

#summary:
"""
1. __call__(*input, **kwargs):
    (1rst):  pre_hooks(global/local): tuple(modified input); input = hook(self, input)
    (2nd): if full_backward_hooks(global/local full_backward hook) :  
                input: tuple(tensor(value, grad_fn = Backwarbackward), tensor(value, grad_fn)-变成元组input, 另， grad_fn 加backward
                -----------
                if full_backward_hooks:
                    bw_hook = hooks.BackwardHook(self, full_backward_hooks)
                    input = bw_hook.setup_input_hook(input)
                ---------
    (3rd): forward(*input): 
    (4th): forward_hooks: get modified output by hook
    (5th): if full_backward_hooks: update result: tuple(result), grad_fn = Backwardbackward
                result = bw_hook.setup_output_hook(result)
                
                
                -------
                hook(module, input, output) -> None or modified output
                if _global_forward_hooks or self._forward_hooks:
                for hook in itertools.chain( _global_forward_hooks.values(),  self._forward_hooks.values()):
                    hook_result = hook(self, input, result)
                if hook_result is not None:
                    result = hook_result
                -------------
    (6th): non_full backward hooks: 给ouput.grad_fn.register_hook(hook)
                ------
                for hook in non_full_backward_hooks:
                    wrapper = functools.partial(hook, self)
                    functools.update_wrapper(wrapper, hook)
                    grad_fn.register_hook(wrapper)
                self._maybe_warn_non_full_backward_hook(input, result, grad_fn)
                ----------

2, state dict:
   def state_dict:: -> return dictionary : contains parameters and persistent buffers of module & submodules; 
                        dictionary is updated by hook in Dict： self._state_dict_hooks
   def load_state_dict: --> pre_hook take care of dictionary of state_dict,-->load paremter and buffer of module & submodule to current module.
"""

# 1. _global_backward_hooks: Dict[int, Callable] = OrderedDict()->
        #1.1: content generated<--
        """
                (1): def register_module_backward_hook(
                        hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]]) -> RemovableHandle
                         
                         'Registers a backward hook common to all the modules.
                          This function is deprecated in favor of :meth:`nn.module.register_module_full_backward_hook`
                                and the behavior of this function will change in future versions
                        
                                'handle = hooks.RemovableHandle(_global_backward_hooks)
                                _global_backward_hooks[handle.id] = hook'
      
                
                (2): def register_module_full_backward_hook
                        hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]]) -> RemovableHandle
                        
                        '1. Registers a backward hook common to all the modules.
                        
                         2. warning::
                                2.1: This adds global state to the 'nn.module''' module;
                                2.2: and it is only intended for debugging/profiling purposes.

                                2.3: The current implementation will not have the presented behavior
                                        for complex :class:`Module` that perform many operations.
                                        In some failure cases,:attr:`grad_input` and :attr:`grad_output` will only
                                        contain the gradients for a subset of the inputs and outputs.
                                        For such :class:`Module`, you should use :func:`torch.Tensor.register_hook`
                                        directly on a specific input or output to get the required gradients.

                         3. The hook will be called every time the gradients with respect to module
                                inputs are computed. The hook should have the following signature::

                                hook(module, grad_input, grad_output) -> Tensor or None

                                The :attr:`grad_input` and :attr:`grad_output` are tuples. The hook should
                                not modify its arguments, but it can optionally return a new gradient with
                                respect to the input that will be used in place of :attr:`grad_input` in
                                        subsequent computations. :attr:`grad_input` will only correspond to the inputs given
                                as positional arguments and all kwarg arguments will not appear in the hook. Entries
                                in :attr:`grad_input` and :attr:`grad_output` will be ``None`` for all non-Tensor
                                arguments.

                        4. Global hooks are called before hooks registered with `register_backward_hook`
                         
                         'handle = hooks.RemovableHandle(_global_backward_hooks)
                        _global_backward_hooks[handle.id] = hook'
                    
                        

        """
        # 1.2 used by method def:
        """
            (1): def _get_backward_hooks: 
                'Returns the backward hooks for use in the call function.
                It returns two lists, one with the full backward hooks and one with the non-full backward hooks.'-->
                
                Dict:   1)full_backward_hooks ;-->True, used by : 
                                1)):def __call_impl: --> 
                                        >> bw_hook = hooks.BackwardHook(self, full_backward_hooks) # 实例化BackwarHook
                                        >> input = bw_hook.setup_input_hook(input)
                                         #  return new input: is a tuple(tensor1, tensor 2, ..tensor axb)
                                                1))): hooks.BackwardHook: 
                                            new input used in forward(*input):
                                                1))): self.forward_call(*input, **kwargs)
                                
                        2) non_full_backward_hooks.-->True, used by : 
                                1)):def __call_impl:    
                        
        (2): def __call_impl
        """
# 2. _global_forward_pre_hooks:
        # 2.1 add content by:
            """
            (1)> def register_module_forward_pre_hook()
                            (hook: Callable[..., None]) -> RemovableHandle:
                r'
                1. Registers a forward pre-hook common to all modules.

                2. .. warning ::
                        2.1: This adds global state to the `nn.module` module
                        2.2 : and it is only intended for debugging/profiling purposes.

                3. The hook will be called every time before :func:`forward` is invoked.
                4. It should have the following signature::

                        hook(module, input) -> None or modified input

                5. The input contains only the positional arguments given to the module.
                Keyword arguments won't be passed to the hooks and only to the ``forward``.
                6. The hook can modify the input. User can either return a tuple or a
                    single modified value in the hook. We will wrap the value into a tuple
                    if a single value is returned(unless that value is already a tuple).

                7. This hook has precedence over the specific module hooks registered with
                    ``register_forward_pre_hook``.
                           '     
            """
        # 2.2： used by :
        """
        (1) def __call__impl
        
        """

# 3. _global_forward_hooks:
                           # Dict[int, Callable] = OrderedDict()

        # 3.1: contents add by:
            """
            (1).def register_module_forward_hook
                                                (hook: Callable[..., None]) -> RemovableHandle:
                r' 1. Registers a global forward hook for all the modules
                2. .. warning ::
                        2.1: This adds global state to the `nn.module` module
                        2.2: and it is only intended for debugging/profiling purposes.

                3. The hook will be called every time after :func:`forward` has computed an output.
                4. It should have the following signature::
                        hook(module, input, output) -> None or modified output

                5. The input contains only the positional arguments given to the module.
                        Keyword arguments won't be passed to the hooks and only to the ``forward``.
                6. The hook can modify the output. It can modify the input inplace but
                        it will not have effect on forward since this is called after
    :                   func:`forward` is called.
                '"""
        # 3.2： used by :
        """
        (1) def __call__impl
        """

#4. self._forward_pre_hooks
    #4.1: add contents by:
    """
    (1)self. register_forward_pre_hook:
                                        (self, hook: Callable[..., None]) -> RemovableHandle:
        '1. Registers a forward pre-hook on the module.
        2. The hook will be called every time before :func:`forward` is invoked.
        3. It should have the following signature::
                hook(module, input) -> None or modified input
        4. The input contains only the positional arguments given to the module.
            Keyword arguments won't be passed to the hooks and only to the ``forward``.
        5.The hook can modify the input. User can either return a tuple or a
            single modified value in the hook. We will wrap the value into a tuple
            if a single value is returned(unless that value is already a tuple).
        '
    """
    # 4.2： used by :
        """ (1) def __call__impl """

# 5.self._forward_hooks:
    # 5.1 : contents add by:
        """
        (1). def register_forward_hook 
                    (self, hook: Callable[..., None]) -> RemovableHandle:
                    
            '1. Registers a forward hook on the module.

            2. The hook will be called every time after :func:`forward` has computed an output.
            3. It should have the following signature::
                    hook(module, input, output) -> None or modified output
            4. The input contains only the positional arguments given to the module.
                Keyword arguments won't be passed to the hooks and only to the ``forward``.
            5. The hook can modify the output. It can modify the input inplace but
                    it will not have effect on forward since this is called after
                    :func:`forward` is called.
            '
        """
    # 5.2： used by :
        """ (1) def __call__impl """

# 6. self._backward_hooks:
    # 6.1 content added by :
        """
        (1) def register_backward_hook
                    (self, hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]]) -> RemovableHandle:
                
                '1. Registers a backward hook on the module.
                2.  This function is deprecated in favor of :meth:`nn.Module.register_full_backward_hook` and
                    the behavior of this function will change in future versions.
                '   
        (2) def register_full_backward_hook:
                    self, hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]]) -> RemovableHandle:
                
                '1.Registers a backward hook on the module.

                2. The hook will be called every time the gradients with respect to module
                        inputs are computed. 
                3. The hook should have the following signature::
                        hook(module, grad_input, grad_output) -> tuple(Tensor) or None

                4. The :attr:`grad_input` and :attr:`grad_output` are tuples that contain the gradients
                        with respect to the inputs and outputs respectively. 
                5. The hook should not modify its arguments, but it can optionally return a new gradient with
                    respect to the input that will be used in place of :attr:`grad_input` in
                    subsequent computations. 
                6.  :attr:`grad_input` will only correspond to the inputs given as positional arguments and 
                    all kwarg arguments are ignored. 
                7. Entries in :attr:`grad_input` and :attr:`grad_output` will be ``None`` for all non-Tensor
                    arguments.

        .. warning ::
            Modifying inputs or outputs inplace is not allowed when using backward hooks and
            will raise an error.
                ' """
    # 6.2 used by method def:
        """
        (1): def _get_backward_hooks: 
                'Returns the backward hooks for use in the call function.
                It returns two lists, one with the full backward hooks and one with the non-full backward hooks.'-->

                Dict:   1)full_backward_hooks ;-->True, used by : 
                                1)):def __call_impl: --> 
                                        >> bw_hook = hooks.BackwardHook(self, full_backward_hooks) # 实例化BackwarHook
                                        >> input = bw_hook.setup_input_hook(input)
                                        #  1))return new input: is a tuple(tensor1, tensor 2, ..tensor axb)                                        
                                                1))): hooks.BackwardHook: 
                                                        # <1> register hook for grad_fn
                                                        #<2> return input/output in tuple, grad_fn = BackwardHookBackward..
                                        #  2)) new input used in forward(*input):    
                                                2))): self.forward_call(*input, **kwargs)

                         2) non_full_backward_hooks.-->True, used by : 
                             1)):def __call_impl:    

(2): def __call_impl
"""
# 7. self._load_state_dict_pre_hooks
    # 7.1 added content by:
    """
    (1)def __setstate__
                (self, state):
                
        'self.__dict__.update(state)
        # Support loading old checkpoints that don't have the following attrs:
         if '_load_state_dict_pre_hooks' not in self.__dict__:
            self._load_state_dict_pre_hooks = OrderedDict()
            '
            
    (2)def _register_load_state_dict_pre_hook (self, hook):
        '1. These hooks will be called with arguments: `state_dict`, `prefix`,
            `local_metadata`, `strict`, `missing_keys`, `unexpected_keys`,
            `error_msgs`, before loading `state_dict` into `self`. 
            These arguments are exactly the same as those of `_load_from_state_dict`
        '
                handle = hooks.RemovableHandle(self._load_state_dict_pre_hooks)
                self._load_state_dict_pre_hooks[handle.id] = hook                         
    """
    #7.2 used by method:
        """
        (1) def _load_from_state_dict # 将state_dict 字典里的相应version module 的parameter, buffer加到该module, 加之前，先pre-hook 处理存储的内容
                (self, state_dict, prefix, local_metadata, strict,missing_keys, unexpected_keys, error_msgs):
            '1. Copies parameters and buffers from :attr:`state_dict` into only this module, but not its descendants. 
            2. This is called on every submodule in :meth:`~torch.nn.Module.load_state_dict`. 
            3. Metadata saved for this module in input :attr:`state_dict` is provided as :attr:`local_metadata`.
            4. For state dicts without metadata, :attr:`local_metadata` is empty.
            5. Subclasses can achieve class-specific backward compatible loading using
                    the version number at `local_metadata.get("version", None)`.

            6... note::
                :attr:`state_dict` is not the same object as the input
                :attr:`state_dict` to :meth:`~torch.nn.Module.load_state_dict`. So
                it can be modified.

            7. Args:
                state_dict (dict): a dict containing parameters and persistent buffers.
                prefix (str): the prefix for parameters and buffers used in this module
                local_metadata (dict): a dict containing the metadata for this module.
                    
                strict (bool): whether to strictly enforce that the keys in
                        :attr:`state_dict` with :attr:`prefix` match the names of parameters and buffers in this module
                missing_keys (list of str): if ``strict=True``, add missing keys to this list
                unexpected_keys (list of str): if ``strict=True``, add unexpected keys to this list
                error_msgs (list of str): error messages should be added to this list, and will be reported together in
                    :meth:`~torch.nn.Module.load_state_dict`                                   
                '
                ----------------------------
                 for hook in self._load_state_dict_pre_hooks.values():
                    hook(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs
                    
                 for name, param in local_state.items():
                    key = prefix + name
                    if key in state_dict:
                    input_param = state_dict[key]
                ---------------------------
                ----------> used by: 
                        1))dump_patches: bool = False
                                'This allows better BC support for :meth:`load_state_dict`. In
                                    :meth:`state_dict`, the version number will be saved as in the attribute
                                    `_metadata` of the returned state dict, and thus pickled. `_metadata` is a
                                    dictionary with keys that follow the naming convention of state dict. See
                                    ``_load_from_state_dict`` on how to use this information in loading.

                                    If new parameters/buffers are added/removed from a module, this number shall
                                    be bumped, and the module's `_load_from_state_dict` method can compare the
                                    version number and do appropriate changes if the state dict is from before the change.
                        2))  _version: int = 1
                
                        3)):def load_state_dict：: 将static里模型及submodule 的parmeter, buffer加过来
                                    (self, state_dict: 'OrderedDict[str, Tensor]', strict: bool = True):
                    
                            ’1. Copies parameters and buffers from :attr:`state_dict` into  this module and its descendants. 
                            2. If :attr:`strict` is ``True``, then the keys of :attr:`state_dict` must exactly match the keys returned
                                by this module's :meth:`~torch.nn.Module.state_dict` function.

                            3. Args:
                                state_dict (dict): a dict containing parameters and persistent buffers.
                                strict (bool, optional): whether to strictly enforce that the keys
                                    in :attr:`state_dict` match the keys returned by this module's
                                    :meth:`~torch.nn.Module.state_dict` function. Default: ``True``

                            4. Returns:
                                ``NamedTuple`` with ``missing_keys`` and ``unexpected_keys`` fields:
                                * **missing_keys** is a list of str containing the missing keys
                                * **unexpected_keys** is a list of str containing the unexpected keys  '
                            -------------------------------------
                            def load(module, prefix=''):
                                local_metadata = {} if metadata is None else metadata.get(prefix[:-1], {})
                                module._load_from_state_dict(
                                    state_dict, prefix, local_metadata, True, missing_keys, unexpected_keys, error_msgs)
                             
                             for name, child in module._modules.items():
                                if child is not None:
                                load(child, prefix + name + '.')
            """

# 8. self._state_dict_hooks
        # 8.1 added content by:
            """
            (1)def __setstate__
                            (self, state):

            'self.__dict__.update(state)
            # Support loading old checkpoints that don't have the following attrs:
            if '_state_dict_hooks' not in self.__dict__:
            self._state_dict_hooks = OrderedDict()
            '

            (2)def _register_state_dict_hook (self, hook):
                '1.These hooks will be called with arguments: `self`, `state_dict`,
                    `prefix`, `local_metadata`, after the `state_dict` of `self` is set.
                2. Note that only parameters and buffers of `self` or its children are
                        guaranteed to exist in `state_dict`. 
                3. The hooks may modify `state_dict` inplace or return a new one
    '
                    handle = hooks.RemovableHandle(self._load_state_dict_pre_hooks)
                    self._state_dict_hooks[handle.id] = hook
                                         
            """
        # 8.2 used by method:
            """
            (1) def state_dict: 将module 及其submodule 的parameter, buffer, 存在字典dictionary 里， 并给dictionary 添加Hook, -hook值是新的字典内容
                            (self, destination=None, prefix='', keep_vars=False):
                '1. Returns a dictionary containing a whole state of the module.
                 2. Both parameters and persistent buffers (e.g. running averages) are
                        included. Keys are corresponding parameter and buffer names.
                3.Returns:
                    dict: a dictionary containing a whole state of the module
                4. Example::
                        >> module.state_dict().keys()
                            ['bias', 'weight']
                 ---> use below method:
                        
                        -----------------
                        self._save_to_state_dict(destination, prefix, keep_vars)
                        for name, module in self._modules.items():
                            if module is not None:
                            module.state_dict(destination, prefix + name + '.', keep_vars=keep_vars)
                        
                        for hook in self._state_dict_hooks.values():
                            hook_result = hook(self, destination, prefix, local_metadata)
                        -------------------------------
                        
                        <1)): self._save_to_state_dict:
                                                        (destination, prefix, keep_vars)-->save current modulue state(parameter, buffers) to Dict desitnation
                                '1.  Saves module state to `destination` dictionary, containing a state
                                        of the module, but not its descendants. 
                                2. This is called on every submodule in :meth:`~torch.nn.Module.state_dict`.
                                3. In rare cases, subclasses can achieve class-specific behavior by
                                overriding this method with custom logic.

                                    Args:
                                        destination (dict): a dict where state will be stored
                                        prefix (str): the prefix for parameters and buffers used in this module
                                '
                                ----------------------------------------
                                for name, param in self._parameters.items():
                                    if param is not None:
                                        destination[prefix + name] = param if keep_vars else param.detach()
                                for name, buf in self._buffers.items():
                                    if buf is not None and name not in self._non_persistent_buffers_set:
                                        destination[prefix + name] = buf if keep_vars else buf.detach()
                                ----------------------------
                                
                        <2))): Dict:   self._state_dict_hooks
                                                         -> dict: a dictionary containing a whole state of the module
                                    for hook in self._state_dict_hooks.values():
                                        hook_result = hook(self, destination, prefix, local_metadata)
                                    if hook_result is not None:
                                        destination = hook_result
                                    return destination ( dict: a dictionary containing a whole state of the module)
                '
                """
# 0. Hooks.BackwardHook:
"""
class BackwardHook(builtins.object)
     |  BackwardHook(module, user_hooks)
     |
     |  A wrapper class to implement nn.Module backward hooks.
     |  It handles:
     |    - Ignoring non-Tensor inputs and replacing them by None before calling the user hook
     |    - Generating the proper Node to capture a set of Tensor's gradients
     |    - Linking the gradients captures for the outputs with the gradients captured for the input
     |    - Calling the user hook once both output and input gradients are available
     |
     |  Methods defined here:
     |
     |  __init__(self, module, user_hooks)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |
     |  setup_input_hook(self, args)
     |
     |  setup_output_hook(self, args)
     |
     
"""
        # (1)def setup_input_hook:(self, args):
#               return new args: in tuple type and apply grad_fn= BackwardHookFunctionBackward>):
#               tuple(tensor1(value, grad_fn=<BackwardHookFunctionBackward>),.tensor2...) by <---
                """
                1.1): def _apply_on_tensors: (fn, args):
                        '<1> return tuple(arg_list), tensor in args apllied Backward function' by <--
                                1.1.1)): torch.nn.modules._functions.BackwardHookFunction.apply:
                                        new_tensors = torch.nn.modules._functions.BackwardHookFunction.apply(*tensors)
                        
                        '<2>: register user hooks on grad_input' , by <--
                                1.1.2)): fn(grad_fns[0]) (method defined in setup_input_hook method):
                                         grad_fns[0] = <BackwardHookFunctionBackward>, call:
                                         
                                         1.1.2.1))):self._set_user_hook(method defined in Hooks.BackWard):
                                                <1>:   @functools.wraps(user_hook)
                                                        def hook(grad_input, _):-->return new grad_input, not modify in-place
                                                <2>: grad_fn.register_hook:
                                                        给tensor: grad_fn: register hook: -->RemovableHandle()                                    
                                     
                """
        # (2)def setup_output_hook:(self, args):
                """
                2.1): def _apply_on_tensors: (fn, args):
                        '<1> return tuple(arg_list), tensor in args apllied Backward function' by <--
                                1.1.1)): torch.nn.modules._functions.BackwardHookFunction.apply:
                                        new_tensors = torch.nn.modules._functions.BackwardHookFunction.apply(*tensors)
                                        
                        '<2>: register user hooks on grad_input' , by ???
                                1.1.2)): fn(grad_fns[0]) (method defined in setup_out_hook method):
                                         grad_fns[0] = <BackwardHookFunctionBackward>, call:
                                         
                                         1.1.2.1))): !!!: def hook(_, grad_output) 
                                                    (not use self._set_user_hook which use in def setup_input_hook
                                                <1>: grad_fn.register_hook:
                                                        给tensor: grad_fn: register hook: -->RemovableHandle() 
                                                        
                                                <2> No idea what return....????
                                                    ‘res = user_hook(self.module, grad_inputs, self.grad_outputs)'
                                                    'if res is not None and not (isinstance(res, tuple) and all(el is None for el in res)):
                                                    raise RuntimeError("Backward hook for Modules where no input requires "
                                                        "gradient should always return None or None for all gradients.") '   
                """