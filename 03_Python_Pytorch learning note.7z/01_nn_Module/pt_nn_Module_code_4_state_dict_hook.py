from  pt_nn_Module_init_1 import *
from pt_nn_Module_hook_method_3 import *
from typing import Callable, Any, TypeVar, Mapping, overload, NamedTuple

__call__: Callable[..., Any]
class Module4(Module3):
    def __setsate__(self, state):
        self.__dict.__.update(state)

        #support loading old checkpoints that don't have the following attrs:

        if '_forward_pre_hooks' not in self.__dict__:
            self._forward_pre_hooks = OrderedDict()
        if '_state_dict_pre_hooks' not in self.__dict__:
            self._state_dict_pre_hooks = OrderedDict()
        if '_load_state_dict_pre_hooks' not in self.__dict__:
            self._load_state_dict_pre_hooks=OrderedDict()
        if '_non_persistent_buffers_set' not in self.__dict__:
            self._non_persistent_buffers_set = set()
        if '_is_full_backward_hook' not in self.__dict__:
            self._is_full_backward_hook = None
    def __getattr__(self, name: str) -> Union[Tensor, 'Module']:
        if "_parameters" in self.__dict__:
            _parameters = self.__dict__['_parameters']
            if name in _parameters:
                return _parameters[name]
        if '_buffers' in self.__dict__:
            _buffers = self.__dict__['_buffers']
            if name in _buffers:
                return _buffers[name]
        if '_modules' in self.__dict__:
            modules = self.__dict__['_modules']
            if name in modules:
                return modules[name]
        raise AttributeError("'{}' object has no attribute '{}'"
                             .format(type(self).__name__, name))

    def __setattr__(self, name: str, value: Union[Tensor, 'Module']) -> None:
        def remove_from(*dicts_or_sets):
            for d in dicts_or_sets:
                if name in d:
                    if isinstance(d, dict):
                        del d[name]
                    else:
                        d.discard(name)
        params = self.__dict__.get('_parameters') # self.__dict__['_parameters']
        #--> params may come from __dict__['_parameters'], __dict__['_buffers'], __dict__['modules']
        # note: dict : dict.get(key): will not raise error if there is not this key in dict;
          #      while dict[key]: will raise error if no this key

        if isinstance(value, Parameter):
            if params is None:
                raise AttributeError("cannot assign parameters before Module.__init__() call")

            remove_from(self.__dict__, self._buffers, self._modules, self._non_persistent_buffers_set)
            self.register_parameter(name, value)

        elif params is not None and name in params:
            if value is not None:
                raise TypeError("cannot assign '{}' as parameter '{}'"
                                "torch.nn.Parameter or None expected")
            self.register_parameter(name, value)

        else:
            modules = self.__dict__.get('_modules')
            if isinstance((value, nn.Module)):
                if modules is None:
                    raise AttributeError("cannot assign module before Module.__init__() call")
                remove_from(self.__dict__, self._parameters, self._buffrs, self._non_persistent_buffers_set)
                modules[name] = value

            elif modules is not None and name in modules:
                if value is not None:
                    raise TypeError("cannot assign '{}' as child module '{}' (torch.nn.Module or None expected)"
                                    .format(torch.typename(value), name))
                modules[name] = value

            else:
                buffers = self.__dict__.get('_buffers')
                if buffers is not None and name in buffers:
                    if value is not None and not isinstance(value, torch.Tensor):
                        raise TypeError("cannot assign '{}' as buffer '{}' (torch.Tensor or None expected)"
                                        .format(torch.typename(value), name))
                    buffers[name] = value

                else:
                    object.__setattr__(self, name, value) # -->new attr in __dict__, not in _buffer, _parameters, _modules.
    """ python字典get()方法和[key]区别
    dic.get(key[,fault]) ，当key不存在不会抛出异常，会显示fault信息
    dic[key]，当key不存在会抛出 KeyError 错误
    """
    def __delattr__(self, name):
        if name in self._parameters:
            del self._parameters[name]
        if name in self._buffers:
            del self._buffers[name]
        if name in self._modules:
            del self._modules[name]
        else:
            object.__delattr__(self, name)

    def register_state_dict_hook(self, hook):
        r"""
        1. These hooks will be called with arguments:'self', 'state_dict',
            'prefix', 'local_metadata', after the 'state_dict' of self is set.
        2. Note : that only parameters and buffers of 'self' or its children are
            guaranteed to exist in 'state_dict'.
        3. !!!The hooks may modify 'state_dict' inplace or return a  new one!!!

        """
        handle = hooks.RemovableHandle(self._state_dict_hooks)
        self._state_dict_hooks = hook
        return handle

    def _save_to_state_dict(self, destination, prefix, keep_vars):
        r"""
        1.Saves module state to 'destination' dictionary, containing a state
            of the module, but not its descendants.
        2.!!! This is called on every submodule in : meth: '~torch.nn.Module.state_dict'.!!!

        3. In rare cases, subclasses can achieve class-specific behavior by
            overriding this method with custom logic.

        Args:
            destination (dict): a dict when state will be stored
            prefix(str): the prefix for parameters and buffers used in this modle

    """
        for name, param in self._parameters.items():
            if param is not None:
                destination[prefix + name] = param if keep_vars else param.detach()
                # tensor.detach()-->create a copy: new tensor: while id(new tensor0 == id(tensor), required_grad=False
                # id same, 不要求求导。
        for name, buf in self._buffers.items():
            if buf is not None and name  not in self._non_persistent_buffers_set:
                destination[prefix+name] = buf if keep_vars else buf.detach()

        #The user can pass an optional arbitrary mappable object to 'state_dict', in which case
        #'state_dict' returns back that same object.
        # but if they pass noting, an 'OrderedDict' is created and returned.

    T_destination = TypeVar('T_destination', bound=Mapping[str, Tensor])

    @overload
    def state_dict(self, destination: T_destination, prefix:str=..., keep_vars: bool = ...) -> T_destination:
        ...

    # TODO: Remove string escape once Python-3.6 no longer supported
    # See https://github.com/python/mypy/issues/6904#issuecomment-496207426
    @overload
    def state_dict(self, prefix: str = ..., keep_vars: bool = ...)-> 'OrderedDict[str, Tensor]':
        ...

    def state_dict(self, destination=None, prefix='', keep_vars=False):
        r"""Return a dictionary containing a whole state of the module.

        Both parameters and persistent buffers (e.g running average) are
        included. Keya are corresponding parameter and buffer names.

        Returns:
            dict:
                a dictionary containing a whole state of the module

        Example:
        >> module.state_dict().keys()
            ['bias', 'weight']

        """
        if destination is None:
            destination= OrderedDict()
            destination._metadata = OrderedDict()
        destination._metadata = local_metadata=dict(version=self._version)
        #1. go to importlib.metadata-->version, metadata
        #2. dict(): -->a tuple of dict: -->{'version': self._version}
        self._save_to_state_dict(destination, prefix, keep_vars)
        for name, module in self._modules.items():
            module.state_dict(destination, prefix + name +'', keep_vars=keep_vars)

        for hook in self._state_dict_hooks.values():
            hook_result = hook(self, destination, prefix, local_metadata)
            if hook_result is not None:
                destination = hook_result

        return destination

    def _register_load_state_dict_pre_hook(self, hook):
        r"""
        1. These hooks will be called with arguments: 'state_hook', 'prefix', 'local_metadata', 'strict',
            'missing_keys', 'unexpected_keys', 'error_msgs';
            before loading 'state_dict' into 'self'.
        These arguments are exactly the same as those of '_load_from_state_dict'.
          """
        handle = hooks.RemovableHandle(self._load_state_dict_pre_hooks)
        self._load_state_dict_pre_hooks = hook
        return handle

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict,
                              missing_keys, unexpected_keys, error_msgs):
        r"""
        1.Copies parameters and buffers from : attr:'state_dict' into only
            this module, but not its descendants.
        2. This is called on every submodule in : meth:'~torch.nn.Module.load_state_dict'
        3. Metadata saved for this module in input: attr:'state_dict' is provided as : attr: 'local_metadata'
        4. for state dicts without metadata, :attr: 'local_metadata' is empty.
        5. Subclass can achieve class-specific backward compatible loading using the version number
            at 'local_metadata.get('version', None)'.

        ..note::
            :attr: 'state_dict' is not the same object as the input
            :attr: 'state_dict' to : meth: '~torch.nn.Module.load_state_dict'.
                so it can be modified.???

        Args:
            state_dict(dict): a dict containing parameters and persistent buffers.

            prefix(str): the prefix for parameters and buffers use in this module

            local_metadata(dict): a dict containing the metadata for this module.

            strict(bool):whether to strictly enforce that the keys in  :attr: 'state_dict'
                with: attr:'prefix' match the names of parameters and buffers in this module

            missing_keys(list of str): if 'strict=True', add missing keys to this list
            unexpected_keys(list of str): if 'strict=True', add unexpected keys to this list
            error_msgs(list of str): error messages should be added to this list , and will be reported
                together in : meth:'~torch.nn.Module.load_state_dict'
        """
        for hook in self._load_state_dict_pre_hooks.values():
            hook(state_dict, prefix, local_metadata, strict, missing_keys,unexpected_keys, error_msgs)

        persistent_buffers = {k: v for k, v in self._buffers.items() if
                              k not in self._non_persistent_buffers_set}
        local_name_params = itertools.chain(self._parameters.items(), persistent_buffers.items())
        local_state = {k: v for k,v in local_name_params if v is not None }

        for name , param in local_state:
            key = prefix + name
            if key in state_dict:
                input_param = state_dict[key]

                #???!!!
                #this is used to avoid copying unitialized parameters into
                # non-lazy modules, since they dont have the hook to do the check in such case,
                #it will error when accessing the .shape attribute.
                is_param_lazy = torch.nn.parameter.is_lazy((param))

                #backward compatibility: loading 1-dim tensor from 0.3.* to version 0.4+???
                if not is_param_lazy and len(param.shape) ==0 and len(input_param.shape)==1:
                    input_param=input_param[0]

                if not is_param_lazy and input_param.shape != param.shape:
                    # local shape should match the one in the checkpoint(except 1-dim)
                    error_msgs.append('size mismatch for {}: copying a param with shape{} from checkpoint '
                                      
                                      'the shape in current model is{}'.format(key, input_param.shape, param.shape))
                    continue # go to for loop

                try:
                    with torch.no_grad(): # copy to param, while 二者直接grad 不计算
                        param.copy_(input_param)
                        """
                        2.使用copy_():
                            解释说明: 比如x4.copy_(x2), 将x2的数据复制到x4,并且会
                            修改计算图,使得反向传播自动计算梯度时,计算出x4的梯度后
                            再继续前向计算x2的梯度. 注意,复制完成之后,两者的值的改变互不影响,
                            因为他们并不共享内存.
                        """
                except Exception as ex:
                    error_msgs.append("While copying the parameter named '{}', "
                                      "whose dimensions in the model are {} and"
                                      "whose dimensions in the checkpoint are {},"
                                      "an exception occured: {}."
                                      .format(key, param.size(), input_param.size(), ex.args))
            elif strict:
                missing_keys.append(key)

        if strict:
            for key in state_dict.keys():
                if key.startswith(prefix):
                    input_name = key[len(prefix):]
                    input_name = input_name.split('.',1)[0] # get the name of param/buffer/child
                    if input_name not in self._modules and input_name not in local_state:
                        unexpected_keys.append(key)

    def load_state_dict(self, state_dict: 'OrderedDict[str, Tensor]', strict: bool = True):
        r"""
        1. Copies parameters and buffers from : attr: 'state_dict' into this module and !!! its descendants!!!

        2. If : attr: 'strict' is 'True', then the keys of : attr: 'state_dict' must exactly match the keys returned
            by this module's: meth: '~torch.nn.Module.state_dict' function.

        Args:
            state_dict(dict): a dict containing parameters and persistent buffers.
            strict(bool, optional): whether to strictly enforce that the keys in :attr:
                'state_dict' match the keys returned by this module's: meth: '~torch.nn.Module.state_dict' function.
                Default: 'True'
        Returns:
            'NamedTuple' with 'missing_keys' and 'unexpected_keys' fields:
            * * missing_keys** is a list of str containing the missing keys
            ** unexpected_keys** is a list of str containing the unexpected keys
        """
        missing_keys: list[str] = []
        unexpected_keys: list[str] = []
        error_msgs: list[str] = []

        #copy state_dict so _load_from_state_dict can modify it
        metadata = getattr(state_dict, '_metadata', None) #
        state_dict = state_dict.copy()
        # is 'deepcopy here', id(state_dict) changed.
        if metadata is not None:
            # mypy isn't aware that '_metadata' exists in state_dict
            state_dict._metadata = metadata # type: ignore [attr_defined]

        def load(module, prefix=''):
            local_metadata= {} if metadata is None else metadata.get(prefix[:-1], {})# [:-1}-->get previous str excpet last character
            #why?? because +'.'??
            module._load_from_state_dict(
                state_dict, prefix, local_metadata, True, missing_keys, unexpected_keys, error_msgs)
            # note: no returns on _load_from_state_dict: as self.attr and position arguments ,change directdly
            for name, child in module._modules.items():
                load(child, prefix+name+'.') # why add'.'??

        load(self)
        del load # why delete load?? incase load again??

        if strict:
            if len(unexpected_keys)>0:
                error_msgs.insert(0, 'Unexpected keys(s) in state_dict:{}'.format(
                    '.'.join('"{}"'.format(k) for k in unexpected_keys))) # id not change using .insert()

            if len(missing_keys) > 0:
                error_msgs.insert(0, 'Missing key(s) in state_dict:{}'.format(
                    '.'.join('"{}"'.format(k) for k in missing_keys)))
            if  len(error_msgs)>0:
                raise RuntimeError("Errors(s) in loading state_dict for {}: \n\t{}"
                                   .format(self.__class__.__name__, '\n\t'.join(error_msgs)))
        return _IncompatibleKeys(missing_keys, unexpected_keys)



class _IncompatibleKeys(NamedTuple('IncompatibleKeys', ['missing_keys', 'unexpected_keys'])):
    def __repr__(self):
        if not self.missing_keys and not self.unexpected_keys:
            return '<All keys matched successfully>'
        return super(_IncompatibleKeys, self).__repr__()



