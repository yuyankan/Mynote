

from pt_nn_Module_code_4_state_dict_hook import *

T = TypeVar('T', bound='Module')

class Module5(Module4)
    def __init__(self):
        super(Module5, self).__init__()

    def train(self: T, mode: bool=True) -> T:
        r"""Sets the module in training mode.

        This has any effect only on certain modules. See documentations of
        particular modules for details of their behaviors in training/evaluation
        mode, if they are affected, e.g.: class:'Dropout', : class:'BatchNorm', etc.

        Args:
            mode(bool): whether to set training mode('True') or evaluation
                mode('False'). Default: 'True'

        Returns:
            Module: self

        """
        if not isinstance(mode, bool):
            raise ValueError("training mode is expected to be boolean")
        self.training = mode
        for module in self.children():
            module.train(mode)
        return self

    def eval(self: T)->T:
        r"""Sets the module in evaluation mode.

        1. This has any effect only on certain modules. See documentations of
            particular modules for details of their behaviors in training/evaluation
            mode, if they are affected, e.g: class:'Dropout', :class: 'BatchNorm', etc.

        2. This is equivalent with: meth:'self.train(False) <torch.nn.Module.train>'

        3. See : ref:'locally-discable-grad-doc' for a comparison between '.eval()'
            and several similar mechanism that may be confused with it.

        Returns:
            Module: self.

        """
        return self.train(False)

    def requires_grad_(self, requires_grad: bool = True) ->T:
        r"""
        1. Change if autograd should record operations on parameters in this modules
        2. This method sets the parameters': attr" 'requires_grad' attributes in-place
        3. This method is helpful for freezing part of the module for finetuning or
            training parts of a model individually(e.g. GAN training)

        4. See: ref: 'locally-disable-grad-doc' for a comparision between
            '.requires_grad_()' and several similar mechanisms that may be confused with it.

        Args:
            requires_grad(bool): whether autograd should record operations on parameters in
                this module. Default 'True'
        Returns:
            Module: self
         """
        for p in self.parameters():
            p.requires_grad_(requires_grad) # start to record operation on Tensor, change attr. requires_grad in-place
        return self

    def zero_grad(self, set_to_none: bool = False) ->None:
        r"""
        1. Set gradients of all model parameters to zero. See similar function under: class:
            'torch.optim.Optimizer' for more context.

        Args:
            set_to_none(bool): instead of setting to zero, set the grads to None.
                See: meth: 'torch.optim.Optimizer.zero_grad' for details.
        """
        if getattr(self, '_is_replica', False): # 是否是复制品
            warnings.warn(
                "Calling.zero_grad() from a module created with nn.DataParallel() has no effect."
                "The parameters are copied (in a differentiable manner) from the original module."
                "This means they are not leaf nodes in autograd and so don't accumulate gradients"
                ""   )
        for p in self.parameters():
            if p.grad is not None:
                if set_to_none:
                    p.grad = None
                else:
                    if p.grad.grad_fn is not None: #
                        p.grad.detach_() # why??-->require_grad = False-->become a leaf.
                        # make p is leaf node:
                            # case1: Tensor.requires_grad = False-->will take Tensor is leaf by convention
                            # case2: Tensor crated by user: requires_grad=True, Tensor.grand.grad_fn is None
                        # detach_(): in-place change tensor attr. required_grad=False
                    else:
                        p.grad.requires_grad(False) # case2
                    p.grad.zero_() # Tensor.zero_(): fill tensor with 0

    def share_memory(self: T)->T:
        r""" See: meth: 'torch.Tensor.share_memory_""
        """
        """torch.Tensor.share_memory_
        Moves the underlying storage to shared memory.
        This is a no-op if the underlying storage is already in shared memory and for CUDA tensors.
        Tensors in shared memory cannot be resized.
        """
        return self._apply(lambda t: t.share_memory_())

    def _get_name(self):
        return self.__class__.__name__

    def extra_repr(self) ->str:
        r"""Set the extra representation of the module

        To print customized extra information, you should re-implement this method in your own modules.
        Both single-line and multi-line strings are acceptable.
        """
        return ''

    # -->called when call print()
    def __repr__(self):
        # we treat the extra repr like the sub-module, one item per line
        extra_lines = []
        extra_repr = self.extra_repr()

        #empty string will be split into list['']
        if extra_repr:
            extra_lines = extra_repr.split('\n') # -->differnet line -> to a list
        child_lines =[]
        for key, module in self._modules.items():
            mod_str = repr(module)
            mod_str= _addindent(mod_str, 2)
            child_lines.append('(' + key + ')' + mod_str)
        lines = extra_lines + child_lines

        main_str = self._get_name() + '('
        if lines:
            #simple one-linear info. which most builtin Modules will use
            if len(extra_lines) ==1 and not child_lines:
                main_str+=extra_lines[0]
            else:
                main_str+='\n' + '\n'.join(lines) + '\n'
        main_str += ')'
        return main_str

    def __dir__(self):
        module_attrs = dir(self.__class__) # __dir__,__call__....
        attrs = list(self.__dict__.keys())
        parameters =list(self._parameters.keys())
        modules = list(self._modules.keys())
        buffers = list(self._buffers.keys())
        keys = module_attrs + parameters + modules + attrs + buffers

        #Eliminate attrs that are not legal Python variable names
        keys = [key for key in keys if not key[0].isdigit()]

        return sorted(keys)

    def _replicated_for_data_parallel (self):
        replica = self.__new__(type(self))
        replica.__dict__= self.__dict__.copy() # shallow copy:
        # id(replica.__dict__) different from id(self.__dict__)
        # id(replica_buffers/_parameters/..} = id (self._buffers/_parameters/..)

        #replicas do not have parameters themselves, the replicas reference the origianl module
        replica._parameters = OrderedDict()
        replica._buffers = replica.buffers.copy()
        replica._modules = replica.modules.copy()
        # id(replica_buffers/_parameters/..} is new one, != id (self._buffers/_parameters/..),

        replica._is_replica = True

        return replica




"""*********************************************************************"""
def _addindent(s_, numSpaces):
    s = s_.split('\n')
    # don't do anything for single-line stuff
    if len(s) == 1:
        return s_
    first = s.pop(0)
    s = [(numSpaces * ' ') + line for line in s]
    s = '\n'.join(s)
    s = first + '\n' + s
    return s







