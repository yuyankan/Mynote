# note:
# Dict: self._modules --->
#   def named_modules (yield: dict: with module name, module); -->use for loop
#       def modules(no name info.): yield module--use for loop
# Dict: self._buffers --->
#   def named_buffers (yield :dict: with buffers name, module); -->use for loop
#       def buffers(no name info.): yield buffer-->use for loop
# Dict: self._parameter --->
#   def named_parameters (yield :dict: with parameter name, module); -->use for loop
#       def parameters(no name info.): yield parameter-->use for loop

# note: class Parameter: nn.module.Parameter()-->created tensor, when this tensor is the attr of Module, it will
# be add automatically to module.parameters: module._parameter dict.-->then could be find in module.named parameters, moduel.parameters:
"""
1.__init__: -->给Module/实例赋值: e.g: l = Parameter(torch.Tensor((1,1),requires_grad=True):
  -->赋值 ’=‘ go to '__setattr__': will check 'l' value ，then decide:
    (1)register_parameer(name, value), or (2)self._modules[name] = value,
    (3)or self._buffers[name]= vaule, or (4)object.__setattr__(self, name, value)

    note: register_parameter-->self._parameters[name]=value
"""

import torch

from collections import OrderedDict
from typing import Any, Optional, Callable, List, Iterator, Tuple
from torch import Tensor
from torch.nn import Parameter
import torch.nn as nn


# Trick mypy into not applying contravariance rules(逆差规则) to inputs by defining
#forward as value, rather than a function. See also  https://github.com/python/mypy/issues/8795

def _forward_unimplemented(self, *input: Any)->None:
    r"""Defines the computation performed at every call.
    Should be overridden by all subclasses.

    ..note::
    Although the recipe for forward pass needs to be defined within
    this function, one should call the : class:'Module' instance afterwards
    instead of this , since the former takes care of running the
    registered hooks while the latter silently ignores them.?????
    """
    raise NotImplementedError




class Module_s:
    r""" Base class for all nueral network modules.

    Your models should also subclass this class.

    Modules can also contain other Modules, allowing to nest them in
    a tree structure. You can assign the submodules as regular attributes::

        import torch.nn as nn
        import torch.nn.functional as F

        class Model(nn.Module):
            def __init__(self):
                super(Model, self).__init__(0
                self.conv1 = nn.Conv2d(1, 20, 5)
                self.conv2 = nn.Conv2d(20, 20,5)

            def forward(self, x):
            x = F.relue(self.conv1(x))
            return F.relu(self.conv2(x))

    Submodules assigned in this way will be registered, and will have their
    parameters converted too when you call: meth: 'to', etc.????!!!

    :ivar training: Boolen represents whether this module is in training or
        evaluate mode.
    :vartype training: bool
"""

    dump_patches: bool = False
    r""" This allows better BC support for : meth: 'load_state_dict'. In
    : meth:'state_dict', the version number will be saved as in the
    attribute '_metadata' of the returned state dict, and thus pickled. '_metadata'
    is a dictionary with keys that follow the naming convention of state dict.
    
    See '' _load from_state_dict'' on how to use this information in loading
    
    If new parameters/buffers are added/removed from a module, this number
    shall be bumped, and the module's '_load from_state_dict' method can compare
    the version number and do appropriate changes if the state dict is from before the change.
    
    """
    # pickle.dump(data, jar) # 将pickle后的数据写入jar文件
    # pickle.load(pkl_file) # 把它加载进一个变量
    _version: int = 1

    training: bool
    _is_full_backward_hook: Optional[bool]

    def __init__(self):
        """
        Initializes internal Module state, shared by both nn.Module and ScriptModule.
        """
        torch.C.log_api_usage_once("python.nn_module")# ？？？
        """
        _log_api_usage_once(...) method of builtins.PyCapsule instance
            _log_api_usage_once(arg0: str) -> None
        """
        self.training = True
        self._parameters = OrderedDict()
        self._buffers = OrderedDict()
        self._non_persistent_buffers_set =set()
        self._backward_hooks = OrderedDict()
        self._is_full_backward_hook = None
        self._forward_hooks = OrderedDict()
        self._forward_pre_hooks = OrderedDict()
        self._state_dict_hooks = OrderedDict()
        self._load_state_dict_pre_hooks = OrderedDict()
        self._modules = OrderedDict()

    forward: Callable[..., Any] = _forward_unimplemented
    #buffer: 缓冲区
    def register_buffer(self, name: str, tensor: Optional[Tensor], persistent: bool=True)->None
        r""" Adds a buffer to the module.
        
        This is typically used to register a buffer that should not be 
        considered a model parameter. For example, BatchNorm's 'running_mean'
        is not a parameter, but is part of the module's state. Buffers, by default,
        are persistent and will be saved alongside parameters. This 
        behavior can be changed by setting: attr: 'persistent' to 'False'. 
        
        The only difference between a persistent buffer and a non-persistent buffer
        is that the latter will not be a part of this module's
        :attr: 'state_dict'!!!
        
        Buffers can be accessed as attributes using given names.
        
        Args: 
            name(string):name of the buffer. The buffer can be accessed
                from this module using the given name.
            tensor(Tensor): buffer to be registered.
            persistent(bool): whether the buffer is part of this module's"
                    :attr:'state_dict'
        
        Example::
            >> self.register_buffer('running_mean', torch.zeros(num_features))
        
        """
        if persistent is False and isinstance(self, torch.jit.ScriptModule):
            raise RuntimeError("ScripModule does not support non-persistent buffer")
        # jit.ScriptModule: 保存和加载模型；if is non-persistent, not module attr.-->will not save /load.from

        if '_buffers' not in self.__dict__: # set this attr in __init__, check re-laoded moduel call __init__ or not
            raise AttributeError("cannot assign buffer before Module.__init__() call")

        elif not isinstance(name, torch._six.string_classes):
            raise TypeError("buffer name should be a string. get {}.".format(torch.typename(name)))

        elif '.' in name:
            raise KeyError("buffer name can't contain\".\"")
        elif name == '':
            raise KeyError("buffer name can't be empty string\"\"")
        elif hasattr(self, name) and name not in self._buffers:
            raise KeyError("attribute '{}' alrady exists".format(name))
        elif tensor is not None and not isinstance(tensor, torch.Tensor):
            raise TypeError("cannot assign '{}' object to buffer '{}'"
                            "(torch Tensor or None required)"
                            .format(torch.typename(tensor), name))
        else:
            self._buffers[name] = tensor
            if persistent:
                self._non_persistent_buffers_set.discard(name)
            else:
                self._non_persistent_buffers_set.add(name)

    # 只能将叶子注册为nn.Module paremter 中, 非叶子不可注册->用forward function()实现运算。
    def register_parameter(self, name: str, param: Optional[Parameter])->None:
        r"""Adds a parameter to the module.

        The parameter can be accessed as an attribute using given name.

         Args:
            name (string): name of the parameter. The parameter can be accessed
                from this module using the given name
            param (Parameter): parameter to be added to the module.
        """
        if '_parameters' not in self.__dict__:
            raise AttributeError("cannot assign parameter before Module.__init__() call")

        elif not isinstance(name, torch._six.string_classes):
            raise TypeError("parameter name should be a string. Got {}"
                            .format(torch.typename(name)))
        elif '.' in name:
            raise KeyError("parameter name can't contain \".\"")
        elif name == '':
            raise KeyError("parameter name can't be empty string \"\"")
        elif hasattr(self, name) and name not in self._parameters:
            raise KeyError("attribute '{}' already exists".format(name))

        if param is None:
            self._parameters[name] = None
        elif not isinstance(param, Parameter):
            raise TypeError("cannot assign '{}' object to parameter '{}'"
                            "(torch.nn.Parameter or None required)".format(torch.typename(param), name))
        elif param.grad_fn:
            raise ValueError(
                "Cannot assign non-leaf Tensor to parameter '{0}'."
                "Model parameters must be created explicitly. To express '{0}'"
                "as a function of another Tensor, compute the value in the forward () method."
                .format(name)
            ) # {0} vs {}???
        else: self._parameters[name] = param

    def add_module(self, name: str, module: Optional[nn.Module])->None:
        r"""Adds a child module to the current module.

        The module can be accessed as an attribute using the given name.

        Args:
            name(string): name of the child module. The child module can be accessed from this module using the given name
            module (Module): child module to be added to the module.
        """
        if not isinstance(module, nn.Module) and module is not None:
            raise TypeError("{} is not a Module subclass".format(torch.typename(module)))
        elif not isinstance(name, torch._six.string_classes):
            raise TypeError("module name should be a string. Got{}".format(torch.typename(name)))
        elif hasattr(self, name) and name not in self._modules:
            raise KeyError("attribute '{}' already exists".format(name))
        elif '.' in name:
            raise KeyError("module name can not contain\".\"")
        elif name == ' ':
            raise KeyError("module name can't be empty string\"\"")
        self._modules[name] = module

    def get_submodule(self, target: str)->nn.Module:
        """
        Returns the submodule given by ''target'' if it exists,
        otherwise throws an error.

        For example, let's say you have an ''nn.Module'', A.
        A looks like this:

        ..code-block::test

        A(
            (net_b): Module(
                    (net_c):Module(
                        (conv): Conv2d(16, 33, kernel_size=(3,3), stride=(2,2))
                    )
                    (linear):Linear(in_features=100, out_features=200, bias=True)
            )
        )
    (The diagram shows an ''nn.Module'', ''A''. ''A'' has a nested submodule [net_b',
    which itself has two submodules 'net_c' and 'linear'. net_c then has a submodule 'conv'.)

    To check whether or not we have the 'linear' submodule, we would call ''get_submodule('net_b.linear')''
    to check whether or not we have the 'conv' sumodule, we would call ''get_submodule("net_b.net_c.conv")''

    The runtime of ''get_submodule'' is bounded by the degree of module nesting in 'target'

    ！！！ A query against 'named_modules' achieves the same result, but it is the 0(N) in the number
    of transitive modules.

    So, for a simple check to see if some submodule exists, 'get_submodule' should always be used.

    Args:
        target: The fully-qualified string name of the submodule to look for.
        (see above example for how to specify a fully-qualified string)

    Returns:
        torch.nn.Module: The submodule referenced by 'target'

    Raises:
        AttributeError: If the target string reference an invalid path or resolves to something that is not an
        'nn.Module'
        """

        if target == '':
            return self

        atoms: List[str] = target.split("'") # -->get a list: each elementis the submodule/parent module.
        mod: torch.nn.Module = self # class instance

        for item in atoms:
            if not hasattr(mod, item): # check if each target element-parentmdule is attr of class instance.
                raise AttributeError(mod._get_name() + "has no attribute '" + item + '"')
            mod = getattr(mod, item)# module mod中含item 名字的属性

            if not isinstance(mod, torch.nn.Module): # check if this attribute type is nn.Module
                raise AttributeError("'" + item + " is not an nn.Module")
        return mod

    def get_parameter(self, target: str)->Parameter:
        """
        Returns the parameter given by 'target' if it exists.
        otherwise throws an error.

        See the docstring for the 'get_submodule' for a more detailed
        explanation of this method's functionality as well as how to
        correctly specify 'target'.

        Args:
            target: the fully-qualified string name of the Parameter
            to look for. (See ``get_submodule`` for how to specify a
                fully-qualified string.)

        Returns:
            torch.nn.Parameter: The Parameter referenced by ``target``

        Raises:
            AttributeError: If the target string references an invalid
                path or resolves to something that is not an
                ``nn.Parameter``
        """
        module_parth, _, param_name = target.rpartition(".")
        mod: torch.nn.Module = self.get_submodule(module_parth)

        if not hasattr(mod, param_name):
            raise AttributeError(mod._get_name() + 'has no attribute “' + param_name + '"')
        param: torch.nn.Parameter = getattr(mod, param_name)

        if not isinstance(param, torch.nn.Parameter):
            raise AttributeError('"' + param_name + '" is not an nn.Parameter')

        return param


    def get_buffer(self, target: str) -> Tensor:
        """
        Returns the buffer given by ``target`` if it exists,
        otherwise throws an error.

        See the docstring for ``get_submodule`` for a more detailed
        explanation of this method's functionality as well as how to
        correctly specify ``target``.

        Args:
            target: The fully-qualified string name of the buffer
                to look for. (See ``get_submodule`` for how to specify a
                fully-qualified string.)

        Returns:
            torch.Tensor: The buffer referenced by ``target``

        Raises:
            AttributeError: If the target string references an invalid
                path or resolves to something that is not a
                buffer
        """
        module_path, _, buffer_name = target.rpartition(".")

        mod: torch.nn.Module = self.get_submodule(module_path)

        if not hasattr(mod, buffer_name):
            raise AttributeError(mod._get_name() + " has no attribute `"
                                 + buffer_name + "`")

        buffer: torch.Tensor = getattr(mod, buffer_name)

        if buffer not in mod._buffers.values():
            raise AttributeError("'" + buffer_name + "' is not a buffer")

        return buffer

    def named_children(self) -> Iterator[Tuple[str, 'Module']]:
        r"""Return an iterator over immediate children modules, yielding both the name
        of the module as well as the module itself.

        Yields:
            (string, Module): Tuple containing a name and child module

        Example::

            >> for name, module in model.named_children():
            >>     if name in ['conv4', 'conv5']:
            >>         print(module)
        """
        memo = set()
        for name, module in self._modules.items():
            if module is not None and module not in memo:
                memo.add(module)  # note: set(), has no attr. append, use add()
                yield name, module
        """
        yield: 先把yield看做“return”，它首先是个return，普通的return是什么意思，就是在程序中返回某个值，返回之后程序就不再往下运行了。
        看做return之后再把它看做一个是生成器（generator）的一部分（带yield的函数才是真正的迭代器）
        """

    def children(self) -> Iterator['Module']:
        r""" Returns an iterator over immediate children modules.

        Yields:
        Module: a child module
        """
        for name, module in self.named_children():
            yield module

    def named_modules(self, memo: Optional[Set['Module']] = None,
                      prefix: str = '', remove_duplicate: bool = True):
        r""" Returns an iterator over all modules in the network,
        yielding both the name of the module as well as the module itself.

        Args:
            memo: a memo to store the set of modules already added to the result
            prefix: a prefix that will be added to the  name of the module
            remove_duplicate: whether to remove the duplicated module instances
            in the result or not

        Yields:
        (string, Module): Tuple of name and module

        Note:
            Duplicate modules are returned only once. In the following
             example, 'l' will be returned only once.

         Example::

            >> l = nn.Linear(2, 2)
            >> net = nn.Sequential(l, l)
            >> for idx, m in enumerate(net.named_modules()):
                    print(idx, '->', m)

            0 -> ('', Sequential(
              (0): Linear(in_features=2, out_features=2, bias=True)
              (1): Linear(in_features=2, out_features=2, bias=True)
            ))
            1 -> ('0', Linear(in_features=2, out_features=2, bias=True))
        """
        if memo is None:
            memo = set()

        if self not in memo:
            if remove_duplicate:
                memo.add(self)
            yield prefix, self  # 0 ->self??
            for name, module in self._modules.items():
                if module is None:
                    continue  # 跳出本次循环
                submodule_prefix = prefix + ('.' if prefix else '') + name
                for m in module.named_modules(memo, submodule_prefix, remove_duplicate):
                    yield m

    def modules(self) -> Iterator['Module']:
        r""" Returns an iterator over all modules in the newwork.

        Yield:
            Module: a module in the network

        Note:
            Duplicate modules are returned only once. In the following
            example, 'l' will be returned only once.

         Example::

            >> l = nn.Linear(2, 2)
            >> net = nn.Sequential(l, l)
            >> for idx, m in enumerate(net.modules()):
                    print(idx, '->', m)

            0 -> Sequential(
              (0): Linear(in_features=2, out_features=2, bias=True)
              (1): Linear(in_features=2, out_features=2, bias=True)
            )
            1 -> Linear(in_features=2, out_features=2, bias=True)

        """
        for _, module in self.named_modules():
            yield module

        # _named_member for what??

    def _named_members(self, get_members_fn, prefix='', recurse=True):  # recurse: 递归
        r"""Helper method for yielding various names + members of modules."""
        memo = set()
        modules = self.named_modules(prefix=prefix) if recurse else [(prefix, self)]  # True: -->also go to all subcalss
        for module_prefix, module in modules:
            members = get_members_fn(module)  # get_member_fn???-->dict?? 调用member 的function
            for k, v in members:
                if v is None or v in memo:
                    continue
                    memo.add(v)
                    name = module_prefix + ('.' if module_prefix else '') + k
                    yield name, v

    def named_buffers(self, prefix: str = '', recurse: bool = True) -> Iterator[Tuple[str, Tensor]]:
        r"""Returns an iterator over module buffers, yielding both
        the name of the buffer as well as the buffer itself.

        Args:
            prefix(str): prefix to pretend (前置) to all buffer names.
            recurse(bool): if Ture, then yields buffers of this module
                and all submodules. Otherwise, yields only buffer that
                are direct members of this module.

        Yields:
            (string, torch.Tensor): Tuple containing the name and buffer

        Example：
            >> for name, buf in self.named_buffers():
            >>    if name in ['running_var']:
            >>        print(buf.size())

        """
        gen = self._named_members(lambda module: module._buffers.items(), prefix=prefix, recurse=recurse)
        for elem in gen:
            yield elem

    def buffers(self, recurse: bool = True) -> Iterator[Tensor]:
        r"""Returns an iterator over module buffers.

        Args:
            recurse(bool): if True, then yields buffers of this module
            and all submodules. Otherwise, yields only buffers that
            are direct members of this module.

        Yields:
            torch.Tensor: module buffer

        Example::
            >> for buf in model.buffers():
            >>     print(type(buf), buf.size())
            <class 'torch.Tensor'> (20L,)
            <class 'torch.Tensor'> (20L, 1L, 5L, 5L)

        """
        for _, buf in self.named_buffers(recurse=recurse):
            yield buf

    def named_parameters(self, prefix:str='', recurse: bool = True) -> Iterator[Tuple[str, Parameter]]:
        r"""Returns an iterator over module parameters, yielding both the
        name of the parameter as well as the parameter itself.

        Args:
            prefix(str): prefix to prepend to all parameter names.
            recurse(bool): if True, then yields parameters of this module
            and all submodules. Otherwise, yields only parameters that
            are direct members of this module.

        Yields:
            (string, Parameter): Tuple containing the name and parameter

        Example::
            >> for name, param in self.named_parameters():
            >>    if name in ['bias']:
            >>        print(param.size())
        """
        gen = self._named_members(lambda module: module._parameters.items(),
                                  prefix=prefix, recurse=recurse)
        for elem in gen:
            yield elem

    def parameters(self, recurse: bool = True) -> Iterator[Parameter]:
        r""" Returns an iterator over module parameters.

        This is typically passed to an optimizer.

        Args:
            recurse(bool): if True: then yields parameters of this module
            and all submodules. Otherwise, yield only parameters that
            are direct members of this module.

        Yields:
            Parameter: module parameter

        Example::
            >> for param in model.parameters():
            >>     print(type(param), param.size())
            <class 'torch.Tensor'> (20L,)
            <class 'torch.Tensor'> (20L, 1L, 5L, 5L)
        """
        for name, param in self.named_parameters(recurse=recurse):
            yield param # -->when call parameters(), use for loop!!



