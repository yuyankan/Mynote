# help understanding _state_dict

import torch.nn as nn
from collections import OrderedDict
from torch.nn import Parameter
import torch


class A1(nn.Module):
    def __init__(self):
        super(A1, self).__init__()
        print("_1. A1: _init__ is called")
        self.a1 = Parameter(torch.zeros(1,3))

class A2(A1):
    def __init__(self):
        super(A2, self).__init__()
        print("2. A2: __init__ is called")
        self.a2 = Parameter(torch.ones(1,2))
        self.l = nn. Linear(2,3)

    def _save_to_state_dict(self, destination, prefix, keep_vars):
        print("-"*50)
        print("2.1: _save_to_state_dict is called")
        print("destination 1:", destination)
        for name, param in self._parameters.items():
            if param is not None:
                destination[prefix + name] = param if keep_vars else param.detach()
        for name, buf in self._buffers.items():
            if buf is not None and name not in self._non_persistent_buffers_set:
                destination[prefix + name] = buf if keep_vars else buf.detach()
        print("destination 2:", destination)
        print("-" * 50)

    def state_dict(self, destination=None, prefix='', keep_vars=False):
        print("*" * 50)
        print("2.2state_dict is called")
        if destination is None:
            destination = OrderedDict()
            destination._metadata = OrderedDict()
        destination._metadata[prefix[:-1]] = local_metadata = dict(version=self._version)# 添加destination version 信息-与实例联系起来
        print("2.2: 0. destination:\n", destination)
        print("2.2: 1. destination._metadata:\n", destination._metadata)
        self._save_to_state_dict(destination, prefix, keep_vars)
        print("self._modules:", self._modules)

        print("*" * 50)
        return destination

e = A2()
print("*"*50)
print(e.state_dict())

