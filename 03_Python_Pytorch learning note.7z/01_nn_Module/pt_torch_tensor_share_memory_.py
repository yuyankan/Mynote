
# 1. Tensor.share_memory_()[source]

"""
Moves the underlying storage to shared memory.
This is a no-op if the underlying storage is already in shared memory and for CUDA tensors.
Tensors in shared memory cannot be resized.
"""