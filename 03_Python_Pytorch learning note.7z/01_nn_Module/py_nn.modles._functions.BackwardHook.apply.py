# help understanding: nn.modules._functions.BackwardHook
# 1. torch.nn.modules._functions.BackwardHookFunction.apply(*input) -->tensor info.of each input: value + grad_fn
import torch
import torch.nn as nn
x = torch.zeros((2), requires_grad=True)
l = nn.Linear(2,1)
y = l(x)

new_tensors_t = torch.nn.modules._functions.BackwardHookFunction.apply(*x)
#apply(*x): (tensor(0., grad_fn=<BackwardHookFunctionBackward>), tensor(0., grad_fn=<BackwardHookFunctionBackward>))

grad_fns_t = [t.grad_fn for t in new_tensors_t if t.grad_fn is not None and t.grad_fn.name() == "BackwardHookFunctionBackward"]
#grad_fns: [<torch.autograd.function.BackwardHookFunctionBackward object at 0x000001FFEB9D8E40>, <torch.autograd.function.BackwardHookFunctionBackward object at 0x000001FFEB9D8E40>]

y.backward()
print("*"*50)
print("apply(*x):",new_tensors_t)
print("\ngrad_fns:",grad_fns_t)


arg_list = list(x)
#arg_list: [tensor(0., grad_fn=<BackwardHookFunctionBackward>), tensor(0., grad_fn=<BackwardHookFunctionBackward>)]

tensors_idx_t =[0,1]
for idx, val in zip(tensors_idx_t, new_tensors_t):
    arg_list[idx] = val
print("*"*50)
print("arg_list:",arg_list)
print("\n tuple(arg_list):",tuple(arg_list))
# tuple(arg_list): (tensor(0., grad_fn=<BackwardHookFunctionBackward>), tensor(0., grad_fn=<BackwardHookFunctionBackward>))

