
import torch
import torch.nn.modules._functions
args = torch.randn(3,2,requires_grad=True)

tensors_idx = []
tensors = []
for i, arg in enumerate(args):
    if isinstance(arg, torch.Tensor):
        tensors_idx.append(i)
        tensors.append(arg)
print("\nargs:", args)
print("\ntensors:", tensors)
new_tensors = torch.nn.modules._functions.BackwardHookFunction.apply(*tensors)
print("*"*50)
print("\nnew_tensors:",new_tensors)
arg_list = list(args)
print("-"*50)
print("\nlist(args_list):", list(arg_list))
for idx, val in zip(tensors_idx, new_tensors):
    arg_list[idx] = val

print("\ntuple(arg_list):",tuple(arg_list))
print("\ntensors_idx:", tensors_idx)
print("*"*50)
print("*"*50)
grad_fns = [t.grad_fn for t in new_tensors if t.grad_fn is not None and t.grad_fn.name() == "BackwardHookFunctionBackward"]
print('grad_fns:', grad_fns)

"""RUN:


args: tensor([[-0.5121, -0.5243],
        [ 0.8469,  0.4476],
        [ 0.5519,  0.7885]], requires_grad=True)

tensors: [tensor([-0.5121, -0.5243], grad_fn=<UnbindBackward>), tensor([0.8469, 0.4476], grad_fn=<UnbindBackward>), tensor([0.5519, 0.7885], grad_fn=<UnbindBackward>)]
**************************************************

new_tensors: (tensor([-0.5121, -0.5243], grad_fn=<BackwardHookFunctionBackward>), tensor([0.8469, 0.4476], grad_fn=<BackwardHookFunctionBackward>), tensor([0.5519, 0.7885], grad_fn=<BackwardHookFunctionBackward>))
--------------------------------------------------

list(args_list): [tensor([-0.5121, -0.5243], grad_fn=<UnbindBackward>), tensor([0.8469, 0.4476], grad_fn=<UnbindBackward>), tensor([0.5519, 0.7885], grad_fn=<UnbindBackward>)]

tuple(arg_list): (tensor([-0.5121, -0.5243], grad_fn=<BackwardHookFunctionBackward>), tensor([0.8469, 0.4476], grad_fn=<BackwardHookFunctionBackward>), tensor([0.5519, 0.7885], grad_fn=<BackwardHookFunctionBackward>))

tensors_idx: [0, 1, 2]
**************************************************
**************************************************
grad_fns: [<torch.autograd.function.BackwardHookFunctionBackward object at 0x0000028CD08FDC80>, <torch.autograd.function.BackwardHookFunctionBackward object at 0x0000028CD08FDC80>, <torch.autograd.function.BackwardHookFunctionBackward object at 0x0000028CD08FDC80>]

Process finished with exit code 0

"""