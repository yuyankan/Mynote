r"""This tracks hooks common to all modules that are executed before/after calling forward and backward. This is global
state used for debugging/profiling purposes"""
import functools
from typing import Dict, Callable, Optional, Union
from collections import OrderedDict
from torch.utils.hooks import RemovableHandle
from torch.utils import hooks
from pt_nn_Module_init_1 import *
import warnings
import itertools
_global_backward_hooks: Dict[int, Callable] = OrderedDict() #??
_global_is_full_backward_hook: Optional[bool] = None
_global_forward_pre_hooks: Dict[int, Callable] = OrderedDict()
_global_forward_hooks: Dict[int, callable] = OrderedDict()
_grad_t = Union[Tuple[Tensor, ...], Tensor]

class Module3(Module_s):
    def __init__(self):
        super(Module3, self).__init__()

    def registr_backward_hook(
            self, hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]]
                              ) -> RemovableHandle:
        r"""Register a backward hook on the module.
        !!!
        This function is deprecated(弃用) in favor of : meth" 'nn.Module.register_full_backward_hook'
        !!!

        and the behavior of this function will change in future versions.

        Returns:
            :class:'torch.utils.hooks.RemovableHandle':
            a hand that can be used to remove the added hook by calling
            'handle.remove()'

        """
        if self._is_full_backward_hook is True:
            raise RuntimeError("Cannot use both regular backward hooks and full backward hooks on a"
                               "single Module. Pleae use only one of them.")

        self._is_full_backward_hook = False
        handle = RemovableHandle[self._backward_hooks]
        self._backward_hooks[handle.id] = hook
        return handle

    def register_full_backward_hook(
            self, hook: Callable[['Module',_grad_t, _grad_t], Union[None, Tensor]]
                                    ) ->RemovableHandle:
        r"""Registers a backward hook on the module.

        1.The hook will be called every time the gradients with respect to module
            inputs are computed.
        2.The hook should have the following signature::
            hook(module, grad_input, grad_output) -> tuple(Tensor) or None
        3. The : attr: 'grad_input' and : attr: 'grad_output' are tuples that contain the gradients
            with respect to the inputs and outputs respectively.
        4.!!! the hook should not modify its arguments but it can optionally return a new gradient with
            respect to the input that will be used in place of:attr: 'grad_input' in subsequent
            computations.
        5. !!! :attr: 'grad_input' will only correspond to the inputs given as positional arguments,   #(positional arguments)?????
            and all kwarg arguments are ignored. Entries in: attr:'grad_input' and :attr:'grad_output'
            will be 'None' for all non-Tensor arguments.

            ..warning::
                Modifying inputs or outputs inplace is not allowed when using backward hooks and
                will raise an error.

            Returns:
                :class:'torch.utils.hooks.RemovableHandle'
                    a handle that can be used to remove the added hook by calling
                    'handle.remove()'
        """

        if self._is_full_backward_hook is False: # set False in def register_backward_hook-> register_backward_hook is caled
            raise RuntimeError("Cannot use both regular backward hooks and full backward hooks on a"
                               "single Module. Pleae use only one of them.")
        self._is_full_backward_hook = True

        handle = hooks.RemovableHandle(self._backward_hooks)
        self._backward_hooks[handle.id] = hook
        return handle

    def _get_backward_hooks(self):
        r"""Returns the backward hooks for use in the call function.
        It returns two lists: one with the full backward hooks and one with the non-full
        backward hooks.
        """
        full_backward_hooks: List[Callable] = []
        if(_global_is_full_backward_hook is True):
            full_backward_hooks += _global_backward_hooks.values()
        if(self._is_full_backward_hook is True):
            full_backward_hooks += self._backward_hooks

        non_full_backward_hooks: List[Callable] = []
        if(_global_is_full_backward_hook is False):
            non_full_backward_hooks += _global_backward_hooks.values()
        if(self._is_full_backward_hook is False):
            non_full_backward_hooks += self._backward_hooks.values()

        return full_backward_hooks, non_full_backward_hooks

    def _maybe_warn_non_full_backward_hook(self, inputs, result, grad_fn):
        if not isinstance(result, torch.Tensor):
            if not(isinstance(result, tuple) and all([isinstance(r, torch.Tensor) for r in result])):
                warnings.warn("Using non-full backward hooks on a Module that does not return a"
                              "signle Tensor or a tuple of Tensor is deprecated and will be removed"
                              "in future versions. This hook will be missing some of the grad_output."
                              "Please use register_full_backward_hook to get the documented behavior.")
                return
        else:
            result =(result,)

        if not isinstance(input, torch.Tensor):
            if not (isinstance(inputs, tuple) and all(isinstance(i, tuple) for i in inputs)):
                warnings.warn("Using non-full backward hooks on a Module that does not take as input a "
                              "single Tensor or a tuple of Tensors is deprecated and will be removed "
                              "in future versions. This hook will be missing some of the grad_input. "
                              "Please use register_full_backward_hook to get the documented behavior.")
                return
        else:
            inputs = (inputs,)

        # At this point we are sure that inputs and result are tuple of Tensors
        out_grad_fn = {r.grad_fn for r in result if r.grad_fn is not None}
        if len(out_grad_fn) == 0 or (len(out_grad_fn)==1 and grad_fn not in out_grad_fn):
            warnings.warn("Using a non-full backward hook when outputs are nested in python data structure "
                          "is deprecated and will be removed in future versions. This hook will be missing "
                          "some grad_output.")
        elif len(out_grad_fn)>1:
            warnings.warn("Using a non-full backward hook when outputs are generated by different autograd Nodes "
                          "is deprecated and will be removed in future versions. This hook will be missing "
                          "some grad_output. Please use register_full_backward_hook to get the documented behavior.")
        else:
            # At this point the grad_output part of the hook will most likely be correct
            inputs_grad_fn = {i.grad.fn for i in inputs if i.grad.fn is not None}

            next_functions = {n[0] for n in grad_fn.next_functions}
            if inputs_grad_fn != next_functions:
                warnings.warn("Using a non-full backward hook when the forward contains multiple"
                              "autograd Nodes, is deprecated and will be removed in future versions. This hool will be"
                              "missing some grad_input. Please use register_full_backward_hook to get the behavior")

    def register_forward_pre_hook(self, hook: Callable[..., None]) -> RemovableHandle:
        r"""Registers a forward pre-hook on the module.

        1.The hook will be called every time ！！before！！: func: 'forward' is invoked.
        2. It should have the following signature::

            hook(module, input) -> None or modified input

        3. ！！！The input contains only the positional arguments given to the module.
            keyword arguments won't be passed to the hooks and only to the 'forward'.
        4. The hook can !! modify !! the input. User can either return a tuple or a
            single modified value in the hook. we will wrap the value into a tuple
            if a single value is returned(unless that value is already a tuple).

        Returns:
            :class:`torch.utils.hooks.RemovableHandle`:
                a handle that can be used to remove the added hook by calling
                ``handle.remove()``
        """
        handle = hooks.RemovableHandle(self._forward_pre_hooks)
        self._forward_pre_hooks[handle.id] = hook
        return handle

    def register_forward_hook(self, hook: Callable[..., None]) -> RemovableHandle:
        r"""Register a forward hook on the module

        1. The hook will be called every time !!after !!: func: 'forward' has computed an output.
            It should have the following signature::

            hook (module, input, output) -> None or modified output

        2. The input contains only the positional arguments given to the module.
            Keyword arguments won't be passed to the hooks and only to the 'forward'.
        3. !! The hook can !!modify !! the output. It can modify the input in-place, but
            it will not have effect on forward since this is called after : func: 'forward' is called.

        Returns:
            :class:`torch.utils.hooks.RemovableHandle`:
                a handle that can be used to remove the added hook by calling
                ``handle.remove()``

        """

        handle = hooks.RemovableHandle(self._forward_hooks)
        self._forward_hooks[handle.id] = hook
        return handle

    """********************?????do not get slow forward?????????******************"""
    def _slow_forward(self, *input, **kwargs):
        tracing_state = torch._C._get_tracing_state()
        if not tracing_state or isinstance(self.forward, torch._C.ScriptMethod): # -->check if module is script or traced
            return self.forward(*input, **kwargs)
        recording_scopes = torch.jit._trace._trace_module_map is not None # is a dict for all submodules , key is module, value is module name
        if recording_scopes:
            # type ignore was added because at this point one knows that
            # torch.jit._trace._trace_module_map is not Optional and has type Dict[Any, Any]-->is traced module
            name = torch.jit._trace._trace_module_map[self] if self in \
         torch.jit._trace._trace_module_map else None # type: #ignore[index, operator], # noqa: B950
            if name:
                tracing_state.push_scope(name) # ??
            else:
                recording_scopes = False
        try:
            result = self.forward(*input, **kwargs)
        finally: # run finally when meet error in try
            if recording_scopes:
                tracing_state.pop_scope()
        return result

    ###do not fully get it def_call_impl!!! # for hook?
    """???????????????????????????????????????????????????????????????????????????????????????????????????????"""
    def _call_impl(self, *input, **kwargs):
        # 判断用slow_forward 还是正常forward, based on 是否是traced state (using script is has if loop.)
        forward_call = (self._slow_forward if torch._C._get_tracing_state() else self.forward)

        #If we don't have any hooks, we want to skip the rest of the logic in
        # this function, and just call forward.
        """1. 如果没有hook-->直接forward_call"""
        if not(self._backward_hooks or self._forward_hooks or
        self._forward_pre_hooks or _global_forward_pre_hooks or _global_forward_hooks or _global_backward_hooks):
            return forward_call(*input, **kwargs)

        # Do not call functions when jit is used. ??(hooks do not use in jit???
        """2. 如果有hook """

        full_backward_hooks, non_full_backward_hooks = [],[]
        if self._backward_hooks or _global_backward_hooks:
            full_backward_hooks, non_full_backward_hooks = self._get_backward_hooks()

        """2.1 有 pre-hook-->return new input/not modify input , use in subcomputation in forward"""
        # 用pre-forward_Hook 对Input 做处理，并将新input 用于forward中
        if self._forward_pre_hooks or _global_forward_pre_hooks:
            for hook in itertools.chain(_global_forward_pre_hooks.values(), self._forward_pre_hooks.values()):
                result = hook(self, input)
                if result is not None:
                    if not isinstance(result, tuple)
                        result = tuple(result,) # why set to be tuple type??!
                        input = result

        """2.2: 有 full_backward_hooks-->grad_fn of input, gran_fn.register_hook, use in backward()
        note: input no change
        """
        # backward_hook 处理 input_grad, output_grad,
        bw_hook = None
        if full_backward_hooks:# every input * output element grad_in, grad_out register_hook:给每个元素注册tensor hook
            # -->True: means there are _global_module_full_forward_hook() or _full_backward_hook()
            # 0. tensor.register_hook(),
            #       ->register hook in Dict: _backward_hook

            # 1.Global:
            # 1.1 .register_module_backward_hook & register_module_full_backward_hook
            #       -->register hook in Dict: _global_backward_hook
            # 1.2.register_module_forward_hook
            #       -->register hook in Dict: _global_forward_hook
            # 1.3.register_module_pre_forward_hook
            #       -->register hook in Dict: _global_pre_forward_hook

            # 2.Module:
            # 2.1 .register_backward_hook & register_full_backward_hook
            #       -->register hook in Dict: _backward_hook
            # 2.2.register_forward_hook
            #       -->register hook in Dict: _forward_hook
            # 2.3.register_pre_forward_hook
            #       -->register hook in Dict: _pre_forward_hook

            bw_hook = hooks.BackwardHook(self, full_backward_hooks) # 实例化，module self, -->full_backward_hooks
            # all backward hooks registered in BackwardHook
            input = bw_hook.setup_input_hook(input)
            # input torch.tensor(a, b) no change, return new input: is a tuple(tensor1, tensor 2, ..tensor axb)
            # register grad_input.register_hook; -->register hook in Dict:_backward_hooks???

            result = forward_call(*input, **kwargs)

        """2.3: 有forward_hook: -->call after forward(), 可以读取forward 计算的input, output, 并修改-->get hook_result->result"""
            #forward_hook:call after forward(), could modify input in-place, no influence on forward.
            # could use input and output computed in forward
        if _global_forward_hooks or self._forward_hooks:
            for hook in itertools.chain(_global_forward_hooks.values(), self._forward_hooks.values()):
                hook_result = hook(self, input, result)
                if hook_result is not None:
                    result = hook_result
        """2.4: 有full_backward, 给output grad_fn注册hook: grand_fn.register_hook(); note: output no change"""
        if bw_hook:# Dict full_backward_hook is not None.
            result = bw_hook.setup_output_hook(result) # use updated result from forward_hook
            #note: 给result.grad_fn 注册hook in module._backward_hook

        """3. 有non-full backward:->给 result.grad_fn, 注册hook的装饰闭包"""
        # handle the non-full backward hooks
        if non_full_backward_hooks:
            var = result
            while not isinstance(var, torch.Tensor):
                if isinstance(var, dict):
                    var = next(v for v in var.values() if isinstance(v,torch.Tensor))
                else:
                    var = var[0]
            grad_fn = var.grad_fn
            if grad_fn is not None:
                for hook in non_full_backward_hooks:
                    wrapper = functools.partial(hook, self) # hook (): change default of positional arguments to self.->new method: wrapper
                    functools.update_wrapper(wrapper, hook) # add __doc__, __name__ attri. to wrapper
                    # hook is wrapped fun, wrapper: 是装饰器闭包函数， attr, dict same as hook,
                    #但闭包函数的属性变动， 不会引起Hook 函数本身的变化。另：wrapper.__wrapped__ =hook: hook 成为wrapper 的一个method.
                    grad_fn.register_hook(wrapper)
                self._maybe_warn_non_full_backward_hook(input, result, grad_fn)

        return result

    __call__: Callable[..., Any] = _call_impl
    # 可以看到，当我们执行model(x)的时候，底层干了以下几件事：

    # 1.调用 forward 方法计算结果

    # 2.判断有没有注册 forward_hook，有的话，就将 forward 的输入及结果作为hook的实参。然后让hook自己干一些不可告人的事情。

    # 看到这，我们就明白hook签名的意思了，还有为什么hook不能修改input的output的原因。
    """
    再看 nn.Module 的__call__方法（被阉割了，只留下需要关注的部分）：
    def __call__(self, *input, **kwargs):
    result = self.forward(*input, **kwargs)
    for hook in self._forward_hooks.values():
       #将注册的hook拿出来用
       hook_result = hook(self, input, result)
   ...
   return result
    """


# help: while:
"""
import torch
var = {'hi':torch.ones(2,3), 'you':torch.zeros(1)}
print(type(var))
if isinstance(var, dict):
    print("test")
    var = next(v for v in var.values() if isinstance(v, torch.Tensor))# next(): only call one time
    # var = var[0]
    print(var)

print("*"*50)
print(var)
"""
"""RUN:
<class 'dict'>
test
tensor([[1., 1., 1.],
        [1., 1., 1.]])
**************************************************
tensor([[1., 1., 1.],
        [1., 1., 1.]])
"""


""" backward hook: hook(module, grad_input, grad_output)
1. The hook will be called every time the gradients with respect to module
            inputs are computed.
   3. The : attr: 'grad_input' and : attr: 'grad_output' are tuples that contain the gradients
            with respect to the inputs and outputs respectively.
        4.!!! the hook should not modify its arguments but it can optionally return a new gradient with
            respect to the input that will be used in place of:attr: 'grad_input' in subsequent
            computations.
"""












"""below are gobal hooks in base nn.Module"""
_global_backward_hooks: Dict[int, Callable] = OrderedDict() #??
_global_is_full_backward_hook: Optional[bool] = None
_global_forward_pre_hooks: Dict[int, Callable] = OrderedDict()
_global_forward_hooks: Dict[int, callable] = OrderedDict()
#a: Dict[int, Callable] = OrderedDict()
#a = {1: '3',  2: '4' }

def register_module_forward_pre_hook(hook: Callable[...,None])->RemovableHandle:
    r"""Registers a forward pre-hook common to all modules.

    ..warning::

    This adds global state to the 'nn.module' module and it is only intended for debugging /profiling purposes.

    The hook will be called every time before: func: 'forward' is invoked.
    It should have the following signature::

        hook(module, input) -> None or modified input

    The input contains only the positional arguments given to the module.
    Keyword arguments won't be passed to hooks and only to the 'forward'.
    The hook can modify the input. User can either return a tuple or a single
    modified value in the hook. we will wrap the value into a tuple if a single
    value is returned(unless that value is already a tuple).

    This hook has precedence over the specific module hooks registered with
    'register_forward_pre_hook'.

    Returns:
        :class: 'torch.utils.hook.RemovableHandle':
            a handle that can be used to remove the added hook by calling
            'handle.remove()'
    """
    handle = hooks.RemovableHandle(_global_forward_pre_hooks)
    _global_forward_pre_hooks[handle.id] = hook
    return handle

def register_module_forward_hook(hook: Callable[..., None])->RemovableHandle
    r"""Registers a global forward hook for all the modules

        .. warning ::

            This adds global state to the `nn.module` module
            and it is only intended for debugging/profiling purposes.

        The hook will be called every time after :func:`forward` has computed an output.
        It should have the following signature::

            hook(module, input, output) -> None or modified output

        The input contains only the positional arguments given to the module.
        Keyword arguments won't be passed to the hooks and only to the ``forward``.
        The hook can modify the output. 
       
    !!! It can modify the input inplace but
        it will not have effect on forward since this is called after
        :func:`forward` is called.!!!

        Returns:
            :class:`torch.utils.hooks.RemovableHandle`:
                a handle that can be used to remove the added hook by calling
                ``handle.remove()``

   !!! This hook will be executed before specific module hooks registered with
        ``register_forward_hook``.!!!
        """
    handle = hooks.RemovableHandle(_global_forward_hooks)# weakref. of _global_forward_hooks, not add+1 to 引用次数；
    _global_forward_hooks[handle.id] =  hook
    return handle # handle.remove(): could delete hooks forever;

from typing import Union, Tuple
from torch import Tensor
_grad_t = Union[Tuple[Tensor, ...], Tensor]

def register_module_backward_hook(hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]])->RemovableHandle:
    r"""Register a backward hook common to all the modules.

    This function is deprecated（废弃） in favor of : meth: 'nn.module.register_module_full_backward_hook'
    and behavious of this function will change in future versioins.

    Returns:
    :class:'torch.utils.hooks.RemovableHandle':
    a handle that can be used to remove the added hook by calling
            ``handle.remove()`

    """
    global _global_is_full_backward_hook
    if _global_is_full_backward_hook is True:
        raise RuntimeError("Cannot use  both regular backward hooks and full backward hooks"
                           "as a global Module hook, Please use only one of them ")
    _global_is_full_backward_hook = False

    handle = hooks.RemovableHandle(_global_backward_hooks)
    _global_backward_hooks[handle.id] = hook
    return handle

def register_module_full_backward_hook(
    hook: Callable[['Module', _grad_t, _grad_t], Union[None, Tensor]]) -> RemovableHandle:
    r"""Registers a backward hook common to all the modules.

    ..warning::
        This adds global state to the 'nn.module' module
        and it is only intended for debugging /profiling purposes.
        !!!
        The current implementation will not have the presented behavior
        for complex: class: 'Module' that perform many operations.
        In some failure cases, :attr:'grad_input' and :attr:'grad_output' will only
        contain the gradients for a subset of the inputs and outputs.
        For such : class: 'Module', you should use: func: 'torch.Tensor.register_hook'
        directly on a specific input or output to get the required gradients.

    The hook will be called every time the gradients with respect to module
    inputs are computed. The hook should have the following signature::

        hook(module, grad_input, grad_output)-> Tensor or None
    !!!
    The :attr:'grad_input' and :attr：’grad_output' are tuples. The hook should
    not modify its arguments, but it can optionally return a new gradient with respect
    to the input that will be used in place of :attr:'grad_input' in subsequent computations.
    :attr:`grad_input` will only correspond to the inputs given
    as positional arguments and all kwarg arguments will not appear in the hook. Entries
    in :attr:`grad_input` and :attr:`grad_output` will be ``None`` for all non-Tensor
    arguments.!!!

    !!! Global hooks are called before hooks registered with 'register_backward_hook'

    Returns:
        :class:`torch.utils.hooks.RemovableHandle`:
            a handle that can be used to remove the added hook by calling
            ``handle.remove()``

    """
    global _global_is_full_backward_hook
    if _global_is_full_backward_hook is False: # means regular backward hooks is called as only set to False here.
        raise RuntimeError("Cannot use both regular backward hooks and full backward hooks as a "
                           "global Module hook. Please use only one of them.")
    _global_is_full_backward_hook = True
    handle = hooks.RemovableHandle(_global_backward_hooks)
    _global_backward_hooks[handle.id] = hook
    return handle

