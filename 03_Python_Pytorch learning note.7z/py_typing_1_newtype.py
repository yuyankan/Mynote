
# python Typing模块-类型注解
"""
typing 是python3.5中开始新增的专用于类型注解(type hints)的模块，为python程序提供静态类型检查，如下面的greeting函数规定了参数name的类型是str，返回值的类型也是str。


def greeting(name: str) -> str:
    return 'Hello ' + name

"""
# note: below case: help info. for input type, yet also ok to run if use other type parameter.

#在实践中，该模块常用的类型有 Any, Union, Tuple, Callable, TypeVar,Optional和Generic等

# 注意事项：typing模块虽然已经正式加入到了标准库中，但是如果核心开发者认为有必要的话，api也可能会发生改变，即不保证向后兼容性
def greeting(name: str) -> str:
    return name
a = greeting(1)
print(a)

#1.Type aliases
"""
简单的类型注解及其形式如开篇例子所示，那么除了默认的int、str等简单类型，就可以通过typing模块来实现注解。首先，我们可以通过给类型赋予别名，
简化类型注释，如下例中的Vector和List[float]是等价的。
"""
from typing import List
Vector = List[float]
def scale(scalar: float, vector: Vector) ->Vector:
    return[scalar * num for num in vector]

s1 = 3.0
s2 = [1.0,2.0]
print(scale(s1, s2))


"""官网还给了另外一个例子，非常生动形象：
from typing import Dict, Tuple, Sequence

ConnectionOptions = Dict[str, str]
Address = Tuple[str, int]
Server = Tuple[Address, ConnectionOptions]

def broadcast_message(message: str, servers: Sequence[Server]) -> None:
    pass

def broadcast_message2(
        message: str,
        servers: Sequence[Tuple[Tuple[str, int], Dict[str, str]]]) -> None:
    pass

函数broadcast_message2的注解明显比broadcast_message更加简洁清晰。
"""

# 2. NewType: 可以使用NewType来创建一个用户自定义类型，如：

from typing import NewType

UserId = NewType("UserId", int)

def get_user_name(user_id: UserId) -> str:
    print(user_id)
    pass

# 可以通过类型检查
user_a = get_user_name(UserId(42351))
# 不能够通过类型检查, 但程序仍可执行。
user_b = get_user_name(-1)
"""*************************************************************************************************************"""
# 2.1 NewType的实现方式：
# NewType的实现方式很简单，在运行时，NewType(name, tp)返回一个函数，这个函数返回其原本的值。静态类型检查器会将新类型看作是原始类型的一个子类。
# NewType实现代码
print("\n2.1: NewType orginal code: ")
def NewType(name, tp):
    def new_type(x):

        return x
    new_type.__name__ = name
    new_type.__supertype__ = tp
    print("type(new_type: ", type(new_type))
    print("new_type:", new_type)
    return new_type
newtype = NewType('hi', 10) # newtype is a function get from def NewType
print(newtype.__name__)
print(newtype.__supertype__)
print(newtype(3))


# 2.2: 因为NewType被看做原始类型的子类，因此在新类型上你可以进行原始类型允许的操作，且结果的类型是原始类型，看起来是不是很神奇，甚至有点绕！
# 其实关键还是要理解其原理，举两个例子：

#case1:
user_id1 = UserId(23)
user_id2 = UserId(10)
print(user_id1 + user_id2)

# case2:
# 请和NewType第一个例子对比
def get_num(num: int) -> int:
    return num

# 可以通过类型检查
get_num(1)

user_id: UserId = UserId(23)
# 可以通过类型检查
get_num(user_id)

"""
请注意，这些检查仅会被静态类型检查程序强制执行。在运行时，Derived = NewType('Derived'，Base) 将 Derived 一个函数，
该函数立即返回传递给它的任何参数。这意味着表达式 Derived(some_value) 不会创建一个新的类或引入任何超出常规函数调用的开销。更确切地说，
表达式 some_value is Derived(some_value) 在运行时总是为真。这也意味着无法创建 Derived 的子类型，因为它是运行时的标识函数，而不是实际的类型。
"""
