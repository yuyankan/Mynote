# compared with deepcopy_list: 列表copy: memo for tuple没有保存tuple object 这个键值对， 只保存了元组元素的id 和value.

"""
tuple:
x0 = [1, 2, 3]
x1=(1, 2, 3)
x2 = ([1, 1, 1], 2, 3)
-->
1. list -->tuple: id changed
2. tuple: x: all element is imutable: -->tuple(x): id same: id(x) == id(tuple(x) == id(deepcopy(x))
3. tuple2: has element mutalble-->id(tuple(x))= id(x), !=id(([1, 1, 1], 2, 3)) !=id(deepcopy(x))
"""


from copy import deepcopy
from copy import _deepcopy_dispatch


def _deepcopy_list1(x, memo, deepcopy=deepcopy):
    print("\n1. deepcopy_list is called")

    y = []
    memo[id(x)] = y
    print(memo[id(x)] is y)
    append = y.append
    print("memo in deepcopy_list():", memo)
    print("*"*50)
    for a in x:
        append(deepcopy1(a, memo)) # memo is not modified here: -->yet memo[id(x)] = y: id(y): y changed-->memo value changed too.
        print("\na in deepcopy_list:", a)
        print('memo in deepcopy_list:', memo)
        print("y in deepcopy_list:", y)
        print("-" * 50)
    print(memo[id(x)] is y)
    print("*"*50)
    return y

def deepcopy1(obj, memo_d=None, _nil=[]):
    print("\n0. deepcopy () is called")
    print("a in deepcopy:", obj)
    #print("memo_d in deepcopy():", memo_d)

    if memo_d is None:
        memo_d ={}
    d = id(obj)
    print("obj id in deepcopy:", d)
    y_d = memo_d.get(d, _nil)
    if y_d is not _nil:
        return y_d # then jump out def deepcopy method.
    cls = type(obj)
    if cls == tuple:
        copier = _deepcopy_tuple_0
    elif cls == list:
        copier = _deepcopy_list1
    else:
        copier = _deepcopy_dispatch.get(cls)
    print("memo_d in deepcopy()1:", memo_d)
    y_d = copier(obj, memo_d) # memo_d no change here?

    memo_d[d] = y_d
    print("y in deepcopy(): id(y_d), y_d", id(y_d), y_d)
    print("memo_d in deepcopy()2:", memo_d)

    return y_d

def _deepcopy_tuple_0(x, memo, deecopy=deepcopy):
    y = []
    memo[id(x)] = y
    print("*"*50)
    print("\n1.deepcopy_tuple is called")
    print("-" * 50)
    append = y.append
    for a in x:
        append(deepcopy1(a, memo))
    #y = [deepcopy(a, memo) for a in x] # y is list: []
    # We're not going to put the tuple in the memo, but it's still important we
    # check for it, in case the tuple contains recursive mutable structures.
        print("\ny in deepcopy_tuple:", y)
        print("memo in deepcopy_tuple:", memo)
    print("*" * 50)

    try:
        print('test1')
        return tuple(memo[id(x)]) # obect x has been copied
    except KeyError:
        print('test11')
        pass

    for k, j in zip(x, y):
        if k is not j:
            print('test2')
            y = tuple(y) # why do this check for changeable object x ??
            break
    else:
        print('test3')
        y = tuple(y)  # something wrong with this code?? y have same id as x
    return tuple(y)

def _deepcopy_tuple(x, memo, deecopy=deepcopy):
    #y = []
    #memo[id(x)] = y # 1. vs deepcop_list:  remove this code will generate memo[id(obj)], value is obj.
    print("*"*50)
    print("\n1.deepcopy_tuple is called")
    print("-" * 50)
    #append = y.append
    #for a in x:
        #append(deepcopy(a, memo)) # same function as above1.
    y = [deepcopy(a, memo) for a in x] # y is list: []
    # We're not going to put the tuple in the memo, but it's still important we
    # check for it, in case the tuple contains recursive mutable structures.
    print("\ny in deepcopy_tuple:", y)
    print("memo in deepcopy_tuple:", memo)
    print("*" * 50)

    try:
        return memo[id(x)] # 2. obect x has been copied # memo[id(x)]: as coding should has no this key.
    except KeyError:
        pass

    for k, j in zip(x, y):
        if k is not j:
            y = tuple(y) # have mutable elemenet in tuple x-->tuple(y)-->change to tuple, while id(tuple(y)) ! = id(x)
            break
    else:
        y = x  # tuple x all element is immutable-->id(y) = id(x)
    return y


obj = ([6, 6, 6], (2, 3), 5)
y = deepcopy1(obj)
print("*"*50)
print(y)









