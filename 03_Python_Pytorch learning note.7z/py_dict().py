# Python dict()函数

""" 描述：
dict 函数，用于创建一个新的字典（dictionary），返回一个新的字典
语法：dict(key/value)
参数说明：key/value -- 用于创建字典的键/值对，可以表示键/值对的方法有很多。

用法：
"""

dict0 = dict()  # 1、传一个空字典
print('dict0:', dict0)

dict1 = dict({'name': 'li', 'age': 24})  # 2、传一个字典
print('dict1:', dict1)

dict2 = dict(user='admin', password=123456)  # 3、传关键字
print('dict2:', dict2)

dict3 = dict([('student', 1), ('teacher', 2)])  # 4、传一个包含一个或多个元组的列表
print('dict3:', dict3)

dict5 = dict(zip(['a', 'A'], [3, 4]))  # 5、传一个zip()函数

"""RUN:
dict0: {}
dict1: {'name': 'li', 'age': 24}
dict2: {'user': 'admin', 'password': 123456}
dict3: {'student': 1, 'teacher': 2}
"""