"""
Help on module torch.utils.hooks in torch.utils:

NAME
    torch.utils.hooks

CLASSES
    builtins.object
        BackwardHook
        RemovableHandle

    class BackwardHook(builtins.object)
     |  BackwardHook(module, user_hooks)
     |
     |  A wrapper class to implement nn.Module backward hooks.
     |  It handles:
     |    - Ignoring non-Tensor inputs and replacing them by None before calling the user hook
     |    - Generating the proper Node to capture a set of Tensor's gradients
     |    - Linking the gradients captures for the outputs with the gradients captured for the input
     |    - Calling the user hook once both output and input gradients are available
     |
     |  Methods defined here:
     |
     |  __init__(self, module, user_hooks)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |
     |  setup_input_hook(self, args)
     |
     |  setup_output_hook(self, args)
     |
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |
     |  __dict__
     |      dictionary for instance variables (if defined)
     |
     |  __weakref__
     |      list of weak references to the object (if defined)

    class RemovableHandle(builtins.object)
     |  RemovableHandle(hooks_dict: Any) -> None
     |
     |  A handle which provides the capability to remove a hook.
     |
     |  Methods defined here:
     |
     |  __enter__(self) -> 'RemovableHandle'
     |
     |  __exit__(self, type: Any, value: Any, tb: Any) -> None
     |
     |  __getstate__(self)
     |
     |  __init__(self, hooks_dict: Any) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |
     |  __setstate__(self, state) -> None
     |
     |  remove(self) -> None
     |
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |
     |  __dict__
     |      dictionary for instance variables (if defined)
     |
     |  __weakref__
     |      list of weak references to the object (if defined)
     |
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |
     |  __annotations__ = {'id': <class 'int'>, 'next_id': <class 'int'>}
     |
     |  next_id = 0

FUNCTIONS
    unserializable_hook(f)
        Decorator which marks a function as an unserializable hook.
        This suppresses warnings that would otherwise arise if you attempt
        to serialize a tensor that has a hook.

    warn_if_has_hooks(tensor)

DATA
    Any = typing.Any
        Special type indicating an unconstrained type.

        - Any is compatible with every type.
        - Any assumed to have all methods.
        - All values assumed to be instances of Any.

        Note that all the above statements are true from the point of view of
        static type checkers. At runtime, Any should not be used with instance
        or class checks.

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\utils\hooks.py


"""

import torch
from collections import OrderedDict
import weakref
import warnings
import functools
from typing import Any


class RemovableHandle(object):
    """A handle which provides the capability to remove a hook."""

    id: int
    next_id: int = 0

    def __init__(self, hooks_dict: Any) -> None:
        self.hooks_dict_ref = weakref.ref(hooks_dict) # weakreferance of hooks_dict
        self.id = RemovableHandle.next_id # 0,
        RemovableHandle.next_id += 1 # next_id +1

    def remove(self) -> None:
        hooks_dict = self.hooks_dict_ref() # 获取若引用对象: hooks_dict; 引用次数+1
        if hooks_dict is not None and self.id in hooks_dict: # self.id 在实例hooks_dict: 里。
            del hooks_dict[self.id] # -->删除实例hooks_dict 中的self.id 键值对。

    def __getstate__(self):
        return (self.hooks_dict_ref(), self.id)# class return: weakreferance;

    def __setstate__(self, state) -> None:
        if state[0] is None:
            # create a dead reference
            self.hooks_dict_ref = weakref.ref(OrderedDict())
        else:
            self.hooks_dict_ref = weakref.ref(state[0])
        self.id = state[1]
        RemovableHandle.next_id = max(RemovableHandle.next_id, self.id + 1)

    def __enter__(self) -> 'RemovableHandle':
        return self

    def __exit__(self, type: Any, value: Any, tb: Any) -> None: #???退出程序时自动删掉该Hook!!!
        self.remove()


def unserializable_hook(f):
    """
    Decorator which marks a function as an unserializable hook.
    This suppresses warnings that would otherwise arise if you attempt
    to serialize a tensor that has a hook.
    """
    f.__torch_unserializable__ = True
    return f


def warn_if_has_hooks(tensor):
    if tensor._backward_hooks:
        for k in tensor._backward_hooks:
            hook = tensor._backward_hooks[k]
            if not hasattr(k, "__torch_unserializable__"):
                warnings.warn("backward hook {} on tensor will not be "
                              "serialized.  If this is expected, you can "
                              "decorate the function with @torch.utils.hooks.unserializable_hook "
                              "to suppress this warning".format(repr(hook)))


