
""" 一、time 模块
1. 三种时间表现形式：
1.1 timestamp：时间戳，时间戳表示的是从1970年1月1日00:00:00开始按秒计算的偏移量
1.2 struct_time： 时间元组，共有九个元素组
1.3 format time： 格式化时间，已格式化的结构使时间更具可读性。包括自定义格式和固定格式


'''
三种格式：
时间戳timestape: time.time()
时间元组struct_time: time.localtime()
格式化时间format_time（包括自定义格式与固定格式）: time.ctime()
'''
************************************************************************************************
2. 时间格式转换图:
2.1: struct_time - format string
 struct time --------> strftime --------> Format string
 struct time <-------- strptime <-------- Format string

2.2: struct_time - Timestamp
 struct time --------> mktime --------> Timestamp
 struct time <------- localtime, gmtime <-------- Timestamp

2.3: %a %b %d &H: &M: %S %Y 串

%a %b %d &H: &M: %S %Y 串  <-------------- asctime <--------- struct_time
%a %b %d &H: &M: %S %Y 串  <-------------- asctime <--------- Timestamp
"""

"""3. 常用方法"""
# ===============Example1: get current time===
import time
a1 = time.time()
print("\nExample1: get current time: time.time():")
print("                         a1=time.time():", a1)
print("                               type(a1):", type(a1))

# ===============Example2: get current time of struct_time format===
print("\nExample2: 当前时间的 struct_time 形式: ")
a2 = time.localtime()
print("                 a2=time.localtime():", a2)

# ===============Example3: get current time change to struct_time format===
print("\nExample3: get current time change to struct_time format:")
a3 = time.gmtime(a1)
print("timestamp a1-->struct_time: time.gmtime(a1):\n"
      "                                    ", a3)   #结果同上: time.localtime()



# ===============Example4:  struct_time change to timestamp===
print("\nExample4: struct_time change to timestamp:")
a4 = time.mktime(a2)
print("struct_time a2-->timestamp:\n"
      "    a4: a4=time.mktime(a2):", a4)


# ===============Example5:  current time : string mode: 当前时间的字符串str格式  Thu Jan 24 12:16:28 2019   是一种固定的格式化时间===
print("\nExample5: current time string mode: 当前时间的字符串str格式  Thu Jan 24 12:16:28 2019   是一种固定的格式化时间")
a5 = time.ctime()
print("current time string mode: time.ctime(): ", a5)

# ===============Example6:  当前时间的struct_time转为特定格式化时间===
print("\nExample6: 当前时间的struct_time转为特定格式化时间:")
a6 = time.strftime('%Y-%m-%d %H: %M: %S', time.localtime())
print("'%Y-%m-%d %H: %M: %S', time.localtime():", a6)

# ===============Example7: 将特定格式化时间转为struct_time===
print("\nExample7: 将特定格式化时间转为struct_time:")
a7 = time.strptime('2021-09-15 10: 43: 56', '%Y-%m-%d %H: %M: %S' )
print("time.strptime('2021-09-15 10: 43: 56', '%Y-%m-%d %H: %M: %S' ):\n", a7)


# ===============Example8: time.clock()===
"""
补充：time.clock()
在UNIX系统上，它返回的是“进程时间”，它是用秒表示的浮点数（时间戳）。
而在WINDOWS中，第一次调用，返回的是进程运行的实际时间。而第二次之后的调用
是自第一次调用以后到现在的运行时间。
"""
from time import clock
start = time.clock()
print('Hi')
finish = time.clock()
fps = finish - start

