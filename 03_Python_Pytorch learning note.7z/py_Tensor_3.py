""" torch的基本功能
torch:张量的相关运算，eg:创建、索引、切片、连续、转置、加减乘除等相关运算。

torch.nn:包含搭建网络层的模块（modules)和一系列的loss函数。eg.全连接、卷积、池化、BN分批处理、dropout、CrossEntropyLoss、MSLoss等。

torch.autograd:提供Tensor所有操作的自动求导方法。

torch.nn.functional:常用的激活函数relu、leaky_relu、sigmoid等。

torch.optim:各种参数优化方法，例如SGD、AdaGrad、RMSProp、Adam等。

torch.nn.init:可以用它更改nn.Module的默认参数初始化方式。

torch.utils.data:用于加载数据。
"""


"""Torchvision基本功能
torchvision.datasets:常用数据集,MNIST、COCO、CIFAR10等。

torchvision.models:常用模型AlextNet、VGG、ResNet、DenseNet等。

torchvision.transforms:图片相关处理。裁剪、尺寸缩放、归一化等。

torchvision.utils:将给定的Tensor保存成image文件。

"""

""" TORCH

Torch包里有很多已经定义好的构造多维Tensor和数学操作的数据构造器。此外，它提供了许多高效构建Tensor和任意数据类型的工具，还有一些其它的有用的工具。
它包含一个附赠的CUDA，能让你在NVIDIA GPU上跑你的Tensor计算程序

TORCH.NN
这个包里藏着关于神经网络的操作。

TORCH.NN.FUNCTIONAL
包含着很多的函数操作。

TORCH.OPTIM
里边有很多优化操作，常用的优化方法都定义好了，且接口是通用的。

PIL

Python图像库PIL(Python Image Library)是python的第三方图像处理库，但是由于其强大的功能与众多的使用人数，几乎已经被认为是python官方图像处理库了。

TORCHVISION

torchvision是独立于pytorch的关于图像操作的一些方便工具库。
vision.datasets :几个常用视觉数据集，可以下载和加载，这里主要的高级用法就是可以看源码如何自己写自己的Dataset的子类
vision.models : 流行的模型，例如 AlexNet, VGG, ResNet 和 Densenet 以及 与训练好的参数。
vision.transforms : 常用的图像操作，例如：随机切割，旋转，数据类型转换，图像到tensor ,numpy数组到tensor , tensor 到 图像等。
vision.utils : 用于把形似 (3 x H x W)的张量保存到硬盘中，给一个mini-batch的图像可以产生一个图像格网。

UTILS
在Python开发中,将常用功能封装成为接口,并放入Utils工具类中,直接调用,可以提升效率

NUMPY
常用的数学计算库

CV2
如果找不到这个包，就得安装opencv。
pip install opencv-python
"""