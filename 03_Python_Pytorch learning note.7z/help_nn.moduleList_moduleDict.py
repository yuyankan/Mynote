import torch.nn as nn
from collections import OrderedDict

class MyModule(nn.Module):
    def __init__(self):
        super(MyModule, self).__init__()
        self.linears = nn.ModuleList([nn.Linear(10, 10) for i in range(10)])# 实例化Modules List， nn.Sequential
        self.model = nn.Sequential(OrderedDict([
            ('conv1', nn.Conv2d(1, 20, 5)),
            ('relu1', nn.ReLU()),
            ('conv2', nn.Conv2d(20, 64, 5)),
            ('relu2', nn.ReLU())
        ]))
        self.choices = nn.ModuleDict({
            'conv': nn.Conv2d(10, 10, 3),
            'pool': nn.MaxPool2d(3)
        })


        print("init is called")

a1 = MyModule()
print("a1.linears:",a1.linears)
print("\na1.linears._modues:",a1.linears._modules.keys())
print("a1.model:",a1.model)
print("\na1.model._modules:",a1.model._modules)

print("*"*50)
print(a1._modules.keys())

print('a1.linears.__class__:',a1.linears.__class__(list(a1.linears._modules.values())[1:3]))
print('a1.linears._modules.values())[1:3]:',list(a1.linears._modules.values())[1:3])
print('a1.linears.__class__:',a1.linears.__class__)#??

print('\na1.choices:', a1.choices)
print('\na1.choices._modules:',a1.choices._modules)