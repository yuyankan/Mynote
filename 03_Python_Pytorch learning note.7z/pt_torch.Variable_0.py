from torch.autograd import Variable
#help(Variable)

"""
class Variable(torch._C._LegacyVariableBase)
 |  # mypy doesn't understand torch._six.with_metaclass
 |  
 |  Method resolution order:
 |      Variable
 |      torch._C._LegacyVariableBase
 |      builtins.object
 |  
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Static methods inherited from torch._C._LegacyVariableBase:
 |  
 |  __new__(*args, **kwargs) from builtins.type
 |      Create and return a new object.  See help(type) for accurate signature.
"""
"""**********************************************************************"""
 # 一. class _LegacyVariableBase(builtins.object)
"""
class _LegacyVariableBase(builtins.object)
 |  Static methods defined here:
 |  
 |  __new__(*args, **kwargs) from builtins.type
 |      Create and return a new object.  See help(type) for accurate signature.
"""
"""**********************************************************************"""
# 二. with_metaclass(meta: type, *bases)
"""
with_metaclass(meta: type, *bases) -> type
    Create a base class with a metaclass.
"""
"""**********************************************************************"""
# 三、Help on class _EngineBase in module torch._C:
"""
# class _EngineBase(builtins.object)
#  |  Methods defined here:
#  |
#  |  is_checkpoint_valid(...)
#  |
#  |  queue_callback(...)
#  |
#  |  run_backward(...)
#  |
#  |  ----------------------------------------------------------------------
#  |  Static methods defined here:
#  |
#  |  __new__(*args, **kwargs) from builtins.type
#  |      Create and return a new object.  See help(type) for accurate signature.
"""
import torch
from torch._six import with_metaclass

# 1. Class VaraibleMeta: check if class instance is torch.Tensor, return True or False-->2. Variable
class VariableMeta(type):
    def __instancecheck__(cls, other):
        return isinstance(other, torch.Tensor)


#2. Class Varaible()-->create new objcet/Variable, with a metal class??

# mypy doesn't understand torch._six.with_metaclass
class Variable(with_metaclass(VariableMeta, torch._C._LegacyVariableBase)):  # type: ignore[misc]
    pass


from torch._C import _ImperativeEngine as ImperativeEngine
Variable._execution_engine = ImperativeEngine()