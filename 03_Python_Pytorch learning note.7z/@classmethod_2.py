"""classmethod:
1.1 描述
classmethod 修饰符对应的函数不需要实例化，不需要 self 参数，但第一个参数需要是表示自身类的 cls 参数，可以来调用类的属性，类的方法，实例化对象等。

1.2 语法
classmethod 语法： @classmethod

1.3 返回值
返回函数的类方法。
"""

"""二、作用
很多博客只是说@calssmethod的作用就是“可以不需要实例化，直接类名.方法名()来调用。这有利于组织代码，把某些应该属于某个类的函数给放到那个类里去，
同时有利于命名空间的整洁”。很抽象，其实具体作用如下：

@classmethod的作用实际是可以在class内实例化class，一般使用在有工厂模式要求时。作用就是比如输入的数据需要清洗一遍再实例化，
可以把清洗函数定义在class内部并加上@classmethod装饰器已达到减少代码的目的。总结起来就是：@class method可以用来为一个类创建一些预处理的实例。

Factory methods（工厂方法模式）:
工厂方法模式即用户只需通过固定的接口获得一个对象的实例，降低了维护的复杂性。
"""

# ===example1: @class method可以用来为一个类创建一些预处理的实例====
# ====original code without pre-dealing====
"""
print("\nexample: time: yymmdd")
class data_test():
    data = {'year': 0, 'month': 0, 'day': 0}
    def __init__(self, year, month, day):
        self.data['year'] = year
        self.data['month'] = month
        self.data['day'] = day

    def out_data(self):
        for key, value in self.data.items():
            print("{}: {}".format(key, value))

t = data_test(2020, 12, 10)
t.out_data()
"""
#==================================
"""如果用户输入的是 "2016-8-1" 这样的字符格式，那么就需要调用Date_test 类前做一下处理：
string_data = '2020-12-01'
year, month, day = map(int, string_data.split('-'))
s = data_test(year,month, day)
s.out_data()
"""
"""************************************************************"""
"""
先把‘2020-1-1’ 分解成 year，month，day 三个变量，然后转成int，再调用Date_test(year,month,day)函数。 也很符合期望。
那我可不可以把这个字符串处理的函数放到 Date_test 类当中呢？那么@classmethod 就开始出场了：

"""
"""
map(function, iterable,...)
>>>function: 接受一个函数名，
>>> iterable: 接受一个或多个可迭代的序列，返回的是一个集合
把函数依次作用在List中的每个元素上，得到一个新的list 并返回

str.split(str="", num=string.count(str)):
>>> str-分隔符， 默认为所有的空字符，包括空格，换行(\n), 制表符(\t)等。
>>> num-分割次数。默认为-1, 即分割所有
"""
#  ====with new clasmethod===
print("\nexample2: time: yymmdd")
class data_test2():
    data = {'year': 0, 'month': 0, 'day': 0}
    def __init__(self, year, month, day):
        self.data['year'] = year
        self.data['month'] = month
        self.data['day'] = day

    @classmethod
    def get_date(cls, data_string):  # #这里第一个参数是cls， 表示调用当前的类名
        year, month, day = map(int, data_string.split('-'))
        date1 = cls(year, month, day) # 返回的是一个初始化后的类
        return date1

    def out_data(self):
        for key, value in self.data.items():
            print("{}: {}".format(key, value))

t = data_test2.get_date('2021-09-09') # 返回的是一个初始化后的类
t.out_data()

"""
这样子等于先调用get_date（）对字符串进行出来，然后才使用Data_test的构造函数初始化。
这样的好处就是你以后重构类的时候不必要修改构造函数，只需要额外添加你要处理的函数，然后使用装饰符 @classmethod 就可以了。
"""