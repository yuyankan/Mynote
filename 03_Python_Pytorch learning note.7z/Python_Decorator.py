"""
Python decorator: python装饰器就是用于拓展原来函数功能的一种函数，这个函数的特殊之处在于它的返回值也是一个函数，
使用python装饰器的好处就是在不用更改原函数的代码前提下给函数增加新的功能

"""
# == time for original function
# ==example1: original function ====
import time


def func():
    print("hello")
    time.sleep(1)
    print("world")


# func()
# ==example2: modify original function: record function running time ====

def func():
    startTime = time.time()

    print("hello")
    time.sleep(1)
    print("world")
    endTime = time.time()

    msecs = (endTime - startTime) * 1000
    print("time is %d ms" % msecs)


# ==example3:  避免直接侵入原函数修改，但是生效需要再次执行函数 ====

def deco(func3):
    startTime = time.time()
    func3()
    endTime = time.time()
    msecs = (endTime - startTime) * 1000
    print("time is %d ms" % msecs)


def func3():
    print("hello")
    time.sleep(1)
    print("world")


# if __name__ == '__main__':

# deco(func3)  # 只有把func3()或者f()作为参数执行，新加入功能才会生效, 不加（）
# print("f.__name__ is", func3.__name__)  # f的name就是func3


# ==example4:  #既不需要侵入，也不需要函数重复执行 ====
print('4'*50)
def deco4(func):
    print('try example4: with decorator')
    a = 1

    def wrapper():  # perform wrapper in the last
        b =2
        print('test1'*10)
        startTime = time.time()
        func()
        endTime = time.time()
        msecs = (endTime - startTime) * 1000
        print("time is %d ms" % msecs)
        print('hi, example4')

    print('test')
    return wrapper

print('5'*50)
@deco4
def func4():
    c = 3
    print("hello",c)
    time.sleep(1)
    print("world")

print('6'*50)
if __name__ == '__main__':
    func4()
    print('func4.__dir__:', func4.__dict__)

"""
这里的deco函数就是最原始的装饰器，它的参数是一个函数，然后返回值也是一个函数。其中作为参数的这个函数func()就在返回函数wrapper()的内部执行。然后在函数func()前面加上@deco，func()函数就相当于被注入了计时功能，现在只要调用func()，它就已经变身为“新的功能更多”的函数了。
所以这里装饰器就像一个注入符号：有了它，拓展了原来函数的功能既不需要侵入函数内更改代码，也不需要重复执行原函数。
"""


# ==example5:  带有参数的装饰器 ====
print('7'*50)
def deco5(func):
    print('example5')

    def wrapper(a, b):
        print('wrapper is called')
        startTime = time.time()
        func(a, b)
        endTime = time.time()
        msecs = (endTime - startTime) * 1000
        print("time is %d ms" % msecs)
        print('hi, example5')

    return wrapper

print('8'*50)
@deco5  # fucntion between deco and wrapper, like print('example5') still run by @ deco,  even if func5 not called.
def func5(a, b):
    print("hello, here is a func for add: ")
    time.sleep(1)
    print("result is %d" % (a + b))

print('9'*50)
if __name__ == '__main__':
    func5(3,4)


# ==example6:  带有不定参数的装饰器 ====
print('9'*50)
def deco6(func):
    print('example 6: 带有不定参数的装饰器')  # when perform func6, do not run codes between deco and wrapper,

    # which run by @deco code only

    def wrapper(*args, **kwargs):
        print('wrapper is called')
        startTime = time.time()
        func(*args, **kwargs)
        endTime = time.time()
        msecs = (endTime - startTime) * 1000
        print("time is %d ms" % msecs)
        print('hi, example6')

    return wrapper
print('1-0'*50)

@deco6
def func6(a, b):
    print('example6: 2 parameters add')
    print("hello, here is a func for add: ")
    time.sleep(1)
    print("result is %d" % (a + b))

print('1-1'*50)

@deco6
def func6_2(a, b, c):
    print('\nexample6_2: 3 parameters add')
    print("hello, here is a func for add: ")
    time.sleep(1)
    print("result is %d" % (a + b + c))

print('1-2'*50)
if __name__ == '__main__':
    func6(3, 4)
    print('1-3' * 50)
    func6_2(3, 4, 5)
print('1-4'*50)

# ==example7:  多个装饰器====

def deco7_1(func):
    print('\nexample7: 1rst decorator')

    def wrapper1(*args, **kwargs):
        print('start: 1rst decorator')
        startTime1 = time.time()
        print('startTime1: %d' % (startTime1 * 1000))
        func(*args, **kwargs)
        endTime1 = time.time()
        print('endTime1: %d' % (endTime1*1000))
        msecs = (startTime1 - endTime1) * 1000
        print('time is %d ms: 1rst' % msecs)
        print('end: 1rst decorator')

    return wrapper1


def deco7_2(func):
    print('\nexample7: 2nd decorator')

    def wrapper2(*args, **kwargs):
        print('start: 2nd decorator')
        startTime2 = time.time()
        print('startTime2: %d' % (startTime2*1000))
        func(*args, **kwargs)
        endTime2 = time.time()
        print('endTime2: %d' % (endTime2*1000))
        msecs = (startTime2 - endTime2) * 1000
        print('time is %d ms: 2nd' % msecs)
        print('end: 2nd decorator')

    return wrapper2

def deco7_3(func):
    print('\nexample7: 3rd decorator')
    def wrapper3(a, b):
        print('start: 3rd decorator')
        func(a, b)
        print('end: 3rd decorator')
    return wrapper3

@deco7_1
@deco7_2
@deco7_3
def func7(a, b):
    print("hello, here is a func for add: ")
    time.sleep(1)
    print("result is %d" % (a + b))

if __name__ == '__main__':
    func7(3, 4)

""" 
!!!!!!装饰器的外函数和内函数之间的语句是没有装饰到目标函数上的，而是在装载装饰器时的附加操作。!!!!!
188~190行是装载装饰器的过程，相当于执行了func7=dec07_1(dec07_2(func7))，此时先执行dec07_2(func7)，结果是输出'example7:2nd decorator'
将func指向函数func7、并返回函数wrapper2，然后执行deco7_2(wrapper2)，结果是输出 'example7: 1rst decorator',
将func指向函数wrapper2、并返回函数wrapper1，然后进行赋值。

用函数替代了函数名func7。 196行则是实际调用被装载的函数，这时实际上执行的是函数wrapper1，运行到func()时执行函数wrapper2，
再运行到wrapper2 内的func()时执行未修饰的函数fuc7.



"""

