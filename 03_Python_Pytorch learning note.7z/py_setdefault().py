import torch
help(dict.setdefault)
# dict.setdefault()
"""
setdefault(self, key, default=None, /)
    Insert key with a value of default if key is not in the dictionary.
    
    Return the value for key if key is in the dictionary, else defaul

"""
# 1. torch.set_default_tensor_type
"""
Help on function set_default_tensor_type in module torch:

set_default_tensor_type(t)
    Sets the default ``torch.Tensor`` type to floating point tensor type
    ``t``. This type will also be used as default floating point type for
    type inference in :func:`torch.tensor`.
    
    The default floating point tensor type is initially ``torch.FloatTensor``.
    
    Args:
        t (type or string): the floating point tensor type or its name
    
    Example::
    
        >>> torch.tensor([1.2, 3]).dtype    # initial default for floating point is torch.float32
        torch.float32
        >>> torch.set_default_tensor_type(torch.DoubleTensor)
        >>> torch.tensor([1.2, 3]).dtype    # a new floating point tensor
        torch.float64
"""

# 2. set_default_dtype(d)
"""

    Sets the default floating point dtype to :attr:`d`.
    This dtype is:
    
    1. The inferred dtype for python floats in :func:`torch.tensor`.
    2. Used to infer dtype for python complex numbers. The default complex dtype is set to
       ``torch.complex128`` if default floating point dtype is ``torch.float64``,
       otherwise it's set to ``torch.complex64``
    
    The default floating point dtype is initially ``torch.float32``.
    
    Args:
        d (:class:`torch.dtype`): the floating point dtype to make the default
    
    Example:
        >>> # initial default for floating point is torch.float32
        >>> torch.tensor([1.2, 3]).dtype
        torch.float32
        >>> # initial default for floating point is torch.complex64
        >>> torch.tensor([1.2, 3j]).dtype
        torch.complex64
        >>> torch.set_default_dtype(torch.float64)
        >>> torch.tensor([1.2, 3]).dtype    # a new floating point tensor
        torch.float64
        >>> torch.tensor([1.2, 3j]).dtype   # a new complex tensor
        torch.complex128
"""