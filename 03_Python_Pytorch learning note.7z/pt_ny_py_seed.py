from torch import seed
import torch
import numpy as np
import random
from torch import Tensor

# pytorch 搭建神经网络CNN的 初始化 set_seed ()

# 1. 第一步，设置种子随机数
"""
在神经网络中，参数默认是进行随机初始化的。不同的初始化参数往往会导致不同的结果，当得到比较好的结果时我们通常希望这个结果是可以复现的，
在pytorch中，通过设置随机数种子可以达到这个目的。
"""


def set_seed(seed):
    torch.manual_seed(seed)  # cpu 为CPU设置种子用于生成随机数，以使得结果是确定的
    torch.cuda.manual_seed(seed)  # gpu 为当前GPU设置随机种子
    torch.backends.cudnn.deterministic = True  # cudnn
    np.random.seed(seed)  # numpy
    random.seed(seed)  # random and transforms

#  0 Ref:. 利用随机数种子来使pytorch中的结果可以复现
# ref:https://cloud.tencent.com/developer/article/1149041
"""
在神经网络中，参数默认是进行随机初始化的。不同的初始化参数往往会导致不同的结果，当得到比较好的结果时我们通常希望这个结果是可以复现的，
在pytorch中，通过设置随机数种子也可以达到这么目的。
 在百度如何设置随机数种子时，搜到的方法通常是：
>> SEED = 0
>> torch.manual_seed(SEED)
>> torch.cuda.manual_seed(SEED)

自己在按照这种方法尝试后进行两次训练所得到的loss和误差都不同，结果并没有复现。

也搜过一些方法，比如设置参数:
>> torch.backends.cudnn.deterministic = True
"""
"""
但是在自己的网络中这样设置并没有用，依然得到不同的结果。

后面偶然在google中搜到有人在设置随机数种子时还加上了np.random.seed(SEED)，经过尝试后发现结果是可复现的了。
但检查自己网络的实现发现并没有直接调用numpy来产生随机数的地方，推测可能是pytorch内部调用了numpy的一些函数。去查看了一些pytorch中关于参数初始化的代码，
"""
# 比如normal的初始化：
"""
torch.nn.init.normal_(tensor, mean=0.0, std=1.0)[SOURCE]
    Fills the input Tensor with values drawn from the normal distribution N(mean, std^2)

    Parameters:
    1. tensor – an n-dimensional torch.Tensor
    2. mean – the mean of the normal distribution
    3. std – the standard deviation of the normal distribution
    
    Examples:
    >>> w = torch.empty(3, 5)
    >>> nn.init.normal_(w)
"""


# 点开source查看源码:torch.nn.init.norma_()
def normal_(tensor: Tensor, mean: float = 0., std: float = 1.) -> Tensor:
    r"""Fills the input Tensor with values drawn from the normal
    distribution :math:`\mathcal{N}(\text{mean}, \text{std}^2)`.

    Args:
        tensor: an n-dimensional `torch.Tensor`
        mean: the mean of the normal distribution
        std: the standard deviation of the normal distribution

    Examples:
        >>> w = torch.empty(3, 5)
        >>> nn.init.normal_(w)
    """
    return _no_grad_normal_(tensor, mean, std)


"******************************************************"


def _no_grad_normal_(tensor, mean, std):
    with torch.no_grad():
        return tensor.normal_(mean, std)


# help(torch.Tensor.normal_): tensor.normal_()
"""
normal_(...)
    normal_(mean=0, std=1, *, generator=None) -> Tensor

    Fills :attr:`self` tensor with elements samples from the normal distribution
    parameterized by :attr:`mean` and :attr:`std`.
"""
# 通过这些还是没能发现pytorch和numpy除了之前众所周知的接口外的内在联系，....

#补充更新：在整理代码时，发现自己在处理数据时用上了这样一行:
"""
data1 = data1.sample(frac=1).reset_index(drop=True) 
当时是用来打乱数据。这里是调用的pandas里面的方法，把这行代码注释掉再把np.random.seed(SEED)注释掉发现结果可以复现。可以推断是这里的随机需要给numpy也设置随机数种子。

如果没有涉及其他随机处理的话这两行可以固定pytorch中的随机数。

>> SEED = 0
>> torch.manual_seed(SEED)
>> torch.cuda.manual_seed(SEED)
"""

# 100: ref: numpy.random.seed()的使用
"""
seed( ) 用于指定随机数生成时所用算法开始的整数值，如果使用相同的seed( )值，则每次生成的随即数都相同，如果不设置这个值，
则系统根据时间来自己选择这个值，此时每次生成的随机数因时间差异而不同。'设置 seed 相当于选择一条世界线。'设置了seed是一直有效的
"""
# 编写如下第一份代码：
from numpy import *
num=0
while(num<5):
    random.seed(5)
    print(random.random())
    num+=1
"""
0.22199317108973948
0.22199317108973948
0.22199317108973948
0.22199317108973948
0.22199317108973948
"""
# 可以看到，每次运行的结果都是一样的

# 修改代码，如下为第二份代码：
print("*"*50)
from numpy import *
num=0
random.seed(5)
while(num<5):
    print(random.random())
    num+=1

"""
0.22199317108973948
0.8707323061773764
0.20671915533942642
0.9186109079379216
0.48841118879482914
可以看到，和上一份代码的运行结果不同。这里每次的输出结果都是不一样的。这也就提醒了我们在以后编写代码的时候要明白一点：random.seed(something)只能是一次有效。其实仔细想想也很自然，如果不是一次有效，比如说是一直有效，那岂不是会影响到后续的代码中随机数的选取？
"""
"""
seed( ) 用于指定随机数生成时所用算法开始的整数值。
1.如果使用相同的seed( )值，则每次生成的随即数都相同；
2.如果不设置这个值，则系统根据时间来自己选择这个值，此时每次生成的随机数因时间差异而不同
3.设置的seed()值一直有效
"""