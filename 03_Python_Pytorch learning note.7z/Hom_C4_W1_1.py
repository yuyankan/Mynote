import matplotlib_inline  #PACKAGE CONTENTS  ：   backend_inline   config
import numpy as np
import h5py
import matplotlib.pyplot as plt

#=========================================1 - Packages=================================
"""
Let’s first import all the packages that need:
- numpy is the fundamental package for scientific computing with Python.
- matplotlib is a library to plot graphs in Python.
- np.random.seed(1) is used to keep all the random function calls consistent. It will help us grade your work.

"""
plt.rcParams['figure.figsize'] =(5.0, 4.0) # set default size of plots
plt.rcParams['image.interpolation'] ='nearest' # interpolation: 插值
plt.rcParams['image.cmap'] ='Greys'

np.random.seed(1)

#=========================================2 - Zero_padding=================================
# GRADED FUNCTION: zero_pad

def zero_pad(x, pad):
    """
    Pad with zeros all images of the dataset X. The padding is applied to the height and width of an image,
    as illustrated in Figure 1.

    Argument:
    X -- python numpy array of shape (m, n_H, n_W, n_C) representing a batch of m images
    pad -- integer, amount of padding around each image on vertical and horizontal dimensions

    Returns:
    X_pad -- padded image of shape (m, n_H + 2*pad, n_W + 2*pad, n_C)
    """
    ### START CODE HERE ### (≈ 1 line)
    x_pad = np.pad(x, ((0,0), (pad, pad), (pad, pad), (0,0)), 'constant')
    ### END CODE HERE ###
    return x_pad

x = np.random.randn(4,3,3,2)
x_pad = zero_pad(x, 2)

print('x.shape = ',x.shape)
print('x_pad.shape',x_pad.shape)
print('x[1,1] = ',x[1,1])
print('x_pad[1,1] = ',x_pad[1,1])

fig, axarr = plt.subplots(1,2)
axarr[0].set_title('x')
axarr[0].imshow(x[0,:,:,0])
axarr[1].set_title('x_pad')
axarr[1].imshow(x_pad[0,:,:,0])
plt.show()

"""
x.shape =  (4, 3, 3, 2)
x_pad.shape (4, 7, 7, 2)
x[1,1] =  [[ 0.90085595 -0.68372786]
 [-0.12289023 -0.93576943]
 [-0.26788808  0.53035547]]
x_pad[1,1] =  [[0. 0.]
 [0. 0.]
 [0. 0.]
 [0. 0.]
 [0. 0.]
 [0. 0.]
 [0. 0.]]
"""