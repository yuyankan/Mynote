
# help(str.rpartition)
"""
rpartition(self, sep, /)
    Partition the string into three parts using the given separator.

    This will search for the separator in the string, starting at the end. If
    the separator is found, returns a 3-tuple containing the part before the
    separator, the separator itself, and the part after it.

    If the separator is not found, returns a 3-tuple containing two empty strings
    and the original string.

"""
a = '2021.10.04'
b = a.rpartition('.')
print(b) # ('2021.10', '.', '04')
c = a.rpartition('-')
print(c) #('', '', '2021.10.04')