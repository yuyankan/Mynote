# 可调用的对象
"""
你可能已经知道了，在Python中，函数是一等的对象。这意味着它们可以像其他任何对象一样被传递到函数和方法中，这是一个十分强大的特性。

Python中一个特殊的魔法方法允许你自己类的对象表现得像是函数，然后你就可以“调用”它们，把它们传递到使用函数做参数的函数中，等等等等。这是另一个强大而且
方便的特性，让使用Python编程变得更加幸福。

__call__(self, [args…])
允许类的一个实例像函数那样被调用。本质上这代表了 x() 和 x.__call__() 是相同的。注意 __call__ 可以有多个参数，这代表你可以像定义其他任何函数一样，
定义 __call__ ，喜欢用多少参数就用多少。

"""

#上下文管理器
"""
在Python 2.5中引入了一个全新的关键词，随之而来的是一种新的代码复用方法—— with 声明。上下文管理的概念在Python中并不是全新引入的（之前它作为标准库
的一部分实现），直到PEP 343被接受，它才成为一种一级的语言结构。可能你已经见过这种写法了:

with open('foo.txt') as bar:
    # 使用bar进行某些操作

当对象使用 with 声明创建时，上下文管理器允许类做一些设置和清理工作。上下文管理器的行为由下面两个魔法方法所定义：

>1. __enter__(self)
定义使用 with 声明创建的语句块最开始上下文管理器应该做些什么。注意 __enter__ 的返回值会赋给 with 声明的目标，也就是 as 之后的东西。


>2. __exit__(self, exception_type, exception_value, traceback)
定义当 with 声明语句块执行完毕（或终止）时上下文管理器的行为。它可以用来处理异常，进行清理，或者做其他应该在语句块结束之后立刻执行的工作。
如果语句块顺利执行， exception_type , exception_value 和 traceback 会是 None 。否则，你可以选择处理这个异常或者让用户来处理。
如果你想处理异常，确保 __exit__ 在完成工作之后返回 True 。如果你不想处理异常，那就让它发生吧。

对一些具有良好定义的且通用的设置和清理行为的类，__enter__ 和 __exit__ 会显得特别有用。你也可以使用这几个方法来创建通用的上下文管理器，用来包装其他对象。下面是一个例子
"""
class Closer:
    '''一个上下文管理器，可以在with语句中
    使用close()自动关闭对象'''

    def __init__(self, obj):
        self.obj = obj

    def __enter__(self, obj):
        return self.obj # 绑定到目标

    def __exit__(self, exception_type, exception_value, traceback):
        try:
            self.obj.close()
        except AttributeError:  # obj不是可关闭的
            print('Not closable')
            return True # 成功地处理了异常

"""
>>> from magicmethods import Closer
>>> from ftplib import FTP
>>> with Closer(FTP('ftp.somesite.com')) as conn:
...         conn.dir()
...
# 为了简单，省略了某些输出
>>> conn.dir()
# 很长的 AttributeError 信息，不能使用一个已关闭的连接
>>> with Closer(int(5)) as i:
...         i += 1
...
Not closable.
>>> i

看到我们的包装器是如何同时优雅地处理正确和不正确的调用了吗？这就是上下文管理器和魔法方法的力量。Python标准库包含一个 contextlib 模块，
里面有一个上下文管理器 contextlib.closing() 基本上和我们的包装器完成的是同样的事情（但是没有包含任何当对象没有close()方法时的处理）。
"""