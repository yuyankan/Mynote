"""*************************************************************************************************************"""
# 1. operator——函数的标准操作

#operator模块输出一系列对应Python内部操作符的函数。例如：operator.add(x, y)等价于表达式x+y。许多函数的名称都被一些特定的方法使用，
# 没有下划线加持。为了向下兼容，它们中的许多都保留着由双下划线的变体。那些不具备双下划线的变体是为了使表达更清晰。

#这些函数在各种函数目录里扮演者对相比较、逻辑操作、数学运算以及序列操作等角色。

#对于所有对象来讲对象比较函数是十分有用的，并且这些函数以它们支持的丰富的比较操作命名。

"""
operator. lt(a, b)          //less than小于

operator. le(a, b)          //lessthan or equal to小于等于

operator. eq(a, b)          //equal to等于

operator. ne(a, b)          //not equalto不等于

operator. ge(a, b)          //greaterand equal to大于等于

operator. gt(a, b)          //greater大于

operator. __le__(a, b)

operator. __lt__(a, b)

operator. __eq__(a, b)

operator. __ne__(a, b)

operator. __ge__(a, b)

operator. __gt__(a, b)

在a与b之间之行丰富的比较操作。特别地，lt(a, b)等价于a < b、le(a, b)等价于a <= b、eq(a, b)等价于a == b、ne(a, b)等价于a != b、gt(a, b)
等价于a > b、ge(a, b)等价于a >= b。注意：这些函数可以返回任何值，这个值可能当做布尔值用、也有可能不行。

"""
"""*************************************************************************************************************"""
# 2.逻辑操作一般也适用于所有对象，并且支持真值比较、定义测试和布尔操作。
"""
operator. not_(obj)

operator. __not__(obj)

返回非obj的结果。（注意：对于对象实例不存在__not__()方法；只有解释器代码定义了这个操作。它的结果受__bool__()和__len__()方法影响）。
"""

# 3. operator. truth(obj)
""" 如果obj是真的，就返回True，否则返回False。等价于使用布尔构造器。
operator. is_(a, b)

返回表达式a is b，用于测试对象的定义。

operator. is_not(a, b)

返回表达式a is not b，用于测试对象定义。
"""
"""*************************************************************************************************************"""
#3. 和序列有关的操作（其中的一些也可用于映射），包括：
"""
operator. concat(a, b)
operator. __concat__(a, b)
返回a + b，a与b都为序列。

operator. contains(a, b)
operator. __contains__(a, b)
返回测试b in a的结果。请注意反转操作数。

operator. countof(a, b)
返回b在a中出现的次数。

operator. delitem(a, b)
operator. __delitem__(a, b)
删除a索引b的值。

operator. getitem(a, b)
operator. __getitem__(a, b)
返回a索引b的值。

operator. indexof(a, b)
返回b在a中第一次出现时的索引。

operator. setitem(a, b, c)
operator. __setitem__(a, b, c)
a中索引b的位置上的值设置为c。

operator. length_hint(obj, default=0)
返回对象obj的估算长度。首先试图返回真实的长度，不行的话使用obj.__length_hint__()估算长度，再不行的话返回默认值规定的长度。
"""
"""*************************************************************************************************************"""

#4. operator模块也定义了一些广义属性和项目查找的工具。它们常用于为诸如map()、sorted()、itertools. groupby()或其他需要函数作为参数的函数
# 提供参数，该参数为一个高速的字段提取器。

"""
operator. attrgetter(attr)

operator. attrgetter(*attrs)

返回一个可点用对象，该对象能从其操作中捕获attr。如果提供了多个属性，返回一个属性构成的元组。属性名也可以包含符号点。例如：

•••运行 f = attrgetter(‘name’)之后，调用f(b)，返回b.name。

•运行 f = attregetter(‘name’,’date’)之后，调用f(b)，返回(b. name, b,date)。

•运行f =attregetter(‘name.first’, ‘name. last’)之后，调用f(b)，返回(b. name. first, b. name. last)。
"""

# 2.原址操作
#许多操作都有其原地操作版本。以下列出的函数提供了比普通语法操作更原始的原址操作。例如：语句x += y等价于x = operator. iadd(x, y)。
#其它方法提出说z = operatgor.iadd(x, y)等价于复合语句 z= x; z += y。
#在其他例子中，注意，当一个原址操作被调用，计算和分配在讲个分割开来的步骤里进行。以下列出的原址函数值做了第一步，调用原址方法。第二步，分配却没有被操作。
#对于不变的目标李如意字符串、数组和元组，被更新的值是需要计算的，但是不回配输入变量：
"""
>>>a ='hello'

>>>iadd(a, ' world')

'helloworld'

>>>a

'hello
"""
# 对于可变对象例如列表和字典，预案之操作将会运行更新，因此不需要后续分配。
"""
>>>s = ['h', 'e', 'l', 'l', 'o']

>>>iadd(s, [' ', 'w', 'o', 'r', 'l', 'd'])

['h', 'e','l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd']

>>>s

['h', 'e','l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd']

"""


