import torch
# help(torch.__future__)
"""
Help on module torch.__future__ in torch:

NAME
    torch.__future__

DESCRIPTION
    This global flag controls whether to assign new tensors to the parameters
    instead of changing the existing parameters in-place when converting an `nn.Module`
    using the following methods:
    1. `module.cuda()` / `.cpu()` (for moving `module` between devices)
    2. `module.float()` / `.double()` / `.half()` (for converting `module` to a different dtype)
    3. `module.to()` / `.type()` (for changing `module`'s device or dtype)
    4. `module._apply(fn)` (for generic functions applied to `module`)
    
    Default: False

FUNCTIONS
    get_overwrite_module_params_on_conversion()
    
    set_overwrite_module_params_on_conversion(value)

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\__future__.py



Process finished with exit code 0


"""