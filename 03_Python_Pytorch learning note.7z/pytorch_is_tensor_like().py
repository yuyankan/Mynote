"""
    is_tensor_like(inp)
        Returns ``True`` if the passed-in input is a Tensor-like.

        Currently, this occurs whenever there's a ``__torch_function__``
        attribute on the type of the input.

        Examples
        --------
        A subclass of tensor is generally a Tensor-like.

       # >>> class SubTensor(torch.Tensor): ...
       # >>> is_tensor_like(SubTensor([0]))
        True

        Built-in or user types aren't usually Tensor-like.

      #  >>> is_tensor_like(6)
        False
       # >>> is_tensor_like(None)
        False
       # >>> class NotATensor: ...
       # >>> is_tensor_like(NotATensor())
        False

        But, they can be made Tensor-like by implementing __torch_function__.

       # >>> class TensorLike:
        ...     def __torch_function__(self, func, types, args, kwargs):
        ...         return -1
      #  >>> is_tensor_like(TensorLike())
        True
"""
from torch.overrides import is_tensor_like
class TensorLike:
    def __torch_function__(self, func, types, args, kwargs):
        return -1

print(is_tensor_like(TensorLike()))