"""
List： python 中的 list 是 python 的内置数据类型，list 中的数据类型不必相同，
在 list 中保存的是数据的存放的地址，即指针，并非数据。！！！！！！

array： array() 是 numpy 包中的一个函数，array 里的元素都是同一类型。ndarray 是一个多维的数组对象，具有矢量算术运算能力和复杂的广播能力，
并具有执行速度快和节省空间的特点。ndarray 的一个特点是同构：即其中所有元素的类型必须相同。
"""
import numpy as np
a = [1, 2, 3, 4, 5, 'hi']
b = np.array([1,2, 3, 4, 5, 6])
c = np.array([[1,2,3], [4, 5, 6]])
print("\nlist a = [1, 2, 3 ,4, 5 6]: \n", a)
print("\nb = np.array([1,2, 3, 4, 5, 6]): \n", b)
print("\nc = np.array([[1,2,3], [4, 5, 6]]):\n", c)

"""NumPy 提供的 array() 函数可以将 Python 的任何序列类型转换为 ndarray 数组。例如将一个列表转换成 ndarray 数组："""
a2 = np.array(a)
print(a2) # -->all change to string: ['1' '2' '3' '4' '5' 'hi']