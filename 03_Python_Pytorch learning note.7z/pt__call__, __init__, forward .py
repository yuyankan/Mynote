"""
pytorch主要也是按照__call__, __init__,forward三个函数实现网络层之间的架构的
__init__: 类的初始化函数，类似于c++的构造函数
__call___: 使得 '类对象' 具有类似函数的功能。

"""


#  ==========================Example 1:  Call function ====================

class A:
    def __call__(self):
        print("I can called like a function")

print('1'*50)
a = A()
print('2'*50)
a()
print('3'*50)

#  ==========================Example 2:  Call function with parameter====================

class A:
    def __call__(self, param):
        print('I can called like a function')
        print('input parameter type is ', type(param))

print('4'*50)

a = A()  # not a = A(parameter), as no init function where parameter used directly.
print('5'*50)
a('i')
print('6'*50)


#  ==========================Example 3:  Call function with forward function===================


class A:
    def __call__(self, param):
        print('I can called like a function')
        print('input parameter type is : {}, content is: {}'.format(type(param), param))

        res = self.forward(param)
        return res

    def forward(self, input_):
        print('forward function is been called')

        print('in forward, input parameter type is: {}, value is : {}'.format(type(input_), input_))
        return input_

print('7'*50)
a = A()
print('8'*50)
input_param = a('i')
print('9'*50)


#  ==========================Example 4:  init function + Call function with forward function===================

class A:
    def __init__(self, init_age: int):
        super().__init__()
        print('My age is: ', init_age)
        self.age = init_age

    def __call__(self, added_age: int):
        res = self.forward(added_age)
        return res

    def forward(self, input_):
        print('forward function is been called')

        return input_ + self.age

print('10'*50)
print('initialize')
a = A(10)  # use a = A(parameter) , parameter for __init__ method.
print('11'*50)
input_param2 = a(2)
print('12'*50)
print('my current age is : ', input_param2)
