
# Python中的三个类get内置方法（魔法函数），很容易让人混淆，我们在理清这三个方法的用途和区别之前，先看看Python中对于一个对象是怎么获取它的属性的。

# Python中对象属性的获取链:
# 我们在使用obj.value时，Python内部是怎么样的查找顺序呢？（value不是数据描述符，数据描述符请看下面）:
"""
我们在使用obj.value时，Python内部是怎么样的查找顺序呢？（value不是数据描述符，数据描述符请看下面）:
obj.value等价于getattr(obj, 'value')，会调用基类object Python默认的__getattribute__方法，该方法逻辑如下
1. 最开始，Python会使用obj.__dict__[vlaue]的方法查找，也就是查找 对象（类实例） 内置字典的key值
2. 如果上述方法查找不到，会使用type(obj).__dict__[value]来查找，也就是会查找obj的 类 的属性
3. 如果上述方法查找不到，Python会用mro的查找方法遍历type(obj)的基类，在其基类中查找 类 (不是类实例)属性，直到找到为止
4. 如果还找不到，__getattribute__在抛出AttributeError前调用__getattr__方法
"""
class E1:
    def __init__(self):
        self.a = 8
    a = 6
    print("\n1.class character a=6 is called")
    print("*"*50)

class E2(E1):
    def __init__(self, v):
        print("\n2.subclass __init__ is called")
        self.b = v

    b = 10
    print("\n3.subclass character b = 10 is called\n")
    print("*" * 50)

p1 = E2(9)
print("1" * 50)
print(p1.__dict__)
print("2" * 50)
print(type(p1))
print("3" * 50)
print(type(p1).__dict__)
print("4" * 50)
print("5" * 50)
print(p1.a)

# 1. 内置方法__getattr__
# 如果你在obj的类里定义了__getattr__方法，当我们使用正常的属性访问都找不到属性时，会调用这个__getattr__方法，
# __getattr__内置方法是用于在查找不到属性时的调用。

"""
class Foo:
    name = 'foo'
    value = 'value'
 
    def __init__(self, name):
        self.name = name
 
    def __getattr__(self, item):
        print('__getattr__ method called!')
        return 'non attr'
 
 
if __name__ == '__main__':
    foo = Foo('doo')
    # 会正常访问实例属性，而不是类的属性
    print(foo.name)
    # 因为实例没有value属性，会访问到类属性
    print(Foo.value)
    # 实例和类都没有password属性，会访问定义的__getattr__方法
    print(foo.password)
    
# 输出：
# doo
# value
# __getattr__ method called!

"""
# 2. 内置方法__getattribute__
#我们之前所说的查找方式为默认的Python为我们设置的方式，而当我们在类的内部定义了__getattribute__方法，就会打破原有属性查找方式，
# 在obj.value查找属性时，Python会无条件调用__getattribute__方法。
"""
class Foo:
    def __init__(self, name):
        self.name = name
 
    def __getattribute__(self, item):
        print('__getattribute__ method called!')
        return 'attribute'
 
 
if __name__ == '__main__':
    foo = Foo('doo')
    # 实例foo有name的属性，但是不会访问到，会直接调用__getattribute__方法
    print(foo.name)
 
# 输出：
# __getattribute__ method called!
# attribute

"""
# 值得注意的是，一般我们很少会重写定义__getattribute__方法，因为类的属性获取方式相当重要，而我们一旦写不好__getattribute__方法，属性获取就会变得非常混乱。

"""**************************************************************************************************************"""

# 3. 内置方法__get_:
#_get__内置方法与上面两个方法不同，它的作用是为了把一个类的实例当做描述符来用，与它一起作用的还有__set__、__delete__方法。
"""
__get__、__set__、__delete__
类定义任何上面三个方法的任意一个，类的实例就会被认为是一个描述符
类同时定义了__get__和 __set__方法，它的实例被认为是一个 数据 描述符
只定义 __get__方法被认为是 非数据 描述符
数据和非数据描述符的区别：如果一个实例的字典有和数据描述符同名的属性，那么数据描述符会被优先使用；实例的字典实现了非数据描述符的定义，那么这个字典中的属性会被优先使用
只读数据描述符：类中同时定义__get__和__set__方法，且在__set__方法中抛出AttributeError异常

"""
# 这三个方法的使用：我们把一个定义了这三个方法的数据描述符当做另一个对象属性来调用时，比如obj.value，其中value的属性值是数据描述符的实例对象，
# 则调用obj.value，会调用value对象的__get__方法，其他两个方法同。