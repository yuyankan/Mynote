# ================show only one image, use Image.open=================
# = Image open: https://www.cnblogs.com/d0main/p/7613296.html =====================

from PIL import Image
from torchvision import transforms as T
import torch
img = Image.open('D:/Exersize/02_DATA LOADER/01_Data loader and '
                 'dataset/Classification-Model-of-RMB-master/02_test_try/01_Image/01/image_ex.png')
print('Image open, PIL shape', img.size)  # no channel dimension:WH (534, 473)
print('Image mode', img.mode)
img_change = T.ToTensor()(img)  # change to Tensor for modifying
print(img_change.size())  # Tensor dimension: CHW: [4, 473,534]: 4 channels:  RGBA

t = torch.tensor([50])  # Image noise value: 50
img_change1 = img_change + t  # add noise modification to image
print(img_change1.shape)
img_plg1 = T.ToPILImage()(img_change1) # change modified image to pil
print(img_plg1.size)  # changed image PIL dimension back to WH
img.show()
img_plg1.show()


