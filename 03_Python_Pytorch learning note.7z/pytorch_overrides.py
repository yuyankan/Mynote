import torch.overrides
#1. Help on module torch.overrides in torch:
"""

Help on module torch.overrides in torch:

NAME
    torch.overrides - Python implementation of ``__torch_function__``

DESCRIPTION
    While most of the torch API and handling for ``__torch_function__`` happens
    at the C++ level, some of the torch API is written in Python so we need
    python-level handling for ``__torch_function__`` overrides as well. The main
    developer-facing functionality in this file are handle_torch_function and
    has_torch_function. See torch/functional.py and test/test_overrides.py
    for usage examples.
    
    Note
    ----
    heavily inspired by NumPy's ``__array_function__`` (see:
    https://github.com/pytorch/pytorch/issues/24015 and
    https://www.numpy.org/neps/nep-0018-array-function-protocol.html
    )
    
    If changing this file in a way that can affect ``__torch_function__`` overhead,
    please report the benchmarks in ``benchmarks/overrides_benchmark``. See the
    instructions in the ``README.md`` in that directory.

FUNCTIONS
    get_ignored_functions() -> Set[Callable]
        Return public functions that cannot be overridden by ``__torch_function__``.
        
        Returns
        -------
        Set[Callable]
            A tuple of functions that are publicly available in the torch API but cannot
            be overridden with ``__torch_function__``. Mostly this is because none of the
            arguments of these functions are tensors or tensor-likes.
        
        Examples
        --------
        >>> torch.Tensor.as_subclass in torch.overrides.get_ignored_functions()
        True
        >>> torch.add in torch.overrides.get_ignored_functions()
        False
    
    get_overridable_functions() -> Dict[Any, List[Callable]]
        List functions that are overridable via __torch_function__
        
        Returns
        -------
        Dict[Any, List[Callable]]
            A dictionary that maps namespaces that contain overridable functions
            to functions in that namespace that can be overridden.
    
    get_testing_overrides() -> Dict[Callable, Callable]
        Return a dict containing dummy overrides for all overridable functions
        
        Returns
        -------
        Dict[Callable, Callable]
            A dictionary that maps overridable functions in the PyTorch API to
            lambda functions that have the same signature as the real function
            and unconditionally return -1. These lambda functions are useful
            for testing API coverage for a type that defines ``__torch_function__``.
        
        Examples
        --------
        >>> import inspect
        >>> my_add = torch.overrides.get_testing_overrides()[torch.add]
        >>> inspect.signature(my_add)
        <Signature (input, other, out=None)>
    
    handle_torch_function(public_api: Callable, relevant_args: Iterable[Any], *args, **kwargs) -> Any
        Implement a function with checks for ``__torch_function__`` overrides.
        
        See torch::autograd::handle_torch_function for the equivalent of this
        function in the C++ implementation.
        
        Arguments
        ---------
        public_api : function
            Function exposed by the public torch API originally called like
            ``public_api(*args, **kwargs)`` on which arguments are now being
            checked.
        relevant_args : iterable
            Iterable of arguments to check for __torch_function__ methods.
        args : tuple
            Arbitrary positional arguments originally passed into ``public_api``.
        kwargs : tuple
            Arbitrary keyword arguments originally passed into ``public_api``.
        
        Returns
        -------
        object
            Result from calling ``implementation`` or an ``__torch_function__``
            method, as appropriate.
        
        Raises
        ------
        TypeError : if no implementation is found.
        
        Example
        -------
        >>> def func(a):
        ...     if type(a) is not torch.Tensor:  # This will make func dispatchable by __torch_function__
        ...         return handle_torch_function(func, (a,), a)
        ...     return a + 0
    
    has_torch_function = _has_torch_function(...)
        Check for __torch_function__ implementations in the elements of an iterable.
        Considers exact ``Tensor`` s and ``Parameter`` s non-dispatchable.
        Arguments
        ---------
        relevant_args : iterable
            Iterable or aguments to check for __torch_function__ methods.
        Returns
        -------
        bool
            True if any of the elements of relevant_args have __torch_function__
            implementations, False otherwise.
        See Also
        ________
        torch.is_tensor_like
            Checks if something is a Tensor-like, including an exact ``Tensor``.
    
    is_tensor_like(inp)
        Returns ``True`` if the passed-in input is a Tensor-like.
        
        Currently, this occurs whenever there's a ``__torch_function__``
        attribute on the type of the input.
        
        Examples
        --------
        A subclass of tensor is generally a Tensor-like.
        
        >>> class SubTensor(torch.Tensor): ...
        >>> is_tensor_like(SubTensor([0]))
        True
        
        Built-in or user types aren't usually Tensor-like.
        
        >>> is_tensor_like(6)
        False
        >>> is_tensor_like(None)
        False
        >>> class NotATensor: ...
        >>> is_tensor_like(NotATensor())
        False
        
        But, they can be made Tensor-like by implementing __torch_function__.
        
        >>> class TensorLike:
        ...     def __torch_function__(self, func, types, args, kwargs):
        ...         return -1
        >>> is_tensor_like(TensorLike())
        True
    
    is_tensor_method_or_property(func: Callable) -> bool
        Returns True if the function passed in is a handler for a
        method or property belonging to ``torch.Tensor``, as passed
        into ``__torch_function__``.
        
        .. note::
           For properties, their ``__get__`` method must be passed in.
        
        This may be needed, in particular, for the following reasons:
        
        1. Methods/properties sometimes don't contain a `__module__` slot.
        2. They require that the first passed-in argument is an instance
           of ``torch.Tensor``.
        
        Examples
        --------
        >>> is_tensor_method_or_property(torch.Tensor.add)
        True
        >>> is_tensor_method_or_property(torch.add)
        False
    
    wrap_torch_function(dispatcher: Callable)
        Wraps a given function with ``__torch_function__`` -related functionality.
        
        Parameters
        ----------
        dispatcher: Callable
            A callable that returns an iterable of Tensor-likes passed into the function.
        
        Note
        ----
        This decorator may reduce the performance of your code. Generally, it's enough to express
        your code as a series of functions that, themselves, support __torch_function__. If you
        find yourself in the rare situation where this is not the case, e.g. if you're wrapping a
        low-level library and you also need it to work for Tensor-likes, then this function is available.
        
        Examples
        --------
        >>> def dispatcher(a): # Must have the same signature as func
        ...     return (a,)
        >>> @torch.overrides.wrap_torch_function(dispatcher)
        >>> def func(a): # This will make func dispatchable by __torch_function__
        ...     return a + 0

DATA
    __all__ = ['get_ignored_functions', 'get_overridable_functions', 'get_...

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\overrides.py



Process finished with exit code 0

"""
