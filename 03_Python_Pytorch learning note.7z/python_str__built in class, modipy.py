"""
特殊方法（特殊成员）：这类方法名字特殊，有特殊用途，会自动调用。
因为特殊又会自动调用，大家也叫做魔术方法（魔法方法）。
特殊方法组成：固定命名-开头结尾都是双下划线。
"""

#  ==== 1、init()：一般用来初始化类的参数，大家习惯叫做[构造方法] =======
"""
使用情况：最多使用，一般的类都会使用
自动调用方式：生成对象（实例化类）的时候自动调用。如：类()
"""


class Person:

    def __init__(self, name, age):
        print('\nexample1: class case perform __init__ method only')

    def test_init(self):
        print('\ncheck: if class case only performe __init__, no if printed this message.')


p1 = Person('jack', 18)  # 返回：执行__init__方法  解读：实例化只执行__init__方法

#  ==== 2、call()：告诉你类对象也可以当作函数来调用，一般叫【函数式调用】 =======
"""
使用情况：使用较少，装饰器用的多。
自动调用方式：将对象当做函数时调用。如：对象()、类()()、装饰器
备注：如果某个类中写了这个方法，类的实例就变成可调用对象，可以像函数那样去调用
"""


class eg2:
    def __init__(self):
        print('\nexample2: class with call , only __init__ method, is called when class -->case')

    def __call__(self, *args, **kwargs):
        print('\nexample2: class case with __call__, method is called when class cases called')


p2 = eg2()  # 返回： 执行__init__方法， 解读： 实例化只执行__init__方法
p2()  # 返回： 执行__call_方法， 解读：对象（当作函数）加小括号，执行__call__方法

"""
note:
在python下实例化一个类对象时一般都会在类名后加上小括号，但如果不带括号会执行什么操作呢？
如果不带括号本质上是给类对象起了一个别名，类似C语言中的typedef关键字，而并不会创建一个实例。
"""

#  ==== 3、get()：类中实现这个方法叫做描述器（set、delete） =======
""" 
使用情况：使用较少，装饰器用的多
自动调用方式：类作为另一个类的属性调用、装饰器
"""


class eg3_1:
    def __init__(self):
        print('\nexample3_1: class get() method use as attributer for other class：\n'
              '            perform __init__ method')

    def __get__(self, instance, owner):
        print('\nexample3_1: class get() method use as attributer for other class: \n'
              '            perform __get__ method')


class D:
    a = eg3_1()


eg3 = D()  # 返回：执行__init__方法， 解读： 实例化只执行__init__方法， 不调用__get__方法
eg31 = eg3.a  # 返回： 执行__get()__方法， 解读： eg3_1类作为 D 类的属性调用时， 执行__get__方法

#  ==== 4、中括号取值 =======
"""
使用情况：基本不用我们自己写
getitem(item)：list[1]、list[1:2:2] 切片或索引 自动执行
setitem(item)：list[1]=‘123’ 赋值 自动执行
delitem(item)：del list[1] 删除值 自动执行
"""

#  ==== 5、可迭代对象 =======
"""
使用情况：基本不用我们自己写
iter()：可迭代对象，for循环时 自动执行
如果类中有__iter__方法，就是可迭代对象
对象.iter()的返回值是迭代器
"""

#  ==== 6、其他很多很多 =======
"""
使用情况：基本不用我们自己写
str() ：print(对象) 自动执行
dict()：类名.dict，自动调用，对象中封装的所有成员通过字典形式返回
doc()：类名.doc 时，自动调用，返回类都注释信息
len()：使用len()函数时，自动调用
add()：使用加号时，自动调用
还有很多很多，是不需要我们自己去写的，我们只知道，这类特殊方法是通过某种方式自动调用执行的就行了。
当然，如果你自己写的某个类中，希望以这样的方式运行，那你就自己去写对应都特殊函数就可以了。
比如咱们打印字符串对象 print(‘hello world’) 返回值是hello world；如果你想在你写都类中，打印类对象时，显示【这是我自己写的类】，
那你就在你自己的类中写一个__str__() 函数
"""


# example7: Python进阶-----通过类的内置方法__str__和__repr__自定制输出（打印）对象时的字符串信息...

class str_personalize:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return '\nExample6: Personalize str printing: \n' \
               '            name is : %s, age is : %d' % (self.name, self.age)


p = str_personalize('Hi', 18)
print(p)
