"""
__class__是***类***的一个***内置属性***，表示类的类型，返回<type ‘type’> ;
也是***类的实例***的属性，表示实例对象的类。
1. __class__的作用为获取对象的类型（如int,string,list等等）
例调用__class__属性时会指向该 '实例对应的类'，然后可以再去调用其它类属性，毕竟类属性还是由类调用会比较好
example：
   self.__classs__.__name__             %23首先用__class__将self实例变量指向类，然后再去调用__name__类属性，通常情况__name__的值为‘__main__’


"""
class B():
    pass
class A(B):
    a =1
    pass

a = A()
print(type(a))
print(a.__class__)
print(a.__dict__)# {} : instance dict: defined in __init__
print(a.__class__.__dict__)# a.__class__ -->class: A(); -->Class per se dict：
print(A.__class__.__name__)
print(B.__class__)