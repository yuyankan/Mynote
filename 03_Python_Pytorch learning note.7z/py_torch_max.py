
# torch.max

"""1. 形式： torch.max(input) → Tensor
返回输入tensor中所有元素的最大值：

a = torch.randn(1, 3)
>>0.4729 -0.2266 -0.2085
torch.max(a) #也可以写
"""

"""2. 形式： torch.max(input, dim, keepdim=False, out=None) -> (Tensor, LongTensor)
按维度dim 返回最大值，并且返回索引。
torch.max(a,0)返回每一列中最大值的那个元素，且返回索引（返回最大元素在这一列的行索引）。返回的最大值和索引各是一个tensor，一起构成元组(Tensor, LongTensor)
"""
"""
a = torch.randn(3,3)
>>
0.2252 -0.0901  0.5663
-0.4694  0.8073  1.3596
 0.1073 -0.7757 -0.8649
 
torch.max(a,0)
>>
(
 0.2252
 0.8073
 1.3596
[torch.FloatTensor of size 3]
, 
 0
 1
 1
[torch.LongTensor of size 3]
)
"""
"""
torch.max(a,1)返回每一行中最大值的那个元素，且返回其索引（返回最大元素在这一行的列索引）:

a = torch.randn(3,3)
>>
0.2252 -0.0901  0.5663
-0.4694  0.8073  1.3596
 0.1073 -0.7757 -0.8649
 
torch.max(a,1)
>>
(
 0.5663
 1.3596
 0.1073
[torch.FloatTensor of size 3]
, 
 2
 2
 0
[torch.LongTensor of size 3]
)
"""
#torch.max()[0]， 只返回最大值的每个数
#troch.max()[1]， 只返回最大值的每个索引
#torch.max()[1].data 只返回variable中的数据部分（去掉Variable containing:）
#torch.max()[1].data.numpy() 把数据转化成numpy ndarry
#torch.max()[1].data.numpy().squeeze() 把数据条目中维度为1 的删除掉
import torch
a = torch.randn(3,3)

b = torch.max(a,0)
print('a: ', a)
print('b =torch.max(a,0):\n', b)
print(b[1].data)
print(b[1].data.numpy())
print(b[1].data.numpy().squeeze())