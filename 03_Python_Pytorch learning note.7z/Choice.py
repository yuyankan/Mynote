""" Choice
choice() 方法返回一个列表，元组或字符串的随机项。

1.语法
以下是 choice() 方法的语法:
import randomrandom.choice( seq )
注意：choice()是不能直接访问的，需要导入 random 模块，然后通过 random 静态对象调用该方法。

2. 参数
seq -- 可以是一个列表，元组或字符串。

3.返回值
返回随机项。
"""
from random import choice
values = [1,2,3,4,5,6,7]
a = choice(values)
print(a)