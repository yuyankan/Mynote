
# Pytorch中Variable变量
"""
1.它是一个可以变化的变量，符合反向传播和参数更新的属性，而tensor不能反向传播

pytorch中的tensor就像鸡蛋，Variable就像装鸡蛋的篮子
"""
import torch
from torch.autograd import Variable # torch 中 Variable 模块
tensor = torch.FloatTensor([[1,2],[3,4]])
# 把鸡蛋放到篮子里, requires_grad是参不参与误差反向传播, 要不要计算梯度，Variable默认不需要被求导的
variable = Variable(tensor, requires_grad=True)

print(tensor)
print("*"*50)
"""RUN :
tensor([[1., 2.],
        [3., 4.]])
"""
print(variable)
""" RUN:
tensor([[1., 2.],
        [3., 4.]], requires_grad=True)
"""

print(type(tensor))# tensor
print(type(variable)) #tensor

#2.Variable计算时，会逐步生成计算图，这个图将所有的计算节点都连接起来，最后进行loss反向传播时，一次性将所有Variable里的梯度计算出来，然而tensor没有这个能力

print(variable.grad) # None
print(tensor.grad) #None

# 3.我们在输出时常将Variable形式的数据进行转换，转换成tensor形式或者numpy形式，因为有时候直接输出Variable形式用不了

print("*"*50)
print("*"*50)
print(variable.data) # 将variable形式转为tensor 形式
"""RUN:
tensor([[1., 2.],
        [3., 4.]])
"""
print("-"*50)
print(variable.data.numpy())#numpy形式
"""
[[1. 2.]
 [3. 4.]]
"""


"""!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"""
# Variable和Tensor合并后，PyTorch的代码要怎么改？
"""https://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80105285?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522163314766416780274120181%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fblog.%2522%257D&request_id=163314766416780274120181&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~first_rank_v2~rank_v29-1-80105285.pc_v2_rank_blog_default&utm_term=python%2C+variable%2C+tensor+%E6%98%AF%E5%90%A6%E5%90%88%E5%B9%B6&spm=1018.2226.3001.4450"""
"""
 PyTorch 0.4.0 版本，该版本有诸多更新和改变，比如支持 Windows，Variable 和 Tensor 合并等等，详细介绍请查看文章《Pytorch 重磅更新》。

本文是一篇迁移指南，将介绍从先前版本迁移到新版本时，所需做出的一些代码更改：
1.Tensors/Variables 合并
2. 支持零维（标量）张量
3. 弃用 volatile 标志
4. dtypes，devices 和 Numpy-style Tensor 创建函数
5.编写一些不依赖设备的代码


--合并 Tensor 和 Variable 类

新版本中，torch.autograd.Variable 和 torch.Tensor 将同属一类。更确切地说，torch.Tensor 能够追踪日志并像旧版本的 Variable 那样运行; Variable 封装仍旧可以像以前一样工作，但返回的对象类型是 torch.Tensor。这意味着你的代码不再需要变量封装器。
"""

#扩展
"""
在PyTorch中计算图的特点总结如下：
autograd根据用户对Variable的操作来构建其计算图。

1. requires_grad
variable默认是不需要被求导的，即requires_grad属性默认为False，如果某一个节点的requires_grad为True，那么所有依赖它的节点requires_grad都为True。

2. volatile
variable的volatile属性默认为False，如果某一个variable的volatile属性被设为True，那么所有依赖它的节点volatile属性都为True。volatile属性为True的节点不会求导，volatile的优先级比requires_grad高。
retain_graph
多次反向传播（多层监督）时，梯度是累加的。一般来说，单次反向传播后，计算图会free掉，也就是反向传播的中间缓存会被清空【这就是动态度的特点】。为进行多次反向传播需指定retain_graph=True来保存这些缓存。
3.  .backward()
反向传播，求解Variable的梯度。放在中间缓存中。
"""