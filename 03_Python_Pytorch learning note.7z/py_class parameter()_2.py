
#1 Parameter 参数类源码
"""
此部分参考《pytorch源码阅读系列之Parameter类》，《通俗的讲解Python中的__new__()方法》

因为Parameter继承于torch.Tensor，没有新的变量和添加函数，只是对一些辅助函数进行了定义

Parameter作为Module类的参数，可以自动的添加到Module类的参数列表中，并且可以使用Module.parameters()提供的迭代器获取到，所以这个类是一切网络结构数据的核心。
"""
import torch
from collections import OrderedDict
from torch import utils

class Parameter(torch.Tensor):
    r"""1. A kind of Tensor that is to be considered a module parameter.

    2. Parameters are: class: '~torch.Tensor' subclasses, that have a very special property when used with:class：
        ’Module's -when they are assigned as Module attributes they are automatically added to the list of its parameters,
        and will appear e.g: in :meth: '~Module.parameters' iterator.
            2.1 assigning a Tensor doesn't have such effect. This is because one might want to cache some temporary state,
                like last hidden state of the RNN, in the model. If there was no such class as: class:'Parameter',
                these temporaries would get registered too.

    3. Args:
        data(Tensor): parameter tensor
        requires_grad(bool, optional)L if the parameter requires gradient. See:ref: 'locally-disable-grad-doc' for
                more details. Default: 'True'
    """
    # 这个方法比__init__方法更先执行，这里就理解为一种初始化方法
    # 详细参考《通俗的讲解Python中的__new__()方法》
    def __new__(cls, data=None, requires_grad=True):
        print("\n1.__new__ is called")
        if data is None:
            data = torch.Tensor([])
        return torch.Tensor._make_subclass(cls, data, requires_grad)

    # 为了方便实用deepcopy方法，对当前数据进行深拷贝，正常的copy方法只拷贝一层，
    # 简单的来说list的list，最好用深拷贝。
    def __deepcopy__(self, memo): #: self: __new__返回的实例
        print("\n2.__deepcopy__ is called")
        if id(self) in memo:
            return memo[id(self)]
        else:
            result = type(self)(self.data.clone(memory_format=torch.preserve_format), self.requires_grad)
            memo[id(self)] = result
            return result

        # 一种可视化方法，给print使用
    def __repr__(self):
        print("\n3. __repr__ is called")
        return "Parameter containing:\n" + super(Parameter, self).__repr__()

    # 用于替代reduce方法
    def __reduce_ex__(self, proto):
        print("4. __reduce_ex__ is called")
        return(torch.utils._requires_grad, (self.data, self.requires_grad, OrderedDict()))

in_feature = 2
out_feature = 5
e1 = Parameter(torch.Tensor(out_feature, in_feature))
print(e1)

print("*"*50)
import torch.nn as nn
class E(nn.Module):
    def __init__(self,fun):
        super(E, self).__init__()
        self.l = nn.Linear(1, 1)
        self.p = fun(torch.Tensor(5, 2)) # fun -Parameer function self defined, will not add self.p auto. to Module named_parameter list.
        #self.p = nn.Parameter(torch.Tensor(5, 2)) # nn.Parameter could


e2 = E(Parameter)
for param in e2.named_parameters():
    print("\n")
    print(param)

print("\n")
print("*"*50)
print("\n")
print(e2.p)




""" 
    __reduce__(self)
    当定义扩展类型时（也就是使用Python的C语言API实现的类型），如果你想pickle它们，你必须告诉Python如何pickle它们。 __reduce__
    被定义之后，
    当对象被Pickle时就会被调用。它要么返回一个代表全局名称的字符串，Pyhton会查找它并pickle，要么返回一个元组。这个元组包含2到5个元素，其中包括：
    一个可调用的对象，用于重建对象时调用；一个参数元素，供那个可调用对象使用；被传递给
    __setstate__
    的状态（可选）；一个产生被pickle的列表元素的迭代器
    （可选）；一个产生被pickle的字典元素的迭代器（可选）；

    __reduce_ex__(self)
    __reduce_ex__
    的存在是为了兼容性。如果它被定义，在pickle时
    __reduce_ex__
    会代替
    __reduce__
    被调用。 __reduce__
    也可以被定义，用于不支持
    __reduce_ex__
    的旧版pickle的API调用。

"""

"""**************************************************************************************************************"""


# deepcopy, while do not use memo in def clone()
"""
def clone(data):
    if isinstance(data,list):
        tmp_data = []
        for x in data:
            xt = clone(x)
            tmp_data.append(xt)
    elif isinstance(data,tuple):
        tmp_data = []
        for x in data:
            xt = clone(x)
            tmp_data.append(xt)
    elif isinstance(data,dict):
        tmp_data = {}
        for k,v in data.items():
            xt = clone(v)
            tmp_data[k] = xt
    elif isinstance(data,set):
        tmp_data = set()
        for x in data:
            xt = clone(x)
            tmp_data.add(xt)
    else:
        tmp_data = data
    return tmp_data
"""