"""
tuple:
x0 = [1, 2, 3]
x1=(1, 2, 3)
x2 = ([1, 1, 1], 2, 3)
-->
1. list -->tuple: id changed
2. tuple: x: all element is imutable: -->tuple(x): id same: id(x) == id(tuple(x) == id(deepcopy(x))
3. tuple2: has element mutalble-->id(tuple(x))= id(x), !=id(([1, 1, 1], 2, 3)) !=id(deepcopy(x))




"""

from copy import deepcopy, copy
x0 = [1, 2, 3]
x1=(1, 2, 3)
x2 = ([1,1,1], 2, 3)

t_c = copy(x1)


t0 = tuple(x0)
t1 = tuple(x1)
t2 = deepcopy(x1)

t11= tuple(x2)
t22 = deepcopy(x2)

print("*"*50)
print("0.shallow copy tuple: x1 = (1, 2, 3), t_c = copy(x1)")
print("\nid(x1):{}\nid(t_c): {}\nt_c is x1:{}".format(id(x1),id(t_c), t_c is x1))

print("*"*50)
print("1.list change to tuple: x0 = [1, 2, 3], x1 = (1, 2, 3), t0 = tuple(x0)")
print("\nid(x0):{}\nid(t0): {}\nid(x1): {}\nt0 is x0:{}\nt0 is x1:{}".format( id(t0), id(x0), id(x1), t0 is x0, t0 is x1))

print("*"*50)
print("2.tuple per se: x1 = (1, 2, 3) ")
print("\nid(x1):{}\nid((1, 2, 3)): {}\nx1 is (1, 2, 3):{}".format( id(x1), id((1, 2, 3)), x1 is (1, 2, 3)))

print("*"*50)
print("3.tuple to tuple: x1 = (1, 2, 3), t1 = tuple(x1) ")
print("\nid(x1):{}\nid((1, 2, 3)): {}\nid(t1):{}\n t1 is x1: {}".format( id(x1), id((1, 2, 3)), id(t1), t1 is x1))
print("*"*50)
print("4.tuple to deepcopoy_tuple: x1 = (1, 2, 3), t2 = deepcopy(x1) ")
print("\nid(x1):{}\nid(t2):{}\n t2 is x1: {}".format( id(x1), id(t2), t2 is x1))
print("*"*50)
print("*"*50)
print("5.tuple with changeable element to tuple: x2 = ([1,1,1], 2, 3), t11= tuple(x2) ")
print("\nid(([1,1,1], 2, 3)):{}\nid(x2):{}\nid(t11):{}\n t11 is x1: {}".format( id(([1,1,1], 2, 3)),id(x2), id(t11), t11 is x2))

print("6.tuple with changeable element to deepcopytuple: x2 = ([1,1,1], 2, 3), t22= deepcopy(x2) ")
print("\nid(([1,1,1], 2, 3)):{}\nid(x2):{}\nid(t22):{}\n t22 is x2: {}".format( id(([1,1,1], 2, 3)),id(x2), id(t22), t22 is x2))
