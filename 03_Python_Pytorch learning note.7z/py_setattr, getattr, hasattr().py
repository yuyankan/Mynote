
# 1.  hasattr(object, name)
# 判断一个对象里面是否有name属性或者name方法，返回BOOL值，有name特性返回True， 否则返回False。
"""
#>>> class test():
...     name="xiaocai"
...     def hello(self):
...             return "HelloWord"
...
#>>> t=test()
#>>> hasattr(t, "name") #判断对象有name属性
True
#>>> hasattr(t, "hello")  #判断对象有hello方法
True
#>>>
"""

# 2. getattr(object, name[,default])
#获取对象object的属性或者方法，如果存在打印出来，如果不存在，打印出默认值，默认值可选。
"""
>>> class test():
...     name="xiaocai"
...     def hello(self):
...             return "HelloWord"
...
>>> t=test()
>>> getattr(t, "name") #获取name属性，存在就打印出来。
'xiaocai'
>>> getattr(t, "hello")  #获取hello方法，存在就打印出方法的内存地址。
<bound method test.hello of <__main__.test instance at 0x0269C878>>
>>> getattr(t, "hello")()  #获取hello方法，后面加括号可以将这个方法运行。
'HelloWord'
>>> getattr(t, "age")  #获取一个不存在的属性。
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: test instance has no attribute 'age'
>>> getattr(t, "age","18")  #若属性不存在，返回一个默认值。
'18'
>>>
"""

# 3. setattr(object, name, values)
# 给对象的属性赋值，若属性不存在，先创建再赋值
"""
>>> class test():
...     name="xiaocai"
...     def hello(self):
...             return "HelloWord"
...
>>> t=test()
>>> hasattr(t, "age")   #判断属性是否存在
False
>>> setattr(t, "age", "18")   #为属相赋值，并没有返回值
>>> hasattr(t, "age")    #属性存在了
True
>>>
"""