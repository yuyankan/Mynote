import torch.nn as nn
from typing import Optional, Set

def named_modules1(self, memo: Optional[Set['Module']] = None,
                      prefix: str = '', remove_duplicate: bool=True):

    print("test, called \n")

    if memo is None:
        memo = set()

    if self not in memo:
        if remove_duplicate:
            memo.add(self)
        yield prefix, self  # 0 ->self??

        for name, module in self._modules.items():
            print("test2")
            print("prefix:", prefix)
            if module is None:
                continue  # 跳出本次循环
            submodule_prefix = prefix + ('.' if prefix else '') + name

            for m in named_modules1(module, memo, submodule_prefix, remove_duplicate):
                yield m

l = nn.Linear(2, 2)
print('\n')
print('l: ',l)

net = nn.Sequential(l, l)
print('\nnet:',net)
net.named_modules1 = named_modules1(net)
print("*"*50)
for idx, m in enumerate(net.named_modules1):
    print(idx, '->', m)
    print('-'*50)

"""

l:  Linear(in_features=2, out_features=2, bias=True)

net: Sequential(
  (0): Linear(in_features=2, out_features=2, bias=True)
  (1): Linear(in_features=2, out_features=2, bias=True)
)
**************************************************
test, called 

0 -> ('', Sequential(
  (0): Linear(in_features=2, out_features=2, bias=True)
  (1): Linear(in_features=2, out_features=2, bias=True)
))
--------------------------------------------------
test2
prefix: 
test, called 

1 -> ('0', Linear(in_features=2, out_features=2, bias=True))
--------------------------------------------------
test2
prefix: 
test, called 

"""
print("="*50)

for i, j in l.named_modules():
    print(i, j)
print("-"*50)
print("net._named_members:", net.named_modules)