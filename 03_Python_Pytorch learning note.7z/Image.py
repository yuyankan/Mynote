import numpy as np
a = np.asarray((3,2))
b= np.asarray([3,2])
c = np.ones([3,2])
d = np.ones((3,2))
print('a: ', a)
print('b: ', b)
print('c: ', c)
print('d: ', d)
for i, value in enumerate(a):
    print('i: ', i)
    print(value)