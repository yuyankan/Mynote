#Pickling
"""
如果你和其他的Python爱好者共事过，很可能你已经听说过Pickling了。Pickling是Python数据结构的序列化过程，当你想存储一个对象稍后再取出读取时，
Pickling会显得十分有用。然而它同样也是担忧和混淆的主要来源。

Pickling是如此的重要，以至于它不仅仅有自己的模块（ pickle ），还有自己的协议和魔法方法。首先，我们先来简要的介绍一下如何pickle已存在的对象类型
"""

#pickling : 小试牛刀
"""
我们一起来pickle吧。假设你有一个字典，你想存储它，稍后再取出来。你可以把它的内容写入一个文件，小心翼翼地确保使用了正确地格式，要把它读取出来，
你可以使用 exec() 或处理文件输入。但是这种方法并不可靠：如果你使用纯文本来存储重要数据，数据很容易以多种方式被破坏或者修改，导致你的程序崩溃，
更糟糕的情况下，还可能在你的计算机上运行恶意代码。因此，我们要pickle它:
"""
"""
import pickle

data = {
    'foo': [1, 2, 3],
    'bar': ('Hello', 'world!'),
    'baz': True
}
jar = open('data.pkl', 'wb')
pickle.dump(data, jar) # 将pickle后的数据写入jar文件
jar.close()

过了几个小时，我们想把它取出来，我们只需要反pickle它:
import pickle

pkl_file = open('data.pkl', 'rb') # 与pickle后的数据连接
data = pickle.load(pkl_file) # 把它加载进一个变量
print data
pkl_file.close()
将会发生什么？正如你期待的，它就是我们之前的 data 
"""
"""
现在，还需要谨慎地说一句： pickle并不完美。Pickle文件很容易因为事故或被故意的破坏掉。Pickling或许比纯文本文件安全一些，
但是依然有可能被用来运行恶意代码。而且它还不支持跨Python版本，所以不要指望分发pickle对象之后所有人都能正确地读取。然而不管怎么样，
它依然是一个强有力的工具，可以用于缓存和其他类型的持久化工作。

"""

#Pickle你的对象
"""
Pickle不仅仅可以用于内建类型，任何遵守pickle协议的类都可以被pickle。Pickle协议有四个可选方法，可以让类自定义它们的行为（这和C语言扩展略有不同，那不在我们的讨论范围之内）

__getinitargs__(self)
如果你想让你的类在反pickle时调用 __init__ ，你可以定义 __getinitargs__(self) ，它会返回一个参数元组，这个元组会传递给 __init__ 。注意，这个方法只能用于旧式类。

__getnewargs__(self)
对新式类来说，你可以通过这个方法改变类在反pickle时传递给 __new__ 的参数。这个方法应该返回一个参数元组。

__getstate__(self)
你可以自定义对象被pickle时被存储的状态，而不使用对象的 __dict__ 属性。 这个状态在对象被反pickle时会被 __setstate__ 使用。

__setstate__(self)
当一个对象被反pickle时，如果定义了 __setstate__ ，对象的状态会传递给这个魔法方法，而不是直接应用到对象的 __dict__ 属性。这个魔法方法和
 __getstate__ 相互依存：当这两个方法都被定义时，你可以在Pickle时使用任何方法保存对象的任何状态。

__reduce__(self)
当定义扩展类型时（也就是使用Python的C语言API实现的类型），如果你想pickle它们，你必须告诉Python如何pickle它们。 __reduce__ 被定义之后，
当对象被Pickle时就会被调用。它要么返回一个代表全局名称的字符串，Pyhton会查找它并pickle，要么返回一个元组。这个元组包含2到5个元素，其中包括：
一个可调用的对象，用于重建对象时调用；一个参数元素，供那个可调用对象使用；被传递给 __setstate__ 的状态（可选）；一个产生被pickle的列表元素的迭代器
（可选）；一个产生被pickle的字典元素的迭代器（可选）；

__reduce_ex__(self)
__reduce_ex__ 的存在是为了兼容性。如果它被定义，在pickle时 __reduce_ex__ 会代替 __reduce__ 被调用。 __reduce__ 也可以被定义，用于不支持
 __reduce_ex__ 的旧版pickle的API调用。

"""
import time
class Slate:
    '''存储一个字符串和一个变更日志的类，每次被pickle都会忘记它当前的值'''

    def __init__(self, value):
        self.value = value
        self.last_change = time.asctime()
        self.history = {}

    def change(self, new_value):
        # 改变当前值，将上一个值记录到历史
        self.history[self.last_change] = self.value
        self.value = new_value
        self.last_change= time.asctime()

    def print_change(self):
        print("Change for Slate object:")
        for k, v in self.history.items():
            print("%s\t %s" %(k, v))

    def __getstate__(self):
        # 故意不返回self.value或self.last_change
        # 我们想在反pickle时得到一个空白的slate
        return self.history

    def __setstate__(self, state):
        self.history = state
        self.value, self.last_change = None, None


