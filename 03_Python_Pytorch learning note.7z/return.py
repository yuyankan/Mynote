
"""
1、return语句就是把执行结果返回到调用的地方，并把程序的控制权一起返回
程序运行到所遇到的第一个return即返回（退出def块），不会再运行第二个return。

"""
print("Example1: return: exit def mode:")
def eg():
    a = [1, 2, 3]
    b = 2
    c = [4, 5, 6]
    for j in c:
       for i in a:
            if i !=b:
                 print(i)
            else:
                print(b)
                return(b) # 跳出2个for, 推出def .



print(eg())

"""  2、但是也并不意味着一个函数体中只能有一个return 语句，"""
print("\nExample2: 一个函数体中有多个return 语句 ")
def eg2(x):
    if x >0:
        return x
    else:
        return 0
print("max(x,0):x=2", eg2(2))

"""3、函数没有 return，默认 return一个 None 对象。
递归函数中没有return 的情况
"""
print("\nExample3: 函数没有 return，默认 return一个 None 对象")
def eg3(a,b):
    if a%b ==0:
        return b

print(eg3(4,3))

"""4、在交互模式下，return的结果会自动打印出来，而作为脚本单独运行时则需要print函数才能显示。
python中什么是交互模式：结尾有3个>符号（>>>）。>>>被叫做Python命令提示符（prompt）
输入一行python代码就会执行该代码，这种模式就叫做Python交互模式（interactive mode）
"""

"""5、默认情况下，遇见 return 函数就会返回给调用者，但是 try，finally情况除外：
try检测范围出错后，跳到except (然后将错误原因输出), 可以加一个finallly，执行最后操作(e.g将文件关闭)。
"""
def eg5():
    try:
        print("\nExample5: try, finally function with return:\n")
        a = 1 + 2 # a = 1 + '2'
        return 'return in try-finally'  # 默认情况下，遇见 return 函数就会返回给调用者，但是 try，finally情况除外：

    except TypeError as reason:
        print("Error 1: reason:", str(reason))
    except NameError as reason:
        print("Error 2: reason:", str(reason))

    finally:
        print('finally function')

print(eg5())

"""6、函数作为返回值返回:（其实是个闭包函数)
"""
print("\nExample6: 函数作为返回值返回 ")
def eg6(*args):
    def eg_6():
        x = 0
        for i in args:
            x = x+i
        return x
    return eg_6
obj6 = eg6(1, 2, 3, 4)
print(obj6()) # 结果： 10 = 1+2+3+4

"""7、返回一个函数列表：
"""
print("\nExample7: 返回一个函数列表：")
print('0'*50)
def eg7():
    print('test1')
    fs = []
    fs2 = []
    for i in range(1, 4):
        print('test2')
        j = 0
        def f():
            return i*i
        fs.append(f)

        print("fs2", fs2)
        print(fs[i - 1]()) # fs[0]() = f()=1; fs[1]=f()=4-->fs[0]=4
        for j in range(i-1):
            print('test3')
            print(fs[j]())

    return fs

print('2'*50)
print("返回的函数列表：\n", eg7()) # 返回函数列表
print('1'*50)
f1, f2, f3 = eg7()
print("返回的函数列表detail: f1, f2, f3 = eg7():")
print("f1(): ",f1())
print("f2(): ",f2())
print("f3(): ",f3())

"""8、返回一个函数值列表：
"""
print("\nExample8: 返回一个函数值列表：")
def eg8():
    fs = []

    for i in range(1, 4):
        def f():
            return i*i
        fs.append(f())  # change from f to f()


    return fs

print("返回的函数列表：\n", eg8()) # 返回函数列表
f1, f2, f3 = eg8()
print("返回的函数列表detail: f1, f2, f3 = eg8():")
print("f1(): ",f1) # change from f1() to f1
print("f2(): ",f2)
print("f3(): ",f3)