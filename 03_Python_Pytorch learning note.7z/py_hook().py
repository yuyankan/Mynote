
 # 什么是钩子
"""
钩子函数，顾名思义，就是把我们自己实现的hook函数在某一时刻挂接到目标挂载点上。
1. hook函数，就是我们自己实现的函数，函数类型与挂载点匹配（返回值，参数列表）
2. 挂接，也就是hook或者叫注册（register）,使得hook函数对目标可用
3. 目标挂载点，也就是挂我们hook函数的地方（我们想在这个目标点实现我们自己的功能）

hook的概念在windows的消息响应机制里面体现的尤为明显。可能我们大家有写过windows桌面相关的程序（像MFC），里面有各种消息监听响应机制。
比如，要监听鼠标左键是否按下这个事件，我们要去实现一个onLeftKeyDown（）之类的方法，该方法可以称为钩子函数。同时，我们还要去注册钩子函数，
MFC中是通过一组宏来实现的。这样当鼠标左键按下后，就能调到我们定义的方法了。

 """

# 为什么需要钩子
"""
左键按下方法具体的逻辑是由框架自身去实现，还是由我们用户（调用者）去实现呢？显然应该由我们自己去实现。要提供通用的框架能力，框架自身去实现该方法功能，
是没有意义的，所以框架给提供一个挂载的point，把具体逻辑的实现交给用户就好了，灵活可用。
"""

# 钩子使用:
# hook是一个编程机制，与语言无关。这里给个python的简单例子，帮助理解：

import time
class LazyPerson():
    def __init__(self, name):
        self.name = name
        self.watch_tv_func = None
        self.have_dinner_func = None

    def get_up(self):
        print("%s get up at: %s" % (self.name, time.time()))

    def register_tv_hook(self, watch_tv_func):
        self.watch_tv_func = watch_tv_func


    def enjoy_a_lazy_day(self):
        #get up
        print("\n")
        self.get_up()
        time.sleep(3)
        #watch tv
        #che the watch_tv_func(hooked or unhooked)
        # hooked
        if self.watch_tv_func is not None:
            self.watch_tv_func(self.name) # is a function

        #unhooked
        else:
            print('no tv to watch')

def watch_daydayup(name):
    print("%s: The program-----daydayup----is funny!!!" % name)

if __name__ == '__main__':
    lazy_Tom = LazyPerson('Tom')
    #register hook:
    lazy_Tom.register_tv_hook(watch_daydayup)
    # enjoy a day:
    lazy_Tom.enjoy_a_lazy_day()


