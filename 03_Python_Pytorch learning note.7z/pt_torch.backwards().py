
# 损失函数
"""
一个损失函数包括两个输入（预测值和实际值），然后返回这两个值的距离。
在nn package里面有不同的损失函数。一个简单的损失函数是：nn.MSELoss，它返回的是均方差，即每一个分量相减的平方累计最后除分量的个数。
"""
import torch.nn as nn
import torch
l1 = nn.Linear(2,3)
l2 = nn.Linear(3,10)
input = torch.ones((1,2), requires_grad=True)
net = nn.Sequential(l1, l2)
output = net(input)
target = torch.arange(1, 11)  # a dummy target, for example
target = target.view(1, -1)  # make it the same shape as output
criterion = nn.MSELoss()

loss = criterion(output, target)
print("\nloss:",loss)

""" tensor(38.2002)
如果你沿着loss的反向，用.grad_fn属性查看，你会得到如下的计算图：

input -> conv2d -> relu -> maxpool2d -> conv2d -> relu -> maxpool2d
      -> view -> linear -> relu -> linear -> relu -> linear
      -> MSELoss
      -> loss
"""

#所以，当你调用loss.backward()时，在整个计算图都会进行微分，所有requires_grad=True的张量的.grad属性都会累加。

#为了更好的理解它，列出很少的几步：
print("\nloss.grad_fn:",loss.grad_fn)
print("\nloss.grad_fn.next_functions:",loss.grad_fn.next_functions)
print("\nloss.grad_fn.next_functions[0][0].next_functions:", loss.grad_fn.next_functions[0][0].next_functions)
"""

<MseLossBackward object at 0x7f170cbe37d0>
((<AddmmBackward object at 0x7f170cbe3790>, 0L),)
((<ExpandBackward object at 0x7f170cbe3790>, 0L), (<ReluBackward object at 0x7f170cbe3810>, 0L), 
(<TBackward object at 0x7f170cbe3850>, 0L))
"""



# 反向传播
# 为了反向传播误差我们所要做的就只是调用loss.backward()。也需要清除已经存在的梯度，不然梯度会和已经存在的梯度进行累计。
#我们调用loss.backward()，看下conv1‘s的bias的梯度在反向传播前后的变化。
"""
net.zero_grad()
print('conv1.bias.grad before backward')
print(net.conv1.bias.grad)
 
loss.backward()
 
print('conv1.bias.grad after backward')
print(net.conv1.bias.grad)
"""