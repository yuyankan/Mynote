"""test: builtins and __builtins__ == different in different file"""

import python_builtins
import python_builtins_3_add_new
hello()
# new added builtin function 'hello()'in 'python_builtin_3' could use in any mode with this file' python_builtin_3'

""" RUN result:

current working mode:
__name__:    python_builtins
**************************************************

check if  builtins ==/ is __builtins__:
builtins == __builtins__:  False
 __builtins__ is builtins:  False
**************************************************

check id of   builtins & __builtins__:
id (__builtins__):  2102789151360
id (builtins)     : 2102789139248
**************************************************

check if  __builtins__ is builtins.__dict :
__builtins__ is builtins.__dict__: True

"""