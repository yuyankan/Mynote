"""
try检测范围出错后，跳到except (然后将错误原因输出), 可以加一个finallly，执行最后操作(e.g将文件关闭)。
"""
def eg():
    try:
        print("\n1. try, finally function with return")
        a = 1 + '1'
        return 'return in try-finally'  # 默认情况下，遇见 return 函数就会返回给调用者，但是 try，finally情况除外：
    except TypeError as reason:
        print("\n2.Error 1: reason:", str(reason))
    except NameError as reason:
        print("\n3.Error 2: reason:", str(reason))

    finally:
        print('\n4.finally function')

print(eg())
