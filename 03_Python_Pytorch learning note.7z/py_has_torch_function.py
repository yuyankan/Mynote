"""
import torch
import torch.nn.functional
help(torch.nn.functional)-->get below:
"""

"""

 has_torch_function = _has_torch_function(...)
        Check for __torch_function__ implementations in the elements of an iterable.
        Considers exact ``Tensor`` s and ``Parameter`` s non-dispatchable.
        Arguments
        ---------
        relevant_args : iterable
            Iterable or aguments to check for __torch_function__ methods.
        Returns
        -------
        bool
            True if any of the elements of relevant_args have __torch_function__
            implementations, False otherwise.
        See Also
        ________
        torch.is_tensor_like
            Checks if something is a Tensor-like, including an exact ``Tensor``.

    has_torch_function_unary = _has_torch_function_unary(...)
        Special case of `has_torch_function` for single inputs.
        Instead of:
          `has_torch_function((t,))`
        call:
          `has_torch_function_unary(t)`
        which skips unnecessary packing and unpacking work.

    has_torch_function_variadic = _has_torch_function_variadic(...)
        Special case of `has_torch_function` that skips tuple creation.

        This uses the METH_FASTCALL protocol introduced in Python 3.7; for 3.6
        and before it has roughly equivilent performance compared to
        `has_torch_function`.

        Instead of:
          `has_torch_function((a, b))`
        call:
          `has_torch_function_variadic(a, b)`
        which skips unnecessary packing and unpacking work.
"""