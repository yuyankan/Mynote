"""函数参数
*args: 允许函数接收多个参数，函数体内args类型为tuple
**kwargs: 允许函数接收多个关键字参数，函数体内kwargs为字典

调用函数
*: 调用函数时，*用在tuple变量之前作为函数参数，可将tuple/list 转化为多个参数传入函数
**: 调用函数时，**用在字典变量之前作为函数参数，可将字典 转化为多个关键字参数传入函数
"""

""" ===expliain how *, **, *args ** kwargs work ======"""


def add_function(a, b, c, d):
    print('{} +{} + {} + {} = {}'.format(a, b, c, d, a + b + c + d))


def person(name=None, age=10, name2=None, age2=1):
    print("Person name: {}; age: {};name2: {}; age2: {};".format(name, age, name2, age2))


def show_params(first, second, *args, **kwargs):
    """
    show how parameters work
    Args:
        first:
        second:
        *args: accept any number argument
        **kwargs: accept any number key-value argument
    Returns:
    """
    print("first param is {}".format(first))
    print("second param is {}".format(second))
    print("args is a tuple {}".format(args))
    print("kwargs is a dictionary {}".format(kwargs))

    # 调用函数时， ** 把字典转为多个关键字参数传入函数
    person(**kwargs)
    for key, value in kwargs.items():  # """visit dictionary"""
        print(key, value)

    # 调用函数时，*可以展开tuple为多个参数传入函数，所以len(tuple)应该等于函数参数个数，否则会报错
    add_function(*args)


if __name__ == '__main__':
    show_params(1, 2, 3, 4, 5, 6, name="Hi", age=25, name2="Hi", age2=25)

"""NoneType 是一类特别的类型，该类型只能有一个值 None，而且该值几乎没有任何可以做的操作。那其作用是什么呢？由于每个变量一定要有一个值，
    必须指向一个对象，在我们不知道其应该取什么值时就可以让其等于 None。
    请看下面的例子：
    >>> a = None
    >>> b = None
    >>> id(a) # 所有值为None的对象的地址相同，执行同一个对象
    4368575992
    >>> id(b)
    4368575992
    >>> a is b
    True"""
