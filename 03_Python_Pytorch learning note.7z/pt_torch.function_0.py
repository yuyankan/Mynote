from torch.autograd.function import FunctionMeta as F
import torch._autograd_functions
# help(torch._autograd_functions)

#1. Function理解
""" 
Pytorch是利用Variable(Now change to combined in Tensor)与Function来构建计算图的。回顾下Variable，Variable就像是计算图中的节点，保存计算结果（包括前向传播的激活值，反向传播的梯度），
而Function就像计算图中的边，实现Variable的计算，并输出新的Variable。
简单来说Function就是针对Variable的运算，Function与Variable构成了pytorch的自动求导机制

2. Function与Module差异与应用场景
Function与Module都可以对pytorch进行自定义拓展，使其满足网络的需求，但这两者还是有十分重要的不同：

Function一般只定义一个操作，因为其无法保存参数（如果需要这些参数参与到backward的计算当中，则可以通过saved_for_backward来保存参数），
因此适用于激活函数、pooling等操作；Module是保存了参数，因此适合于定义一层，如线性层，卷积层，也适用于定义一个网络
Function需要定义三个方法：init, forward, backward（需要自己写求导公式）；Module：只需定义__init__和forward，而backward的计算由自动求导机制构成
可以不严谨的认为，Module是由一系列Function组成，因此其在forward的过程中，Function和Variable组成了计算图，
在backward时，只需调用Function的backward就得到结果，因此Module不需要再定义backward。下面会有用Module将Function包装起来的例子
Module不仅包括了Function，还包括了对应的参数，以及其他函数与变量，这是Function所不具备的

"""

# Help on class Function
"""
Help on class Function in module torch.autograd.function:

class Function(torch._C._FunctionBase, _ContextMethodMixin, _HookMixin)
 |  Function(*args, **kwargs)
 |
 |  Records operation history and defines formulas for differentiating ops.
 |
 |  See the Note on extending the autograd engine for more details on how to use
 |  this class: https://pytorch.org/docs/stable/notes/extending.html#extending-torch-autograd
 |
 |  Every operation performed on :class:`Tensor` s creates a new function
 |  object, that performs the computation, and records that it happened.
 |  The history is retained in the form of a DAG of functions, with edges
 |  denoting data dependencies (``input <- output``). Then, when backward is
 |  called, the graph is processed in the topological ordering, by calling
 |  :func:`backward` methods of each :class:`Function` object, and passing
 |  returned gradients on to next :class:`Function` s.
 |
 |  Normally, the only way users interact with functions is by creating
 |  subclasses and defining new operations. This is a recommended way of
 |  extending torch.autograd.
 |
 |  Examples::
 |
 |      >>> class Exp(Function):
 |      >>>
 |      >>>     @staticmethod
 |      >>>     def forward(ctx, i):
 |      >>>         result = i.exp()
 |      >>>         ctx.save_for_backward(result)
 |      >>>         return result
 |      >>>
 |      >>>     @staticmethod
 |      >>>     def backward(ctx, grad_output):
 |      >>>         result, = ctx.saved_tensors
 |      >>>         return grad_output * result
 |      >>>
 |      >>> #Use it by calling the apply method:
 |      >>> output = Exp.apply(input)
 |
 |  Method resolution order:
 |      Function
 |      torch._C._FunctionBase
 |      _ContextMethodMixin
 |      _HookMixin
 |      builtins.object
 |
 |  Methods defined here:
 |
 |  __call__(self, *args, **kwargs)
 |      Call self as a function.
 |
 |  __init__(self, *args, **kwargs)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |
 |  backward(ctx: Any, *grad_outputs: Any) -> Any
 |      Defines a formula for differentiating the operation.
 |
 |      This function is to be overridden by all subclasses.
 |
 |      It must accept a context :attr:`ctx` as the first argument, followed by
 |      as many outputs as the :func:`forward` returned (None will be passed in
 |      for non tensor outputs of the forward function),
 |      and it should return as many tensors, as there were inputs to
 |      :func:`forward`. Each argument is the gradient w.r.t the given output,
 |      and each returned value should be the gradient w.r.t. the
 |      corresponding input. If an input is not a Tensor or is a Tensor not
 |      requiring grads, you can just pass None as a gradient for that input.
 |
 |      The context can be used to retrieve tensors saved during the forward
 |      pass. It also has an attribute :attr:`ctx.needs_input_grad` as a tuple
 |      of booleans representing whether each input needs gradient. E.g.,
 |      :func:`backward` will have ``ctx.needs_input_grad[0] = True`` if the
 |      first input to :func:`forward` needs gradient computated w.r.t. the
 |      output.
 |
 |  forward(ctx: Any, *args: Any, **kwargs: Any) -> Any
 |      Performs the operation.
 |
 |      This function is to be overridden by all subclasses.
 |
 |      It must accept a context ctx as the first argument, followed by any
 |      number of arguments (tensors or other types).
 |
 |      The context can be used to store arbitrary data that can be then
 |      retrieved during the backward pass.
 |
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |
 |  __dict__
 |      dictionary for instance variables (if defined)
 |
 |  __weakref__
 |      list of weak references to the object (if defined)
 |
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |
 |  is_traceable = False
 |
 |  ----------------------------------------------------------------------
 |  Methods inherited from torch._C._FunctionBase:
 |
 |  name(...)
 |
 |  register_hook(...)
 |
 |  ----------------------------------------------------------------------
 |  Class methods inherited from torch._C._FunctionBase:
 |
 |  apply(...) from torch.autograd.function.FunctionMeta
 |
 |  ----------------------------------------------------------------------
 |  Static methods inherited from torch._C._FunctionBase:
 |
 |  __new__(*args, **kwargs) from builtins.type
 |      Create and return a new object.  See help(type) for accurate signature.
 |
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from torch._C._FunctionBase:
 |
 |  dirty_tensors
 |
 |  materialize_grads
 |
 |  metadata
 |
 |  needs_input_grad
 |
 |  next_functions
 |
 |  non_differentiable
 |
 |  requires_grad
 |
 |  saved_tensors
 |
 |  saved_variables
 |
 |  to_save
 |
 |  ----------------------------------------------------------------------
 |  Methods inherited from _ContextMethodMixin:
 |
 |  mark_dirty(self, *args)
 |      Marks given tensors as modified in an in-place operation.
 |
 |      **This should be called at most once, only from inside the**
 |      :func:`forward` **method, and all arguments should be inputs.**
 |
 |      Every tensor that's been modified in-place in a call to :func:`forward`
 |      should be given to this function, to ensure correctness of our checks.
 |      It doesn't matter whether the function is called before or after
 |      modification.
 |
 |  mark_non_differentiable(self, *args)
 |      Marks outputs as non-differentiable.
 |
 |      **This should be called at most once, only from inside the**
 |      :func:`forward` **method, and all arguments should be outputs.**
 |
 |      This will mark outputs as not requiring gradients, increasing the
 |      efficiency of backward computation. You still need to accept a gradient
 |      for each output in :meth:`~Function.backward`, but it's always going to
 |      be a zero tensor with the same shape as the shape of a corresponding
 |      output.
 |
 |      This is used e.g. for indices returned from a max :class:`Function`.
 |
 |  mark_shared_storage(self, *pairs)
 |
 |  save_for_backward(self, *tensors)
 |      Saves given tensors for a future call to :func:`~Function.backward`.
 |
 |      **This should be called at most once, and only from inside the**
 |      :func:`forward` **method.**
 |
 |      Later, saved tensors can be accessed through the :attr:`saved_tensors`
 |      attribute. Before returning them to the user, a check is made to ensure
 |      they weren't used in any in-place operation that modified their content.
 |
 |      Arguments can also be ``None``.
 |
 |  set_materialize_grads(self, value)
 |      Sets whether to materialize output grad tensors. Default is true.
 |
 |      **This should be called only from inside the** :func:`forward` **method**
 |
 |      If true, undefined output grad tensors will be expanded to tensors full
 |      of zeros prior to calling the :func:`backward` method.



"""