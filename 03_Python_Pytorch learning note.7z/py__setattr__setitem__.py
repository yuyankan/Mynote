"""
在类中对属性进行赋值操作时，python会自动调用__setattr__()函数，来实现对属性的赋值。但是重写__setattr__()函数时要注意防止无限递归的情况出现，
一般解决办法有两种，一是用通过super()调用__setatrr__()函数，二是利用字典操作对相应键直接赋值。
"""

"""
(1)__setattr__(self, item, value):
会拦截所有属性的的赋值语句，如果定义了这个方法，在给属性变量赋值时会调用__setattr__(self, item, value)方法，执行self.__dict__[key] = value。
当在__setattr__(self, item, value)方法内对属性进行赋值时，不可使用self.name = value,因为他会再次调用__setattr__(self, item, value)方法形成无限循环，
最后导致堆栈溢出异常。应该通过对属性字典做索引运算来赋值任何实例属性，也就是使用self.__dict__[‘name’] = value.

(2)__setitem__(self, key, value):
同setattr方法类似，会拦截所有属性的赋值语句，区别在于如果将对象当作字典操作，设置键值对时会触发该方法，
同样在__setitem__(self, key, value)方法内对属性进行赋值时，也不能使用self.name = value，而应该使用self.__dict__[‘name’] = value.

例子
"""
class Student():
    def __setattr__(self, key, value):
        print('1.__setattr__ is called')
        self.__dict__[key] = value # will call __setitem__

    def __setitem__(self, key, value):
        print('2. __setitem__ is called.')
        self.__dict__[key] = value

s = Student()
s.age = 1 #1.__setattr__ is called
s['name'] = 'test' # 2. __setitem__ is called. -->s.name='test'
print(s.__dict__)


print('*'*50)


""" 利用字典操作对相应键直接赋值 """
print("1. 利用字典操作对相应键直接赋值")
class E1():
    def __init__(self, base=0, height=0):
        print("\n1. intro.__init__")
        self.base = base
        self.height = height

    def __setattr__(self, name, value): # self.base = base 这一赋值为setattr 的self.
        print("\n2. into. __setattr__")
        print("name: {}\nvalue: {}".format(name, value))
        if name == "equilateral":
            self.base = value
            self.height =3* value
        else:
            print("\n3. intro__dict__")
            self.__dict__[name] = value # 利用字典进行操作。

    def Area(self):
        return self.base*self.height

a1 = E1(5, 6)
print(a1.Area())
print(a1.__dict__)# {'base': 5, 'height': 6}

"""利用super()调用__setattr__()函数。。"""
print("\n2. 利用super()调用__setattr__()函数")
class E2():
    def __init__(self, base=0, height=0):
        print("\n1. intro.__init__")
        self.base = base
        self.height = height

    def __setattr__(self, name, value): # self.base = base 这一赋值为setattr 的self.
        print("\n2. into. __setattr__")
        print("name: {}\nvalue: {}".format(name, value))
        if name == "equilateral":
            self.base = value
            self.height =3* value
        else:
            print("\n3. intro__dict__")
            super().__setattr__( name, value) # 利用super()进行操作。 or object.__setattr__(self, name, value)-three arguments/
            # super().__setattr__(name, value)-two arguments

    def Area(self):
        return self.base*self.height

a2 = E2(7, 8)
print(a2.Area())
print(a2.__dict__)# {'base': 5, 'height': 6