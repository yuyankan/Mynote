"""

python报错：TypeError:   missing 1 required positional argument: 'self'

问题：

class test:
    def test01(self):
        pass

if __name__ == "__main__":
    test.test01()
--------------------------------------

如上执行，会报错：TypeError:  test  missing 1 required positional argument: 'self'；

原因：

对象的声明需要括号。而类的声明括号可有可无

定义在自定义类中的方法需要一个默认的self参数。错误提示没有self 就是说明这个类的对象没有创建成功。

修改为：

if __name__ == "__main__":
    test().test01()
------------------------------------------执行成功！

虽然是个小问题，但是写的时候一不注意就容易漏掉括号！

note: 静态方法@classicmethod: 可以不实例化直接调用类函数: test.test01()
class test:

    @classicmethod:
    def test01(self):
        pass

"""