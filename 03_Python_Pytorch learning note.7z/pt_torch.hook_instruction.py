 # 一 正文
"""
自动求导求梯度机制相关的一个参数我们应该都熟悉，requires_grad。
当在定义一个tensor的时候并且将requires_grad设置为True。这个tensor就拥有自动求梯度：
 """
import torch
x1 = torch.rand(5,5) # requires_grad=False by default
y1 = torch.rand(5,5) # requires_grad=False by default
z1 = torch.rand(5,5, requires_grad=True)
a1 = x1 + y1
print(a1.requires_grad) # False
b1 = a1 + z1
print(b1.requires_grad) # True
print(a1.requires_grad)# False
# 这是官方的示例程序，只要有一个tensor的requires_grad设置为True，那么接下来的计算中所有相关的tensor都会支持自动求导求梯度。

"""***********************************************************************"""
# 1. register hook
"""自动求导的机制有个我们需要注意的地方：
自动求导机制中只保存叶子节点，也就是中间变量在计算完成梯度后会自动释放以节省空间，所以下面代码我们在计算过程中只得到了z对x的梯度。
"""
print("*"*50)
print("*"*50)
print("1. register hook\n")
x2 = torch.tensor([1,2], dtype=torch.float32, requires_grad=True)
y2 = x2 * 2
z2 = torch.mean(y2)
print('z2: ',z2)
z2.backward()
print("x2.grad: ",x2.grad) # RUN:  tensor([1., 1.])
#print("y2.grad: ",y2.grad) #RUN: NONE
#print("z2.grad: ",z2.grad)  #RUN: NONE

# 有没有办法可以得到y和z的梯度呢，当然是有的。这就需要我们的hook函数了

"""-----------------------------------------------------------------------"""

#1.1 register hook (hook)[source]这个函数属于torch.tensor类，这个函数在与这个tensor梯度计算的时候就会执行，
# 这个函数的参数hook是一个函数，这个函数应该是以下的形式：
"""
 hook(grad) -> Tensor or None。grad是这个tensor的梯度，该函数返回grad，我们可以改变这个hook函数的返回值，但是不能改变其参数。
 """
print("*"*50)
print("1. register hook\n")
x3 = torch.tensor([1,2], dtype=torch.float32, requires_grad=True)
y3 = x3 * 2
print("y3.requires_grad: ", y3.requires_grad)# True
print(y3.register_hook(print)) #<torch.utils.hooks.RemovableHandle object at 0x0000021C4AFEF670>
t = y3.register_hook(lambda grad: grad*2) # t = hooks.RemovableHandle(print)
# # __getstate__(self): return (self.hooks_dict_ref(), self.id) is called.-->print
z3 = torch.mean(y3)
print('-'*50)
z3.backward()
print('-'*50)

"""RUN:
tensor([0.5000, 0.5000])
tensor([0.5000, 0.5000])
"""
#上面的函数，我们通过对y进行register_hook引入print这个函数 及grad*2: 2个hook，print即是简单的打印，将y相关的grad打印出来，结果我们看到了，
 # 在z.backward()执行的时候，y的hook函数也执行了，打印出了y关于输出z的梯度，也就是之前那段代码中的(0.5,0.5)。!!!

# (1) y3.register_hook(print)
"""
> y3.required grad == True-->
>>self._backward_hooks = OrderedDict()
>>> self.grad_fn (is None) = None
handle = hooks.RemovalbeHandle(self._backward_hooks)<---实例化Remvoalhandle class: __init__() performaed
hanle.hooks_dict_ref = weakref.ref(hooks_dict)= weakref.ref(self._backward_hooks)
hanle.id = RemovableHandle.next_id =0,
        RemovableHandle.next_id += 1 # next_id +1
"""
# (2.)print(y3.register_hook(print)):
"""
-->call： handle.__getstate__(self):   return (self.hooks_dict_ref(), self.id)#-->return print() function; self.id=0

"""
# (3).z.backward() ??how does this goes??
"""

"""

"""
---------------------------------------------------------------------------
def register_hook(self, hook):
    if not self.requires_grad:
        raise RuntimeError("cannot register a hook on a tensor that "
                               "doesn't require gradient")
    if self._backward_hooks is None:
        self._backward_hooks = OrderedDict()
    if self.grad_fn is not None:
        self.grad_fn._register_hook_dict(self)
    handle = hooks.RemovableHandle(self._backward_hooks)
    self._backward_hooks[handle.id] = hook
    return handle
        """
"""
-------------------------------------------------------------------------
class RemovableHandle(object):
    ‘A handle which provides the capability to remove a hook.’

    id: int
    next_id: int = 0

    def __init__(self, hooks_dict: Any) -> None:
        self.hooks_dict_ref = weakref.ref(hooks_dict) # weakreferance of hooks_dict
        self.id = RemovableHandle.next_id # 0,
        RemovableHandle.next_id += 1 # next_id +1

    def remove(self) -> None:
        hooks_dict = self.hooks_dict_ref() # 获取若引用对象: hooks_dict; 引用次数+1
        if hooks_dict is not None and self.id in hooks_dict: # self.id 在实例hooks_dict: 里。
            del hooks_dict[self.id] # -->删除实例hooks_dict 中的self.id 键值对。

    def __getstate__(self):
        return (self.hooks_dict_ref(), self.id)# class return: weakreferance;

    def __setstate__(self, state) -> None:
        if state[0] is None:
            # create a dead reference
            self.hooks_dict_ref = weakref.ref(OrderedDict())
        else:
            self.hooks_dict_ref = weakref.ref(state[0])
        self.id = state[1]
        RemovableHandle.next_id = max(RemovableHandle.next_id, self.id + 1)

    def __enter__(self) -> 'RemovableHandle':
        return self

    def __exit__(self, type: Any, value: Any, tb: Any) -> None: #???退出程序时自动删掉该Hook!!!
        self.remove()
"""