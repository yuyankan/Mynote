"""
copy()与deepcopy()之间的区分必须要涉及到python对于数据的存储方式。

首先直接上结论：

—–我们寻常意义的复制就是深复制，即将被复制对象完全再复制一遍作为独立的新个体单独存在。所以改变原有被复制对象不会对已经复制出来的新对象产生影响。
—–而浅复制并不会产生一个独立的对象单独存在，他只是将原有的数据块打上一个新标签，所以当其中一个标签被改变的时候，数据块就会发生变化，另一个标签也会随之改变。
这就和我们寻常意义上的复制有所不同了。

对于简单的 object，用 shallow copy 和 deep copy 没区别

复杂的 object， 如 list 中套着 list 的情况，shallow copy 中的 子list，并未从原 object 真的「独立」出来。也就是说，
如果你改变原 object 的子 list 中的一个元素，你的 copy 就会跟着一起变。这跟我们直觉上对「复制」的理解不同。

"""
import copy
origin = [1, 2, [3, 4]]  #origin 里边有三个元素：1， 2，[3, 4]
cop1 = copy.copy(origin)
cop2 = copy.deepcopy(origin)
print(cop1 == cop2) # result: True
print(cop1 is cop2) # False
#cop1 和 cop2 看上去相同，但已不再是同一个object
print('id(origin):',id(origin))
print('id(cop1):',id(cop1))
print('id(cop2):',id(cop2))

origin[2][0] = 'hey'
print(origin, cop1, cop2)

"""
可以看到 cop1，也就是 shallow copy 跟着 origin 改变了。而 cop2 ，也就是 deep copy 并没有变。
似乎 deep copy 更加符合我们对「复制」的直觉定义: 一旦复制出来了，就应该是独立的了。如果我们想要的是一个字面意义的「copy」，那就直接用 deep_copy 即可。

"""

"""python的数据存储方式
Python 存储变量的方法跟其他 OOP 语言不同。它与其说是把值赋给变量，不如说是给变量建立了一个到具体值的 reference。
当在 Python 中 a = something 应该理解为给 something 贴上了一个标签 a。当再赋值给 a 的时候，就好象把 a 这个标签从原来的 something 上拿下来，
贴到其他对象上，建立新的 reference。 这就解释了一些 Python 中可能遇到的诡异情况.
"""
a = [1, 2, 3]
b = a
a[:]= [4, 5, 6] # 赋新的值给 a
# a = [4, 5, 6] # --> id(a) change to new one
print(a) # 4, 5, 6
print(b) # 1,2,3
print('1'*50)
"""
首次把 [1, 2, 3] 看成一个物品。a = [1, 2, 3] 就相当于给这个物品上贴上 a 这个标签。而 b = a 就是给这个物品又贴上了一个 b 的标签。
第一种情况：
a = [4, 5, 6] 就相当于把 a 标签从 [1 ,2, 3] 上撕下来，贴到了 [4, 5, 6] 上。
在这个过程中，[1, 2, 3] 这个物品并没有消失。 b 自始至终都好好的贴在 [1, 2, 3] 上，既然这个 reference 也没有改变过。 b 的值自然不变。
"""
a2 = [1, 2, 3]
b2 = a2
a2[0], a2[1], a2[2] = 4, 5, 6
print(a2) # 4, 5, 6
print(b2) # 4, 5, 6

"""第二种情况：

a[0], a[1], a[2] = 4, 5, 6 则是直接改变了 [1, 2, 3] 这个物品本身。把它内部的每一部分都重新改装了一下。内部改装完毕后，[1, 2, 3] 本身变成了 [4, 5, 6]。
而在此过程当中，a 和 b 都没有动，他们还贴在那个物品上。因此自然 a b 的值都变成了 [4, 5, 6]。
"""

"""
copy对于一个复杂对象的子对象并不会完全复制.
什么是复杂对象的子对象呢？就比如序列里的嵌套序列，字典里的嵌套序列等都是复杂对象的子对象。对于子对象，python会把它当作一个公共镜像存储起来，
所有对他的复制都被当成一个引用，所以说当其中一个引用将镜像改变了之后另一个引用使用镜像的时候镜像已经被改变了。

所以说看这里的origin[2]，也就是 [3, 4] 这个 list。

根据 shallow copy 的定义，在 cop1[2] 指向的是同一个 list [3, 4]。那么，如果这里我们改变了这个 list，就会导致 origin 和 cop1 同时改变。
这就是为什么上边 origin[2][0] = “hey!” 之后，cop1 也随之变成了 [1, 2, [‘hey!’, 4]]。

而deepcopy:
deepcopy的时候会将复杂对象的每一层复制一个单独的个体出来。
这时候的 origin[2] 和 cop2[2] 虽然值都等于 [3, 4]，但已经不是同一个 list了。即我们寻常意义上的复制
"""



""" list copy"""
print("\n --------------------------list copy-------------------:")
list1 = [1, 2, 3, 4, 5, 6]
list2 = list1
list3 = list1[1:4]
list4 = list1[:]
list1[2] = 88
print("list1: {}\nlist2= list1: {}\nlist3=list1[1:4]: {}\nlist4= list1[:]: {}".format(list1, list2, list3, list4))
"""python变量名相当于标签名
list2 = list1, 直接赋值，实质上指向的是同一个内存值。任意一个变量(list1 or list2)发生改变，都会影响另外一个。
而list3和list4是通过切片对list1的复制操作，分别指向了新的值。任意改变list3或list4的值，不会影响其他。
"""
print("\n --------------------------list copy-------------------:")
""" array copy"""
import numpy as np
print("\n1. list copy:")
array1 = np.array([1, 2, 3, 4, 5, 6])
array2 = array1
array3 = array1[1:4]
array4 = array1[:]
array5 = array1.copy()
array6 = array1[1:4].copy()

array1[2] = 88 # have to same type as array1 above value
print("\n2. array copy:")
print(" \narray1 = np.array([1, 2, 3, 4, 5, 6]): \n", array1)
print(" \narray2 = array1: \n", array2)
print(" \narray3 = array1[1:4]: \n", array3)
print(" \narray4 = array1[:]: \n", array4)
print(" \narray5 = array1.copy(): \n", array5)
print(" \narray6 = array1[1:4].copy(): \n", array6)

"""
数组切片是原始数组的视图，这意味着数据不会被复制，视图上的任何修改都会被直接反映到源数组上。
array1, array2, array3, array4实际指向同一个内存值，任意修改其中的一个变量，其他变量值都会被修改。
若想要得到的是array切片的一份副本而非视图，就需要显式的进行复制操作函数copy()。

"""


"""
一、copy模块的介绍
1、copy模块
copy模块用于对象的拷贝操作。copy模块非常简单，只有两个api。分别是copy.copy(x)和copy.deepcopy(x)。这两个函数分别返回参数x的浅复制和深复制。该模块只提供了两个主要的方法：

copy.copy：浅复制（Shallow copy）
copy.deepcopy：深复制（Deep copy）
二、copy模块的使用
copy仅拷贝对象本身，而不对其中的子对象进行拷贝，故对子对象进行修改也会随着修改。（例如下面的：[1,2,3, [2,3],4] 其中[2,3] 就是子对象）
deepcopy是真正意义上的复制，即从新开辟一片空间。我们经常说的复制实际上就是deepcopy.（深拷贝之后的对象是不受原对象的影响，无论原对象发生什么修改，深拷贝的对象都不会发生改变）

"""
"""复制引用"""
import copy
a = [1, 2, [3,4]]
b1 = a # 复制引用
b2 = copy.copy(a) # 克隆对象 浅复制策略： 如果想要对目标进行克隆，而不是简单的引用绑定，就需要用到copy模块。使用copy模块可以创建一个与原对象一模一样的新对象。
b3 = copy.deepcopy(a) # 克隆对象： 深复制策略
print("\n: a = [1, 2, 3]:")
print("\n1. 复制引用:")
print("\n1.1 b1 =a : \n", b1)
print("id(b1) == id(a):", id(b1) == id(a))

print("\n2.: 克隆对象：浅复制策略 ")
print("\n2.1: b2 = copy.copy(a): ", b2)
print("2.2:id(b2)==id(a):", id(b2)==id(a))# 浅拷贝, new id for object b2, yet sub-object id same
print("2.3: id(a[0])==id(b2[0]))", id(a[2])==id(b2[2])) # True    浅拷贝，并没有改变子对象的

print("\n3.: 克隆对象：深复制策略 ")
print("\n3.1: b3 = copy.deepcopy(a): ", b3)
print("3.2 id(b3)==id(a):", id(b3)==id(a))
print("3.3: id(a[2])==id(b3[2]))", id(a[2])==id(b3[2])) # True    深拷贝，改变子对象的id
print("3.3: a[0] is b3[0]:", a[0] is b3[0]) # True    深拷贝，并没有改变子对象的id_when sub_object is non-changable
b3[0]='test'
print(b3, a)
print("3.3: id(a[0])==id(b3[0]))", id(a[0])==id(b3[0])) # False   子对象的id_when sub_object is non-changable-->change id, ->new value

"""3. 克隆策略
当对象x里面包含了另外一个对象z，甚至对象z里面包含了对象a、对象b、对象c。情况就变得复杂了。这个时候有两种策略可以选择：
1. 仅仅创建一个新对象y: new id(y)，而y里面的对象z，通过复制引用绑定到同一个对象上。
2. 递归地克隆目标对象及目标对象中包含的其他对象。
这两种策略，就对应了copy模块里面的copy()和deepcopy()。

"""

"""简单的说就是有没有递归调用的区别。

可以看出，深复制更加彻底，可以由里到外创建一个完完全全的新对象而不受原对象影响。但这也会导致一些问题的出现：

对于某些过于复杂的对象，深复制可能会严重拖累程序的运行。某些共享数据并不需要复制，深复制会导致不同对象之间不同步。
当然，deepcopy()函数也使用了一些方法避免以上情况的出现：
1. 维护一个“memo”字典，保存当前复制操作已经复制过的对象。
2. 允许用户自定义克隆策略。
至于选择哪种克隆策略，还是要具体问题具体分析。
"""

"""4. 自定义克隆策略
用户自定义的类允许重写copy和deepcopy函数，这样就可以自定义调用copy模块时的操作，自行调整克隆策略：

import copy

class a():
    # 重写copy函数无需额外参数
    def __copy__(self):
        return "override copy"

    # 重写deepcopy函数需要一个额外参数，字典类型
    def __deepcopy__(self, memo):
        return "override deepcopy"

x = a()
print(copy.copy(x)) # override copy
print(copy.deepcopy(x)) # override deepcopy

"""

"""5. 其他需要注意的地方
copy模块无法复制诸如：type、函数、stack trace、stack frame、file、socket、window、array等类型。调用copy模块复制上述类型的对象会返回原对象或者直接报错。

字典的浅复制可以使用y = x.copy()。而列表可以通过使用切片达到同样的目的y = x[:]
"""

"""
拓展说明：
1、id( )函数的使用
python中会为每个对象分配内存，哪怕他们的值完全相等。id(object)函数是返回对象object在其生命周期内位于内存中的地址，id函数的参数类型是一个对象。

2、is和== 的区别
用is判断两个对象是否相等时，依据就是这个id值。
is与==的区别就是，is是内存中的比较，而==是值的比较
"""