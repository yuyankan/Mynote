import torch
x = torch.Tensor(3,2)
y = x * 2
print(torch._has_compatible_shallow_copy_type(x, y))
#help(torch._has_compatible_shallow_copy_type)
"""
Help on built-in function _has_compatible_shallow_copy_type:
_has_compatible_shallow_copy_type(...)
"""

#torch._has_compatible_shallow_copy_type
"""
# 比较tensor, 及新的tensor_applied based on tesnor, 是否type 兼容， 是-->True: 改变现在tensor 内容为新tensor.
# 但要有来自user 的确认，是否希望in-place change: torch.__future__.get_overwrite_module_params_on_conversion()
                
                If the new tensor (tensor_applied) has compatible tensor type as the existing tensor,
                # the current behavior is to change the tensor in-place using `.data =`,
                # and the future behavior is to overwrite the existing tensor. However,
                # changing the current behavior is a BC-breaking change, and we want it
                # to happen in future releases. So for now we introduce the
                # `torch.__future__.get_overwrite_module_params_on_conversion()`
                # global flag to let the user control whether they want the future
                # behavior of overwriting the existing tensor or not.
                """

