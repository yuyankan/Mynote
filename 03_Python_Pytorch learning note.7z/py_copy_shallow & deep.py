import copy

ele = [4, 5]
mu_list = [1,2, 3, ele]
mu_dic = {1:1, 2:2}

copy_mu_list = copy.copy(mu_list)
deepcopy_mu_list = copy.deepcopy(mu_list)
mu_list[3][0] = 999
if copy_mu_list == [1,2, 3, [999, 5]]:
    print("shallow copy")

if deepcopy_mu_list == [1,2, 3, [4, 5]]:
    print("deep copy")


#内存驻留机制的影响
#注：驻留适用范围：由数字，字符和下划线（_）组成的python标识符以及整数[-5,256]。 驻留时机 ：python中的驻留发生在compile_time,而不是run_time。
"""
>>>a = "Hello_World"
>>>b = "Hello_World"
>>>a is b 
True
>>>a = "Hello World"   # 字符串中出现了非标识符时，不采用驻留，所以a与b不指向同一内存地址
>>>b = "Hello World"
>>>a is b
False
>>>a = -5
>>>b = -5
>>>a is b
True
>>>a = -6
>>>b = -6
>>>a is b
False
>>>a = 256
>>>b = 256
>>>a is b
True
>>>a = 257
>>>b = 257   # 整型的界限是(-5,256)，只有这个范围内才驻留
>>>a is b
False

>>> str1='sten'+'waves'
>>> str2 is 'stenwaves'
True
>>> str3='sten'
>>> str4=str3+'waves'
>>> str4 is 'stenwaves' 
False
"""
print('1'*50)
a = "Hello_World"
b = "Hello_World"
print(a is b) # True
print('1'*50)
a = "Hello World"   # 字符串中出现了非标识符时，不采用驻留，所以a与b不指向同一内存地址
b = "Hello World"

print(a is b) # False
print('2'*50)

a = -5
b = -5
print(a is b)  #True
print('3'*50)
a = -6
b = -6
print(a is b) #False
print('4'*50)

a = 256
b = 256
print(a is b) # True
print('5'*50)

a = 257
b = 257   # 整型的界限是(-5,256)，只有这个范围内才驻留# seems no...
print(a is b) #True
print('5'*50)

str1='sten'+'waves'
print(id(str1), id('stenwaves')) #same
print('6'*50)

str3='sten'
str4 = str3+'waves'

print(id(str4), id('stenwaves')) # different
print(str4)
print('7'*50)
