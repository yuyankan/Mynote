"""
nn.Linear内部调用了torch.nn.Linear (F.Linear)
"""
from torch.overrides import has_torch_function

""" linear()函数的输入可以不是二维的问题
在写代码时，发现F.linear()的输入可以不是二维的，对于不是二维的情况，该函数默认最后一维为输入特征数，废话不多说，看下源码定义：
"""

import torch
#def linear(input1, weight1, bias=None):
#type:#(Tensor, Tensor, Optional[Tensor]) -> Tensor

"""Applies a linear transformation to the incoming data: :math:`y = xA^T + b`.
    Shape:
- Input::math: `(N, *, in \_features)` where `*` means any number of additional dimensions
- Weight::math: `(out\_features, in \_features)`
- Bias::math: `(out\_features)`
- Output::math: `(N, *, out\_features)`
"""
import torch
from torch.overrides import has_torch_function
from torch.overrides import handle_torch_function

def linear(input1, weight1, bias=None):
    ten_ops = (input1, weight1)
    # make sure using torch funciton
    if not torch.jit.is_scripting():
        if any(type(t) is not torch.Tensor for t in ten_ops) and has_torch_function(ten_ops):
            # torch. Tensor 是张量， 默认all element is float, while torch. tensor 根据输入值判断type.
            return handle_torch_function(linear, ten_ops, input1, weight1, bias=bias)
    # make sure using torch function

    if input1.dim()==2 and bias is not None:
        # fused/combined ten_ops is marginally faster????
        ret = torch.addmm(bias, input1, weight1.t()) # torch.t(): 转置
        #--> ret = weight.t * input + bias

    else:
        output = input1.matmul(weight1.t()) # input1 matrix x weight1.t() matrix, matmul used of batch,
        #input1.dim > 2
        if bias is not None:
            output += bias

        ret = output

    return ret








