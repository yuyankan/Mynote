
""" @ lazy_property
这个装饰器的作用和@property类似，不同的是，@property每次调用的时候都会对属性进行重复运算，造成了额外开销，但是@lazy_property
只在第一次调用的时候进行计算，随即调用setattr(obj,name,val)把这个值保存到自己的属性里。

另外一层含义就是这个属性不是随着对象的创建而创建，而是在调用的时候才创建，所以叫做lazy property。

"""
"""
Python 对象的延迟初始化是指，当它第一次被创建时才进行初始化，或者保存第一次创建的结果，然后每次调用的时候直接返回该结果。延迟初始化主要用于提高性能，避免浪费计算，并减少程序的内存需求。
"""

# 1. property:可以将属性的访问转变成方法的调用。
class Circle():
    def __init__(self,radius):
        self.radius = radius

    @property
    def area(self):
        return 3.14*self.radius**2

c = Circle(4)
print(c.radius) # 4
print(c.area) # 50.24
# 可以看到，area虽然是定义成一个方法的形式，但是加上@property后，可以直接执行c.area，当成属性访问。

#现在问题来了，每次调用c.area，都会计算一次，太浪费cpu了，怎样才能只计算一次呢?这就是lazy property。

#lazy property 实现延迟初始化有两种方式，一种是使用python描述符，另一种是使用@property修饰符。

#方式1：使用python描述符
class Lazy1(): # is 描述符 (has any one of these method:__get__, __set__, __del__)
    def __init__(self, func): # self 是谁？？area 属性？-->使用描述符的attr-->Circle类!
        self.func = func

    def __get__(self, instance, cls):# __get__(self, instance, ower)
        # self: 使用描述符的属性 实例
        # instance: 使用描述符属性的 类的实例
        #owner: 使用描述符属性的 类
        val = self.func(instance)
        setattr(instance, self.func.__name__, val) # 给类Circle 实例 增加属性： area;
        return val

class Circle():
    def __init__(self, radius):
        self.radius = radius

    @Lazy1
    def area(self):
        print('evaluate')
        return 3.14 * self.radius**2

#note: 装饰器Lazy1将-->area定义为描述符， 在描述符里给使用描述符的类定义属性
c = Circle(4)
print(c.radius) # 4
print(c.area)  # evaluate ;#50.24
print(c.area) #50.24
print("test*"*20)
print(c.__dict__['area']) #50.24-->描述符将lazy 属性加给实例
print(Circle.__dict__['area']) # <__main__.Lazy1 object at 0x000001A6901B56A0>
d= Circle(4)
print(d.area)# evaluate ;#50.24

"""
结果'evalute'只输出了一次。

在lazy类中，我们定义了get__()方法，所以它是一个描述符。

1. 当我们第一次执行c.area时，python解释器会先从c._dict_中进行查找，没有找到，就从Circle._dict_中进行查找，这时因为area被定义为描述符，所以调用__get方法。

2.在get__()方法中，调用Circle实例c的area()方法计算出结果，并动态给实例添加一个同名属性area，然后将计算出的值赋予给它，相当于设置c.__dict['area']=val。

当我们再次调用c.area时，直接从c.dict中进行查找，这时就会直接返回之前计算好的值了。
"""
print('\n')
print("*"*50)
print("Method2")
#方式2：使用@property修饰符
print('0_0'*20)
def lazy_property(func):
    print('1'*50)
    attr_name = '_lazy_' + func.__name__
    print('attr_name1:',attr_name)

    @property
    def _lazy_property(self):
        print('2' * 50)
        if not hasattr(self, attr_name):
            print('3' * 50)
            setattr(self,attr_name, func(self))
            print('attr_name2:', attr_name)
        print('8' * 50)
        return getattr(self, attr_name)

    print('4' * 50)
    return _lazy_property

class Circle():
    def __init__(self, radius):
        self.radius = radius

    @lazy_property
    def area(self):
        print("evaluate: method2")
        return 3.14*self.radius**2
print('0'*50)
c2 = Circle(6)
print(c2.radius) # 6
print(c2.area)  #evaluate: method2 ;# 113.04
print(c2.area) # 113.04
"""
1rst: lay_property: run others code except @property....
2nd: c2 实例化。。
3rd: c2.area---> go to '_lazy_property' directly..:  register self.attr, then return getarrt()
     to c2.area directly...





"""
# area()前添加@lazy_property相当于运行以下代码：lazy_property(area)
"""
lazy_property()方法返回_lazy_property，_lazy_property又会调用_lazy_property()方法，剩下的操作与方法1类似。
"""