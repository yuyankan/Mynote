#import weakref

# python weakref模块
# 地址：http://docs.python.org/library/weakref.html
"""
对一个对象的弱引用。相对于通常的引用来说，如果一个对象有一个常规的引用，它是不会被垃圾收集器销毁的，但是如果一个对象只剩下一个弱引用，那么它可能被垃圾收集器收回。
并非所有的对象都支持weakref，例如list和dict就不支持，但是文档中介绍了可以通过继承dict来支持weakref。
"""

# 2. weakref模块具有的方法
"""
1. class weakref.ref(object[, callback]) 

    创建一个弱引用对象，object是被引用的对象，callback是回调函数（当被引用对象被删除时的，会调用改函数）。

2.weakref.proxy(object[, callback]) 

   创建一个用弱引用实现的代理对象，参数同上。

3.weakref.getweakrefcount(object) 

   获取对象object关联的弱引用对象数

4.weakref.getweakrefs(object)

   获取object关联的弱引用对象列表

5.class weakref.WeakKeyDictionary([dict]) 

   创建key为弱引用对象的字典

6.class weakref.WeakValueDictionary([dict]) 

   创建value为弱引用对象的字典

7.class weakref.WeakSet([elements]) 

   创建成员为弱引用对象的集合对象


weakref模块具有的属性

1.weakref.ReferenceType  -------- 被引用对象的类型

2.weakref.ProxyType        --------- 被代理对象（不能被调用）的类型

3.weakref.CallableProxyType -- 被代理对象（能被调用）的类型

4.weakref.ProxyTypes      ---------- 所有被代理对象的类型序列

5.exception weakref.ReferenceError 
"""