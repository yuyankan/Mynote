"""
__str__方法其实是在print()对象时调用，所以可以自己定义str字符串显示信息，在该方法return一个字符串，如果不是字符串则报错
print(obj) 等同于-->str(obj) 等同于-->obj.__str__
"""


# Python进阶-----通过类的内置方法__str__和__repr__自定制输出（打印）对象时的字符串信息...

# == example1: 未自定__str__信息 =====
class str1:
    def __init__(self, name, age):
        self.name = name
        self.age = age


eg1 = str1('Hi', 18)
print(eg1)  # <__main__.Foo object at 0x000002EFD3D264A8>  因为没有定制__str__，则按照默认输出


# == example2: 自定__str__信息 =====
class str2:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return '\nExample2: Personalize str printing: \n' \
               '            name is : %s, age is : %d' % (self.name, self.age)


eg2 = str2('Hi', 18)
print(eg2)  # 返回： Personalize str printing， name is Hi, age is 18
s = str(eg2)  # --->eg2.__str__
print(s)  # 返回： Personalize str printing， name is Hi, age is 18

"""
__repr__方法是在控制台直接输出一个对象信息或者print一个对象信息时调用，如果自定了__str__信息，print时默认执行__str__
如果没有自定__str__，则print时执行自定义的__repr__
"""


# == example3: 未自定__str__信息，自定了__repr__ =====
"""  因为没有自定__str__，则执行__repr__ """
class str3:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

    def __repr__(self):
        return '\n example3: personalize __repr__ , not __str__: \n' \
               '             come from repr--->name is : %s, age is: %d' % (self.name, self.age)


eg3 = str3('Hi', 18)
print(eg3)  #来自repr-->name is Hi, age is 18.  因为没有自定__str__，则执行__repr__

# == example4: 自定__str__信息，自定了__repr__ =====
"""  因为自定__str__，, print时不会执行__repr__ """
class str4:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

    def __str__(self):
        return '\n example4: personalize __repr__ & __str__:\n'\
               '             come from str -->name is : %s, age is : %d' % (self.name, self.age)

    def __repr__(self):
        return '\n example4: personalize __repr__ & __str__: \n' \
               '             come from repr -->name is : %s, age is : %d' % (self.name, self.age)


eg4 = str4('Hi', 18)
print(eg4)  #来自str-->名字是Meanwey，年龄是24   因为自定了__str__，则print时不会执行__repr__
