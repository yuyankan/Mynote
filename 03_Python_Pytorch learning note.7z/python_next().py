"""
next(...)
    next(iterator[, default])

    Return the next item from the iterator. If default is given and the iterator
    is exhausted, it is returned instead of raising StopIteration.

"""
#===example===
eg = [1, 2, 3, 'cat']
eg1_generator = iter(eg)  # create generator by ()
print(next(eg1_generator, 'end'))

print(next(eg1_generator, 'end'))
print(next(eg1_generator, 'end'))
print(next(eg1_generator, 'end'))
print(next(eg1_generator, 'end'))
print(next(eg1_generator, 'end'))