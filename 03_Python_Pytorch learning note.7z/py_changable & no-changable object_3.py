# python函数的参数传递
# 由于python规定参数传递都是传递引用，对象赋值是对象的引用，且一切都是对象，所以一切赋值都是引用，也就是传递给函数的是原变量实际所指向的内存空间
# （就把python中函数的参数传递理解成赋值号(=)，即让形参指向实参指向的位置），修改的时候就会根据该引用的指向去修改该内存中的内容，
# 所以按道理说我们在函数内改变了传递过来的参数的值的话，原来外部的变量也应该受到影响。但是上面我们说到了python中有可变类型和不可变类型，这样的话，
# 当传过来的是可变类型(list,dict)时，我们在函数内部修改就会影响函数外部的变量。而传入的是不可变类型时在函数内部修改改变量并不会影响函数外部的变量，
# 因为修改的时候会先复制一份再修改。
"""
下面通过代码证明一下：

def test(a_int, b_list):
    a_int = a_int + 1
    b_list.append('13')
    print('inner a_int:' + str(a_int))
    print('inner b_list:' + str(b_list))

if __name__ == '__main__':
    a_int = 5
    b_list = [10, 11]
    test(a_int, b_list)
    print('outer a_int:' + str(a_int))
    print('outer b_list:' + str(b_list))

运行结果如下:

inner a_int:6

inner b_list:[10, 11, '13']

outer a_int:5

outer b_list:[10, 11, '13']

所以，当函数形参是可变对象（list，dict等）时，要想在函数内部修改改变量时不影响函数外部的变量，可以给函数形参传递可变对象的拷贝，这里有深浅两种拷贝，参见下面的文章

这篇文章看完之后，可以看下面这篇，很有相关性。

NumPy：拷贝和视图: https://blog.csdn.net/xiaohuihui1994/article/details/83274651


"""

def test(a_int, b_list):
    a_int = a_int + 1
    b_list.append('13')
    print('inner a_int:' + str(a_int))
    print('inner b_list:' + str(b_list))

if __name__ == '__main__':
    a_int = 5
    b_list = [10, 11]
    test(a_int, b_list)
    print('outer a_int:' + str(a_int))
    print('outer b_list:' + str(b_list))