""" 概要
Torch Script中的核心数据结构是ScriptModule。 它是Torch的nn.Module的类似物，代表整个模型作为子模块树。 与普通模块一样，
ScriptModule中的每个单独模块都可以包含子模块，参数和方法。 在nn.Modules中，方法是作为Python函数实现的，但在ScriptModules方法中通常实现为
Torch Script函数，这是一个静态类型的Python子集，包含PyTorch的所有内置Tensor操作。 这种差异允许您运行ScriptModules代码而无需Python解释器。

"""

""" 为什么要使用TorchScript对模型进行转换？
a)、TorchScript代码可以在它自己的解释器中调用，它本质上是一个受限的Python解释器。这个解释器不获取全局解释器锁，因此可以在同一个实例上同时处理多个请求。

b)、这种格式允许我们将整个模型保存到磁盘上，并将其加载到另一个环境中，比如用Python以外的语言编写的服务器中

c)、TorchScript提供了一种表示方式，我们可以在其中对代码进行编译器优化，以提供更有效的执行

d)、TorchScript允许我们与许多后端/设备运行时进行交互

"""

""" ScriptModules和Torch Script函数可以通过两种方式创建：
1. Tracing:
使用torch.jit.trace，您可以获取现有模块或python函数，提供示例输入，然后运行该函数，记录在所有张量上执行的操作。 我们将生成的记录转换为Torch 
Script方法，该方法作为ScriptModule的正向方法安装。 该模块还包含原始模块所具有的任何参数。
1、trace方法转换模型
trace方法首先使用输入数据执行一遍模型，并记录下模型执行过程中的参数，并创建一个torch.jit.ScriptModule实例。
"""

""" 1. trace方法转换模型示例 
trace方法首先使用输入数据执行一遍模型，并记录下模型执行过程中的参数，并创建一个torch.jit.ScriptModule实例。"""

print("\nExample1. trace方法转换模型示例:")
import torch
import numpy as np


class eg1(torch.nn.Module):
    def __init__(self):
        super(eg1, self).__init__()
        self.linear = torch.nn.Linear(4, 4)  # in-feature =4, out-feature = 4
        print("1.__init__")

    def forward(self, x, h):
        new_h = torch.tanh(self.linear(x) + h)
        t = "\n2. forward()"  # do not record in trace method.
        print(t)
        return new_h


eg1_c = eg1()  # 实例化，没有参数？？
x = torch.ones(1, 4)
h = torch.ones(1, 4)
x_t = torch.ones(4, 4)
h_t = torch.ones(1, 4)  # broadcasting will be used-batch size 4 here

# 对模型对象 使用trace 方法进行转换
traced_eg1_c = torch.jit.trace(eg1_c, (x, h))  # torch.jit.trace(class case, input)
# check code after traced:
print("check code after traced:", traced_eg1_c.code)  # no print info. any more!!!
# 转换后的模型进行推理
print("转换后的模型traced, 推理：", traced_eg1_c(x_t, h_t))
print("原始模型推理", eg1_c(x_t, h_t))  # sequence: 1.print 2. forward()--->原始模型推理-->result.

"""trace弊端：由于要执行一遍模型，当模型中存在循环或者if语句时，不能覆盖所有的模型代码分支。"""

"""2、Example2: 使用Trace方法转换模型，转换后的模型覆盖if分支：
a)、trace方法的不足之处分析（Module中包含分支语句）
i. 使用Trace方法转换模型，转换后的模型覆盖if分支：
"""

print("\nExample2:使用Trace方法转换模型，转换后的模型覆盖if分支：\n ")


class eg2_d(torch.nn.Module):  # super class have to be torch.nn.Module
    def forward(self, x):
        print("forward test")
        if x.sum() > 0:
            return x
        else:
            return -x


class eg2(torch.nn.Module):
    def __init__(self, dg):
        super(eg2, self).__init__()
        print("1.__init__")
        self.dg = dg

        self.linear = torch.nn.Linear(4, 4)

    def forward(self, x, h):
        print("2.1 forward()")
        new_h = torch.tanh(self.linear(self.dg(x)) + h)
        print("2.2 forward()")
        return new_h


dg = eg2_d()
eg2_c = eg2(dg)  # 实例化without parameter(x,h)??
x2 = torch.ones(3, 4)  # x 是一个3 x 4的全1单位矩阵，所以 x .sum() > 0 必然成立
h2 = torch.ones(3, 4)
# 对模型进行trace转换，trace 方法把eg2_c模型在当前的x和h上执行一遍
# 因为 x .sum() > 0 成立，所以现在MyDecisionGate的forward执行if分支，返回x本身，else分支没有执行
traced_eg2_c = torch.jit.trace(eg2_c, (x2, h2))  # why print "forward test " 3 times???

"""" Result:
1.__init__  # first init
forward test  # dg() called in init
2. forward() # input (x, h), call dg()??why come to def forward(self, x, h) twice????
forward test
2. forward()
forward test
2. forward()
"""
print("2.1: code of judge conditions after traced: traced_eg2_c.dg.code:\n", traced_eg2_c.dg.code)
print("2.2: code of class case use judge conditions after traced: traced_eg2_c.code:\n", traced_eg2_c.code)

""" RUN result:
2.1: code of judge conditions after traced: traced_eg2_c.dg.code:
 def forward(self,
    x: Tensor) -> NoneType:
  return None

2.2: code of class case use judge conditions after traced: traced_eg2_c.code:
 def forward(self,
    x: Tensor,
    h: Tensor) -> Tensor:
  _0 = self.linear
  _1 = (self.dg).forward(x, )
  _2 = torch.tanh(torch.add((_0).forward(x, ), h))
  return _2
"""

# 查看模型推理结果，traced_eg2_c与eg2_c的计算结果相同
print("\n2.3:查看模型推理结果，traced_eg2_c与eg2_c的计算结果相同")
print("traced_eg2_c(x2, h2):\n", traced_eg2_c(x2, h2))
print("\neg2_c(x2, h2):\n")
print(eg2_c(x2, h2))

"""RUN Reuslt
2.3:查看模型推理结果，traced_eg2_c与eg2_c的计算结果相同
traced_eg2_c(x2, h2):
 tensor([[0.5956, 0.8790, 0.9055, 0.9082],
        [0.5956, 0.8790, 0.9055, 0.9082],
        [0.5956, 0.8790, 0.9055, 0.9082]], grad_fn=<TanhBackward>)

eg2_c(x2, h2):

2.1 forward()  # 
forward test #
2.2 forward()  # print(xxx) info. missed in traced moel.!!!
tensor([[0.5956, 0.8790, 0.9055, 0.9082],
        [0.5956, 0.8790, 0.9055, 0.9082],
        [0.5956, 0.8790, 0.9055, 0.9082]], grad_fn=<TanhBackward>)

Process finished with exit code 0

"""
"""结论：对于输入的x和h，代码应该执行到eg_d中forward函数的if分支，trace记录到if分支的操作，trace后的模型输出与原模型一致"""

# """Example3: 使用Trace方法转后覆盖if分支的模型测试else分支："""
print("\nExample3: 使用Trace方法转后覆盖if分支的模型测试else分支：")
"""
# 现在将x乘以-1
# 查看模型推理结果, traced_eg2_c与eg2_c的计算结果不同
# 由于trace方法生成的trace_cell_2对象只记录了MyDecisionGate中forward方法的if分支，丢弃了else分支
"""
print("查看模型推理结果, traced_eg2_c与eg2_c的计算结果不同: (-x2, h2):\n")
print("3.1 traced_eg2_c(x2, h2):\n", traced_eg2_c(-x2, h2))
print("\n3.2 eg2_c(x2, h2):\n")
print(eg2_c(-x2, h2))
"""结论：对于输入的-x和h，代码应该执行到MyDecisionGate中forward函数的else分支，由于trace中记录到的是if分支的操作，
所以trace后的模型对于-x的输出与原模型不一致。"""

# Example 4:  使用Trace方法转换模型，转换后的模型覆盖else分支：
print("Example4: 使用Trace方法转换模型，转换后的模型覆盖else分支：")
traced_eg4_c = torch.jit.trace(eg2_c, (-x2, h2))
print("4.1traced_eg4_c = torch.jit.trace(eg2_c, -x2, h2): traced_eg4_c.dg.code:\n", traced_eg4_c.dg.code)
print("4.2:查看模型推理结果, traced_eg4_c与eg2_c的计算结果相同: (-x2, h2):\n")
print("traced_eg4_c(-x2, h2):\n", traced_eg4_c(-x2, h2))
print("\neg2_c(-x2, h2)):")
print( eg2_c(-x2,h2))

"""
结论：对于输入的-x和h，代码应该执行到MyDecisionGate中forward函数的else分支，重新执行trace方法进行转换，转换后的模型记录到else分支的操作，trace后的模型输出与原模型一致。
总结：”Tracing does exactly what we said it would: run the code, record the operations that happen and construct a ScriptModule that does exactly that”。trace方法只记录执行过程中遇到的操作，另一个分支没有执行到，所以记录不到。所以trace方法不适用于Module中具有分支和循环结构的模型。

"""