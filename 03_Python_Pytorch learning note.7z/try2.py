import numpy as np
b = [3, 4,5]
a = np.array(b)

print(a, b)
print(type(b), type(a))
