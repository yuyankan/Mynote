"""@torch.jit.unused:
help on function unused in module torch._jit_internal:
unused(fn)
This decorator indicates to the compiler that a function or method should be ignored and replaced with the raising
of an exception.This allows you to leave code in your model that is not yet TorchScript compatible and still export
your model.

Example(using `` @ torch.jit.unused` ` on a method)::
"""
import torch
import torch.nn as nn
class MyModule(nn.Module):
    def __init__(self, use_memory_efficient):
        super(MyModule, self).__init__()
        self.use_memory_efficient = use_memory_efficient
        print("1. __init__()")

    @torch.jit.unused  # 模型转换为script model时， 该方法不被编译
    def memory_efficient(self, x):
        import pdb
        pdb.set_trace()
        print("2. @torch.jit.usused")
        return x + 10

    def forward(self, x):
        print("3. forward()")
        # Use not-yet-scriptable memory efficient mode
        if self.use_memory_efficient:
            return self.memory_efficient(x)  # exception raised
        else:
            return x + 10

x1 = False
x = torch.rand(100)
mymodule_1 = MyModule(x1)


m1 = torch.jit.script(mymodule_1, x) # case:--self.use_memory_efficenct = false-->return x+10
#m.save("m.pt")

x2 = True
mymodule_2 = MyModule(x2)
m2 = torch.jit.script(mymodule_2, x)
print(m2.code)
print(m1(x))
print(mymodule_1.memory_efficient(x))


"""
python训练的模型，需要转换为script model:
在这一步官网提供了两种方法：
方法一：Tracing
这种方法操作比较简单，只需要给模型一组输入，走一遍推理网络，然后由torch.ji.trace记录一下路径上的信息并保存即可
缺点是如果模型中存在控制流比如if-else语句，一组输入只能遍历一个分支，这种情况下就没办法完整的把模型信息记录下来。

方法二：Scripting
直接在Torch脚本中编写模型并相应地注释模型，通过torch.jit.script编译模块，将其转换为ScriptModule
上面forward方法会被默认编译，forward中被调用的方法也会按照被调用的顺序被编译

如果想要编译一个forward以外且未被forward调用的方法，可以添加 @torch.jit.export.

如果想要方法不被编译，可使用

@torch.jit.ignore 

或者 @torch.jit.unused
"""


