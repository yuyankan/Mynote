"""1. Raise
是否可以在程序的指定位置手动抛出一个异常？答案是肯定的，Python 允许我们在程序中手动设置异常，使用 raise 语句即可。
你们可能会感到疑惑，即我们从来都是想方设法地让程序正常运行，为什么还要手动设置异常呢？
首先要分清楚程序发生异常和程序执行错误，它们完全是两码事，程序由于错误导致的运行异常，是需要程序员想办法解决的；
但还有一些异常，是程序正常运行的结果，比如用 raise 手动引发的异常。
"""
""" 2. raise 语句的基本语法格式为： raise [exceptionName [(reason)]]
1其中，用 [] 括起来的为可选参数，其作用是指定抛出的异常名称，以及异常信息的相关描述。如果可选参数全部省略，则 raise 会把当前错误原样抛出；
如果仅省略 (reason)，则在抛出异常时，将不附带任何的异常描述信息。

也就是说，raise 语句有如下三种常用的用法：
1.raise：单独一个 raise。
该语句引发当前上下文中捕获的异常（比如在 except 块中），或默认引发 RuntimeError 异常。
2.
raise 异常类名称：raise 后带一个异常类名称，表示引发执行类型的异常。
3.
raise 异常类名称(描述信息)：在引发指定类型的异常的同时，附带异常的描述信息。

显然，每次执行 raise 语句，都只能引发一次执行的异常。

"""

#  ===example1: raise only===
# raise:
"""
Traceback (most recent call last):
  File "D:\Exersize\02_DATA LOADER\01_Data loader and dataset\Classification-Model-of-RMB-master\02_test_try\python_raise
  .py", line 24, in <module>
    raise
RuntimeError: No active exception to reraise
"""
# ***********************************************************************************************************
#  ===example2: raise [exception name]===
# raise ZeroDivisionError
"""
Traceback (most recent call last):
  File "D:\Exersize\02_DATA LOADER\01_Data loader and dataset\Classification-Model-of-RMB-master
  \02_test_try\python_raise.py", line 34, in <module>
    raise ZeroDivisionError
ZeroDivisionError
"""
# ****************************************************************************************
#  ===example3: raise [exception name [(reason)]]===
# raise ZeroDivisionError ('coudl not divide 0')
"""
Traceback (most recent call last):
  File "D:\Exersize\02_DATA LOADER\01_Data loader and dataset\Classification-Model-of-RMB-master
  \02_test_try\python_raise.py", line 43, in <module>
    raise ZeroDivisionError ('coudl not divide 0')
ZeroDivisionError: coudl not divide 0
"""

# ======example4:try, except(else finaly)
"""
我们手动让程序引发异常，很多时候并不是为了让其崩溃。事实上，raise 语句引发的异常通常用 try except（else finally）异常处理结构来捕获并进行处理.
"""
"""
try:
    a = input('input a number')
    if (not a.isdigit()):
        raise ValueError('a has to be a digit')
except ValueError as e:
    print('Error called', repr(e))  # repr()??
    
"""

"""
可以看到，当用户输入的不是数字时，程序会进入 if 判断语句，并执行 raise 引发 ValueError 异常。但由于其位于 try 块中，因为 raise 抛出的异常会被 try 捕获，并由 except 块进行处理。
因此，虽然程序中使用了 raise 语句引发异常，但程序的执行是正常的，手动抛出的异常并不会导致程序崩溃
"""
"""
#  ==example 5: use raise with no parameter ====
try:
    a2 = input('input a digit:')
    if not a2.isdigit():
        raise ZeroDivisionError('a input has to be a digit')
except ZeroDivisionError as e:
    print('Error called: ', repr(e))
    raise
"""
""" RUN:
input a digit:h
Error called:  ZeroDivisionError('a input has to be a digit')
Traceback (most recent call last):
  File "D:\Exersize\02_DATA LOADER\01_Data loader and dataset\Classification-Model-of-RMB-master\02_test_try\python_raise.py", line 75, in <module>
    raise ZeroDivisionError('a input has to be a digit')
ZeroDivisionError: a input has to be a digit
"""

"""
这里重点关注位于 except 块中的 raise，由于在其之前我们已经手动引发了 ValueError 异常，因此这里当再使用 raise 语句时，它会再次引发一次。
"""

# ======example5:try, except(else finaly), raise without parameter====
print('2'*50)
try:
    a5 = input('input a digit: ')
    if not a5.isdigit():
        raise
        # raise without any parameter
except RuntimeError as e:
    print('Error called: ', repr(e))

"""
input a digit: h
Error called:  RuntimeError('No active exception to reraise')
"""
