import typing
#help(typing.NamedTuple)
""" Help on function NamedTuple in module typing:

NamedTuple(typename, fields=None, /, **kwargs)
    Typed version of namedtuple.
    
    Usage in Python versions >= 3.6::
    
        class Employee(NamedTuple):
            name: str
            id: int
    
    This is equivalent to::
    
        Employee = collections.namedtuple('Employee', ['name', 'id'])
    
    The resulting class has an extra __annotations__ attribute, giving a
    dict that maps field names to types.  (The field names are also in
    the _fields attribute, which is part of the namedtuple API.)
    Alternative equivalent keyword syntax is also accepted::
    
        Employee = NamedTuple('Employee', name=str, id=int)
    
    In Python versions <= 3.5 use::
    
        Employee = NamedTuple('Employee', [('name', str), ('id', int)])
"""
from typing import NamedTuple
import collections
# method1
class Employee(NamedTuple):
    name: str
    id: int

# method2:
Employee2 = collections.namedtuple('Employee', ['name', 'id'])

# method3:
Employee3 = NamedTuple('Employee', [('name', str), ('id', int)])

c1 = Employee('y',20)
c2 = Employee2('y',3)
c3 = Employee3('y', 6)
print(c1)
print(c2)
print(c3)