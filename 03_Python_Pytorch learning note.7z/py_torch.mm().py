""" addmm():
在torch/_C/_VariableFunctions.py的有该定义，意义就是实现一下公式:
out = belta x mat + alpha *(mat1 * mat2)
换句话说，就是需要传入5个参数，mat里的每个元素乘以beta，mat1和mat2进行矩阵乘法（左行乘右列）后再乘以alpha，最后将这2个结果加在一起。
"""


#def addmm(self, beta=1, mat, alpha=1, mat1, mat2, out=None):  # real signature unknown; restored from __doc__
"""
    addmm(beta=1, mat, alpha=1, mat1, mat2, out=None) -> Tensor

    Performs a matrix multiplication of the matrices :attr:`mat1` and :attr:`mat2`.
    The matrix :attr:`mat` is added to the final result.

    If :attr:`mat1` is a :math:`(n \times m)` tensor, :attr:`mat2` is a
    :math:`(m \times p)` tensor, then :attr:`mat` must be
    :ref:`broadcastable <broadcasting-semantics>` with a :math:`(n \times p)` tensor
    and :attr:`out` will be a :math:`(n \times p)` tensor.

    :attr:`alpha` and :attr:`beta` are scaling factors on matrix-vector product between
    :attr:`mat1` and :attr`mat2` and the added matrix :attr:`mat` respectively.

    .. math::
        out = \beta\ mat + \alpha\ (mat1_i \mathbin{@} mat2_i)

    For inputs of type `FloatTensor` or `DoubleTensor`, arguments :attr:`beta` and
    :attr:`alpha` must be real numbers, otherwise they should be integers.

    Args:
        beta (Number, optional): multiplier for :attr:`mat` (:math:`\beta`)
        mat (Tensor): matrix to be added
        alpha (Number, optional): multiplier for :math:`mat1 @ mat2` (:math:`\alpha`)
        mat1 (Tensor): the first matrix to be multiplied
        mat2 (Tensor): the second matrix to be multiplied
        out (Tensor, optional): the output tensor

    Example::
"""
""" >>> M = torch.randn(2, 3)
        >>> mat1 = torch.randn(2, 3)
        >>> mat2 = torch.randn(3, 3)
        >>> torch.addmm(M, mat1, mat2)
        tensor([[-4.8716,  1.4671, -1.3746],
                [ 0.7573, -3.9555, -2.8681]])
"""

# 2. torch.mm
"""
torch.mm(mat1, mat2, out=None) → Tensor
torch.matmul(mat1, mat2, out=None) → Tensor
"""
"""
对矩阵mat1和mat2进行相乘。 如果mat1 是一个n×m张量，mat2 是一个 m×p 张量，将会输出一个 n×p 张量out。
参数 ：
mat1 (Tensor) – 第一个相乘矩阵
mat2 (Tensor) – 第二个相乘矩阵
out (Tensor, optional) – 输出张量
"""
import torch
a = torch.ones(2,3)*2
b = torch.randn(3,2)
print(torch.mm(a,b))
print(torch.matmul(a, b))