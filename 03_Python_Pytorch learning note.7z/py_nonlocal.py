#help(nonlocal)

"""
The nonlocal statement
nonlocal_stmt ::=  "nonlocal" identifier ("," identifier)*
The nonlocal statement causes the listed identifiers to refer to previously bound variables in the nearest enclosing scope
 excluding globals. 
 
 This is important because the default behavior for binding is to search the local namespace first. 
 The statement allows encapsulated code to rebind variables outside of the local scope besides the global (module) scope.
Names listed in a nonlocal statement, unlike those listed in a global statement, must refer to pre-existing bindings 
in an enclosing scope (the scope in which a new binding should be created cannot be determined unambiguously).
Names listed in a nonlocal statement must not collide with pre-existing bindings in the local scope.
See also
PEP 3104 - Access to Names in Outer Scopes
The specification for the nonlocal statement.
"""
i = 10
def test():
    print('1'*50)
    i = 0

    def h():
        print('2' * 50)
        j = 1
        #i = 9: #SyntaxError: name 'i' is assigned to before nonlocal declaration
        nonlocal i # 不用在def h()里定义参数
        print(i)
        i +=1
        print(i)

    print('3' * 50)
    i += 1
    print(i)
    print('4' * 50)
    h()# ->i =0, ---->i =1
    print('5' * 50)
    h() # --.i =1--------->i =2

print('6'*50)
a = test()
