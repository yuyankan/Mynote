#  ===== Identity(Module):  模块不改变输入.
# 不区分参数的占位符标识运算符。百度翻译，其实意思就是这个网络层的设计是用于占位的，即不干活，只是有这么一个层，放到残差网络里就是在跳过连接的地方用这个层，显得没有那么空虚！

import torch.nn as nn
from torch import Tensor
import torch


class Identity(nn.Module):
    r"""A placeholder identity operator that is argument-insensitive.

        Args:
            args: any argument (unused)
            kwargs: any keyword argument (unused)

        Examples::

            #>>> m = nn.Identity(54, unused_argument1=0.1, unused_argument2=False)
           # >>> input = torch.randn(128, 20)
            #>>> output = m(input)
           # >>> print(output.size())
           # torch.Size([128, 20])

        """

    def __init__(self, *args, **kwargs):
        super(Identity, self).__init__()

    def forward(self, input: Tensor) -> Tensor:
        return input


identity_try = Identity()
t = torch.tensor(6)
test = identity_try.forward(t)
print(t.item())
