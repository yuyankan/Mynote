
# python Typing模块-类型注解
"""
typing 是python3.5中开始新增的专用于类型注解(type hints)的模块，为python程序提供静态类型检查，如下面的greeting函数规定了参数name的类型是str，返回值的类型也是str。


def greeting(name: str) -> str:
    return 'Hello ' + name

"""
# note: below case: help info. for input type, yet also ok to run if use other type parameter.

#在实践中，该模块常用的类型有 Any, Union, Tuple, Callable, TypeVar,Optional和Generic等

# 注意事项：typing模块虽然已经正式加入到了标准库中，但是如果核心开发者认为有必要的话，api也可能会发生改变，即不保证向后兼容性
def greeting(name: str) -> str:
    return name
a = greeting(1)
print(a)

"""
#
DATA
    Any = typing.Any
        Special type indicating an unconstrained type.

        - Any is compatible with every type.
        - Any assumed to have all methods.
        - All values assumed to be instances of Any.

        Note that all the above statements are true from the point of view of
        static type checkers. At runtime, Any should not be used with instance
        or class checks.
"""
# 6. Any是一种特殊的类型，静态类型检查器视Any与任何类型兼容，任何类型与Any兼容。

from typing import Any
def foo(item: Any) -> int:
    item.bar()

"""
在实际使用中， Any, Union, Tuple, List, Sequence, Mapping, Callable, TypeVar,Optional, Generic等的使用频率比较高，
其中Union、Optional、Sequence、Mapping非常有用，注意掌握。

Union
即并集，所以Union[X, Y] 意思是要么X类型、要么Y类型

Optional
Optional[X]与Union[X, None]，即它默认允许None类型

Sequence
即序列，需要注意的是，List一般用来标注返回值；Sequence、Iterable用来标注参数类型

Mapping
即字典，需要注意的是，Dict一般用来标注返回值；Mapping用来标注参数类型

贴一段类型标注的实例代码，是不是让人一目了然，不需要看具体代码逻辑就知道参数类型以及如何调用呢？

def __init__(
    self,
    X: Optional[Union[np.ndarray, sparse.spmatrix, pd.DataFrame]] = None,
    obs: Optional[Union[pd.DataFrame, Mapping[str, Iterable[Any]]]] = None,
    var: Optional[Union[pd.DataFrame, Mapping[str, Iterable[Any]]]] = None,
    uns: Optional[Mapping[str, Any]] = None,
    obsm: Optional[Union[np.ndarray, Mapping[str, Sequence[Any]]]] = None,
    varm: Optional[Union[np.ndarray, Mapping[str, Sequence[Any]]]] = None,
    layers: Optional[Mapping[str, Union[np.ndarray, sparse.spmatrix]]] = None,
    raw: Optional[Raw] = None,
    dtype: Union[np.dtype, str] = 'float32',
    shape: Optional[Tuple[int, int]] = None,
    filename: Optional[PathLike] = None,
    filemode: Optional[str] = None,
    asview: bool = False,
    *, oidx: Index = None, vidx: Index = None):

类型标注可以使程序的维护性、使用性更高，这一点非常重要；另外，许多IDE配合类型标注可以增强智能提示功能，加快编码速度，提高效率，我们何乐而不为呢？

"""