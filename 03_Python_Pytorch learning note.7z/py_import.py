
#python 杂记
"""
1 导入模块多次和导入一次的效果是一样的

2 若希望模块能像程序一样被执行，可以使用-m切换开关来执行，如python -m progname args (运行带命令行参数args的progname程序)

3 模块真正的用处在于它可以保持自己的作用域

4 告知模块本身是作为程序运行还是导入到其他程序，需要使用__name__变量，被当做程序执行时，__name__的值是__main__,被导入时，值为模块的名字



5 模块存储在文件中，包就是模块所在的目录，为了让python将目录作为包对待，目录必须包含一个__init__.py的文件（模块)

6若将__init__.py作为普通模块导入的话，__init__.py模块的内容就是包的内容。如constants包的__init__.py包括PI=3.14,那么可以像下面这样做：
import constants  print constants.PI



7 非常重要的一个知识点，一定要记住



8 __all__

__all__定义了模块的公有接口

若模块有__all__变量，则__all__代表from 模块 import * 代表什么含义

不在__all__变量中的函数无法通过import *导入，如copy模块中的dispatch_table 不在__all__中，要使用dispatch_table就要通过
from copy import dispatch_table 实现，或先导入copy，再copy.dispatch_table

若模块没有__all__，则import * 默认导入模块中所有不以下划线开头的全局变量

9 想看函数的使用说明，可以打印__doc__，如 print(range.__doc__)

10 找到源码的位置：print copy.__file__

11 sys.argv列表中，脚本的名字为sys.argv[0]

12 利用heapq可以求出前N个最大最小值

import heapq

lyst = [-3, 22, 45, 34, 99, 102, -44]
low3 = heapq.nlargest(3, lyst)
top3 = heapq.nsmallest(3, lyst)
13

为了让特殊字符表现得像普通字符一样，需要对它进行转义

profile模块可用于代码片段效率分析；trace模块可以提供总的分享

cmd 可以编写命令行解释器

14
re.search 寻找匹配的字符，找到了返回true，没找到返回false
re.match 从字符串开头匹配，

=========================

1 open第3个参数控制着文件的缓冲，取值0则表示无缓冲，直接写磁盘；取值1则表示直接写内存，只有flush或close时才写磁盘；大于1时代表换届区大小
（单位是字节），-1（或其他负数）代表使用默认缓冲区大小

2 sys.stdin sys.stdout sys.stderr :它们都是文件，大部分文件对象的方法它们也可以使用（如read)

3 随意读取使用seek：seek(offset,whence),其中offset表示偏移的字节数，whence默认是0，表示从文件开头开始偏移，取值1时表示从当前位置开始偏移，
取值2时表示从文件结尾移动

4 tell返回当前文件的位置

 5 读取大文件的方法：

with open(path,'r') as f:
    for line in f:
        print(line)
print("+++++++++++")
with open(path,'r') as f:
    while True:
        line=f.readline()
        if line:
            print(line)
        else:
            break
print("+++++++++++")
 6 有双下划线的方法是私有方法

7 前面有下划线的名字都不会被带星号的Import语句导入（from module import *)

8 判断一个类是否是另一个类的子类：issubclass

9 在多重继承中，若父类中有相同名字的方法，则先继承的类中的方法会重写后续继承的类中的方法

10 判断方法是否存在：hasattr(Zcy,'haha')

调用方法：getattr(Zcy(),'haha')()

设置方法：

setattr(Zcy,'oo','ouou')
print(Zcy.oo)

def pp():
    print('pp')
setattr(Zcy,'rr',pp)
Zcy.rr()
11



12 自己的异常类要继承自 Exception

13 若想将捕获的异常 传递出去，只需调用不带参数的raise

try:
    print(1/0)
except ZeroDivisionError:
    print("sdf")
    raise
14 捕获多个异常

try:
    print(1/'sdf')
except (ZeroDivisionError,TypeError):
    print("sdf")
15 访问异常对象本是，下面示例中e就是异常对象本身

try:
    ss=1
    print(ss.split(','))
except (ZeroDivisionError,TypeError,AttributeError) as e:
    print(e)
 捕获所有异常用   except Exception as e:

16  调用时间不可知，不建议使用
17 若子类重写了构造方法，那么一定要调用父类的构造方法，否则子类可能不能正确的初始化

18 x[-n] 和 x[ len(x)-n] 是一样的

19


转载于:https://www.cnblogs.com/testzcy/p/11065771.html

相关资源：...进行协程驱动的基于异步的泛型编程的小工具库_Dispatchpython...


"""