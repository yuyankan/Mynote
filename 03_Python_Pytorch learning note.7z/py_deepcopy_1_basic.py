# 3.2: 可变对象
#验证：对下列可变类型进行copy，对比id，结果输出下列语句，得证。
"""
ele = [4, 5]
mu_list = [1, 2, 3, ele]
mu_dic = {1: 1, 2: 2}

if      copy.copy(mu_list) is not mu_list and \
        copy.copy(mu_dic) is not mu_dic and \
        copy.deepcopy(mu_list) is not mu_list and \
        copy.deepcopy(mu_dic) is not mu_dic:
    print('mutable类型变量深浅备份返回新的对象')
"""

# 3.2.1 浅拷贝源码
# 以下就直接添加对应模块的copy方法到copy模块所维护的d中
"""
d[list] = list.copy
d[dict] = dict.copy
d[set] = set.copy
d[bytearray] = bytearray.copy
"""

#3.2.2 深拷贝源码：
from copy import deepcopy

d = _deepcopy_dispatch = {}
"""
d[list] = list.copy
d[dict] = dict.copy
d[set] = set.copy
d[bytearray] = bytearray.copy
"""


def _deepcopy_list(x, memo, deepcopy=deepcopy):
    y = []
    memo[id(x)] = y
    append = y.append # function
    for a in x:
        append(deepcopy(a, memo)) # all element copy to dict meomo(value for key id(x)), also copy to y
    return y # def __deepcopy_list: return copied y , and also memorize in dict memo for the object (x) have been copied, by key : id(x)

d['list'] = _deepcopy_list

"""******************************************************************************************************************"""
def _deepcopy_tuple(x, memo, deecopy=deepcopy):
    y = [deepcopy(a, memo) for a in x] # y is list: []
    # We're not going to put the tuple in the memo, but it's still important we
    # check for it, in case the tuple contains recursive mutable structures.

    try:
        return memo[id(x)] # obect x has been copied
    except KeyError:
        pass


    for k, j in zip(x, y):
        if k is not j:
            y = tuple(y) # why do this check for changeable object x ??
            break
    else:
        y = x  # something wrong with this code??
    return y

d['tuple'] = _deepcopy_tuple

"""******************************************************************************************************************"""
def _deecopy_dict(x, memo, deepcopy=deepcopy):
    y = {}
    memo[id(x)] = y
    for key, value in x.items():
        y[deepcopy(key, memo)] = deepcopy(value, memo) # deepcopy (x,memo) = y= _deepcopy_atomic(x, memo) =x
        # y[key] = value,while for memo[id(x)] = {y[key], y[key] value}
    return y
d['dict'] = _deecopy_dict

"""分析：调用deepcopy进行递归复制可变类型中的元素，返回复制填充完毕后的新y。尤其要注意的是tuple是否包含可变类型，如果不包含就返回x本身，如果包含，就返回新生成的tuple。 """
"""
deepcopy(object, memo):
def deepcopy(x, memo=None, _nil=[]):  # _deepcopy_list() 函数中会循环调用到这个函数
    
    if memo is None:
        memo = {}
 
    d = id(x)
    y = memo.get(d, _nil)
    if y is not _nil:
        return y
 
    cls = type(x) // (->1.这里就是获取被copy的是什么类型的，这里我们是用的list, 所以cls值为：list
 
    copier = _deepcopy_dispatch.get(cls) 
********************************************************************************


# 3.1.2. 不可变类型-深拷贝源码

# 同浅拷贝，获取对应方法并执行
copier = _deepcopy_dispatch.get(cls)
if copier is not None:
    y = copier(x, memo)
"""
"""
def _deepcopy_atomic(x, memo):  # compare with shallow copy' _copy_immutable(x)', have dict 'memo' here.
    return x
# d = _deepcopy_dispatch
"""






