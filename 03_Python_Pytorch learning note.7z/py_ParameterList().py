
#2 ParameterList 参数列表类源码
 # 这个类实际上是将一个Parameter的List转为ParameterList，
# 如下例所示[nn.Parameter(torch.randn(10, 10)) for i in range(10)]类型是List，
# List的每个元素是Parameter，然后这个List作为参数传入这个类构造ParameterList类型。

"""
ParameterList输入一定是一个Parameter的List，其他类型会报错，在注册时候就会提示元素不是Parameter类型:

parms = nn.ParameterList([nn.Parameter(torch.randn(10, 10)) for i in range(10)])
"""

""" ParameterList 源码"""
import torch.nn as nn
import operator
from collections.abc import Iterable
import torch

class ParameterList2(nn.Module):
    def __init__(self, parameters=None): # parameters 是一个python list 类型
        super(ParameterList2, self).__init__()

        # 这里的+=运算是经过重载的，__iadd__定义，可以看出，实际上是调用了extend方法，
        # 将parameters 注册到_parameters中
        print("__init__ is called")

        #print("-"*50)

        if parameters is not None:
            self +=parameters # same: self.extend(parameters):+=--->__iadd__, which use def extend method defined here.

        #print("\n2.self.named_parameters:", self) # parameter 字典： name: value
        #print("1*" * 50)

# 针对非slice的index，判断是否满足取值的条件，并返回对应角标字符串
    def _get_abs_string_index(self, idx):
        idx = operator.index(idx) # 判断输入角标的位置是否为整数

    #这里重载的__len__，返回_parameters的个数
        if not (-len(self)) <= idx < len(self): # 2种访问方法：从左到右：0-->len(self)； 从右到左：-len(self) .... -2, -1)
            raise IndexError ("index{} is out of range".format(idx))
        if idx < 0:#对于负号的问题，就选择倒数的元素
            idx +=len(self)

        return str(idx) # 返回对应的角标字符串

    # 使得这个类可以通过角标访问，比如P[i]这种
    def __getitem__(self, idx):
        if isinstance(idx, slice): # 判断这个角标是否为切片就是P[i:j]这种
            # _parameters是OrderedDict类型，返回值转换为list，
            # __class__表示转换为当前类型，所以，通过切片返回的List仍然是ParameterList类型
            return self.__class__(list(self._parameters.values()[idx]))
        else:
            idx = self._get_abs_string_index(idx)# 检验角标正确性
            return self._parameters[str(idx)]# 返回一个数据，数据类型为Parameter

        # 使得这个类可以通过角标访问，比如P[i] = Q这种，这里面不支持切片复制
    def __setitem__(self, idx, param):
        idx = self._get_abs_string_index(idx)
        return self.register_parameter(str(idx), param)

    # 重载len用法，可以使用len(P)统计list个数
    def __len__(self):
        return len(self._parameters)

    # 重载迭代器算法，可以用于 for i in P这种
    def __iter__(self):
        return iter(self._parameters.values)

    # 重载自加算法，比如P += Q，等价于 P.extend(Q)
    def __iadd__(self, parameters):
        return self.extend(parameters)

    # 列出这个类所有的属性，重载后可以使用dir(P)
    def __dir__(self):
        keys = super(ParameterList2,self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return keys
    # 在list末尾添加一个Parameter
    def append(self, parameter):
        self.register_parameter(str(len(self)), parameter)
        return self
    # 在list末尾添加一个Parameter的list，也可以是ParameterList类型
    def extend(self, parameters):
        print("extend is called")
        if not isinstance(parameters, Iterable):
            raise TypeError("ParameterList.extend should be called with an 'iterable, but got'+ type(parameters).__name__")
        offset = len(self)
        for i, param in enumerate(parameters):
            self.register_parameter(str(offset+i), param)
        return self

    # 可以理解为ParameterList可视化方法，下面给一个调用的例子
    # (0): Parameter containing: [torch.FloatTensor of size 10x10]
    # (1): Parameter containing: [torch.FloatTensor of size 10x10]
    # (2): Parameter containing: [torch.FloatTensor of size 10x10]

    def __repr__(self):
        print("*"*50)
        print("extra_repr is called")
        child_lines = []
        #print("-"*50)
        for k, p in self._parameters.items():
            #print("for loop called:")
            size_str = 'x'.join(str(size) for size in p.size()) #-->size_str: B X C X H X W
            device_str = '' if not p.is_cuda else '(GPU{})'.format(p.get_device)
            parastr = 'Parameter containing: [{} of size {}{}]'.format(torch.typename(p.data), size_str, device_str)
            # torch. typename(p.data)-->torch tensor p element type, e.g: float, integer; p.data: torch p elements
            child_lines.append("("+str(k) + "):" + parastr)
            #print(child_lines)
            #print("-" * 50)
        #print(child_lines)
        tmpstr = '\n'.join(child_lines)
        return tmpstr
print('\n')
print("*"*50)
print("*"*50)
#p3_0 = nn.ParameterList([nn.Parameter(torch.randn(2,3)) for i in range(10)])
p3 = ParameterList2([nn.Parameter(torch.randn(2,3)) for i in range(10)])
print("p3.named_parameters:\n", p3.named_parameters)
print("*"*50)
print("*"*50)
print("p3._parameters:\n", p3._parameters) # _parameters:is the dict for all nn.Moudle parameter
print("*"*50)
print("*"*50)
print("\np3:\n", p3)


#p2 = nn.Parameter(torch.Tensor(3, 3))
#print("p2: ",p2)
#rint("*"*50)





"""
import torch
p = torch.Tensor(2, 3)
size_str = 'x'.join(str(size) for size in p.size())
print(p.size()) # -->torch.size[2, 3]
print(size_str): 2 x 3 

-->
Result: 
"""



# list.extend(seq):
"""

语法
list.extend(seq)
参数
seq -- 元素列表。(例：seq = [1,2,3])
返回值
该方法没有返回值，但会在已存在的列表中添加新的列表内容。
说明
extend() 函数用于在列表末尾一次性追加另一个序列中的多个值（用新列表扩展原来的列表）。
 举个例子：
#列表连接
a = [2,6,8]
b = [7,0,4]
a.extend(b)
print(a)
上述代码输出结果为：[2, 6, 8, 7, 0, 4]--一个新的列表

"""
"""
operator. index(a)
operator. __index__(a)
将a转换为整数数据并返回。等价于a. __index__() 确保a为整数， 否则报错。
"""