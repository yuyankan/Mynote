"""
常规方法合并两个字典，然后修改合并的字典的值，不会使被合并的字典的值发生改变，因为dict3字典中的“x”指向的内存地址是dict3中的。而dict1中的“x”指向的是dict1的内存地址中的
"""

'''

dict1 = {'x': 1, 'y': 2}
dict2 = {'y': 3, 'z': 4}
dict3 = {**dict1, **dict2}
print(f'dict3:-->{dict3}')
dict3['x'] = 10
print(f'dict1:-->{dict1}')
 
print(id(dict1['x']))
print(id(dict3['x']))
=======================================
dict3:-->{'x': 1, 'y': 3, 'z': 4}
dict1:-->{'x': 1, 'y': 2}
1711833200
'''
# 使用ChainMap合并字典，会有不一样的结果
"""
from collections import ChainMap
 
dict4 = ChainMap(dict1, dict2)
print(f'dict4:-->{dict4}')
print(f'dict4:-->{dict(dict4)}')
 
dict1['x'] = 10
print(f'dict1:-->{dict1}')
===========================================
dict4:-->ChainMap({'x': 1, 'y': 2}, {'y': 3, 'z': 4})
dict4:-->{'z': 4, 'y': 2, 'x': 1}
dict1:-->{'x': 10, 'y': 2}
"""

# ChainMap只在逻辑上合并，在内部创建了一个容纳这些字典的列表，使用ChainMap合并字典，并修改x的值，dict1中x的值会发生改变
'''
print(id(dict4['x']))
print(id(dict1['x']))
===============================
1711833488
1711833488
'''
from collections import ChainMap

a={'hi':1, 'test':4}
b={'hi':2, 'hi2':3}
c = ChainMap(a, b)
print(c)
print(set(c))