
"""
Python continue 语句跳出本次循环，而break跳出整个循环。

continue 语句用来告诉Python跳过当前循环的剩余语句，然后继续进行下一轮循环。

continue语句用在while和for循环中。

注意，如果continue语句在try包裹里，并且有finally的话，则finally里的语句即使跳过也一样要执行的
"""
a = 2
while True:
    try:
        if a == 1:
            continue
        print('跳过我！')
    finally:
        print('打印我！')
