
# summary:
"""

2. ParameterLDict:
    ->1.1: __setitem__: called when 给ParameterDict 实例赋值时， e.g:a = nn.ParameterList, a[2] = value-->call ParameterList __setitem__
            more for dict: key-value 赋值。
    ->1.2: __setattr__: 给类/类实例创建 非Parameter 的attr时， 'self.xx= value (not Parameter)' will call setattr.


"""

from torch.nn.modules import Module
from torch.nn import Parameter, ParameterDict
import torch
from typing import Optional, Iterable, overload, TypeVar, Any, Iterator, Union, Mapping, Tuple
from torch import Tensor
import warnings
import operator
from collections import abc as container_abcs
from collections import OrderedDict

T = TypeVar('T', bound=Module)


class ParameterDict1(Module):
    r"""1. Holds parameters in a dictionary.
    2.ParameterDict can be indexed like a regular Python dictionary,  but parameters it contains are properly registered,
        and will be visible by all Module methods.
    3.: class: '~torch.nn.ParameterDict' is an **ordered** dictionary, that respects :
        3.1: * the order of insertion , and
        3.2: * in: meth：’~torch.nn.ParameterDict.update', the order of the merged 'OrderedDict' or another: class:
            '~torch.nn.ParameterDict' (the argument to : meth: '~torch.nn.ParameterDict.update')
    4. Note that: meth: '~torch.nn.ParameterDict.update' with other unordered mapping types (e.g., Pythons's plain 'dict')
            does not preserve the order of the merged mapping.
    Args:
        parameters (iterable, optional): a mapping (dictionary) of (string:: class: '~torch.nn.Parameter') or,
                an iterable of key-value pairs of type (string, : class: '~torch.nn.Parameter')
    Example:
        class MyModule(nn.Module):
            def __init__(self):
                super(MyModule, self).__init__()
                self.params = nn.ParameterDict({
                        'left': nn.Parameter(torch.randn(5, 10)),
                        'right': nn.Parameter(torch.randn(5, 10))
                })

            def forward(self, x, choice):
                x = self.params[choice].mm(x)
                return x
    """
    def __init__(self, parameters: Optional[Mapping[str, 'Parameter']] = None) -> None:
        print("1.: ParameterDict: __init__ is called")
        super(ParameterDict1, self).__init__()
        self._initialized = True
        if parameters is not None:
            self.update(parameters)

    def __setstate__(self, state):
        state['_initialized'] = False
        super(ParameterDict1, self).__setstate__(state)
        self._initialized = True

    def __getitem__(self, key: str) ->Parameter:
        print("1.5: ParameterDict: __getitem__ is called.")
        return self._parameters[key]

    def __setitem__(self, key: str, value: 'Parameter') -> None:
        print("\n1.4: ParameterDict: __setitem__ is called")
        self.register_parameter(key, value)
        print("1.41.: register_parameter:\n" ,self._parameters.keys())

    def __delitem__(self, key: str) ->None:
        del self._parameters[key]

    def __setattr__(self, key: Any, value: Any) ->None:
        print("\n1.1: ParameterDict: __setattr__ is called")
        print("     key->value:           ", key, '->', value)
        if getattr(self, '_initialized', False):
            if not hasattr(self, key) and not isinstance(value, torch.nn.Parameter):
                warnings.warn("Setting attributes on ParameterDict is not supported")
        super(ParameterDict1, self).__setattr__(key, value)

    def __len__(self) -> int:
        return len(self._parameters)

    def __iter__(self) ->Iterator:
        return iter(self._parameters.keys())

    def __contains__(self, key: str) -> bool:
        return key in self._parameters

    def clear(self) ->None:
        """Remove all items from the ParameterDict"""
        self._parameters.clear()

    def pop(self, key: str) -> 'Parameter': # ??not pop the last element in Dict???
        """Remove key from the ParameterDict and return its parameter
        Args:
            key(string): key to pop from the ParameterDict
        """
        v = self[key]
        del self[key]
        return v

    def keys(self) ->Iterable[str]:
        r"""Return an iterable of the parameterDict keys"""
        return self._parameters.keys()

    def items(self) ->Iterable[Tuple[str, 'Parameter']]:
        r"""Return an iterable of the parameterDict key/value pairs"""
        return self._parameters.items()

    def values(self) ->Iterable['Parameter']:
        r"""Return an iterable of the ParameterDict values"""
        return self._parameters.values()

    def update(self, parameters: Mapping[str, 'Parameter']) ->None:
        print("1.2*" *20)
        print("\n1.2: ParameterDict: update() is called:")
        r""" Update the : class: '~torch.nn.ParameterDict' with the key-value pairs from a mapping or an iterable,
                overwriting existing keys.
        ..note::
            If: attr: 'parameters' is an ''OrderedDict'', a: class: '~torch.nn.ParameterDict', or an iterable
                of key-value pairs, the order of new elements in it is preserved.
        Args:
            parameters(iterable): a mapping (dictionary) from string to : class: '~torch.nn.Parameter',
                    or an iterable of key-value pairs of type (string, : class: '~torch.nn.Parameter')
        """
        if not isinstance(parameters, container_abcs.Iterable):
            raise TypeError ("ParameterDict.update should be called with an iterable of key/value paris,"
                             "bug got" + type(parameters).__name__)

        if isinstance(parameters, (OrderedDict, ParameterDict)):
            for key, parameter in parameters.items():
                self[key] = parameter
        elif isinstance(parameters, container_abcs.Mapping):
            print('test'*20)

            for key, parameter in sorted(parameters.items()):
                print("key -> parameter:", key)
                self[key] = parameter # -->__setitem__ is called
                #self['test'] = Parameter(torch.Tensor(2,1))
                print(self.keys())
        else:

            for j, p in enumerate(parameters):
                if not isinstance(p, container_abcs.Iterable): # Iterable: list, tuple, dict are Iterable
                    raise TypeError("ParameterDict update sequence element"
                                    "#" + str(j) + "should be Iterable; is " + type(p).__name__)
                if not len(p) == 2:
                    raise ValueError("ParameterDict update sequence element # " + str(j) + 'has length'
                                     + str(len(p)) + '; 2 is required')
                # parameters as length-2 list too cumberson to type, see ModuleDict.update comment
                self[p[0]] = p[1] # type: ignore[assignment]  ## ???function of '# type: ignore[assignment]' here??
        print("test2"*20)
        print(self)


    def extra_repr(self) ->str:
        print("1.7: ParameterDict: extra_repr() is called.")
        child_lines = []
        for k, p in self._parameters.items():
            size_str = 'x'.join(str(size) for size in p.size())
            device_str = '' if not p.is_cuda else '(GPU {})'.format(p.get_device())
            parastr = 'Parameter containing: [{} of size {} {}]'.format(
                torch.typename(p), size_str, device_str)
            child_lines.append(' (' + k + '): ' + parastr)
            tmpstr = '\n'.join(child_lines)
        return tmpstr

    def __call__(self, input):
        raise RuntimeError('ParameterDict should not be called.')

    def _replicate_for_data_parallel(self):
        warnings.warn('nn.ParameterDict is being used with DataParallel but this is not supported.'
                      'This dict will appear empty for the modules replicated on each GPU except the original one.')
        return super(ParameterDict1, self)._replicate_for_data_parallel()


class MyModule(Module):
    def __init__(self):
        print("0.: Mymodule: __init__ is called")
        super(MyModule, self).__init__()
        self.params = ParameterDict1({
            'left': Parameter(torch.randn(5, 10)),
            'right':Parameter(torch.randn(5, 10))
        })

    def __setattr__(self, name: str, value: Union[Tensor, 'Module']) -> None:
        print("\n0.1: Mymodlue: __setattr__ is called.")
        def remove_from(*dicts_or_sets):
            for d in dicts_or_sets:
                if name in d:
                    if isinstance(d, dict):
                        del d[name]
                    else:
                        d.discard(name)

        params = self.__dict__.get('_parameters')
        if isinstance(value, Parameter):
            if params is None:
                raise AttributeError(
                    "cannot assign parameters before Module.__init__() call")
            remove_from(self.__dict__, self._buffers, self._modules, self._non_persistent_buffers_set)
            self.register_parameter(name, value)
        elif params is not None and name in params:
            if value is not None:
                raise TypeError("cannot assign '{}' as parameter '{}' "
                                "(torch.nn.Parameter or None expected)"
                                .format(torch.typename(value), name))
            self.register_parameter(name, value)
        else:
            modules = self.__dict__.get('_modules')
            if isinstance(value, Module):
                if modules is None:
                    raise AttributeError(
                        "cannot assign module before Module.__init__() call")
                remove_from(self.__dict__, self._parameters, self._buffers, self._non_persistent_buffers_set)
                modules[name] = value
            elif modules is not None and name in modules:
                if value is not None:
                    raise TypeError("cannot assign '{}' as child module '{}' "
                                    "(torch.nn.Module or None expected)"
                                    .format(torch.typename(value), name))
                modules[name] = value
            else:
                buffers = self.__dict__.get('_buffers')
                if buffers is not None and name in buffers:
                    if value is not None and not isinstance(value, torch.Tensor):
                        raise TypeError("cannot assign '{}' as buffer '{}' "
                                        "(torch.Tensor or None expected)"
                                        .format(torch.typename(value), name))
                    buffers[name] = value
                else:
                    object.__setattr__(self, name, value)

a1 = MyModule()
print("1*"*30)
print(a1.params) # ->ParameterDict: extra_repr() is called.
print("2*"*30)
a1.params['TEST'] = Parameter(torch.Tensor(2))
print(a1.params)
print("3*"*30)
#a1.params.test = 'hi' # -->ParameterDict is called, warning: could set attr. to ParameterDict.
print(a1.params._parameters)
