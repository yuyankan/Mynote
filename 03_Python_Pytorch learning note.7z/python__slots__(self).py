""" __slots__ = ()
python中的new-style class要求继承Python中的一个内建类型， 一般继承object，也可以继承list或者dict等其他的内建类型。
在python新式类中，可以定义一个变量__slots__，它的作用是阻止在实例化类时为实例分配dict，

默认情况下每个类都会有一个dict,通过__dict__访问，这个dict维护了这个实例的所有属性
"""


# ====example1: new class without __slots__ =（）==
class base1(object):
    var = 9  # 类变量

    def __init__(self):
        pass


b = base1()
print('\nExample1: new class without __slots__, dic content:\n '
      '                                                     new class.__dict__: ', b.__dict__)
b.x = 'Hi'  # 添加实例变量
b.y = 3  # 添加实例变量
print('                  add new variant class.x = 2, -->:  class.__dict__', b.__dict__)

"""
可见：实例的dict只保持实例的变量，对于类的属性是不保存的，类的属性包括变量和函数。
由于每次实例化一个类都要分配一个新的dict，因此存在空间的浪费，因此有了__slots__。__slots__是一个元组，包括了当前能访问到的属性。
当定义了slots后，slots中定义的变量变成了类的描述符，相当于java，c++中的成员变量声明，
类的实例只能拥有slots中定义的变量，不能再增加新的变量。注意：定义了slots后，就不再有dict.
"""


# ====example2: new class with __slots__ =（）==
class base2(object):
    __slots__ = ('x', 'y')  # put it on the top of class??
    var = 8

    def __init__(self):
        pass


b2 = base2()
b2.x = 'Hi'
b2.y = 2
# b2.z = 'Hi'  # not able to add new variable to class case, as z not in slots defined variants.
"""无法添加slots之外的变量 (AttributeError: 'base2' object has no attribute 'z')"""
# print (b2.__dict__)
""" print b2.__dict__ #定义了__slots__后，就不再有__dict__ (AttributeError: 'base' object has no attribute '__dict__')"""
print('\nExample2: new class with __slots__, no dic any more, \n'
      'only show variants defined in slots: \n'
      '                                     b2.__slots__:', b2.__slots__)

# === example3: new class with __slots__ = (variant ): slots variant name = class variant name ===
"""如果类变量与slots中的变量同名，则该变量被设置为 readonly！！！"""


class base3(object):
    __slots__ = ('v', 'x', 'y')
    # v = 'test' """ error: 'v' in __slots__ conflicts with class variable"""
    variant = 11

    def __init__(self):
        # self.z = 10 """not able to add new variant not in defined in slots"""
        self.x = 10  # will be covered by new variant content: b3.x = 'Hi‘
        pass


b3 = base3()

b3.x = 'Hi'
b3.y = 10
print("Example3: class:  __slot__ = ('variants name') could not same as class variants' name")

"""
Python是一门动态语言，可以在运行过程中，修改实例的属性和增删方法。一般，任何类的实例包含一个字典__dict__,
Python通过这个字典可以将任意属性绑定到实例上。有时候我们只想使用固定的属性，而不想任意绑定属性，
这时候我们可以定义一个属性名称集合，只有在这个集合里的名称才可以绑定。__slots__就是完成这个功能的。
"""


#  === example4: compare new class without __slots__ and with __slots__
class base4_1(object):
    __slots__ = 'x', 'y'

    def printHello(self):
        print('hello 1')


class base4_2(object):
    def printHello(self):
        print('hello 2')


b4_1 = base4_1()
b4_2 = base4_2()

print('Example4: compare new class without __slots__ and with __slots__: b4_1, b4_2 \n')
print('base4_1: attributes list: dir(base4_1):\n ', dir(base4_1))  # #可以看到test_slots类结构里面包含__slots__,x,y
print('base4_2: attributes list: dir(base4_2):\n ', dir(base4_2))  # #test类结构里包含__dict_
print('**************************************')
print('b4_1: attributes list: dir(b4_1):\n ', dir(b4_1))  # 实例结构里面包含__slots__,x,y，不能任意绑定属性
print('b4_2: attributes list: dir(b4_2):\n ', dir(b4_2))  # 实例结构里包含__dict__,可以任意绑定属性
b4_1.x = 2
b4_2.z = 2
print('\n b4_1.x, b4_2.z', b4_1.x, b4_2.z)

""" dir（[object]）函数尝试返回给定对象的有效属性列表。 如果未提供任何参数，则它将返回当前本地范围内的名称列表
If the object contains __dir__() function, then this function will be called. 
This function must return the list of attributes. 
The list of attribute names is sorted in alphabetical order.属性名称列表按字母顺序排序。
"""

# ===Example 5: check class storage: class case with slot and without slots====

"""
默认情况下,Python的新式类和经典类的实例都有一个 dict来存储实例的属性。这在一般情况下还不错，而且非常灵活，
乃至在程序中可以 随意设置新的属性。但是，对一些在”编译”前就知道有几个固定属性的小class来说，这个dict就有点浪费内存了。
当需要创建大量实例的时候，这个问题变得尤为突出。一种解决方法是在 新式类中定义一个__slots__属性。
__slots__声明中包含若干实例变量，并为每个实例预留恰好足够的空间来保存每个变量；这样Python就不会再使用dict，从而节省空间。
【使用memory_profiler模块，memory_profiler模块是在逐行的基础上，测量代码的内存使用率。尽管如此，它可能使得你的代码运行的更慢。使用装饰器@profile来标记哪个函数被跟踪。】

"""
from memory_profiler import profile
print('Example 5: check class storage: class case with slot and without slots\n')
class A(object):
    def __init__(self, x):
        self.x = x

@profile
def main():
    f = [A(523825) for i in range(100000)]
print('1. mem usage for class without slots: f = [A(523825) for i in range(100000):')
if __name__ == '__main__':
    main()

"""
第2列-Mem usage, 表示该行执行后Python解释器的内存使用情况， 第3列Increment 表示该行代码执行前后的内存变化。
在没有定义__slots__属性的情况下，该代码共使用了16.6 MiB内存。
从结果可以看出，内存使用是以MiB为单位衡量的,表示的mebibyte(1MiB = 1.05MB)
"""
# ==== mem usage for class with slots =====

print('\nmem usage for class with slots: f = [A(523825) for i in range(100000):')

class A2(object):
    __slots__ = ('x')
    def __init__(self, x):
        self.x = x

@profile
def main():
    f = [A2(523825) for i in range(100000)]

if __name__ == '__main__':
    main()


"""
可以看到，在定义了__slots__属性的情况下，该代码共使用了5MiB内存，比上面的16MiB节省了很多内存！
综上所述，在确定了 类的属性固定的情况下，可以 使用__slots__来优化内存。
提醒:不要贸然进行这个优化，把它用在所有地方。这种做法不利于代码维护，而且只有生成数以千计的实例的时候才会有明显效果。
"""