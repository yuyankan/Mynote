
#help(nn.Module._named_members)
"""
_named_members(self, get_members_fn, prefix='', recurse=True)
    Helper method for yielding various names + members of modules.
"""

import torch.nn as nn
import torch



def fn(module):
    return module.__dict__.items()

def _named_member1(self, get_members_fn, prefix='', recurse=False):  # recurse: 递归
    r"""Helper method for yielding various names + members of modules."""
    print("_named_member1 is called\n")
    memo = set()
    print("self:\n",self)
    print("1-"*50)
    print("self.named_modules:\n", self.named_modules)
    print("2-" * 50)
    for i, j in self.named_modules():
        print(i, '->',j)
    modules = self.named_modules(prefix=prefix) if recurse else [(prefix, self)]
    print("3-" * 50)

    for module_prefix, module in modules:
        print("module test: ", module)
        members = get_members_fn(module)  # get_member_fn???-->dict
        for k, v in members:
            if v is None or v in memo:
                continue
            memo.add(v)
            name = module_prefix + ('.' if module_prefix else '') + k

            print('name:', name)
            print('v:', v)
            yield name, v

#A._named_member = _named_member1(A, fn, prefix='', recurse=True)

l1 = nn.Linear(3,2)
l2 = nn.Linear(2, 1)
l3 = nn.Linear(3,3)
l4 = nn.Linear(3,3)
net = nn.Sequential(l1, l2)

print("---------------for floop: -----------------")
for i,j in _named_member1(net, lambda module: module.named_parameters()):
    print("*********************test-test*********************")
    print(" {}:->{}:".format(i,j))
    print("-"*50)
