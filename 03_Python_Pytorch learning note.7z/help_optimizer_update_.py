params = param_group['params']
if len(params) != len(
        set(params)):  # len(list) ! = len(set(list)): note set(dict) = (dict.keys.()): 不重复的Key {key1, key2,..}
    warnings.warn("optimizer contains a paraemter group with duplicate parameters;"
                  "in future , this will cause an error;"
                  "see github.com/pytorch/pytorch/issues/40967 for more information")

"""

When we pass a list of parameters or parameter groups to an optimizer, and one parameter appears multiple times we get 
different behaviours, and it is not clear whether this is intended that way:

If the parameter appears twice within one parameter group, everything works. That parameter will get updated twice though.
If the parameter appears in distinct parameter groups, then we get an error.
To Reproduce
import torch
x = torch.zeros((1,), requires_grad=True)
# uncomment one of the following three lines for each of the cases:
# a = torch.optim.SGD(params=[dict(params=[x])], lr=0.1) # baseline
# a = torch.optim.SGD(params=[dict(params=[x, x])], lr=0.1)  # apparently acceptable (?); x is updated twice
# a = torch.optim.SGD(params=[dict(params=x), dict(params=x)], lr=0.1)  # apparently not acceptable
x.sum().backward()
a.step()
print(x)
"""




