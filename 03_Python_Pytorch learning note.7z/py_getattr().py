# getattr() 函数
"""
描述: getattr() 函数用于返回一个对象属性值。

语法: getattr(object, name[, default])

参数:
object – 对象。
name – 字符串，对象属性。
default – 默认返回值，如果不提供该参数，在没有对应属性时，将触发 AttributeError。

返回值: 返回对象属性值。

***************************************************************************************
参数说明：

object：对象的实例
name：字符串，对象的成员函数的名字或者成员变量
default：当对象中没有该属性时，返回的默认值
异常：当没有该属性并且没有默认的返回值时，抛出"AttrbuteError"
"""
# Example
class E():
    bar = 1

a = E()
print(getattr(a, 'bar')) #  获取属性 bar 值:1
#print(getattr(a, 'bar2')) #  获取属性 bar2 值:属性 bar2 不存在，触发异常
print(getattr(a, 'bar2', 'hi')) #  属性 bar2 不存在，但设置了默认值
print(getattr(a, 'bar2'))

#异常安全的写法：
#主要有两种异常
#1. AttributeError: 对象中没有该属性:
"""
try:
    func = getattr(obj, "method")
except AttributeError:
    ...... deal
else:
    result = func(args)
 
// 或指定默认返回值
func = getattr(obj, "method", None)
if func:
    func(args)

"""

# 2.TypeError: 不可调用
"""
func = getattr(obj, "method", None)
if callable(func):
"""

#用getattr实现工厂方法：
"""Demo：一个模块支持html、text、xml等格式的打印，根据传入的formate参数的不同，调用不同的函数实现几种格式的输出"""

"""
import statsout 
def output(data, format="text"):                           
    output_function = getattr(statsout, "output_%s" %format) 
    return output_function(data)
"""
#这个例子中可以根据传入output函数的format参数的不同 去调用statsout模块不同的方法(用格式化字符串实现output_%s)