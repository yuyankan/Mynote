import torch.optim
#help(torch.optim)

"""
Help on package torch.optim in torch:

NAME
    torch.optim

DESCRIPTION
    :mod:`torch.optim` is a package implementing various optimization algorithms.
    Most commonly used methods are already supported, and the interface is general
    enough, so that more sophisticated ones can be also easily integrated in the
    future.

PACKAGE CONTENTS
    _functional
    _multi_tensor (package)
    adadelta
    adagrad
    adam
    adamax
    adamw
    asgd
    lbfgs
    lr_scheduler
    optimizer
    rmsprop
    rprop
    sgd
    sparse_adam
    swa_utils

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\optim\__init__.py



Process finished with exit code 0

"""