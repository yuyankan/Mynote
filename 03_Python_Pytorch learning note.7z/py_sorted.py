
# 1.使用sorted()函数排序
""" 1.1 对数值进行排序
你可以使用Python中的sorted()函数对一个列表进行排序。在本例中，定义了一个整数列表，然后调用sorted()函数，可变的numbers作为sorted()函数的参数。
"""
numbers = [3, 5,1]
print(sorted(numbers)) # RUN: [1, 3, 5]
print(numbers) # No change: numbers = [3, 5,1]
"""
这个例子展示了sorted()函数四种重要的特性：

1.sorted()函数不需要定义。它是一个内置函数，可以在标准的Python安装中使用。

2.在没有额外的参数的情况下，sorted()函数按照升序对值进行排列，也就是按照从小到大的顺序。

3.原始的numbers不会改变，因为sorted()函数提供了一个新的有序的输出结果，并且不改变原始值的顺序。

4.当sorted()函数被调用时，它会提供一个有序的列表作为返回值。
最后一点意味着列表可以使用sorted()函数，并且输出结果可以立刻赋值给一个变量：
"""
numbers_sorted = sorted(numbers)
print(numbers_sorted) # RUN: [1, 3, 5]

# 可以通过调用help()函数来查看sorted()函数以确认所有的这些观察结果。可选参数key和reverse
"""
sorted(iterable, /, *, key=None, reverse=False)
    Return a new list containing all items from the iterable in ascending order.
    
    A custom key function can be supplied to customize the sort order, and the
    reverse flag can be set to request the result in descending order.s
"""

# 2. 元组和集合同样可以使用sorted()函数：
"""
值得注意的是即使输入的是一个集合和元组，输出结果仍然是一个列表，因为sorted()函数根据定义会返回一个新列表。如果返回的对象需要匹配输入类型，
则可以将其转化为新类型。如果试图将结果列表转换回集合类型，请注意，按照定义而言，集合是无序的：
"""
numbers_tuple = (5, 3, 1)
numbers_set = {5, 5, 10, 1}
numbers_tuple_sorted = sorted(numbers_tuple)
numbers_set_sorted = sorted(numbers_set)

print(numbers_tuple_sorted) # RUN: [1, 3, 5]
print(numbers_set_sorted) #RUN: [1, 5, 10]

print(tuple(numbers_tuple_sorted)) # (1, 3, 5)
print(set(numbers_set_sorted)) #{1, 10, 5}
# 正如预料的结果一样，当把结果列表转换为集合时，numbers_set_sorted是无序的。其它的变量，如numbers_tuple_sorted保留了排序后的顺序。!!!

# 3. 对字符串进行排序
#tr类型的排序类似于列表和元组等其它可迭代对象。
string_number = "34521"
string_value = ' I like to sort'
string_number_sorted = sorted(string_number)
string_value_sorted = sorted(string_value)

print(string_number_sorted) #RUN: ['1', '2', '3', '4', '5']
print(string_value_sorted) #RUN: [' ', ' ', ' ', ' ', 'I', 'e', 'i', 'k', 'l', 'o', 'o', 'r', 's', 't', 't']
"""
sorted()函数将一个str看作一个列表，并遍历其中的每一个元素。在一个str中，每一个元素都对应着str中的一个字符。sorted()函数以相同的方式对待每一个句子，它会对每个字符包括空格进行排序。
.split()可以改变这个结果并清理输出，.join()可以将所有内容重新连接在一起
"""
string_value_sorted_2 = sorted(string_value.split())
print(string_value_sorted_2) #RUN: ['I', 'like', 'sort', 'to']
print(''.join(string_value_sorted_2)) #RUN: I like sort to
# 在本例中，原句被转换为一个单词列表而不是作为一个str。然后，对该列表进行排序并再次组合形成一个str而不是一个列表。
t = ''.join(string_value_sorted_2)
print(sorted(t))
