
# 在pytorch训练时，一般用到.item()。比如loss.item()。我们可以做个简单测试代码看看它的区别。
import torch
x = torch.randn(2, 2)
print(x)
print(x[1,1])
print(x[1,1].item())
"""RUN:
tensor([[-0.1572, -0.0319],
        [ 1.0567, -0.0746]])
tensor(-0.0746)
-0.07463619112968445

"""
"""
可以看出是显示精度的区别，item()返回的是一个浮点型数据，所以我们在求loss或者accuracy时，一般使用item()，而不是直接取它对应的元素x[1,1]。
"""