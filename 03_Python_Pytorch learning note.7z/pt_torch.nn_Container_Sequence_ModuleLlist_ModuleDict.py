import operator
import warnings

from torch.nn import Module
from typing import Any, overload, Union, TypeVar, Iterator,Optional, Iterable, Mapping,Tuple
from collections import OrderedDict
from itertools import islice
from torch._jit_internal import _copy_to_script_wrapper
from collections import abc as container_abcs
# summary:
"""
1. nn.Sequential: --> is one module（container)
   ->1.1 add modules in order to it's own Dict: self(nn.Sequential)._modules: name is module name or idx in dict.
            def __init__(self, *args: Module) -> None:
            def __init__(self, arg: 'OrderedDict[str, Module]') -> None:
             
   ->1.2: method: __getitem__, __setitem__, __delitem__, __len__, __dir__, __iter__: is dealing with nn.Sequntial, by 
        directly deal with it's Dict: self._modules.
    ->1.3: forward (): input = module(input): 'chain' all submodules in Dict

2. nn.ModuelList:
    ->2.1 add modules in order to it's own Dict: self(nn.ModuleList)._modules: name is idx: 0, 1, 2, ...
            def __init__(self, modules: Optional[Iterable[Module]] = None) -> None:
    ->2.2: method: __getitem__, __setitem__, __delitem__, __len__, __dir__, __iter__: is dealing with nn.ModuleList, by 
            directly deal with it's Dict: self._modules.
            note: delitem: To preserve numbering, self._modules is being reconstructed with modules after deletion
                    str_indices = [str(i) for i in range(len(self._modules))]
                    self._modules = OrderedDict(list(zip(str_indices, self._modules.values())))
    >2.3 have redefined more method: insert, append, extend..

3.nn.ModuleDict:
    ->3.1 dd modules in order to it's own Dict: module name + value
            self.update ()-->self.__setitem__(): self.add_modules(key, module)
    ->3.2: method: __getitem__, __setitem__, __delitem__, __len__, __dir__, __iter__: is dealing with nn.ModuleDict, by 
            directly deal with it's Dict: self._modules.
    ->3.3 have redefined more method: def keys(), items(), values(), update..
    
   
"""

T = TypeVar('T', bound=Module)
# container 要求见： py_magic method_3： 可变容器：getitem,setitem, delitem, len, etc..
class Container(Module):

    def __init__(self, **kwargs: Any)->None:
        super(Container, self).__init__()
        warnings.warn("nn.Container is deprecated. All of it's functionality now is implemented in nn.Module. Subcalss that instead")
        for key, value in kwargs.items():
            self.add_module(key, value)

class Sequential(Module):
    r"""
    1. A sequential container.
    2. Modules will be added to it in the order they are passed in the constructor.
        Alternatively, and 'OrderedDict' of modules can be passed in.
    3. The 'forward()' method of 'Sequential' accepts any input and forwards it to the first module it contains.
        it then 'chains' outputs to inputs sequentially for each subsequent module;-->
        Finally returning the output of the last module.

    4. The value of a 'Sequential' provides over manually calling a sequence of modules is that: it allows treating the
        whole container as a single module,-->
        such that performing a transformation on the 'Sequential' applies to each of the modules it stores (which are
        each a registered submodule of the 'Sequential')

    5. Difference between a 'Sequential' and a :class: 'torch.nn.ModuleList':
        - 'ModuleList' is exactly what it sounds like -a list for storing 'Module's
        - on the other hand,, the layers in a 'Sequential' are connected in a cascading way.
    Example::

        # Using Sequential to create a small model. When `model` is run,
        # input will first be passed to `Conv2d(1,20,5)`. The output of
        # `Conv2d(1,20,5)` will be used as the input to the first
        # `ReLU`; the output of the first `ReLU` will become the input
        # for `Conv2d(20,64,5)`. Finally, the output of
        # `Conv2d(20,64,5)` will be used as input to the second `ReLU`
        model = nn.Sequential(
                  nn.Conv2d(1,20,5),
                  nn.ReLU(),
                  nn.Conv2d(20,64,5),
                  nn.ReLU()
                )

        # Using Sequential with OrderedDict. This is functionally the
        # same as the above code
        model = nn.Sequential(OrderedDict([
                  ('conv1', nn.Conv2d(1,20,5)),
                  ('relu1', nn.ReLU()),
                  ('conv2', nn.Conv2d(20,64,5)),
                  ('relu2', nn.ReLU())
                ]))
    """
    @overload
    def __init__(self, *args: Module) ->None: ...

    @overload
    def __init__(self, arg: 'OrderedDict')->None:...

    def __init__(self, *args):
        super(Sequential, self).__init__()
        if len(args)==1 and isinstance(args[0], OrderedDict):
            for key, module in args[0].items():
                self.add_module(key, module)

        else:
            for idx, module in enumerate(args):
                self.add_module(str(idx), module)

    def _get_item_by_idx(self, iterator, idx) ->T:
        """Get the idx-th item of the iterator"""
        size = len(self)
        idx = operator.index(idx)
        if not -size < idx < size:
            raise IndexError('indext{} is out of range'.format(idx))
        idx %=size
        return next(islice(iterator,idx, None))

    @_copy_to_script_wrapper
    def __getitem__(self, idx) -> Union ['Sequential', T]:
        if isinstance(idx, slice):
            return self.__class__(OrderedDict(list(self._modules.items())[idx])) # ?????
        else:
            return self._get_item_by_idx(self._modules.values(), idx)

    def __setitem__(self, idx: int, module: Module) ->None:
        key: str = self._get_item_by_idx(self._modules.keys(), idx)

    def __delattr__(self, idx:Union[slice, int])->None:
        if isinstance(idx, slice):
            for key in list(self._modules.keys())[idx]:
                delattr(self,key)

        else:
            key = self._get_item_by_idx(self._modules.keys(), idx)
            delattr(self, key)

    @_copy_to_script_wrapper
    def __len__(self)-> int:
        return len(self._modules)

    @_copy_to_script_wrapper
    def __dir__(self):
        keys = super(Sequential, self).__dir__() # return a list , keys of __class__, parameter, buffers,__dict__
        keys = [keys for key in keys if not key.isdigit()]
        return keys

    @_copy_to_script_wrapper
    def __iter__(self) -> Iterator[Module]:
        return iter(self._modules.values())

    #NB: we can't really type check this function as the type of input may change
    # dynamically (as is tested in TestScript.test_sequential_intermediary_types).
    #can not annotate with Any as TorchScript expects a more precise type??
    def forward(self, input):
        for module in self._modules.values():
            input = module(input)
        return input

class ModuleList(Module):
    r""" 1. Holds submodules in a list
    2. : class: '~torch.nn.ModuleList' can be indexed like a regular Python list, but
        modules it contains are properly registered, and will be visible by all:
        class: '~torch.nn.Module' methods.

    3. Args:
        modules(iterable, optional): an iterable of modules to add

    4. Example::
        class MyModule(nn.Module):
            def __init__(self):
                super(MyModule, self).__init__()
                self.linears = nn.ModuleList([nn.Linear(10, 10) for i in range(10)])

            def forward(self, x):
                # ModuleList can act as an iterable, or be indexed using ints
                for i, l in enumerate(self.linears):
                    x = self.linears[i // 2](x) + l(x)
                return x
    """
    def __init__(self, modules: Optional[Iterable[Module]] = None)->None:
        super(ModuleList, self).__init__()
        if modules is not None:
            self+=modules # 容器 赋值 -->__setitem__ method:

    def _get_abs_string_index(self, idx):
        """Get the absolute index for the list of modules"""
        idx = operator.index(idx)
        if not (-len(self) <= idx <= len(self)):
            raise IndexError('index {} is out of range'.format(idx))
        if idx <0:
            idx +=len(self)
        return idx

    def __setitem__(self, idx: int, module: Module) ->None:
        idx = self._get_abs_string_index(idx)
        return setattr(self, str(idx), module)

    def __getitem__(self, idx: int) -> Module:
        if isinstance(idx, slice):
            return self.__class__(OrderedDict(list(self._modules.items())[idx]))
        else:
            return self._modules[self._get_abs_string_index(idx)]

    def __delitem__(self, idx: Union[int, slice]) ->None:
        if isinstance(idx, slice):
            for k in range(len(self._modules))[idx]:
                delattr(self, str(k))
        else:
            delattr(self, self._get_abs_string_index(idx))

        # To preserve numbering, self._module is being reconsructed with modules after deletion
        str_indices = [str(i) for i  in range(len(self._modules))]
        self._modules = OrderedDict(list(zip(str_indices, self._modules.values))) # !!!!

    @_copy_to_script_wrapper
    def __len__(self) -> int:
        return len(self._modules)

    @_copy_to_script_wrapper
    def __iter__(self) -> Iterator[Module]:
        return iter(self._modules.values())

    def __iadd__(self, modules: Iterable[Module]) -> 'ModuleList':
        return self.extend(modules)

    def __dir__(self):
        keys = super(ModuleList, self).__dir__()
        keys = [key for key in keys if not key.isdigit()]
        return  keys

    def extend(self, modules: Iterable[Module]) ->'ModuleList':
        r"""Appends moduels from a Python iterable to the end of the list
        Args:
            modules(iterable): iterable of modules to append """
        if not isinstance(modules, container_abcs.Iterable):
            raise TypeError("ModuleList.extend should be called with an iterable, "
                            "but got" + type(modules).__name__)
        offset = len(self)
        for i, module in enumerate(modules):
            self.add_module(str(offset+i), module)
        return self

    def append(self, module: Module) -> 'ModuleList':
        r"""Append a given modlue to the end of the list.
        Args:
            modlue(nn.Module): modlue to append
        """
        self.add_module(str(len(self)),module)
        return self

    def insert(self, index: int, modlue: Module) ->None:
        r"""Insert a given modlue before a given index in the list.
        Args:
            index(int)L index to insert
            module(nn.Module)L modlue to insert
             """
        for i in range(len(self._modules), index, -1):
            self._modules[str(i)] = self._modules[str(i-1)]
        self._modules[str(index)] = modlue


    # remove forward alltogether to fallback on Modules _forward_unimplemented

class ModuleDict(Module):
    r"""Holds submodules in a dictionary.

    1. : class: '~torch.nn.ModuleDict' can be indexed like a regular Python dictionary.
        but modules it contains are properly registered, and will be visible by all : call: '~torch.nn.Module' methods
    2. : class: '~torch.nn.ModuleDict' is an **ordered** dictiaonary that respects the oreder of insertion
    3. and in : meth: '~torch.nn.ModuleDict.update', the order of the merged 'OrderedDict', 'dict'(started from python3.6)
        or another :class: '~torch.nn.ModuleDict'
        (the argument to : meth:'~torch.nn.ModuleDict.update')

    4.Note ： meth: '~torch.nn.ModuleDict.update' with other unordered mapping types:(e.g: Pythons plain 'dict' before
        python version 3.6) does not preserve the order of the merged mapping.
    5.Args:
        modules(iterable, optional)： a mapping (dictionary) of (string: module) or
        an iterable of key-value pairs of type(string, module)

    Example::

        class MyModule(nn.Module):
            def __init__(self):
                super(MyModule, self).__init__()
                self.choices = nn.ModuleDict({
                        'conv': nn.Conv2d(10, 10, 3),
                        'pool': nn.MaxPool2d(3)
                })
                self.activations = nn.ModuleDict([
                        ['lrelu', nn.LeakyReLU()],
                        ['prelu', nn.PReLU()]
                ])

            def forward(self, x, choice, act):
                x = self.choices[choice](x)
                x = self.activations[act](x)
                return x
    """

    def __init__(self, modules: Optional[Mapping[str, Module]]=None) ->None:
        super(ModuleDict, self).__init__()
        if modules is not None:
            self.update(modules)

    @_copy_to_script_wrapper
    def __getitem__(self, key: str) ->Module:
        return self.modlues[key]

    def __setitem__(self, key:str, module: Module) ->None:
        self.add_modlue(key, module)

    def __delitem__(self, key: str)->None:
        del self._modules[key]

    @_copy_to_script_wrapper
    def __len__(self) ->int:
        return len(self._modules)

    @_copy_to_script_wrapper
    def __iter__(self) ->Iterator[str]:
        return iter(self._mudules)

    @_copy_to_script_wrapper
    def __contains__(self, key: str)->bool:
        return key in self._modules

    def clear(self) ->None:
        """Remove all items from the ModuleDict"""

        self._modules.clear()

    def pop(self, key: str)->Module:
        r"""Remove key from the ModuleDict and return its module.
        Args:
            key(string): key to pop from the ModuleDict
        """
        v = self[key]
        del self[key]
        return v

    @_copy_to_script_wrapper
    def keys(self) ->Iterable[str]:
        r"""Return an iterable of the ModuleDict Keys"""
        return self._modules.keys()

    @_copy_to_script_wrapper
    def items(self) -> Iterable[Tuple[str, Module]]:
        r"""Return an iterable of the ModuleDict key/value pairs"""
        return self._modules.items()

    @_copy_to_script_wrapper
    def values(self)->Iterable[Module]:
        r"""Return an iterable of the ModuleDict values"""
        return self._modlues.values()


    def update(self, modules: Mapping[str, Module]) ->Module:
        r"""
        1. Update the : class: '~torch.nn.ModuleDict' with the key-value pairs from a mapping or an iterable,
            overwriting existing keys.!!!
        2..note::
            if :attr: 'modulue' is an 'OrderedDict', a : class:'~torch.nn.ModuleDict', or an iterable of key-value pairs,
            the order of new elements in it is preserved.

        3. Args:
            modules(iterable): a mapping (dictionary) from string to class: '~torch.nn.Module',
                or an iterable of key-value pairs of type(string, : class: '~torch.nn.Module')
        """
        if not isinstance(modules, container_abcs.Iterable):
            raise TypeError("ModuleDict.update should be called with an iterable of key/value pairs, "
                            "bug got" + type(modules).__name__)

        if isinstance(modules, (OrderedDict, ModuleDict, container_abcs.Mapping)): # order will be preserved
            for key, module in modules:
                self[key] = module

        else:
            # modules her can be a list with two items
            for j, m in enumerate(modules):
                if not isinstance(m, container_abcs.Iterable):
                    raise TypeError ("ModuleDict update sequence element #" + str(j) + "should"
                                    "be Iterablel; is " + type(m).__name__)
                if not len(m)==2:
                    raise ValueError("ModuleDict update sequence element # " + str(j) +''
                                    "has length" + type(len(m)) + '; 2 is required')
                #modules can be Mapping(what it's typed at), or a list: [(name1, modlue1), (name2, module2)]
                # that's too cumbersome(麻烦) to type correctly with overloads, so we add an ignore here
                self[m[0]] = m[1]  # type: ignore[assignment]

    # remove forward alltogether to fallback on Module's _forward_unimplemented








