from torchtext.datasets import multi30k
#help(multi30k)

"""
Help on module torchtext.datasets.multi30k in torchtext.datasets:

NAME
    torchtext.datasets.multi30k

FUNCTIONS
    Multi30k(root='.data', split=('train', 'valid', 'test'), language_pair=('de', 'en'))
        Multi30k dataset
        
        Reference: http://www.statmt.org/wmt16/multimodal-task.html#task1
        
        Args:
            root: Directory where the datasets are saved. Default: ".data"
            split: split or splits to be returned. Can be a string or tuple of strings. Default: (‘train’, ‘valid’, ‘test’)
            language_pair: tuple or list containing src and tgt language. Available options are ('de','en') and ('en', 'de')

DATA
    DATASET_NAME = 'Multi30k'
    MD5 = {'test': '0681be16a532912288a91ddd573594fbdd57c0fbb81486eff7c552...
    NUM_LINES = {'test': 1000, 'train': 29000, 'valid': 1014}
    URL = {'test': 'http://www.quest.dcs.shef.ac.uk/wmt16_files_mmt/mmt16_...

FILE
    d:\software\envs\pytorch\lib\site-packages\torchtext\datasets\multi30k.py



Process finished with exit code 0

"""
from torchtext.legacy.datasets import Multi30k
#help(Multi30k.splits)
"""
Help on method splits in module torchtext.legacy.datasets.translation:

splits(exts, fields, root='.data', train='train', validation='val', test='test2016', **kwargs) method of builtins.type instance
    Create dataset objects for splits of the Multi30k dataset.
    
    Args:
        exts: A tuple containing the extension to path for each language.
        fields: A tuple containing the fields that will be used for data
            in each language.
        root: Root dataset storage directory. Default is '.data'.
        train: The prefix of the train data. Default: 'train'.
        validation: The prefix of the validation data. Default: 'val'.
        test: The prefix of the test data. Default: 'test'.
        Remaining keyword arguments: Passed to the splits method of
            Dataset.
"""