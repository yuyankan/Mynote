import numpy as np
a = '_h * i_'

print(a.strip('_') )# Result: 'h i'
"""
strip(self, __chars=None, /)
    Return a copy of the string with leading and trailing whitespace removed.
    
    If chars is given and not None, remove characters in chars instead.
"""