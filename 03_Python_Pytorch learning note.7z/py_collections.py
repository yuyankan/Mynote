"""

集合相关的模块都在这里了……提起Python应该没有不知道这个模块的吧，它为开发者提供了一系列敏捷、实用的类和方法——有的是为了对集合进行相关操作，有的本身就是集合

"""
"""概述：collections模块有哪些东西

−'''This module implements specialized container datatypes providing
alternatives to Python's general purpose built-in containers, dict,
list, set, and tuple.

* namedtuple   factory function for creating tuple subclasses with named fields
* deque        list-like container with fast appends and pops on either end
* ChainMap     dict-like class for creating a single view of multiple mappings
* Counter      dict subclass for counting hashable objects
* OrderedDict  dict subclass that remembers the order entries were added
* defaultdict  dict subclass that calls a factory function to supply missing values
* UserDict     wrapper around dictionary objects for easier dict subclassing
* UserList     wrapper around list objects for easier list subclassing
* UserString   wrapper around string objects for easier string subclassing
"""
"""使用__file__属性用来看看source code的位置

>>> import collections
>>> collections.__file__
"""

"""打开idle并导入collections模块，看看都有哪些有趣的东西
>>>dic(collections)

"""
import collections
print(dir(collections))
"""
['ChainMap', 'Counter', 'OrderedDict', 'UserDict', 'UserList', 'UserString', '_Link', '_OrderedDictItemsView', 
'_OrderedDictKeysView', '_OrderedDictValuesView', '__all__', '__builtins__', '__cached__', '__doc__', '__file__', 
'__getattr__', '__loader__', '__name__', '__package__', '__path__', '__spec__', '_chain', '_collections_abc', 
'_count_elements', '_eq', '_heapq', '_iskeyword', '_itemgetter', '_proxy', '_recursive_repr', '_repeat', '_starmap', 
'_sys', '_tuplegetter', 'abc', 'defaultdict', 'deque', 'namedtuple']

"""
"""1. namedtuple（具名元组）
看名字就知道首先namedtuple是一个tuple，其次它……有名字 :-）
namedtuple是一个函数，作用是创建命名元组）——也就是创建一个只有类名和属性却不包括方法的简单类（按照官方的说法，是一个tuple-like的对象
collections.namedtuple(typename, field_names, *, verbose=False, rename=False, module=None)

通常我们关注前两个参数，第一个是具名元组的类名，第二个参数是它的属性名；在实际书写时既可以把多个属性放在一个字符串中，属性之间用空格或逗号分开，
也可以把第二个参数写成一个序列（如tuple、list）形式并把多个属性分别包裹在单引号中它们之间用逗号分开；
另外，namedtuple对象是只读（read-only）的
"""

""" deque（双向队列）
光看名字不知为何物，其实deque全称应该是double-ended queue，也就是双向队列的意思（学过数据结构基础的朋友应该比较熟悉
deque弥补了list插入、删除的效率问题（list类似数组结构，擅长查找
deque是一个类（虽然类名小写。。），以下是它的构造

>>> class collections.deque([iterable[, maxlen]])
接受一个可迭代对象（内置的就是str、tuple、list咯），第二个参数指定最大队列长度（maxlen）
deque是双向队列，是list的完善，所以列表支持的操作它都支持而且还可以从两端的任意端插入新元素（对xxxleft()方法留个心眼即可）
"""

""" efaultdict（默认字典）
又是一个小写的类名（我猜也许是因为考虑到init函数就把该类当函数用了

class collections.defaultdict([default_factory[, ...]])
>>> collections.defaultdict是__builins__.dict的子类，在其父类的基础上补充了魔法方法__missing__(key)

也就是说，如果访问的key不存在或访问抛出异常时（会返回指定内容（__missing__函数的作用）——defaultdict改变的是value的状态，触发条件是KeyError

"""

""" OrderedDict（有序字典）
正如其名，有序字典是有序的；它也是内置dict的子类（所以也支持一切dict拥有的操作集）

>>> class collections.OrderedDict([items])
普通的字典dict(..)返回的对象是无序的（和插入顺序无关），但是OrderedDict就没有这个问题，它会按照用户插入的顺序排序而不是key的排序，
鉴于这样的特性，OrderedDict可以做成一个FIFO的队列（当元素超过上限时删除最先进入的元素
"""
from collections import OrderedDict
od = OrderedDict()
od['z'] = 1
od['y'] = 2
od['x'] = 3
print(od.keys())  # result:   odict_keys(['z', 'y', 'x'])

class eg1(OrderedDict):

    def __init__(self, capacity):
        super(eg1, self).__init__()
        self._capacity = capacity

    def __setitem__(self, key, value):
        containsKey = 1 if key in self else 0
        if len(self)-containsKey >= self._capacity:
            last = self.popitem(last=False)
            print("remove", last)
        if containsKey:
            del self[key]
            print("set: ", (key,value))
        else:
            print("add:", (key, value))
            OrderedDict.__setitem__(self, key, value)




"""
popitem()
随机删除字典中的一个键值对，并且返回该键值对，(key,value)形式。
如果字典已经为空，却调用了此方法，就报出KeyError异常。

在这里，“随机”我看到有好几种解释，我个人理解是我们创建的字典是无序的，它返回给我们的字典是怎样的顺序我们并不清楚，但popitem()会从返回字典的第一个开始删除。

"""

"""
pop (key[,default])
其中，key是必选参数，必须给出，default是可选参数，可以不给出。
如果键值key在字典中存在，删除dict[key]，返回 dict[key]的value值。
否则，如有给出default值则返回default值，如果default值没有给出，就会报出KeyError异常。
pop()方法至少接受一个参数，最多接受两个参数

"""

""" Counter类
collections.Counter类用来计数，类似于MultiSet或Bag

>>> class collections.Counter([iterable-or-mapping])
和defaultdict、OrderedDict类一样，都是dict类的子类
"""
""" 1 可以把一个序列作为参数来构造一个Counter对象，默认下Counter对象（记住，是dict的子类）的key是待计数元素，value是对应的计数；
"""
print('Counter-'*10)
some_data = ['a', '2', 2, 4, 5, '2', 'b', 4, 7, 'a', 5, 'd', 'a', 'z']
from collections import Counter
print(Counter(some_data))

""" 也可以动态的使用循环对序列进行计数
先是创建一个空的Counter对象，接着对其进行填充"""
c = Counter()
for ch in 'hello world':
    print('ch: ',ch)
    c[ch] +=1
    print('c: ', c)
print('-'*50)
print(c)
print('*'*50)