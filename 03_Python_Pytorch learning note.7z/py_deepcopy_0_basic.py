# 1. 深、浅拷贝特点:
"""
对象类型	 深拷贝返回值	        浅拷贝返回值
不可变	本身(不包括tuple)	    本身
可变	   嵌套拷贝对象1	       表层拷贝对象2
"""
#1.1 可能有点抽象，举个例子：
"""
ele = [4]
list_0 = [1, 2, 3, ele]
# 形象点就是copy搬运个网站，里头有链接，也只是原原本本复制链接
# deepcopy在此之上，还会把链接指向的网站内容也复制了
# 例如：
copy_list_0 = [1, 2, 3, ele]
deepcopy_list_0 = [1, 2, 3, [4]]
"""

# 1.2: 注意：深拷贝能够递归拷贝，所以其会引发新的问题——tuple类组合内含有可变类型该如何处理？
# 结论：用tunple函数重新生成一个元组，并返回。
"""**********************************************************************************************************"""
"""**********************************************************************************************************"""
# 2. 源码Document
# 以下为copy模块的说明截取：
"""
The difference between shallow and deep copying is only relevant for
compound objects (objects that contain other objects, like lists or
class instances).

- A shallow copy constructs a new compound object and then (to the
  extent possible) inserts *the same objects* into it that the
  original contains.

- A deep copy constructs a new compound object and then, recursively,
  inserts *copies* into it of the objects found in the original.
翻译：
浅复制和深复制的不同仅仅是对组合对象来说，所谓的组合对象就是包含了其它对象的对象，如列表，类实例。
–浅拷贝将构造一个新的组合对象，然后将所包含的对象直接插入到新的组合对象中
–深拷贝讲构造一个新的组合对象，然后递归的拷贝所包含的对象并插入到新的组合对象中
"""
"""**********************************************************************************************************"""
"""**********************************************************************************************************"""
# 3. 验证及源码说明
# 3.1 不可变类型: 验证：对下列immutable进行深浅拷贝，对比源头id，验证均相同, 得证。（输出略）
"""
import copy

im_int = 0
im_bool = False
im_string = '0'
im_tuple = (0, 0)

if      copy.copy(im_int) is im_int and \
        copy.copy(im_bool) is im_bool and \
        copy.copy(im_string) is im_string and \
        copy.copy(im_tuple) is im_tuple and \
        copy.deepcopy(im_int) is im_int and \
        copy.deepcopy(im_bool) is im_bool and \
        copy.deepcopy(im_string) is im_string and \
        copy.deepcopy(im_tuple) is im_tuple:
    print('immutable类型变量深浅备份仅返回本身')
else:
    print('error')

"""
"""**********************************************************************************************************"""
# 3.1.1 不可变类型-浅拷贝源码:_copy_dispatch
#分析：copy模块先行设置不可拷贝类型的key为_copy_immutable方法，该方法返回x本身。
"""
_copy_dispatch = d = {}
# 如果x为immutable类型，返回本身： (id(x)）
def _copy_immutable(x):
    return x
# 将包括immutable在内的，所有不可拷贝类型添加进字典_copy_dispatch(d)
for t in (type(None), int, float, bool, complex, str, tuple,
          bytes, frozenset, type, range, slice, property,
          types.BuiltinFunctionType, type(Ellipsis), type(NotImplemented),
          types.FunctionType, weakref.ref):
    d[t] = _copy_immutable

"""
#分析：copy模块先行设置不可拷贝类型的key为_copy_immutable方法，该方法返回x本身。

"""
def copy(x):
#    ""Shallow copy operation on arbitrary Python objects.

 #   See the module's __doc__ string for more info.
    ""

    # 获得x类型
    cls = type(x)
    # 获取该类型的处理方法，对于immutable类的type，均返回x本身
    copier = _copy_dispatch.get(cls) #  1. _copy_dispatch is dic{}, .get() to get value of key-cls; 2. for dict: key is unchangable object.
    if copier:
        return copier(x)
"""
#分析：在copy得到带拷贝目标x后，提取其type，并获取字典_copy_dispatch对应的处理方法，对于immutable类型则返回_copy_immutable方法——直接返回x本身。

"""**********************************************************************************************************"""
# 3.1.2. 不可变类型-深拷贝源码
"""
# 同浅拷贝，获取对应方法并执行
copier = _deepcopy_dispatch.get(cls)
if copier is not None:
    y = copier(x, memo)
"""
"""
def _deepcopy_atomic(x, memo):  # compare with shallow copy' _copy_immutable(x)', have dict 'memo' here.
    return x
# d = _deepcopy_dispatch
d[type(None)] = _deepcopy_atomic
d[type(Ellipsis)] = _deepcopy_atomic
d[type(NotImplemented)] = _deepcopy_atomic
d[int] = _deepcopy_atomic
d[float] = _deepcopy_atomic
d[bool] = _deepcopy_atomic
d[complex] = _deepcopy_atomic
d[bytes] = _deepcopy_atomic
d[str] = _deepcopy_atomic
d[types.CodeType] = _deepcopy_atomic
d[type] = _deepcopy_atomic
d[types.BuiltinFunctionType] = _deepcopy_atomic
d[types.FunctionType] = _deepcopy_atomic
d[weakref.ref] = _deepcopy_atomic
d[property] = _deepcopy_atomic
"""
#分析：这里的d就是_deepcopy_dispatch。深拷贝对于除tuple外的immutable类型的处理相似，不做赘述。

#以下重点看深拷贝对不可变类型tuple的处理：
# 3.1.2. 不可变类型-深拷贝源码-->对不可变类型tuple的处理:
import copy
from copy import deepcopy
x = [1, 2, 3]
def __deepcopy__tuple(x, memo, deepcopy=deepcopy):
    # 使用deepcopy对x内的组合进行复制，得到y
    y = [deepcopy(a, memo) for a in x] # deepcopy x 内的每个元素-->memo中有x 的每个元素-id(original-no changeable-a), id(new-chainable-a)
    # We're not going to put the tuple in the memo, but it's still important we
    # check for it, in case the tuple contains recursive mutable structures
    # y now is a list even x is tuple

    try:
        return memo[id(x)] # 跳出def 方法， 返回 对象x的id(x)-字典memo key出的value
    except KeyError: # 处理异常， memo字典中没有id(x)-->continue rest code in this method
        pass

    # 对比x、y中的元素，如果存在一个id不相等，则说明包含有可变类型
    for k, j in zip(x, y):
        if k is not j: # j is deepcopy of k, if id(j) ! = id(k)-->this object is changeable in tuple x
        # 调用tuple重新生成元组
            y = tuple(y)
            break
    else:
        y = x
    return y
#分析：通过调用deepcopy递归赋值tuple内的元素，如果包含可变元素，deepcopy会用响应的方法进行复制，如_deepcopy_list方法，
# 并通过tuple(y)重新生成一个元组并返回。如果不包含，则返回本身。

""" _deepcopy_list"""

def _deepcopy_list(x, memo, deepcopy=deepcopy):
    y = []
    memo[id(x)] = y  # memo: key is id(x), value is y
    append = y.append # append: is the function: y.append function
    for a in x:
        append(deepcopy(a, memo)) # -->1. memo value corresponding to key id(x): change from y to a list: y + x
        # 2. y: changed to be x(copy x)
    return y # id(y) do not change: use append change the value of id(y), id do not change.
d = _deepcopy_list(x)
