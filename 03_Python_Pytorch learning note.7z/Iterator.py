"""1. Iterator defination:
迭代器是一个可以记住遍历的位置的对象。
迭代器对象从集合的第一个元素开始访问，直到所有的元素被访问完结束。迭代器只能往前不会后退。
"""


""" 2. Iterator & iterale
>>> Iterable: with __iter__ or __getitem__ method (will call this method in for loop)
     -->builds
>>> Iterator: with __next__ or __iter__ method
note for iterator: __iter__(self): return self
while for iterable, __iter__(self), not same coding?????

"""

"""
迭代器（Iterator）继承可迭代（Iterable），迭代器必须实现__iter__方法和__next__方法。其中__next__方法用于产出下一个元素。
由继承图可见，迭代器一定是可迭代对象，可迭代对象不一定是迭代器.

迭代器有两个基本的方法：iter() 和 next()。
我们使用iter(iterable)即可把可迭代对象转换成迭代器
使用next(iterator)来获取迭代器的下一个值
"""

"""2. parameter
1. Iterator: is  the object with next() method.
2. next() method: when perform one time, return the next value -->need to record status of iterator object on next().

3. iter()函数有两种用法，一种是传一个参数，一种是传两个参数。结果都是返回一个iterator对象。
iter(object): get an iterator from an object.
    iter(collection) ->iterator:   argument must supplier its own iterator, or be sequence;
    传1个参数：参数collection应是一个容器，支持迭代协议(即定义有__iter__()函数)，或者支持序列访问协议（即定义有__getitem__()函数），否则会返回TypeError异常。
    iter(callable, sentinel) ->iterator:  the callable is called until it returns the sentinel
    传2个参数：当第二个参数sentinel出现时，参数callable应是一个可调用对象(实例)，即定义了__call__()方法，当枚举到的值等于哨兵时，就会抛出异常StopIteration。
"""

# ===Example1: call iterator: __iter__, __next__ =====
a = [1, 2, 3, 4]
a_iter = iter(a)

print('\nexample 1: call iterator which created by iter():  a_iter = iter(a=[1, 2, 3, 4])')
print('1.1 print iterator element by for loop: for i in a_ater: print(i)')
for i in a_iter:
    print(i)

# for i in a_iter:  # not able to repeat iterator, while list is ok.
#    print(i)
# print('1.2 print iterator element by next(a_iter): ')
"""
print(next(a_iter))   # not able to repeat iterator, while list is ok.
print(next(a_iter))
print(next(a_iter))
print(next(a_iter))
"""


# ===Example1: create iterator: __iter__, __next__ =====
class cr_iter:
    def __init__(self):
        self.data = [1, 2, 3, 4]
        self.start = 0
        self.max = 6
        print('\nexample2: Create iterator with __iter__, __next__')

    def __iter__(self):  # -->enable iter()
        print("1.__iter__ is called__")
        return self

    def __next__(self):  # -->enable next()
        print("2.: __next__ is called")
        if self.start < 6:
            self.start += 1
            return self.start
        else:
            return 'Hi: end of iterator'


g = cr_iter()
print('te'*30)
g = iter(g)
print("00"*15)
print(next(g))
print(next(g))
print(next(g))
print(next(g))
print(next(g))
print(next(g))
print(next(g))
"""
print("test"*30)

for i in g:
    print("-"*50)
    print(i)
    break
print("test"*30)
"""
# ===Example3: create iterator: yield =====
def cr2_iter():
    for i in range(5):
        yield i


print('\nexample3: create iterator: method with yield: def cr2_iter():  yield: ')
print(type(cr2_iter()))  # () needed---->method (not class) cr2_iter is generator
for i in cr2_iter():
    print(i)

# ===Example4: Iterator original codes=====
"""
迭代器Iterator是一个抽象基类，它定义在_collections_abc.py中
Iterator源码如下
"""
from collections.abc import Iterable
from abc import abstractmethod


class Iterator(Iterable):
    __slots__ = ()   # no variants definated in slots-->class case no variants

    @abstractmethod
    def __next__(self):
        "Return the next item from the iterator. when exhausted, raise StopIteration"
        raise StopIteration  # raise??

    def __iter__(self):
        return self

    @classmethod # : 可以不用实例类，直接调用该函数： Iterator.__subclasshook__()
    def __subclasshook__(cls, c):
        if cls is Iterator:
            return cls._check_methods(c, '__iter__', '__next__')
        return NotImplemented

    def _check_methods(c, *methods):
        mro = c.__mro__  # class C's, super class
        ck = []
        for method in methods:
            def check():
                for meth in mro: # each super class
                    if method in meth.__dict__(): # each super class 's attributes
                        if meth.__dict__[method]:
                            return True

                return NotImplemented

            ck.append(check())
        return ck


"""
可以看到，它实现了__subclasshook__方法，即不用显式继承Iterator!!!，只需要实现__iter__和__next__方法即可称为Iterator的虚拟子类。????
这里凸现了Python的鸭子类型，实现特定的“协议”即可拥有某种行为。

另外，它自己也定义了__iter__方法，当我们使用iter(Iterator)时直接返回自己，不做任何处理。
"""




