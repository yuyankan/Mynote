""" 其实就是C++里面的静态方法
staticmethod用于修饰类中的方法,使其可以在不创建类实例的情况下调用方法，这样做的好处是执行效率比较高。
当然，也可以像一般的方法一样用实例调用该方法。

该方法一般被称为静态方法。
静态方法不可以引用类中的属性或方法，其参数列表也不需要约定的默认参数self。!!!
静态方法就是类对外部函数的封装，有助于优化代码结构和提高程序的可读性。
"""

class Time():
    def __init__(self, sec):
        self.sec = sec

    # 声明一个静态方法
    @staticmethod
    def sec_minutes(s1, s2):
        # 返回两个时间差
        return abs(s1-s2)


#分别使用类名调用和使用实例调用静态方法
print("----------------------不通过例化的方法调用----------")
print(Time.sec_minutes(10, 5))

print("----------------------通过例化方法调用----------")
t = Time(10)
print(t.sec_minutes(t.sec, 5))

""" @classmethod & @staticmethod
一般来说，要使用某个类的方法，需要先实例化一个对象再调用方法。
而使用@staticmethod或@classmethod，就可以不需要实例化，直接类名.方法名()来调用。
这有利于组织代码，把某些应该属于某个类的函数给放到那个类里去，同时有利于命名空间的整洁。

既然@staticmethod和@classmethod都可以直接类名.方法名()来调用，那他们有什么区别呢
从它们的使用上来看:
1. 
@staticmethod不需要表示自身对象的self和自身类的cls参数，就跟使用函数一样。
@classmethod也不需要self参数，但第一个参数需要是表示自身类的cls参数。
2. 
如果在@staticmethod中要调用到这个类的一些属性方法，只能直接类名.属性名或类名.方法名。!!!
而@classmethod因为持有cls参数，可以来调用类的属性，类的方法，实例化对象等，避免硬编码。
"""

# ====Example2: @classmethod & @staticmethod的区别
print(" @classmethod & @staticmethod的区别")
class c_s():
    data = 'data'
    def __init__(self, data):
        self.args = data

    def printd(self):
        print(self.args)

    @staticmethod
    def smethod(args): # 没有self
        print("Static:", c_s.data) # class.attr

    @classmethod
    def cmethod(cls, *args):
        print("Class: ", cls.data) # instance.attr

eg2_1 = c_s(23) # 1. 参数'23'传递给方法__init__(self, data)中的data, 1. self 参数指向当前实例自身
"""3. 我们不需要传递实例自身给方法，Python解释器自己会做这些操作的"""
eg2_1.printd()  # -->result: 23
eg2_1.smethod(10) # RUN: Static: ()
eg2_1.cmethod() # Class:  (<class '__main__.c_s'>,): for : cmethod(cls-remove cls, *args),
#c_s.printd()  # error: printd() missing 1 required positional argument: 'self'-->print()方法， 只能通过实例eg2_1调用, 不然没有self
c_s.smethod(10) # Static: (): staticmethod: 可通过类及实例调用
c_s.cmethod() # Class:  (): classmethod: 可通过类及实例调用







