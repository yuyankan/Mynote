# ===Dataset & DataLoader===============================
import torch
import torch.utils.data.dataset as Dataset
import torch.utils.data.dataloader as DataLoader
import numpy as np

Data = np.asarray([[1, 2], [3, 4], [5, 6], [7, 8]])
Label = np.asarray([[0], [1], [0], [1]])


# ===========Create subDataset=================================
class subDataset(Dataset.Dataset): # could also use ImageFolder : dataset = transform.dataset.ImageFolder(root='',)
    # ===========Initialize ==================
    def __init__(self, Data, Label):
        self.Data = Data
        self.Label = Label

    # ======return data length ===============
    def __len__(self):
        return len(self.Data)

    # =====get data content and label =========
    def __getitem__(self, index):
        data = torch.Tensor(self.Data[index])
        label = torch.Tensor(self.Label[index])
        return data, label


# ===main contex ==============================
if __name__ == '__main__':
    dataset = subDataset(Data, Label)
    print('dataset:', dataset)
    print('dataset length: ', dataset.__len__())
    print('first dataset item: ', dataset.__getitem__(0)) # getitem reuturn is tuple （元组)
    print('first value in dataset: ', dataset[0][0])

# =====create DataLoader iteration=======
    # dataloader: get data content, and label: tuple(data, label); could use enumerate visit dataloader ===
    dataloader = DataLoader.DataLoader(dataset, batch_size=2, shuffle=False, num_workers=0)

    # for item in dataloader:
    #    data, label = item
    #    print('data: {} \n label: {} '.format(data, label))

    for i, item in enumerate(dataloader):

        data, label = item
        #print(data.shape)
        print('i: ', i)
        print('data: ', data)
        print('label:', label)
       # print('format: {}'.format(item))
