
# - 理解pytorch中的autograd包
""" 1.
torch.Tensor是autograd包的核心类。
如果将张量x的属性.requires_grad设为True，则它将开始追踪(track）在其上的所有操作（这样就可以利用链式法则进行梯度传播了）。
当完成张量x的一系列计算后（此时x已变为y），调用y.backward()方法就可以自动计算梯度。张量x的梯度会累加到x的.grad属性中

"""

"""2. 
如果不想被继续追踪，可以调用.detach()将其从追踪记录中分离，这样就可以防止将来的计算被追踪，这样梯度就穿不过去了。
此外，还可以用withtorch.no_grad()将不想被追踪的操作代码包裹起来，这种方法在评估模型时很有用，因为在评估模型时，我们并不需要计算可训练参数的梯度。
"""

"""3.
Function是另外一个很重要的类。???
Tensor和Function相互连接并建立一个无环图，该图对完整的计算历史进行编码。 每个张量都有一个.grad_fn属性，该属性引用创建了张量的函数
（用户创建的张量除外-它们的grad_fn为None）。
"""

"""4. 
每一个由运算创建的tensor，都有一个grad_fcn性，这个属性指向创建这个tensor的Function的内存地址。注意，由用户自己创建的tensor是没有.grad_fcn这个属性的。
"""

# cases: 1:
import torch
x = torch.ones(2, 2, requires_grad=True)
z = (x+2)*(x+2)*3
out = z.mean()

out.backward()
print("x.grad:",x.grad)
print("id(x): ", id(x))
print("id(x.grad: ", id(x.grad))

"""
其中out.backward是out反向求梯度，x.grad查看梯度计算结果。
!!!  x.grad是区别于x的另一个新的张量，这个张量存储着x相对于某一个标量（例如out）的梯度。!!!
"""


# 二、注意在y.backward()时，如果y是标量，则不需要为backward()传入任何参数，否则，需要传入一个与y同形的Tensor。
"""2.1 
为什么在y.backward()时，如果y是标量，则不需要为backward()传入任何参数；否则，需要传入一个与y同形的Tensor? 
简单来说就是为了避免向量（甚至更高维张量）对张量求导，而转换成标量对张量求导。

举个例子，假设形状为 m x n 的矩阵 X 经过运算得到了 p x q 的矩阵 Y，Y 又经过运算得到了 s x t 的矩阵 Z。那么按照前面讲的规则，
dZ/dY 应该是一个 s x t x p x q 四维张量，dY/dX 是一个 p x q x m x n的四维张量。问题来了，怎样反向传播？怎样将两个四维张量相乘？？？
这要怎么乘？？？就算能解决两个四维张量怎么乘的问题，四维和三维的张量又怎么乘？导数的导数又怎么求，这一连串的问题，感觉要疯掉…… 

为了避免这个问题，我们不允许张量对张量求导，只允许标量对张量求导，求导结果是和自变量同形的张量。所以必要时我们要把张量通过将所有张量的元素加权求和的
方式转换为标量，举个例子，假设y由自变量x计算而来，w是和y同形的张量，则y.backward(w)的含义是：先计算l = torch.sum(y * w)，则l是个标量，然后求l对自变量x的导数。

"""
"""2.2:
假设 x 经过一番计算得到 y，那么 y.backward(w) 求的不是 y 对 x 的导数，而是 l = torch.sum(y*w) 对 x 的导数。w 可以视为 y 的各分量的权重，
也可以视为遥远的损失函数 l 对 y 的偏导数（这正是函数说明文档的含义）。特别地，若 y 为标量，w 取默认值 1.0，才是按照我们通常理解的那样，求 y 对 x 的导数。

********************************************************************************************************************
这个函数的原型是：
torch.autograd.backward(variables, grad_variables=None, retain_graph=None, create_graph=None, retain_variables=None)

文档里的介绍是：
The graph is differentiated using the chain rule. If any of variables are non-scalar (i.e. their data has more than one element)
 and require gradient, the function additionally requires specifying grad_variables. It should be a sequence of matching
  length, that contains gradient of the differentiated function w.r.t. corresponding variables (None is an acceptable 
  value for all variables that don’t need gradient tensors).
  
variables 和 grad_variables 都可以是 sequence，不过平常也不太有一串变量对另一串变量求导这种需求：如果有这种需求的话，自己写个循环就行了；
像 PyTorch 的这个接口，以及 TensorFlow 里提供的求导接口，虽然可以传一堆 x 和一堆 y 进去，但是返回的都是一堆 y 的和对各个 x 的导数，
这样一来这个接口的用法就显得很奇怪。反倒不如定义这一堆 y 的和为 z，然后求 z 对各个 x 的导数更加自然。

"""
"""???
个简单的解决方案就是：

1、不允许 Tensor 对 Tensor 求导，只允许标量 Scalar 对张量 Tensor 求导，求导结果是和自变量同型的 Tensor。

2、在求 dl/dx 的时候（l 是标量，x 是张量），假设有一个中间结果为张量 y，即 x->y->l，那么先求 dl/dy（结果是良定义的、和 y 同型的 Tensor），
然后根据 x 和 dl/dy 想办法直接算出 dl/dx，跳过 dy/dx 是啥这种玄学问题！??????!!!（这种问题在推 MLP 的反向传播时也能遇到，解决办法就是跳过它！）
"""

"""2.4 
然后再回到 PyTorch 的设计上来， backward() 为啥还需要一个额外的参数？就是为了避免 Tensor 对 Tensor 求导结果是啥这种玄学问题！torch.autograd.backward(y, 
w), 或者说 y.backward(w) 的含义是：先计算 l = torch.sum(y * w)，然后求 l 对（能够影响到 y 的）所有变量 x 的导数。这里，y 和 w 是同型 Tensor。也就是说，可以理解成先按照 w 
对 y 的各个分量加权，加权求和之后得到真正的 loss，再计算这个 loss 对于所有相关变量的导数。 

这么设计有什么好处呢？如前所述，这样一来，所有求导操作都是求 Scalar 关于 Tensor 的导数，统一了起来，不存在 Tensor 对 Tensor 求导了。
再回顾一下 PyTorch 自己的文档，它说 torch.autograd.backward 的第二个参数 grad_variables 应该是第一个参数 variables 的对应的导数。

嗯？？这是什么情况？？其实我上面的解释是一致的。假设 y 和 w 是同型 Tensor，那么 l = torch.sum(y*w) 对 y 的导数 dl/dy 就是 w。
所以把这里的 w 理解成 y 的各项的权重也好，或者理解成某个高高在上的虚拟 loss 对 y 的导数也好，其实是一样的。
事实上，l = torch.sum(y*w) 这个形式不正好是导数的定义么？数学分析一上来就学，微分是函数增量的线性主部，而在 l = torch.sum(y*w) 这个形式里，只有线性的项，因此 w 就是 dl/dy。

那为什么标量就不需要这个参数呢？假设 y 是标量，然后取 w=1.0，那么 l=torch.sum(y*w) 其实就是 y 本身。所以这时候，dl/dx = dy/dx，
可以直接把 loss 和 y 混同，这也就是通常直接把损失函数 loss 当成 y 传进去的原因。
"""

#总结：
"""
假设 x 经过一番计算得到 y，那么 y.backward(w) 求的不是 y 对 x 的导数，而是 l = torch.sum(y*w) 对 x 的导数。w 可以视为 y 的各分量的权重，
也可以视为遥远的损失函数 l 对 y 的偏导数。也就是说，不一定需要从计算图最后的节点 y 往前反向传播，从中间某个节点 n 开始传也可以，只要你能把损失函数 
l 关于这个节点的导数 dl/dn 记录下来，n.backward(dl/dn) 照样能往前回传，正确地计算出损失函数 l 对于节点 n 之前的节点的导数。特别地，若 y 为标量，
w 取默认值 1.0，才是按照我们通常理解的那样，求 y 对 x 的导数。
"""