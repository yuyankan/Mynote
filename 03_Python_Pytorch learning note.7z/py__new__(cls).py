
#Python中的__new__()方法
#以为认识了python的__init__()方法就相当于认识了类构造器，结果，__new__()方法突然出现在我眼前，让我突然认识到原来__new__才是老大。

#我们首先得从__new__(cls[,...])的参数说说起，__new__方法的第一个参数是这个类，而其余的参数会在调用成功后全部传递给__init__方法初始化，这一下子就看出了谁是老子谁是小子的关系。


""" 所以，__new__方法（第一个执行）先于__init__方法执行："""

class A:
    def __init__(self):
        print("suplerclassA: __init__ is called")
    def __new__(cls):
        print("suplerclassA: __new__ is called")
        return super().__new__(cls) # base class is object


class B(A):
    def __init__(self):
        print("subclassB: __init__ is classed")

    def __new__(cls):
        print("subclassB: __new__ is called")
        return super().__new__(cls)


b = B()

#我们比较两个方法的参数，可以发现__new__方法是传入类(cls)，而__init__方法传入类的实例化对象(self).

# 而有意思的是，__new__方法返回的值就是一个实例化对象（ps:如果__new__方法返回None，则__init__方法不会被执行，
# 并且返回值只能调用父类中的__new__方法，而不能调用毫无关系的类的__new__方法）。
#
# 我们可以这么理解它们之间的关系，__new__是开辟疆域的大将军，而__init__是在这片疆域上辛勤劳作的小老百姓，只有__new__执行完后，
# 开辟好疆域后，__init__才能工作，结合到代码，也就是__new__的返回值正是__init__中self。

""" 看下面这个例子"""
print("*"*50)
class Cap():
    def __new__(cls,data):

        self_in_init = object.__new__(cls)
        print(self_in_init)
        print(id(self_in_init))
        return object.__new__(cls)
        # only could return 父类中的__new__方法 to __init__(self) method;
        # if return nothing or other, __init__(self) will not perform.
    def __init__(self, string):
        print("init is called")
        print(id(self))
        print(self)
        self.a = string +1
        print('test'*20)
        print(id(self))
        print(self)
        print('test'*20)

a = Cap(1)
print("-"*50)
print(id(a))
print("2"*50)

"""
上面这段代码的内容很简单，在__new__中打印一下返回值的id，在__init__中打印一下self的id值，最后再打印一下创建的这个类的id值
（所谓的id值也就是内存地址），我们可以看到最后的输出结果是一致的，这也就说明，整个类的地盘是由__new__函数"开辟出来的"，
而到了__init__内部就只能在这片地盘上"修修补补"了。
"""
#小结：__new__和__init__相配合才是python中真正的类构造器。
