"""
在类中对属性进行赋值操作时，python会自动调用__setattr__()函数，来实现对属性的赋值。但是重写__setattr__()函数时要注意防止无限递归的情况出现，
一般解决办法有两种，一是用通过super()调用__setatrr__()函数，二是利用字典操作对相应键直接赋值。


"""
import optparse

"""
Python 魔法方法（三） __getattr__，__setattr__， __delattr__
"""
"""
1、__getattr__
当我们访问一个不存在的属性的时候，会抛出异常，提示我们不存在这个属性。而这个异常就是__getattr__方法抛出的，其原因在于他是访问一个不存在的属性的最后
落脚点，作为异常抛出的地方提示出错再适合不过了。
访问存在的属性时，会正常返回值，若该值不存在，则会进入最后的兜底函数__getattr__。
"""
print("\n1__getattr__:")
class E1():
    def __init__(self, value):
        self.value = value

    def __getattr__(self, item):
        print("into__getattr__")
        return "can not find"

a1 = E1(10)
print(a1.value) # 10
print(a1.name) # into__getattr__; can not find
""" 访问存在的属性时，会正常返回值，若该值不存在，则会进入最后的兜底函数__getattr__。"""

"""2、__setattr__
在对一个属性设置值的时候，会调用到这个函数，每个设置值的方式都会进入这个方法。
"""
print("\n2__setattr__")
class E2():
    def __init__(self, value):
        print("intro.__init__")
        self.value = value

    def __setattr__(self, name, value):
        print("intro_setattr__")
        if value ==10:
            print("from__init__")
        object.__setattr__(self, name, value)

a2 = E2(10)
# into __init__
# into __setattr__
# from __init_
print(a2.value) # 10
a2.value = 100 # into __setattr__
print(a2.value) # 100

"""
在实例化的时候，会进行初始化，在__init__里，对value的属性值进行了设置，这时候会调用__setattr__方法。
在对a.value重新设置值100的时候，会再次进入__setattr__方法。
需要注意的地方是，在重写__setattr__方法的时候千万不要重复调用造成死循环。

>>e.g:
    def __setattr__(self, name, value)
         self.name = value
         
这是个死循环。当我们实例化这个类的时候，会进入__init__，然后对value进行设置值，设置值会进入__setattr__方法，而__setattr__方法里面又有一个
self.name=value设置值的操作，会再次调用自身__setattr__，造成死循环。

除了上面调用object类的__setattr__避开死循环，还可以如下重写__setattr__避开循环。
"""
print("*"*50)
class E3():
    def __init__(self, value):
        self.value = value

    def __setattr__(self, name, value):
        self.__dict__[name] = value

a3 = E3(10)
print(a3.value)



""" 3、__delattr__
__delattr__是个删除属性的方法
"""
print("\n3、__delattr__")
class E4():
    def __init__(self, value):
        self.value = value

    def __delattr__(self, item):
        object.__delattr__(self, item)

    def __getattr__(self, item):
        return "when can not find attribute into__getattr__"

a4 = E4(10)
print(a4.value)
del a4.value
print(a4.value)

# Python中使用__delattr__清除属性数据
"""
一、 引言
在前面几节我们介绍了__ getattribute__方法和__setattr__方法，分别实现了实例属性的查询和修改（含定义即新增），作为Python中数据操作必不可少的三剑客get、set、delete，get、set都有操作捕获方法，delete一样有对应操作的捕获方法，这个方法就是内置方法__delattr__。

二、 语法释义

语法：实例. delattr（属性名）
直接调用该函数可以删除 ''对应实例'' 的对应实例变量，不能删除 ''类体中定义的方法和类变量'''，否则会报AttributeError；
该函数无返回值，如果出现异常，直接呈现对应异常.
三、 案例

案例说明
案例中定义了类Car，类中有构造方法和drive方法，有2个实例变量power、totaldistance，用该类定义实例对象car，对相关属性执行__delattr__方法，看执行结果。
案例代码及输出（交互模式执行）
"""


"""
案例小结
通过以上案例可以看到：
1)直接用属性名无法执行__delattr__成功，必须用字符串；
2)实例方法无法执行__delattr__；
3)执行成功__delattr__后，字典中对应属性被删除，与直接“del 实例.属性”效果相同。
"""