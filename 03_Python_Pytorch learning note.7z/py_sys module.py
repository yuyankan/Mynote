
# Python中sys模块:
# 该模块提供对解释器使用或维护的一些变量的访问，以及与解释器强烈交互的函数。它始终可用。

"""sys.getrefcount（对象）
返回对象的引用计数。返回的计数通常比您预期的高一个，因为它包含（临时）引用作为参数getrefcount()。"""


"""
https://blog.csdn.net/qq_38526635/article/details/81739321?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522163296219316780255256853%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=163296219316780255256853&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-1-81739321.first_rank_v2_pc_rank_v29&utm_term=python+sys%E6%A8%A1%E5%9D%97&spm=1018.2226.3001.4187
"""
"""
sys.argv
传递给Python脚本的命令行参数列表。argv[0]是脚本名称（依赖于操作系统，无论这是否是完整路径名）。如果使用-c解释器的命令行选项执行命令，
argv[0]则将其设置为字符串’-c’。如果没有脚本名称传递给Python解释器，argv[0]则为空字符串。

要循环标准输入或命令行上给出的文件列表，请参阅fileinput模块。

sys.byteorder
本机字节顺序的指示符。这将具有’big’big-endian（最重要的字节优先）平台和’little’little-endian（最不重要的字节优先）平台的价值。

2.0版本中的新功能

sys.builtin_module_names
一个字符串元组，给出了编译到此Python解释器中的所有模块的名称。（此信息不以任何其他方式提供 - modules.keys()仅列出导入的模块。）

sys.call_tracing（func，args )
呼叫func(*args)，同时启用跟踪。跟踪状态被保存，然后恢复。这是从调试器从检查点调用，以递归调试其他一些代码。

sys.copyright
包含与Python解释器相关的版权的字符串

sys._clear_type_cache（）
清除内部类型缓存。类型缓存用于加速属性和方法查找。仅在参考泄漏调试期间使用该函数删除不必要的引用。

此功能仅用于内部和专门用途。

版本2.6中的新功能。

sys._current_frames（）
返回一个字典，将每个线程的标识符映射到调用该函数时该线程中当前活动的最顶层堆栈帧。请注意，traceback模块中的函数可以在给定这样的帧的情况下构建调用堆栈。

这对于调试死锁是最有用的：这个函数不需要死锁线程的协作，只要这些线程的调用堆栈保持死锁，它们就会被冻结。对于非死锁线程返回的帧在调用代码检查帧时可能与该线程的当前活动没有关系。

此功能仅用于内部和专门用途。

2.5版中的新功能。

sys.dllhandle

指定Python DLL句柄的整数。可用性：Windows。

sys.displayhook（值）
如果值不是None，则此函数sys.stdout将其打印到并保存builtin._。

sys.displayhook调用在 交互式Python会话中输入的表达式的结果。可以通过为其分配另一个单参数函数来自定义这些值的显示sys.displayhook。

sys.dont_write_bytecode
如果这是真的，Python将不会尝试在源模块的导入上编写.pyc或.pyo文件。此值最初设置为True或 False取决于-B命令行选项和 PYTHONDONTWRITEBYTECODE
环境变量，但您可以自己设置它来控制字节码文件的生成。

版本2.6中的新功能。

sys.excepthook（类型，值，回溯）
此函数打印出给定的回溯和异常sys.stderr。

当引发异常并且未被捕获时，解释器sys.excepthook使用三个参数调用 ，即异常类，异常实例和回溯对象。在交互式会话中，这发生在控制返回到提示之前;
在Python程序中，这发生在程序退出之前。可以通过为其分配另一个三参数函数来自定义此类顶级异常的处理sys.excepthook。

sys._displayhook_
sys._excepthook_
这些对象包含的原始值displayhook，并excepthook 在程序的开始。它们被保存，以便displayhook和 excepthook情况下可以恢复他们碰巧得到破碎的对象替换。

sys.exc_info（）
此函数返回三个值的元组，这些值提供有关当前正在处理的异常的信息。返回的信息特定于当前线程和当前堆栈帧。如果当前堆栈帧未处理异常，则从调用堆栈帧或其调用
者获取信息，依此类推，直到找到正在处理异常的堆栈帧。这里，“处理异常”被定义为“正在执行或已执行except子句。”对于任何堆栈帧，只能访问有关最近处理的异常的信息。

如果堆栈中的任何位置都没有处理异常，None则返回包含三个值的元组 。否则，返回的值是。它们的含义是：type获取正在处理的异常的异常类型（类对象）;
value获取异常参数（其 关联值或第二个参数，如果异常类型是类对象，则始终为类实例）; traceback 获取一个回溯对象（参见参考手册），
该对象在最初发生异常的位置封装调用堆栈。(type, value, traceback)raise

如果exc_clear()被调用，则此函数将返回三个None值，直到当前线程中引发另一个异常或执行堆栈返回到正在处理另一个异常的帧。

警告： 将回溯返回值分配给处理异常的函数中的局部变量将导致循环引用。这将阻止同一函数中的局部变量或回溯引用的任何内容被垃圾回收。
由于大多数函数不需要访问回溯，因此最好的解决方案是使用类似的方法来仅提取异常类型和值。如果确实需要回溯，请确保在使用后删除它（最好使用 … 语句）或
调用本身不处理异常的函数。exctype, value = sys.exc_info()[:2]tryfinallyexc_info()

注意 从Python 2.2开始，当启用垃圾收集并且它们变得无法访问时，这些周期会自动回收，但是避免创建周期仍然更有效。

sys.exc_clear（）
此函数清除与当前线程中发生的当前或最后一个异常相关的所有信息。调用此函数后， exc_info()将返回三个None值，直到在当前线程中引发另一个异常，或者执行堆栈返回到正在处理另一个异常的帧。

仅在少数几个不明显的情况下才需要此功能。这些包括记录有关最后或当前异常的信息的日志记录和错误处理系统。此函数也可用于尝试释放资源并触发对象最终化，但不保证将释放哪些对象（如果有）。

版本2.3中的新功能。
ys.exc_type
sys.exc_value
sys.exc_traceback

从版本1.5开始不推荐使用：exc_info()改为使用。

由于它们是全局变量，因此它们并不特定于当前线程，因此在多线程程序中它们的使用并不安全。当没有处理异常时，exc_type设置为None，其他两个未定义。

sys.exec_prefix
一个字符串，给出了特定于站点的目录前缀，其中安装了与平台相关的Python文件; 默认情况下，这也是’/usr/local’。这可以在构建时使用configure
脚本的–exec-prefix参数 进行设置。具体来说，所有配置文件（例如 头文件）都安装在目录中，并且安装了 共享库模块，其中XY 是Python的版本号。
pyconfig.hexec_prefix/lib/pythonX.Y/configexec_prefix/lib/pythonX.Y/lib-dynload2.7

sys.executable
一个字符串，给出Python解释器的可执行二进制文件的绝对路径，在有意义的系统上。如果Python无法检索其可执行文件的真实路径，sys.executable则将为空字符串或None。

sys.exit（[ arg ] ）
退出Python。这是通过引发SystemExit 异常来实现的，因此遵循finally语句的子句所指定的清理操作try ，并且可以拦截外层的退出尝试。

可选参数arg可以是一个整数，给出退出状态（默认为零）或其他类型的对象。如果它是整数，则零被认为是“成功终止”，并且任何非零值被贝壳等视为“异常终止”。
大多数系统要求它在0-127范围内，否则会产生不确定的结果。有些系统具有为特定退出代码指定特定含义的约定，但这些通常是不发达的;
Unix程序通常使用2表示命令行语法错误，1表示所有其他类型的错误。如果传递了另一种类型的对象，None则相当于传递零，
并且打印任何其他对象stderr并导致退出代码为1.特别是sys.exit(“some error message”) 发生错误时退出程序的快速方法。

由于exit()最终“only”引发了一个异常，它只会在从主线程调用时退出进程，并且异常不会被截获。

sys.exitfunc
该值实际上不是由模块定义的，但可以由用户（或程序）设置，以指定程序退出时的清理操作。设置时，它应该是无参数功能。解释器退出时将调用此函数。
这样只能安装一个功能; 要允许在终止时调用的多个函数，请使用该atexit模块。

注意 当程序被信号杀死，检测到Python致命内部错误或被调用时，不会调用exit函数os._exit()。

从版本2.4开始不推荐使用：atexit改为使用。

sys.flags
struct sequence 标志公开命令行标志的状态。属性是只读的。

属性	                  旗
debug	              -d
py3k_warning	      -3
division_warning	   -Q
division_new -Qnew
inspect	               -i
interactive         	-i
optimize	         -O 要么 -OO
dont_write_bytecode	   -B
no_user_site	      -s
no_site	                -S
ignore_environment	   -E
tabcheck	       -t 要么 -tt
verbose	                -v
unicode	                -U
bytes_warning	       -b
hash_randomization	  -R
"""