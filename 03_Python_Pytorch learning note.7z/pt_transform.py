
# 二十二种 transforms 图片数据预处理方法
# link: https://zhuanlan.zhihu.com/p/200876072
"""
这篇主要分为几个部分介绍 transforms:

裁剪
旋转和翻转
图像变换
transforms 方法操作
自定义 transforms 方法

由于图片经过 transform 操作之后是 tensor，像素值在 0~1 之间，并且标准差和方差不是正常图片的。所以定义了transform_invert()方法。
功能是对 tensor 进行反标准化操作，并且把 tensor 转换为 image，方便可视化。

我们主要修改的是transforms.Compose代码块中的内容，其中transforms.Resize((224, 224))是把图片缩放到 (224, 224)
大小 (下面的所有操作都是基于缩放之后的图片进行的)，然后再进行其他 transform 操作。

"""
# 裁剪
"""
transforms.CenterCrop
torchvision.transforms.CenterCrop(size)
功能：从图像中心裁剪图片

size: 所需裁剪的图片尺寸
transforms.CenterCrop(196)的效果如下：
"""
#如果裁剪的 size 比原图大，那么会填充值为 0 的像素。`transforms.CenterCrop(512)`的效果如下
"""*****************************************************************************************"""
## transforms.RandomCrop
"""
torchvision.transforms.RandomCrop(size, padding=None, pad_if_needed=False, fill=0, padding_mode='constant')
功能：从图片中随机裁剪出尺寸为 size 的图片，如果有 padding，那么先进行 padding，再随机裁剪 size 大小的图片。

size:
padding: 设置填充大小
当为 a 时，上下左右均填充 a 个像素
当为 (a, b) 时，左右填充 a 个像素，上下填充 b 个像素
当为 (a, b, c, d) 时，左上右下分别填充 a，b，c，d


pad_if_need: 当图片小于设置的 size，是否填充
padding_mode:
constant: 像素值由 fill 设定
edge: 像素值由图像边缘像素设定
reflect: 镜像填充，最后一个像素不镜像。([1,2,3,4] -> [3,2,1,2,3,4,3,2])
symmetric: 镜像填充，最后一个像素也镜像。([1,2,3,4] -> [2,1,1,2,3,4,4,4,3])
fill: 当 padding_mode 为 constant 时，设置填充的像素值

transforms.RandomCrop(224, padding=16)的效果如下，这里的 padding 为 16，所以会先在 4 边进行 16 的 padding，默认填充 0，
然后随机裁剪出 (224,224) 大小的图片，这里裁剪了左上角的区域。

`transforms.RandomCrop(224, padding=(16, 64))`的效果如下，首先在左右进行 16 的 padding，上下进行 64 的 padding，然后随机裁剪出 (224,224) 大小的图片。

"""

# ## transforms.FiveCrop(TenCrop)
"""
>> torchvision.transforms.FiveCrop(size)
>> torchvision.transforms.TenCrop(size, vertical_flip=False)
# 功能：FiveCrop在图像的上下左右以及中心裁剪出尺寸为 size 的 5 张图片。Tencrop对这 5 张图片进行水平或者垂直镜像获得 10 张图片。
#
# size: 最后裁剪的图片尺寸
# vertical_flip: 是否垂直翻转

由于这两个方法返回的是 tuple，每个元素表示一个图片，我们还需要把这个 tuple 转换为一张图片的tensor。代码如下：
>> transforms.FiveCrop(112),
>> transforms.Lambda(lambda crops: torch.stack([(transforms.ToTensor()(crop)) for crop in crops]))
"""


##transforms.Normalize
"""

torchvision.transforms.Normalize(mean, std, inplace=False)
功能：逐 channel 地对图像进行标准化

output = ( input - mean ) / std

mean: 各通道的均值
std: 各通道的标准差
inplace: 是否原地操作
该方法调用的是F.normalize(tensor, self.mean, self.std, self.inplace)

而``F.normalize()`方法如下：

def normalize(tensor, mean, std, inplace=False):
    if not _is_tensor_image(tensor):
        raise TypeError('tensor is not a torch image.')

    if not inplace:
        tensor = tensor.clone()

    dtype = tensor.dtype
    mean = torch.as_tensor(mean, dtype=dtype, device=tensor.device)
    std = torch.as_tensor(std, dtype=dtype, device=tensor.device)
    tensor.sub_(mean[:, None, None]).div_(std[:, None, None])
    return tensor

首先判断是否为 tensor，如果不是 tensor 则抛出异常。然后根据inplace是否为 true 进行 clone，接着把 mean 和 std 都转换为 tensor (原本是 list)，
最后减去均值除以方差：tensor.sub_(mean[:, None, None]).div_(std[:, None, None])

对数据进行均值为 0，标准差为 1 的标准化，可以加快模型的收敛。
"""

