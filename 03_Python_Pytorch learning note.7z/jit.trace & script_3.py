"""5、trace、script模型save和load

a)、保存的模型文件包含代码、参数、属性特征以及debug信息，也就是说保存的模型文件包含所有模型需要的信息

b)、所以这个模型文件可以在任何独立的进程中独立运行,甚至是和python运行环境完全不相关的环境中运行

"""

"""
i. 保存模型

# 保存模型
rnn_loop.save("./models/rnn_loop.pth")

ii. 加载模型
# 加载模型
loaded = torch.jit.load("./models/rnn_loop.pth")

iii. 测试模型
# 测试模型
print(loaded(xs))
%timeit loaded(xs)


"""