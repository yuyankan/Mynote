""" 反射
你可以通过定义魔法方法来控制用于反射的内建函数 isinstance 和 issubclass 的行为。下面是对应的魔法方法：

__instancecheck__(self, instance)
检查一个实例是否是你定义的类的一个实例（例如 isinstance(instance, class) ）。!!!!

__subclasscheck__(self, subclass)
检查一个类是否是你定义的类的子类（例如 issubclass(subclass, class) ）。

这几个魔法方法的适用范围看起来有些窄，事实也正是如此。我不会在反射魔法方法上花费太多时间，因为相比其他魔法方法它们显得不是很重要。但是它们展示了在
Python中进行面向对象编程（或者总体上使用Python进行编程）时很重要的一点：不管做什么事情，都会有一个简单方法，不管它常用不常用。这些魔法方法可能看起来
没那么有用，但是当你真正需要用到它们的时候，你会感到很幸运，因为它们还在那儿。

"""

"""abc --- 抽象基类
该模块提供了在 Python 中定义 抽象基类 (ABC) 的组件，在 PEP 3119 中已有概述。查看 PEP 文档了解为什么需要在 Python 中增加这个模块。
（也可查看 PEP 3141 以及 numbers 模块了解基于 ABC 的数字类型继承关系。)

collections 模块中有一些派生自 ABC 的具体类；当然这些类还可以进一步被派生。此外，collections.abc 子模块中有一些 ABC 
可被用于测试一个类或实例是否提供特定的接口，例如它是否可哈希或它是否为映射等。

该模块提供了一个元类 ABCMeta，可以用来定义抽象类，另外还提供一个工具类 ABC，可以用它以继承的方式定义抽象基类。
"""

"""1. class abc.ABC
一个使用 ABCMeta 作为元类的工具类。抽象基类可以通过从 ABC 派生来简单地创建，这就避免了在某些情况下会令人混淆的元类用法，例如：
"""
from abc import ABC
class MyABC(ABC):
    pass

"""
注意 ABC 的类型仍然是 ABCMeta，因此继承 ABC 仍然需要关注元类使用中的注意事项，比如可能会导致元类冲突的多重继承。
当然你也可以直接使用 ABCMeta 作为元类来定义抽象基类，例如：
"""

from abc import ABCMeta
class MyABC2(metclass=ABCMeta):
    pass


"""2. class abc.ABCMeta
用于定义抽象基类（ABC）的元类。

使用该元类以创建抽象基类。抽象基类可以像 mix-in 类一样直接被子类继承。你也可以将不相关的具体类（包括内建类）和抽象基类注册为“抽象子类” —— 
这些类以及它们的子类会被内建函数 issubclass() 识别为对应的抽象基类的子类，但是该抽象基类不会出现在其 MRO（Method Resolution Order，方法解析顺序）中，
抽象基类中实现的方法也不可调用（即使通过 super() 调用也不行）。!!!!!!!
"""

"""2.1 使用 ABCMeta 作为元类创建的类含有如下方法：

2.1: register(subclass)
将“子类”注册为该抽象基类的“抽象子类”，例如：
"""
from abc import ABC
class MyABC3(ABC):
    pass

MyABC3.register(tuple)

assert issubclass(tuple, MyABC)
assert isinstance(tuple, MyABC)
"""
在 3.3 版更改: 返回注册的子类，使其能够作为类装饰器。
在 3.4 版更改: 你可以使用 get_cache_token() 函数来检测对 register() 的调用。

你也可以在虚基类中重载这个方法。
"""

"""_2.2 _subclasshook__(subclass)
（必须定义为类方法。）

检查 subclass 是否是该抽象基类的子类。也就是说对于那些你希望定义为该抽象基类的子类的类，你不用对每个类都调用 register() 方法了，
而是可以直接自定义 issubclass 的行为。（这个类方法是在抽象基类的 __subclasscheck__() 方法中调用的。）

该方法必须返回 True, False 或是 NotImplemented。如果返回 True，subclass 就会被认为是这个抽象基类的子类。如果返回 False，
无论正常情况是否应该认为是其子类，统一视为不是。如果返回 NotImplemented，子类检查会按照正常机制继续执行。
为了对这些概念做一演示，请看以下定义 ABC 的示例：
"""
from abc import abstractmethod
class Foo:
    def __getitem__(self, index):
        pass
    def __len__(self):
        pass

    def get_iterator(self):
        return iter(self)

class MyIterable(ABC):
    @abstractmethod
    def __iter__(self):
        while False:
            yield None

    def get_iterator(self):
        return self.__iter__()

    @classmethod
    def __subclasshook__(cls, C):
        if cls is MyIterable:
            if any("__iter__" in B.__dict__ for B in C.__mro__):
                return True
            return NotImplemented

MyIterable.register(Foo)
print(issubclass(Foo, MyIterable)) # True


# ABC MyIterable : 定义了标准的迭代方法 __iter__() 作为一个抽象方法。这里给出的实现仍可在子类中被调用
"""
ABC MyIterable 定义了标准的迭代方法 __iter__() 作为一个抽象方法。这里给出的实现仍可在子类中被调用。get_iterator() 方法也是 
MyIterable 抽象基类的一部分，但它并非必须被非抽象派生类所重载。

这里定义的 __subclasshook__() 类方法指明了任何在其 __dict__ (或在其通过 __mro__ 列表访问的基类) 中具有 __iter__() 方法的类也都会被视为 MyIterable

最后，末尾行使得 Foo 成为 MyIterable 的一个虚子类，即使它没有定义 __iter__() 方法（它使用了以 __len__() 和 __getitem__() 
术语定义的旧式可迭代对象协议）。 请注意这将不会使 get_iterator 成为 Foo 的一个可用方法，它是被另外提供的。
"""

#3. abc 模块还提供了这些装饰器：
"""

3.1:@abc.abstractmethod
用于声明抽象方法的装饰器。

使用此装饰器要求类的元类是 ABCMeta 或是从该类派生。一个具有派生自 ABCMeta 的元类的类不可以被实例化，除非它全部的抽象方法和特征属性均已被重载。
抽象方法可通过任何普通的“super”调用机制来调用。 abstractmethod() 可被用于声明特性属性和描述器的抽象方法。

不支持动态添加抽象方法到一个类，或试图在方法或类被创建后修改其抽象状态等操作。 abstractmethod() 只会影响使用常规继承所派生的子类；通过 ABC 的 register() 方法注册的“虚子类”不会受到影响。

当 abstractmethod() 与其他方法描述符配合应用时，它应当被应用为最内层的装饰器，如以下用法示例所示:
"""
"""
class C(ABC):
    @abstractmethod
    def my_abstract_method(self, ...):
        ...
    @classmethod
    @abstractmethod
    def my_abstract_classmethod(cls, ...):
        ...
    @staticmethod
    @abstractmethod
    def my_abstract_staticmethod(...):
        ...

    @property
    @abstractmethod
    def my_abstract_property(self):
        ...
    @my_abstract_property.setter
    @abstractmethod
    def my_abstract_property(self, val):
        ...

    @abstractmethod
    def _get_x(self):
        ...
    @abstractmethod
    def _set_x(self, val):
        ...
    x = property(_get_x, _set_x)

"""
"""
为了能正确地与抽象基类机制实现互操作，描述符必须使用 __isabstractmethod__ 将自身标识为抽象的。 通常，如果被用于组成描述符的任何方法都是抽象的
则此属性应当为 True。 例如，Python 的内置 property 所做的就等价于:
"""
class Descriptor:
    @property
    def __isabstractmethod__(self):
        return any(getattr(f, "__isabstractmethod", False) for f in (self.fget, self._fget, self._fdel))

   """ 注解:
    不同于Java抽象方法，这些抽象方法可能具有一个实现。 这个实现可在重载它的类上通过super()机制来调用。 这在使用协作多重继承的框架中可以被用作超调用的一个端点。
   """

"""3.2: abc 模块还支持下列旧式装饰器:
@abc.abstractclassmethod:
>>3.2 新版功能.

>>3.3 版后已移除: 现在可以让 classmethod 配合 abstractmethod() 使用，使得此装饰器变得冗余。
内置 classmethod() 的子类，指明一个抽象类方法。 在其他情况下它都类似于 abstractmethod()。
这个特殊情况已被弃用，因为现在 classmethod() 当将装饰器应用于抽象方法时它会被正确地标识为抽象的:

class C(ABC):
    @staticmethod
    @abstractmethod
    def my_abstract_staticmethod(...):
"""

"""3.3 @abc.abstractproperty
3.3 版后已移除: 现在可以让 property, property.getter(), property.setter() 和 property.deleter() 配合 abstractmethod() 使用，使得此装饰器变得冗余。

内置 property() 的子类，指明一个抽象特性属性。

这个特例已被弃用，因为现在当 property() 装饰器应用于抽象方法时它会被正确地标识为抽象的:

class C(ABC):
    @property
    @abstractmethod
    def my_abstract_property(self):
        ...
上面的例子定义了一个只读特征属性；你也可以通过适当地将一个或多个下层方法标记为抽象的来定义可读写的抽象特征属性:

class C(ABC):
    @property
    def x(self):
        ...

    @x.setter
    @abstractmethod
    def x(self, val):
        ...
如果只有某些组件是抽象的，则只需更新那些组件即可在子类中创建具体的特征属性:

class D(C):
    @C.x.setter
    def x(self, val):
        ...
"""

"""4. abc 模块还提供了这些函数：abc.get_cache_token()
返回当前抽象基类的缓存令牌

此令牌是一个不透明对象（支持相等性测试），用于为虚子类标识抽象基类缓存的当前版本。 此令牌会在任何 ABC 上每次调用 ABCMeta.register() 时发生更改。

3.4 新版功能.
备注: C++ 程序员需要注意：Python 中虚基类的概念和 C++ 中的并不相同。

"""

