
#python 中 的 memoize 和 memoized
"""
python 中编写递归函数时，为减少计算时间，需要用到 memoize 或 memoized 功能。

它们的作用是：记忆函数每次运行的结果，当递归函数每次递归时，若已经计算过子函数，就直接从记忆中的结果获取，避免重复计算。

在使用这个功能时，一般在程序前面加个 memoized 的类（这个类可以直接复制别人写好的代码）就行，然后在定义递归函数时前面加上 @memoized

例如斐波那契函数，没有使用 memoized 功能的计算时间为 41 秒，使用后计算时间为 0秒。
"""
import collections
import functools

class memoized():
    """
    Decorator. Caches a function's return value each time it is called.
    If called later with the same arguments, the cached value is returned
    (not reevaluated).
    """

    def __init__(self, func):
        self.func = func
        self.cache = {}

    def __call__(self, *args):
        if not isinstance(args, collections.Hashable):
            # uncacheable. a list, for instance
            # better to not cattche than blow up.
            return  self.func(*args)

        if args in self.cache:
            return self.cache[args]
        else:
            value = self.func(*args)
            self.cache[args] = value
            return value

    def __repr__(self):
        """Return the functions's docstring."""
        return self.func.__doc__

    def __get__(self, obj, objtype):
        """Support instance methods"""
        return functools.partial(self.__call_, obj) # functools.partial(fun, 'parameter'): change function:
        # 'fun''s default 'parameter' value, return a new func with new default parameter value.



"""**************************************************************************************************************"""

def Myclass():

    @memoized
    def __init__(bias, a, b):
        t = torch.addmm(bias, a, b)
        print(t.shape)
        return(a+b)



