"""深拷贝分析:
深拷贝比浅拷贝符合人类的直觉，代价就是深拷贝实在是太慢了.Python 深拷贝这么慢，其大体结构为:

"""
# deepcopy函数源码
import copy
from copy import deepcopy
def deepcopy(x, memo=None, _nil=[]):
    """Deep copy operation on arbitrary Python objects.
    See the module's __doc__ string for more info.
    """
    if memo is None:
        memo = {}
        # memo 用于记录对象是否被复制过了, 可以防止对象出现循环引用导致无限复制的情景.

    d = id(x)
    y = memo.get(d, _nil)
    """
    Python：字典的get()方法使用: 字典-d.get(argument a, argument2 b):
    表示：若是字典d中包含键"a"，则返回键"a"的键值，若不包含键"a"，则返回b。
    即get()函数的第二个参数设置的就是字典中不包含该键时，get()函数的返回值。
    若是不设置第二个参数，则默认返回None
    """
    if y is not _nil: # id(x) already in memo{}
        return y  # y = memo[id(x)]-->如果memo{}中已经有id(x)这个键， def deepcopy返回值为 memo[id(x)]
    # continue below code when y is _nil (do not return y)
    cls = type(x)

    copier =copy._deepcopy_dispatch.get(cls) # 一些内置的数据类型有特定的复制函数, 比如list等, 在copy.py中可以找到其定义.
    """
    其中 memo 保存着所有拷贝过的对象。为什么要设置 memo 呢？在某些特殊情况下，一个对象的相关对象可以指向它自己，比如双向链表。
    如果不将拷贝过的对象存着，那程序将陷入死循环。
    
    另外一个值得注意的点是 copier = _deepcopy_dispatch.get(cls)，这行代码根据待拷贝对象的类型，选择相应的拷贝函数。可选的拷贝函数有：
    用于拷贝基本数据类型的 _deepcopy_atomic, 用于拷贝列表的 _deepcopy_list，用于拷贝元组 _deepcopy_tuple，
    用于拷贝字典 的 _deepcopy_dict，用于拷贝自定义对象的 _deepcopy_inst 等等。
    
    其中比较重要的拷贝函数 __deepcopy_inst 代码如下所示：如果对象有 _ _ deepcopy _ _ 函数，则使用该函数进行拷贝；如果没有，
    那么先拷贝初始构造参数，然后构造一个对象，再拷贝对象状态。
    """
    if copier:
       y = copier(x, memo) # add x into memo






"""
1. python issubclass() function is used to check if a class is a subclass of another class or not.
Python的issubclass（）函数语法为：issubclass(class, classinfo)
This function returns True if class is a subclass of classinfo.
"""