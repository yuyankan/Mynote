""" 1. python abstractmethod
就是保证baseclass的方法在subclass里面必须定义

2. 抽象方法abstract method表示基类(base class)的一个方法，没有实现，所以基类不能实例化，子类只有实现了该抽象方法才能被实例化。
定义包含抽象方法的基类时，要显式说明metaclass=ABCMeta，这样才能保证只有实现了抽象方法的子类才能实例化

3. Python 除了内置的 @classmethod 类方法与 @staticmethod 静态方法, 还有标准模块 abc 提供的 @abstractmethod 抽象方法

"""

# ====Example 1: abstractmethod ================
""" 要在 Python 类中使用抽象方法, 首先要继承 abc.ABC, 然后给实例方法加上装饰器 @abstractmethod, 这样该类不能被直接实例化, 要想使用该类,
应继承该类并实现所有的抽象方法
"""
from abc import ABC, abstractmethod


class Animal(ABC):  # 定义包含抽象方法的基类时, 要显式说明metaclass=ABCMeta或 ABC
    @abstractmethod
    def info(self):
        print('\nHi,base class: Animal')



class Bird(Animal):
    # 实现抽象方法
    def info(self):
        # call base class method:(even is abstract method)
        super().info()
        print('subclass: Bird')


# create class case based on baseclass directly:
#animal = Animal()  # --->TypeError: Can't instantiate abstract class Animal with abstract method info"""

# create clase case based on subclass with all baseclass abstract method===
bird = Bird()
"""在派生类中实现所有基类的抽象方法后, 便可实例化"""
bird.info()

# == example2====
