""" copy, deepcopy"""


"""
在 Python 中, 我们有两种拷贝对象的方式：浅拷贝和深拷贝。浅拷贝和深拷贝都可以在 copy 模块中找到, 其中 copy.copy() 进行浅拷贝操作,
copy.deepcopy() 进行深拷贝操作。

1.浅拷贝是在另一块地址中创建一个新的对象，但是新对象内的子对象引用指向源对象的子对象。如果这时候我们修改源对象的子对象的属性, 新对象中子对象的属性也会改变。

2. 为了获取一个和源对象没有任何关系的全新对象，我们需要深拷贝。深拷贝是在另一块地址中创建一个新的对象，同时对象内的子对象也是新开辟的，和源对象对比仅仅是值相同。
"""


"""  深拷贝比浅拷贝符合人类的直觉，代价就是深拷贝实在是太慢了。下面代码中，case1 和 case2 是等价的。在我的机器上测试，case1 不到一秒，而 case2 
则达到了 十秒。"""

import time
import copy
import numpy as np
class A():
     def __init__(self):
         self.array = [1, 2, 3]

s1 = time.time()
a = [A() for i in np.arange(100000)]
#print(a[0].array)
a[10].array[0] = 100
e1 = time.time()
t1 = e1 - s1
print("%s" %t1)

# case 1:
b = [A() for i in np.arange(100000)]
s2 = time.time()
for i in np.arange(100000):
    for j in np.arange(3):
        b[i].array[j] = a[i].array[j]
e2 = time.time()
t2 = e2 - s2
print("copy time: %s" %t2)

#case 2:
s3 = time.time()
c = copy.deepcopy(a)
e3 = time.time()
t3 = e3 - s3
print("deepcopy time: %s" %t3)





