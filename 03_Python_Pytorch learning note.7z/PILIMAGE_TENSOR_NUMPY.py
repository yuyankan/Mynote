# =====1 NUMPY TO tensor : HWC=====
import numpy as np
from torchvision import transforms as T
import torch

# ===1.1 numpy.shape, numpy.size ======================================================
print('\n1. numpy to tesnor change:  dimenson check: HWC to CHW')
t = np.asarray(1.5)
x = np.ones((100, 200, 2)) *2 # numpy dimension is : HWC
print('1.1 numpy.shape: HWC: {}\n    numpy.value: {} '.format(x.shape, x[0][0]))  # for numpy:  np.shape() is dimension

# print('numpy.size', x.size)  # for numpy: np.size is the 'total element number' in array (not, not np.size(), while
# tensor is: tensor.size()

# ====1.2 numpy to tensor : CHW=========
x_tensor = T.ToTensor()(x)
print('1.2 numpy to tensor.shape: CHW: {}\n     tensor.value: {}'.format( x_tensor.shape, x_tensor[0][0][0]))
# tensor.shape : tensor dimension；  dimension is CHW
# print('x_tensor.size: ', x_tensor.size())  # tensor.size(),  method of tensor shape, also output tensor dimension.
# tensor中， size()是shape 的方法，tensor.shape, & tensor.size()输出都是维数。
# numpy 中， size, shape 都是 numpy 的属性， 输出不同。

#\n tesnor change to numpy :  dimenson check: CHW to CHW: no change!!!'
x_numpy = x_tensor.numpy()
print('1.3 tensor to numpy: dimension: CHW', x_numpy.shape)

# =======2 NUMPY TO PIL , remove channle C====================================================================
print('\n2. numpy to PIL change:  dimenson check')
x = np.ones((100, 200, 2))  # numpy dimension is : HWC
print('2.1 numpy shape: HWC', x.shape)
x_pil = T.ToPILImage()(np.uint8(x))  # np.uint8(x) is must, for meeting data type
print('2.2 numpy to PIL: function: remove channel C: WH', x_pil.size)  # no pil.shape .....-->remove channel dimension C

# == 2.1 PIL to numpy====
x_numpy = np.array(x_pil)
print('2.3 PIL-->NUMPY: recover channel: HWC  how??', x_numpy.shape)  # channel recover?????

# ==============3 tensor to PIL ===================================================================================
print('\n3. TENSOR TO PIL: dimension change check')
x_tensor = torch.ones(2, 100, 200)
print('3.1 Tensor shape: CHW', x_tensor.shape)
x_pil = T.ToPILImage()(x_tensor)
print('3.2 tensor to pile: remove channel: WH', x_pil.size)
# ====3.2: PIL to tensor =====
x_tensorr = T.ToTensor()(x_pil)
print('3.3 pil to tensor: recover channel: CHW how??', x_tensorr.shape) # recover channel????
