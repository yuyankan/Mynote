# 1、什么是描述符——descriptor以及相关的一系列定义
# (1): 描述符:
""" 某个类，只要是内部定义了方法 __get__, __set__, __delete__ 中的一个或多个，就可以称为描述符，描述符的本质是一个类。"""

# (2): 描述符协议:
""" :描述符本质就是一个新式类,在这个新式类中,至少实现了__get__(),__set__(),__delete__()中的一个,这些魔术方法也被称为描述符协议"""

# （3）非数据描述符:
""" 一个类，如果只定义了 __get__() 或者是__delete__()方法，而没有定义 __set__()方法，则认为是非数据描述符(即没有定义__set__)"""

# （4）数据描述符：
""" 一个类，不仅定义了 __get__() 方法，还定义 __set__(), __delete__() 方法，则认为是数据描述符(即定义了__get__和__set__
"""

# （5）描述符对象：
"""描述符（即一个类，因为描述符的本质是类）的一个对象，一般是作为其他类对象的属性而存在"""

# 2、描述符的作用
"""
描述符就是一个“绑定行为“的对象属性，在描述符协议中，它可以通过方法充写属性的访问。我们或许经常看见描述符的作用描述中，有两个关键词“绑定行为”和“托管属性”，
"""
# (1): 绑定行为：
"""所谓的绑定行为，是指在属性的访问、赋值、删除时还绑定发生了其他的事情，正如前面属性控制三剑客所完成的事情一样；"""
# (2): 托管属性: python描述符是一种创建“托管属性”的方法，
""" 即通过描述符（类）去托管另一个类的相关属性，也可以说是类的属性的一个代理。
以人类而言，Person是一个类，人应该有很多属性，比如人是美丽的、性感的、成熟的、博学的、大方的等等，所谓的“描述”，本身指的就是描述某一个类的某一些特性的，
在程序设计中，属性就是用来描述类的特征的，所谓的描述符（描述类）就是专门再创建一个类，让这个类去描述本身那个类的相关属性，这也正是“描述”二字的由来，
其实和我们生活中的描述是一个意思.
"""

# 描述符的作用是用来代理另外一个类的属性的

"""******************************************************************"""
# 3、描述符三个函数的定义形式：

# 3.1 def __get__(self, instance, owner):
"""
self:指的是描述符类的实例: 使用描述符的类的某个属性
instance：指的是使用描述符的那个类的实例，如student。下面的instance一样的意思。
owner：指的是使用描述符的那个类，如Student
"""
# 3.2，def __set__(self, instance, value)
""" 给使用描述符的类的实例instance, 的属性'self'， 赋值value"""
# 3.3：def __delete__(self, instance,)

"""******************************************************************"""
# 二、描述符的具体实现

# 前面讲了，要实现所谓的描述符，就是要实现上面的三个魔术方法，但是和普通类定义的方式不一样，因为“属性代理（属性托管）”的机制，
# 我们需要定一两个类，一个类A，一个ADescriptor类，即所谓的描述类。

# 1、从一个简单的实例说起——认识描述符
#人的性格描述，悲观的？开朗的？敏感的？多疑的？活泼的？等
class CharacterDescriptor():
    def __init__(self, value):
        print("1.CharacterDescriptor:  __init__ is called")
        self.value = value

    def __get__(self, instance, owner): # note: self in this class means: class 实例-defined actually by __new__
        print("2. CharacterDescriptor:get: visit CharacterDescriptor of owner's instance") # owner: class  that use this decriptor
        return self.value

    def __set__(self, instance, value):
        print('3. CharacterDescriptor: setting character value')
        self.value = value


# 人的体重描述，超重？过重？肥胖？微胖？合适？偏轻？太瘦？等等
class WeightDescriptor:
    def __init__(self, value):
        print("2.1.weightDescriptor: __init__ is called")
        self.value = value

    def __get__(self, instance, owner):
        print("2.2.weightDescriptor: Visit Weight")
        return self.value

    def __set__(self, instance, value):
        print("2.3.weightDescriptor: setting weight")
        self.value = value

# above two is descriptor, while below: class Person is the class use descriptor,
# and this class 's dict : character, weight is:descripted by above descriptor
class Person:
    print("\n")
    print("*" * 50)
    character = CharacterDescriptor('Optimistic')
    weight = WeightDescriptor(150) # note: WeightDescroptor 的实例就是weight: value = 50

print("*"*50)
p = Person()
print("*"*50)
print(p.character)
print("*"*50)
print(p.weight)


print("*" * 50)
print("\n")
p.character = 'Hi'  # will call descriptor : CharacoterDescriptor, __set__method.
print(p.character)  # will call descriptor: CharacoterDescriptor, __get__method.

"""

称描述符为“属性代理”了吧，他其实就是专门用一个类去装饰某一个属性，我可以把这个属性定义成任何我想要的样子，所谓的“一对一定制属性”。人有体重和性格这
两个属性，当然我可以把这两个属性都定义在Person类里面，但是这就不方便为这个属性的操作绑定相应的行为，进行任意的个性化定制属性了，你也许会说，
我依然可以通过“属性控制三剑客”完成啊，参见上一篇文章：

python高级编程——描述符Descriptor详解（中篇）——python对象的属性访问优先级与属性的控制与访问）

但是“属性控制三剑客”的缺点就是无法“一对一定制”，他虽然可以为属性绑定行为，但是任何属性都会绑定，不太方面将一个属性定制成任意我想要的样子。

"""

"""
实际上完成了不就是Person的一个类属性本质上就是属性描述类的一个实例对象啊！哦，原来如此，的确如此，但是需要注意的是，在访问Person的这个类属性的时候，
会发生一些特别的事情。因为我们发现，我们打印的print(p.character)中的character应该是CharacterDescriptor类的实例对象，为什么会打印出一个具体的值呢？这是因为：

访问Person的character属性时，调用了描述符CharacterDescriptor类的__get__()方法。这就达到了描述符的作用。
"""
# 总结：对于类属性描述符，如果解析器发现属性property是一个描述符的话，它能把Class.x转换成Class.__dict__[‘property’].__get__(None, Class)来访问。

#总结：
#（1）对于类装饰器属性，只要出现属性访问（不管是通过对象访问还是类名访问），都会优先调用装饰器的__get__方法;
#（2）对于类装饰器属性，若出现属性修改（不管是通过对象访问还是类名访问），都会优先调用装饰器的__set__方法;
#（3）对于类装饰器属性，若出现属性删除（不管是通过对象访问还是类名访问），都会优先调用装饰器的__delete__方法;

# 2、实例属性描述符
"""两个描述符类的代码不变，仅仅改变Person类的代码，如下："""
print("\n")
print("*"*50)
print("*"*50)
print("*"*50)
class Person2: # class could save '()', while class instance could not
    # Note: __init__ 内的参数/属性， 都是 类-实例 的属性。
    #__init__外定义的属性/方法， 是 类 的属性/方法

    def __init__(self):
        print("Person2: __init__ is called")
        self.character = CharacterDescriptor("Optimistic")
        self.weight = WeightDescriptor(150)

p2 = Person2() # '()' have to use here to make class instance, to mean it's a class, otherwise will only rename class Person2 as p2
print(p2.character)

"""运行结果为:
<__main__.CharacterDescriptor object at 0x0000018444CE8940>
并没有像我们预期的那样调用__get__()、__set__()、__delete__()方法，只是说他是Descriptor的一个对
"""
#总结：描述符是一个类属性，必须定义在类的层次上, 而不能单纯的定义为对象属性。
"""
通过上面的这几个例子，现在应该可以好好体会到“描述符”的两个层面的作用了：

绑定行为：在访问雷属性的时候，会打印出很多的额外信息，这不就是在添加额外的行为吗？

属性代理(托管属性)：将某个属性专门用一个描述符（描述类）加以托管，实现任意的定制化，一对一的定制属性
"""

# 3、类属性描述符对象和实例属性同名时
""" 描述符针对的是类属性，但是当一个类中，如果类属性是描述符对象，而实例属性由于这个描述符属性同名，这该怎么办呢？"""
print("\n")
print("*"*50)
print("*"*50)
print("*"*50)
print("*"*50)
class Person3:

    def __init__(self, character, weight): # run this once start creating class instance
        # __init__parameter come from instance, not from 类属性： above character = CharacterDescriptor("Hi, Hi")
        print("Person3: __init__ is called")
        self.character = character # 实例属性self.character : 是类属性: character = CharacterDescriptor
        self.weight = weight # # 实例self.weight : 是类属性: character = weightDescriptor
# below code run, before create instance of Person3；
    character = CharacterDescriptor("Hi, Hi")
    print("character: \n", character)
    print("\n")
    weight = WeightDescriptor(100)
    print("weight: ", weight)
    # above code run, before create class instance

print("\n")
p3 = Person3("passive", 90)
print("\n")
print(p3.weight)
"""运行结果为:
Person3: __init__ is called
3. CharacterDescriptor: setting character value
2.3.weightDescriptor: setting weight


2.2.weightDescriptor: Visit Weight
90
"""


"""
首先是访问了描述符的__set__方法，这是因为在构建对象的时候，相当于为character和weight赋值，然后再调用__get__方法，这是因为访问了类属性
character和weight，但是最终打印出来值却并不是类属性的值，这是因为，实例属性实际上是在“描述符类属性”后面访问的，所以覆盖掉了。

"""

