from torch._jit_internal import _copy_to_script_wrapper
import torch._jit_internal
help(torch._jit_internal)
#help(_copy_to_script_wrapper)
"""

TorchScript is a way to create serializable and optimizable models from PyTorch code. 
Any TorchScript program can be saved from a Python process and loaded in a process where there is no Python dependency.

We provide tools to incrementally transition a model from a pure Python program to a TorchScript program that can be 
run independently from Python, such as in a standalone C++ program. This makes it possible to train models in PyTorch u
sing familiar tools in Python and then export the model via TorchScript to a production environment where Python programs 
may be disadvantageous for performance and multi-threading reasons.

For a gentle introduction to TorchScript, see the Introduction to TorchScript tutorial.

For an end-to-end example of converting a PyTorch model to TorchScript and running it in C++, see the Loading a PyTorch Model in C++ tutorial.
"""

"""
The weak_script annotation needs to be here instead of inside torch/jit/ so it
can be used in other places in torch/ (namely torch.nn) without running into
circular dependency problems
"""

# Help on module torch._jit_internal in torch:
"""


NAME
    torch._jit_internal

DESCRIPTION
    The weak_script annotation needs to be here instead of inside torch/jit/ so it
    can be used in other places in torch/ (namely torch.nn) without running into
    circular dependency problems

CLASSES
    builtins.object
        BroadcastingListCls
        FunctionModifiers
    torch._C._jit_tree_views.SourceRangeFactory(pybind11_builtins.pybind11_object)
        SourceContext
    
    class BroadcastingListCls(builtins.object)
     |  # allows BroadcastingList instance to be subscriptable
     |  
     |  Methods defined here:
     |  
     |  __getitem__(self, types)
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
    
    class FunctionModifiers(builtins.object)
     |  Used to denote the behavior of a function in TorchScript. See export() and
     |  ignore() for details.
     |  
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  COPY_TO_SCRIPT_WRAPPER = 'if this method is not scripted, copy the pyt...
     |  
     |  DEFAULT = 'default (compile if called from a exported function / forwa...
     |  
     |  EXPORT = 'export (compile this function even if nothing calls it)'
     |  
     |  IGNORE = "ignore (leave as a call to Python, cannot be torch.jit.save'...
     |  
     |  UNUSED = 'unused (ignored and replaced with raising of an exception)'
    
    class SourceContext(torch._C._jit_tree_views.SourceRangeFactory)
     |  SourceContext(source, filename, file_lineno, leading_whitespace_len, uses_true_division=True)
     |  
     |  # Thin wrapper around SourceRangeFactory to store extra metadata
     |  # about the function-to-be-compiled.
     |  
     |  Method resolution order:
     |      SourceContext
     |      torch._C._jit_tree_views.SourceRangeFactory
     |      pybind11_builtins.pybind11_object
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, source, filename, file_lineno, leading_whitespace_len, uses_true_division=True)
     |      __init__(self: torch._C._jit_tree_views.SourceRangeFactory, arg0: str, arg1: object, arg2: int, arg3: int) -> None
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from torch._C._jit_tree_views.SourceRangeFactory:
     |  
     |  make_range(...)
     |      make_range(self: torch._C._jit_tree_views.SourceRangeFactory, arg0: int, arg1: int, arg2: int) -> torch._C._jit_tree_views.SourceRange
     |  
     |  make_raw_range(...)
     |      make_raw_range(self: torch._C._jit_tree_views.SourceRangeFactory, arg0: int, arg1: int) -> torch._C._jit_tree_views.SourceRange
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties inherited from torch._C._jit_tree_views.SourceRangeFactory:
     |  
     |  source
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from pybind11_builtins.pybind11_object:
     |  
     |  __new__(*args, **kwargs) from pybind11_builtins.pybind11_type
     |      Create and return a new object.  See help(type) for accurate signature.

FUNCTIONS
    boolean_dispatch(arg_name, arg_index, default, if_true, if_false, module_name, func_name)
        Dispatches to either of 2 script functions based on a boolean argument.
        In TorchScript, the boolean argument must be constant so that the correct
        function to use can be determined at compile time.
    
    can_compile_class(cls) -> bool
    
    check_args_exist(target_type) -> None
    
    container_checker(obj, target_type) -> bool
        # supports List/Dict/Tuple and Optional types
        # TODO support future
    
    copy_torchscript_modifier(orig, new) -> None
    
    createResolutionCallbackForClassMethods(cls)
        This looks at all the methods defined in a class and pulls their closed-over
        variables into a dictionary and uses that to resolve variables.
    
    createResolutionCallbackFromClosure(fn)
        Create a resolutionCallback by introspecting the function instead of
        looking up the stack for the enclosing scope
    
    createResolutionCallbackFromEnv(lookup_base)
        Creates a resolution callback that will look up qualified names in an
        environment, starting with `lookup_base` for the base of any qualified
        names, then proceeding down the lookup chain with the resolved object.
        
        You should not use this directly, it should only be used from the other
        createResolutionCallbackFrom* functions.
    
    createResolutionCallbackFromFrame(frames_up: int = 0)
        Creates a function which, given a string variable name,
        returns the value of the variable in the scope of the caller of
        the function which called createResolutionCallbackFromFrame (by default).
        
        This is used to enable access in-scope Python variables inside
        TorchScript fragments.
        
        frames_up is number of additional frames to go up on the stack.
        The default value is 0, which correspond to the frame of the caller
        of createResolutionCallbackFromFrame. Also for example, if frames_up is set
        to 1, then the frame of the caller's caller of createResolutionCallbackFromFrame
        will be taken.
        
        For example, the following program prints 2::
        
            def bar():
                cb = createResolutionCallbackFromFrame(1)
                print(cb("foo"))
        
            def baz():
                foo = 2
                bar()
        
            baz()
    
    export(fn)
        This decorator indicates that a method on an ``nn.Module`` is used as an entry point into a
        :class:`ScriptModule` and should be compiled.
        
        ``forward`` implicitly is assumed to be an entry point, so it does not need this decorator.
        Functions and methods called from ``forward`` are compiled as they are seen
        by the compiler, so they do not need this decorator either.
        
        Example (using ``@torch.jit.export`` on a method):
        
        .. testcode::
        
            import torch
            import torch.nn as nn
        
            class MyModule(nn.Module):
                def implicitly_compiled_method(self, x):
                    return x + 99
        
                # `forward` is implicitly decorated with `@torch.jit.export`,
                # so adding it here would have no effect
                def forward(self, x):
                    return x + 10
        
                @torch.jit.export
                def another_forward(self, x):
                    # When the compiler sees this call, it will compile
                    # `implicitly_compiled_method`
                    return self.implicitly_compiled_method(x)
        
                def unused_method(self, x):
                    return x - 20
        
            # `m` will contain compiled methods:
            #     `forward`
            #     `another_forward`
            #     `implicitly_compiled_method`
            # `unused_method` will not be compiled since it was not called from
            # any compiled methods and wasn't decorated with `@torch.jit.export`
            m = torch.jit.script(MyModule())
    
    fake_range()
    
    get_annotation_str(annotation)
        Convert an AST node containing a type annotation to the string present in the source
        that represents the same annotation.
    
    get_args(target_type)
    
    get_callable_argument_names(fn) -> List[str]
        Gets names of all POSITIONAL_OR_KEYWORD arguments for callable `fn`.
        Returns an empty list when other types of arguments are present.
        
        This is used by `torch.jit.trace` to assign meaningful argument names to
        traced functions and modules.
        
        Args:
            fn: A callable.
        Returns:
            Argument names: List[str]
    
    get_class_name_lineno(method) -> Tuple[str, int]
    
    get_closure(fn)
        Get a dictionary of closed over variables from a function
    
    get_origin(target_type)
    
    get_static_fn(cls, fn)
    
    get_torchscript_modifier(fn)
    
    get_type_hint_captures(fn)
        Get a dictionary containing type resolution mappings necessary to resolve types
        for the literal annotations on 'fn'. These are not considered to be closed-over by fn
        and must be obtained separately (e.g. using this function).
        
        Args:
            fn: A callable.
        Returns:
            A Dict[str, Any] containing a mapping from the literal annotations used on
            fn to the Python objects they refer to.
    
    ignore(drop=False, **kwargs)
        This decorator indicates to the compiler that a function or method should
        be ignored and left as a Python function. This allows you to leave code in
        your model that is not yet TorchScript compatible. If called from TorchScript,
        ignored functions will dispatch the call to the Python interpreter. Models with ignored
        functions cannot be exported; use :func:`@torch.jit.unused <torch.jit.unused>` instead.
        
        Example (using ``@torch.jit.ignore`` on a method)::
        
            import torch
            import torch.nn as nn
        
            class MyModule(nn.Module):
                @torch.jit.ignore
                def debugger(self, x):
                    import pdb
                    pdb.set_trace()
        
                def forward(self, x):
                    x += 10
                    # The compiler would normally try to compile `debugger`,
                    # but since it is `@ignore`d, it will be left as a call
                    # to Python
                    self.debugger(x)
                    return x
        
            m = torch.jit.script(MyModule())
        
            # Error! The call `debugger` cannot be saved since it calls into Python
            m.save("m.pt")
        
        Example (using ``@torch.jit.ignore(drop=True)`` on a method):
        
        .. testcode::
        
            import torch
            import torch.nn as nn
        
            class MyModule(nn.Module):
                @torch.jit.ignore(drop=True)
                def training_method(self, x):
                    import pdb
                    pdb.set_trace()
        
                def forward(self, x):
                    if self.training:
                        self.training_method(x)
                    return x
        
            m = torch.jit.script(MyModule())
        
            # This is OK since `training_method` is not saved, the call is replaced
            # with a `raise`.
            m.save("m.pt")
        
        .. testcleanup::
        
            import os
            os.remove('m.pt')
    
    is_dict(ann) -> bool
    
    is_final(ann) -> bool
    
    is_future(ann) -> bool
    
    is_ignored_fn(fn) -> bool
    
    is_list(ann) -> bool
    
    is_optional(ann) -> bool
    
    is_scripting() -> bool
        Function that returns True when in compilation and False otherwise. This
        is useful especially with the @unused decorator to leave code in your
        model that is not yet TorchScript compatible.
        .. testcode::
        
            import torch
        
            @torch.jit.unused
            def unsupported_linear_op(x):
                return x
        
            def linear(x):
               if torch.jit.is_scripting():
                  return torch.linear(x)
               else:
                  return unsupported_linear_op(x)
    
    is_static_fn(cls, fn) -> bool
    
    is_tuple(ann) -> bool
    
    module_has_exports(mod)
    
    raise_error_container_parameter_missing(target_type) -> None
    
    should_drop(fn) -> bool
    
    unused(fn)
        This decorator indicates to the compiler that a function or method should
        be ignored and replaced with the raising of an exception. This allows you
        to leave code in your model that is not yet TorchScript compatible and still
        export your model.
        
            Example (using ``@torch.jit.unused`` on a method)::
        
                import torch
                import torch.nn as nn
        
                class MyModule(nn.Module):
                    def __init__(self, use_memory_efficient):
                        super(MyModule, self).__init__()
                        self.use_memory_efficient = use_memory_efficient
        
                    @torch.jit.unused
                    def memory_efficient(self, x):
                        import pdb
                        pdb.set_trace()
                        return x + 10
        
                    def forward(self, x):
                        # Use not-yet-scriptable memory efficient mode
                        if self.use_memory_efficient:
                            return self.memory_efficient(x)
                        else:
                            return x + 10
        
                m = torch.jit.script(MyModule(use_memory_efficient=False))
                m.save("m.pt")
        
                m = torch.jit.script(MyModule(use_memory_efficient=True))
                # exception raised
                m(torch.rand(100))

DATA
    Any = typing.Any
        Special type indicating an unconstrained type.
        
        - Any is compatible with every type.
        - Any assumed to have all methods.
        - All values assumed to be instances of Any.
        
        Note that all the above statements are true from the point of view of
        static type checkers. At runtime, Any should not be used with instance
        or class checks.
    
    BroadcastingList1 = <torch._jit_internal.BroadcastingListCls object>
    BroadcastingList2 = <torch._jit_internal.BroadcastingListCls object>
    BroadcastingList3 = <torch._jit_internal.BroadcastingListCls object>
    BroadcastingList4 = <torch._jit_internal.BroadcastingListCls object>
    BroadcastingList5 = <torch._jit_internal.BroadcastingListCls object>
    BroadcastingList6 = <torch._jit_internal.BroadcastingListCls object>
    Callable = typing.Callable
        Callable type; Callable[[int], str] is a function of (int) -> str.
        
        The subscription syntax must always be used with exactly two
        values: the argument list and the return type.  The argument list
        must be a list of types or ellipsis; the return type must be a single type.
        
        There is no syntax to indicate optional or keyword arguments,
        such function types are rarely used as callback types.
    
    Dict = typing.Dict
        A generic version of dict.
    
    Final = typing.Final
        Special typing construct to indicate final names to type checkers.
        
        A final name cannot be re-assigned or overridden in a subclass.
        For example:
        
          MAX_SIZE: Final = 9000
          MAX_SIZE += 1  # Error reported by type checker
        
          class Connection:
              TIMEOUT: Final[int] = 10
        
          class FastConnector(Connection):
              TIMEOUT = 1  # Error reported by type checker
        
        There is no runtime checking of these properties.
    
    List = typing.List
        A generic version of list.
    
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Tuple = typing.Tuple
        Tuple type; Tuple[X, Y] is the cross-product type of X and Y.
        
        Example: Tuple[T1, T2] is a tuple of two elements corresponding
        to type variables T1 and T2.  Tuple[int, float, str] is a tuple
        of an int, a float and a string.
        
        To specify a variable-length tuple of homogeneous type, use Tuple[T, ...].
    
    Union = typing.Union
        Union type; Union[X, Y] means either X or Y.
        
        To define a union, use e.g. Union[int, str].  Details:
        - The arguments must be types and there must be at least one.
        - None as an argument is a special case and is replaced by
          type(None).
        - Unions of unions are flattened, e.g.::
        
            Union[Union[int, str], float] == Union[int, str, float]
        
        - Unions of a single argument vanish, e.g.::
        
            Union[int] == int  # The constructor actually returns int
        
        - Redundant arguments are skipped, e.g.::
        
            Union[int, str, int] == Union[int, str]
        
        - When comparing unions, the argument order is ignored, e.g.::
        
            Union[int, str] == Union[str, int]
        
        - You cannot subclass or instantiate a union.
        - You can use Optional[X] as a shorthand for Union[X, None].
    
    __annotations__ = {'_overloaded_fns': typing.Dict[str, typing.List[typ...
    boolean_dispatched = <WeakKeyDictionary>
    i = 6

FILE
    d:\software\envs\pytorch\lib\site-packages\torch\_jit_internal.py



Process finished with exit code 0


"""