import builtins
# print(dir())

"""
['__annotations__', '__builtins__', '__cached__', '__doc__', '__file__', '__loader__', '__name__', '__package__', 
'__spec__', 'builtins'] 

"""
# print(dir(__builtins__))

"""" 
['ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException', 'BlockingIOError', 'BrokenPipeError', 
'BufferError', 'BytesWarning', 'ChildProcessError', 'ConnectionAbortedError', 'ConnectionError', 
'ConnectionRefusedError', 'ConnectionResetError', 'DeprecationWarning', 'EOFError', 'Ellipsis', 'EnvironmentError', 
'Exception', 'False', 'FileExistsError', 'FileNotFoundError', 'FloatingPointError', 'FutureWarning', 'GeneratorExit', 
'IOError', 'ImportError', 'ImportWarning', 'IndentationError', 'IndexError', 'InterruptedError', 'IsADirectoryError', 
'KeyError', 'KeyboardInterrupt', 'LookupError', 'MemoryError', 'ModuleNotFoundError', 'NameError', 'None', 
'NotADirectoryError', 'NotImplemented', 'NotImplementedError', 'OSError', 'OverflowError', 
'PendingDeprecationWarning', 'PermissionError', 'ProcessLookupError', 'RecursionError', 'ReferenceError', 
'ResourceWarning', 'RuntimeError', 'RuntimeWarning', 'StopAsyncIteration', 'StopIteration', 'SyntaxError', 
'SyntaxWarning', 'SystemError', 'SystemExit', 'TabError', 'TimeoutError', 'True', 'TypeError', 'UnboundLocalError', 
'UnicodeDecodeError', 'UnicodeEncodeError', 'UnicodeError', 'UnicodeTranslateError', 'UnicodeWarning', 'UserWarning', 
'ValueError', 'Warning', 'WindowsError', 'ZeroDivisionError', '__build_class__', '__debug__', '__doc__', 
'__import__', '__loader__', '__name__', '__package__', '__spec__', 'abs', 'all', 'any', 'ascii', 'bin', 'bool', 
'breakpoint', 'bytearray', 'bytes', 'callable', 'chr', 'classmethod', 'compile', 'complex', 'copyright', 'credits', 
'delattr', 'dict', 'dir', 'divmod', 'enumerate', 'eval', 'exec', 'exit', 'filter', 'float', 'format', 'frozenset', 
'getattr', 'globals', 'hasattr', 'hash', 'help', 'hex', 'id', 'input', 'int', 'isinstance', 'issubclass', 'iter', 
'len', 'license', 'list', 'locals', 'map', 'max', 'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord', 'pow', 
'print', 'property', 'quit', 'range', 'repr', 'reversed', 'round', 'set', 'setattr', 'slice', 'sorted', 
'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip'] 

"""
print('\ncurrent working mode:')
print('__name__:   ', __name__)
print('*'*50)
print('\nmodule type of builtins & __builtins__:')
print('__builtins__:', __builtins__)  # <module 'builtins' (built-in)>
print('builtins    : ', builtins) # <module 'builtins' (built-in)>

"""
print('*'*50)
print('\nmodule name of builtins & __builtins__:')
print('__builtins__.__name__: ', __builtins__.__name__)
print('builtins.__name__    : ', builtins.__name__)
"""

print('*'*50)
print('\ncheck if  builtins ==/ is __builtins__:')
print('builtins == __builtins__: ', builtins == __builtins__)
print(' __builtins__ is builtins: ', __builtins__ is builtins)
print('*'*50)
print('\ncheck id of   builtins & __builtins__:')
print('id (__builtins__): ', id(__builtins__))
print('id (builtins)     :', id(builtins))

print('*'*50)
print('\ncheck if  __builtins__ is builtins.__dict :')
print('__builtins__ is builtins.__dict__:', __builtins__ is builtins.__dict__)

print('builtins.__dic__ is __builtins__', builtins.__dict__ is __builtins__)

