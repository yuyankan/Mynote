# pytorch的两个函数 .detach() .detach_() 的作用和区别
# 前言：当我们再训练网络的时候可能希望保持一部分的网络参数不变，只对其中一部分的参数进行调整；或者值训练部分分支网络，
# 并不让其梯度对主网络的梯度造成影响，这时候我们就需要使用detach()函数来切断一些分支的反向传播

"""一、tensor.detach() """
"""
1. 返回一个新的tensor，从当前计算图中分离下来的，但是仍指向原变量的存放位置,不同之处只是requires_grad为false
，得到的这个tensor永远不需要计算其梯度，不具有grad。

2. 即使之后重新将它的requires_grad置为true,它也不会具有梯度grad

3. 这样我们就会继续使用这个新的tensor进行计算，后面当我们进行反向传播时，到该调用detach()的tensor就会停止，不能再继续向前进行传播

4. 注意：
使用detach返回的tensor和原始的tensor共同一个内存，即一个修改另一个也会跟着改变。

比如正常的例子是：
"""

import torch

a = torch.tensor([1, 2, 3.], requires_grad=True)
print(a.grad)
out = a.sigmoid()

out.sum().backward()
print(a.grad)
""" RUN:
None
tensor([0.1966, 0.1050, 0.0452])
"""
# 1.1 当使用detach()分离tensor但是没有更改这个tensor时，并不会影响backward():
print("*"*50)
import torch

a = torch.tensor([1, 2, 3.], requires_grad=True)
print(a.grad)
out = a.sigmoid()
print(out)

# 添加detach(),c的requires_grad为False
c = out.detach()
print(c)

# 这时候没有对c进行更改，所以并不会影响backward()
out.sum().backward()
print(a.grad)
"""RUN:
None
tensor([0.7311, 0.8808, 0.9526], grad_fn=<SigmoidBackward>)
tensor([0.7311, 0.8808, 0.9526])
tensor([0.1966, 0.1050, 0.0452])
"""
"""
从上可见tensor  c是由out分离得到的，但是我也没有去改变这个c，这个时候依然对原来的out求导是不会有错误的，
即c,out之间的区别是c是没有梯度的，out是有梯度的,但是需要注意的是下面两种情况是汇报错的，"""

# 1.2 当使用detach()分离tensor，然后用这个分离出来的tensor去求导数，会影响backward()，会出现错误
print("1.2*"*50)

import torch

a = torch.tensor([1, 2, 3.], requires_grad=True)
print(a.grad)
out = a.sigmoid()
print(out)

# 添加detach(),c的requires_grad为False
c = out.detach()
print(c)

# 使用新生成的Variable进行反向传播
#c.sum().backward()
print(a.grad)

"""
None
tensor([0.7311, 0.8808, 0.9526], grad_fn=<SigmoidBackward>)
tensor([0.7311, 0.8808, 0.9526])
Traceback (most recent call last):
  File "D:\Exersize\02_DATA LOADER\01_Data loader and dataset\Classification-Model-of-RMB-master\02_test_try\pt_tensor_detach().py", line 73, in <module>
    c.sum().backward()
  File "D:\software\envs\pytorch\lib\site-packages\torch\_tensor.py", line 255, in backward
    torch.autograd.backward(self, gradient, retain_graph, create_graph, inputs=inputs)
  File "D:\software\envs\pytorch\lib\site-packages\torch\autograd\__init__.py", line 147, in backward
    Variable._execution_engine.run_backward(
RuntimeError: element 0 of tensors does not require grad and does not have a grad_fn
tensor([0.1966, 0.1050, 0.0452])
"""

#1.3 当使用detach()分离tensor并且更改这个tensor时，即使再对原来的out求导数，会影响backward()，会出现错误
#如果此时对c进行了更改，这个更改会被autograd追踪，在对out.sum()进行backward()时也会报错，因为此时的值进行backward()得到的梯度是错误的：
print("1.3*"*50)
import torch

a = torch.tensor([1, 2, 3.], requires_grad=True)
print(a.grad)
out = a.sigmoid()
print(out)

# 添加detach(),c的requires_grad为False
c = out.detach()
print(c)
c.zero_()  # 使用in place函数对其进行修改

# 会发现c的修改同时会影响out的值
print(c)
print(out)

# 这时候对c进行更改，所以会影响backward()，这时候就不能进行backward()，会报错
out.sum().backward()
"""RUN:
None
tensor([0.7311, 0.8808, 0.9526], grad_fn=<SigmoidBackward>)
tensor([0.7311, 0.8808, 0.9526])
tensor([0., 0., 0.])
tensor([0., 0., 0.], grad_fn=<SigmoidBackward>)
Traceback (most recent call last):
  File "D:\Exersize\02_DATA LOADER\01_Data loader and dataset\Classification-Model-of-RMB-master\02_test_try\pt_tensor_detach().py", line 111, in <module>
    out.sum().backward()
  File "D:\software\envs\pytorch\lib\site-packages\torch\_tensor.py", line 255, in backward
    torch.autograd.backward(self, gradient, retain_graph, create_graph, inputs=inputs)
  File "D:\software\envs\pytorch\lib\site-packages\torch\autograd\__init__.py", line 147, in backward
    Variable._execution_engine.run_backward(
RuntimeError: one of the variables needed for gradient computation has been modified by an inplace operation: [torch.FloatTensor [3]], which is output 0 of SigmoidBackward, is at version 1; expected version 0 instead. Hint: enable anomaly detection to find the operation that failed to compute its gradient, with torch.autograd.set_detect_anomaly(True).

Process finished with exit code 1

"""

# 二、tensor.detach_()
"""
1. 将一个tensor从创建它的图中分离，并把它设置成叶子tensor

2. 其实就相当于变量之间的关系本来是x -> m -> y,这里的叶子tensor是x，但是这个时候对m进行了m.detach_()操作,其实就是进行了两个操作：
    2.1 将m的grad_fn的值设置为None,这样m就不会再与前一个节点x关联，这里的关系就会变成x, m -> y,此时的m就变成了叶子结点
    2.2 然后会将m的requires_grad设置为False，这样对y进行backward()时就不会求m的梯度
"""

# 三 总结：
"""
其实detach()和detach_()很像，两个的区别就是detach_()是对本身的更改，detach()则是生成了一个新的tensor：
比如x -> m -> y中如果对m进行detach()，后面如果反悔想还是对原来的计算图进行操作还是可以的

但是如果是进行了detach_()，那么原来的计算图也发生了变化，就不能反悔了
"""