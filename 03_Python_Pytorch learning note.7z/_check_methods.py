def _check_methods(c, *methods):
    mro = c.__mro__  # class C's, super class
    print("\nclass c's super class: c.__mro__:\n",mro)
    cr = [] # check result list: True or false for each method
    for method in methods:

        def smethod_check():
            for meth in mro:  # each super class
                print("\nclass c's super class: {}'s __dict__:\n{}".format(meth, meth.__dict__))
                if method in meth.__dict__:  # each super class 's attributes
                    if meth.__dict__[method] is None:
                        print('\n1. {} is in {}, yet no value'.format(method, meth))


                    else:
                        print ('\n2. {} is Implemented in {}'.format(method, meth))
                        return '2. implemented'

                else:
                    print('\n3. {} is not Implemented in {}'.format(method, meth))

                return 'NotImplemented'
        cr.append(smethod_check())
    return cr


methods = ('__dict__', 'int', 'test') # , added to make sure _dict__ is one value, not a string
class A():
    def __init__(self):
        self.a = [1,2, 3] # list, iteralbe, have __str__

class B(A):
    def test(self):
        pass

c1, c2, c3 = _check_methods(B, *methods)
print(c1, c2, c3)





