
# register_backward_hook和register_forward_hook是差不多的，一个在backward中执行一个在forward中执行，这里只讲解下register_backward_hook函数

"""
该函数的形式是register_backward_hook(hook)，同样参数是一个hook函数，hook函数的形式为：
hook(module, grad_input, grad_output) -> Tensor or None
"""

"""???
register_backward_hook函数同样在module输入的梯度进行计算的时候会执行，注意hook函数中的grad_input和grad_output参数格式不可以改变，
但是在hook函数中可以对grad_input参数进行修改并返回一个新的自定义的grad_input，以便在某些算法中实现不同的功能。注意当输入或者输出为多个时，
rad_input和grad_output也会变成多个，格式为tuples

"""
# Example:
# x = (x1, x2, x3, x4); y = x*w.T (w = [w1, w2, w3, w4]; z = y/4 是标量

import torch
import torch.nn as nn
device = torch.device("cude:0" if torch.cuda.is_available() else "cpu")
class Mymean(nn.Module):
    def forward(self, input):
        out = input/4
        return out

def tensor_hook(grad):
    print("tensor hook")
    print("grad:", grad)
    return grad

class MyNet(nn.Module):
    def __init__(self):
        super(MyNet,self).__init__()
        self.f1 = nn.Linear(4, 1, bias=True)
        self.f2 = Mymean()
        self.weight_init()

    def forward(self, input):
        self.input = input
        output = self.f1(input) # is actually c nn.Moduel.__call__ method.,
        # which call nn.Module.forward() method-which also call forward_hook
        output = self.f2(output) # is actually c nn.Moduel.__call__ method., which call nn.Module.forward() method
        return output

    def weight_init(self):
        self.f1.weight.data.fill_(8.0)# 这里设置Linear的权重为8
        self.f1.bias.data.fill_(2.0) # 这里设置Linear的bias为2

    def my_hook(self, module, grad_input, grad_output):
        print("doing my_hook")
        print("original grad：", grad_input)
        print('origianl outgrad: ', grad_output)
        # grad_input = grad_input[0]*self.input   # 这里把hook函数内对grad_input的操作进行了注释，
        # grad_input = tuple([grad_input])        # 返回的grad_input必须是tuple，所以我们进行了tuple包装。
        # print('now grad:', grad_input)
        return grad_input

if __name__ == '__main__':
    input = torch.tensor([1, 2, 3, 4], dtype=torch.float32, requires_grad=True).to(device)
    net = MyNet()
    net.to(device)
    input.register_hook(tensor_hook)
    net.register_backward_hook(net.my_hook)

    print("1"*50)
    #net.register_forward_hook(net.my_hook)
    # 这两个hook函数一定要result = net(input)执行前执行，因为hook函数是在forward的时候进行绑定的

    result = net(input)
    # -->use nn.Module __call__-->which call forward()-->f1(input): f1__call__-->f1.forward
    print("2"*50)
    print("\nresult = ", result)
    print("3" * 50)
    result.backward()
    print("4" * 50)
    print("input.grad", input.grad)
    print("5" * 50)
    #for param in net.parameters(): or use named_parameters() as below;
    for name, param in net.named_parameters():
        print(("{}:grad->{}".format(name, param.grad)))
    print("6" * 50)
"""RUN:
-----------
result =  tensor([20.5000], grad_fn=<DivBackward0>)
----------------------
doing my_hook
original grad： (tensor([0.2500]), None)
origianl outgrad:  (tensor([1.]),)
-------------------------
tensor hook
grad: tensor([2., 2., 2., 2.])
---------------------------------
input.grad tensor([2., 2., 2., 2.])
--------------------------------------
Parameter containing:
tensor([[8., 8., 8., 8.]], requires_grad=True):grad->tensor([[0.2500, 0.5000, 0.7500, 1.0000]])
Parameter containing:
tensor([2.], requires_grad=True):grad->tensor([0.2500])
"""
"""
好了我们来按顺序根据输出分析一下整个过程。

>1. 结果为result=20.5很容易看出来，(1+2+3+4)*8 + 2/4 = 20.5。
> 然后是MyNet()中的hook函数首先执行，注意输出的original grad是0.25，我们的输入x有4个元素然后输出z为一个标量，
但是输出这个grad是0.25只有一个元素。这个0.25是怎么来的，我们之前的两个运算分别是：

y = w_{1}\times x_{1} + w_{2}\times x_{2} + w_{3}\times x_{3} + w_{4}\times x_{4} + b。
z = y \div 4。

>2. 这个0.25是第二个式子z = y/4中，z对y的梯度。而original outgrad就是z对z的梯度当然是1了。
>3. 接下来是tensor hook，输出的grad: tensor([ 2., 2., 2., 2.], device=’cuda:0′)，这里输出的是z对x的梯度。我们根据前面两个式子很容易得出是[2,2,2,2]。
>4. input.grad: 同理 tensor([ 2., 2., 2., 2.]
>5. 最后打印的是Linear运算单元的权重和其grad，我们发现w(1-4)权重的grad是[ 0.2500, 0.5000, 0.7500, 1.0000]，这个是怎么得来的，
这里是z对w的权重而不是对输入x的，比如w的grad就是 1 拿w1来举例就是 2。
"""

# 2. 修改一下上面程序中 layer sequence:
# #  output = self.f2(input)
#  output = self.f1(output)
"""
y = (x1, x2, x3, x4)/4
z = y*(w1, w2, w3, w4).T + b =(y1+y2+y3+y4)*8 + 2
"""
"""RUN:
result =  tensor([22.], grad_fn=<AddBackward0>)
**************************************************
doing my_hook
original grad： (tensor([1.]), tensor([1.]))
origianl outgrad:  (tensor([1.]),)
tensor hook
grad: tensor([2., 2., 2., 2.])
**************************************************
input.grad tensor([2., 2., 2., 2.])
**************************************************
Parameter containing:
tensor([[8., 8., 8., 8.]], requires_grad=True):grad->tensor([[0.2500, 0.5000, 0.7500, 1.0000]])
Parameter containing:
tensor([2.], requires_grad=True):grad->tensor([1.])

"""
# -->发现original grad: (tensor([ 1.], tensor[ 1.])发生了变化。

# 3. 再修改一下使forward层为：
#  output = self.f2(input)
#  output = self.f1(output)/4
"""
y = (x1, x2, x3, x4)/4
z = (y1+y2+y3+y4)*8 +2 = (y*w +b)/4

"""


"""--> original grad： (tensor([0.2500]), None)"""
"""
发生上面现象的原因其实是pytorch的一个bug，一个问题，在pytorch的issue中有这样一个回答, 我们的hook函数只会绑定在module中最后一个执行函数上，
上面的MyNet在forward函数进行修改后，最后一个执行函数f1或f2发生了变化，所以导致的结果不同：
1. 当：
output = self.f1(input)
 output = self.f2(output)
 时，最后的f2为z = y /4所以为0.25.
 
 2. 之后我们改成：（f1和f2顺序互换）
 output = self.f2(input)
 output = self.f1(output)
 y = (x1, x2, x3, x4)/4
z = y*(w1, w2, w3, w4).T + b =(y1+y2+y3+y4)*8 + 2
最后的f2为一个Linear(4,1)。这个Linear有bias也就是这个公式为z = y1 + y2 + y3 + y4 + b(其中y = wx)。
而hook将上面的式子解析成了z = (y1 + y2 + y3 + y4) + b <==> m + b。
也就是两个式子m和b（m为(y1 + y2 + y3 + y4)集合）所以得到了两个grad ==> z对m和b的，从式子z = m + b 很容易得到 得到。
也就对应着之前说的(tensor([ 1.], tensor([ 1.])。

3. 最后我们又将forward中的执行函数改成：
 output = self.f2(input)
 output = self.f1(output)/4
y = (x1, x2, x3, x4)/4
z = (y1+y2+y3+y4)*8 +2 = (y*w +b)/4
在f1，第二个式子中除以了4,也就是实 z = y1 + y2 + y3 + y4 + b变为z = (y1 + y2 + y3 + y4 + b)/4。这样将(y1 + y2 + y3 + y4 + b)看成n。于是乎，z = n /4。
"""
# 这些是pytorch设计中的一个bug，设计者建议使用tensor的hook而不建议使用module的hook大概是这个原因，但是我们只要多注意一下，知道这些bug就可以不必犯错。


"""************************************************************************"""
# 三、后记
"""
说了这么多，回到之前提到的require_grad参数。在平时设计神经网络的时候并没有特意去设置require_grad这个参数，这是为什么。
因为我们平时进行训练的是神经网络的权重，神经网络的权重才是我们要训练的参数，并不是输入也不是其他东西。在pytorch中，在你设计了一个神经网络层后，这个层中的参数默认是可以进行梯度运算的：
"""

# 这里定义一个自编码器的网络层
import torch.nn.functional as F
import torch.nn as nn
class Autoencoder(nn.Module):
    def __init__(self):
        super(Autoencoder, self).__init__()
        # 实例化nn.Sequential-->self.encoder._parameters.items()
        # class Autoencoder 实例的参数： --
        self.encoder = nn.Sequential(
            nn.Conv1d(3, 128,3),
            nn.Conv1d(128, 256),
            nn.Conv1d(128, 256),
            nn.Flatten(),
            nn.Linear(1024*4*4, 1024),
            nn.Linear(1024, 1024*4, 4),

        )
net = Autoencoder()
# 打印出这个net的encoder部分的参数是否可以requires_grad
for param in net.encoder.parameters():# note
    print(param.requires_grad)

"""
True
True
True
True
True
True
True
True
True
True
True
True
True
True
"""
# 也就是说，设计的net里面的权重参数默认都是可以进行自动梯度求导的，我们平常的loss.backward()中反向求导中的所要更新的值也就是net中的权重参数值。